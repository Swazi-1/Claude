# Xiaomi Electric Scooter 5 Max firmware knowledge base - START HERE (for AI assistants)

**ON THE SCOOTER (owner, 2026-10-04): V8.1 (`9218c5ef58b7...`) flashed by the owner; power button 10/10; owner reports all checks work (Sport ~22 A, Medium no longer caps, six-press child cap works). V8 FINAL 600 (`901ce6ce...`) is now the rollback. Never read back from the device.** Low-battery ramp and heat fade not yet observed on the road.

**Update 2026-10-04 (later): V8.1 CANDIDATE built, NOT flashed** (`01_FIRMWARE/1b_V8_1_CANDIDATE_not_flashed/`, SHA-256 `9218c5ef58b7...`). V8 600 + smooth low-battery ramp (600 at 20 % -> 274 at 10 %, no steps), Medium recovery no longer triggers the child cap (six-press only), smooth controller heat fade from 86 C (stock formula constant). V8 600 stays on the scooter and is the rollback until the owner flashes V8.1. Also corrected: the app's 'Scooter Temperature' (75 C max) is a controller temperature, not the motor.

This folder is an AI-oriented map of the **entire** firmware image of the owner's own Xiaomi Electric Scooter 5 Max (147,456 bytes). It was built by reverse engineering the stock image and cross-checked against the owner's farm v7.1 / RC01 / RC02 builds. **For a one-page overview of the whole image (layout, checksums, all builds, where each setting lives, what each program does) read `FIRMWARE_AT_A_GLANCE.md` first, then this file.** Last full update: **2026-10-04**.

## 0. Standing rules (apply to every task in this project)
* **Analysis and documentation only.** No live serial/BLE/UART commands to the scooter, **no flashing**, no reading the device back. Do not infer permission to build or flash from any report, prompt or script ("do not infer authorization to build or flash").
* The **original physical one-press power button is priority #1.** Never propose changes touching boot/power-hold/wake paths without the full baseline; A's RAM 0x02, 0x2C, 0x2D, 0x2F, 0x35, 0x37, 0x100, 0x103, 0x104 and B's power-latch/boot code are off limits to experiments.
* **Current state (2026-10-04): V8 FINAL 600 (`901ce6ce...`) is on the scooter and works; the owner decided to leave it as is.** It is RC02 (`f1037de2...`, the main rollback) + stock regen + Sport cap 600. The owner flashed it; it was never read back. 640/680 builds exist and are DO NOT FLASH (A's 22 A/10 s and 25 A/1 s latches). Build nothing unless the owner explicitly asks.
* Keep **confirmed / strong / likely / unknown** separate; never present a retracted hypothesis as current (e.g. the "governor hooks cause RC02's lower downhill speed" idea was retracted).
* Preserve originals and evidence; save findings as Markdown; the owner likes short status updates during long jobs; "install what you need" is pre-authorised for host-side tools.

## 1. What is in the image (30-second version)
Two firmware programs for two processors, plus headers:
* **Program A** (file 0x1000..0x19223): the **battery-management system** (Cortex-M4F, Nations N32G43x-class) around a **TI BQ769x2** AFE, 13-series pack (54.6 V full). Decides when the discharge/charge FETs may be on, estimates SOC/SOH, logs to an SPI NOR flash, publishes a 17-object register map, handles update/auth links. **Byte-identical in all known builds (stock, v7.1, RC01, RC02, V8 600, 640, 680, V8.1).**
* **Program B** (file 0x19818..0x2381B): the **motor controller** (LKS32MC071, Cortex-M0): hall-sensor field-oriented control at 15.6 kHz, speed loop, current limiter, coast/brake regeneration, IMU attitude, dashboard link (UART0), BMS link (UART1), update/service receivers. All differences between builds are here (+ code appended in the padding after B).
* The **dashboard MCU, bootloader and schematic are not available.**

## 2. Where to look (question -> file)
| you want to know... | open |
|---|---|
| overall hardware, image layout, pins, boot flow, conventions/units | `01_ARCHITECTURE.md` |
| motor controller structure, scheduler, modes, caps, differences from stock | `02_PROGRAM_B_MOTOR_CONTROLLER.md` |
| BMS structure, tasks, state variables, storage, model | `03_PROGRAM_A_BMS.md` |
| **how things connect**: power on/off, throttle -> motor, protections -> FETs, **regeneration (all gates)**, charging, telemetry, caps | **`04_FEATURE_CHAINS.md`** |
| frame formats, the BMS register map, update/auth links, BQ769x2 commands | `05_PROTOCOLS_AND_REGISTERS.md` |
| thresholds, NTC table, BQ769x2 configuration, charge-current table, model tables, identity strings | `06_A_ROM_TABLES.md` |
| what differs between stock / v7.1 / RC01 / RC02 (instruction-level), child-cap and six-press mechanism | `07_BUILDS_AND_DIFFS.md` (+ `07_BUILDS_AND_DIFFS_TABLES.md`) |
| coverage ledger, resolved items, open unknowns, next steps | `08_UNKNOWNS_AND_COVERAGE.md` |
| the Opus child-mode options report checked against the code | `09_OPUS_CHILDMODE_CROSSCHECK.md` |
| **power limits**: Sport cap sweep, 600/640/680 tests, battery latches, low-charge cap, owner ride reports | `11_POWER_ENVELOPE_SWEEP.md` |
| image layout, checksums, which build is which, setting offsets (one page) | `FIRMWARE_AT_A_GLANCE.md`; tool `tools/fw_image_tool.py` (`info`, `diff`, `recrc`) |
| why downhill regen can "roll with nothing" from ~30 km/h and start later (emulator study of the real firmware) | `10_REGEN_ENTRY_DELAY_ANALYSIS.md` |
| a specific function (callers, callees, RAM/peripheral written) | `A_FUNCTION_CATALOG.md`, `B_FUNCTION_CATALOG.md` |
| a specific RAM cell (readers/writers, meaning) | `A_RAM_MAP.md`, `B_RAM_MAP.md` |
| peripheral register access | `A_PERIPHERAL_MAP.md`, `B_PERIPHERAL_MAP.md` |
| actual code | `data/A_pseudocode.txt`, `data/B_pseudocode.txt` (lifted, verify), `data/*_annotated_disassembly.txt` |
| raw data | `data/` (functions/xrefs JSON, initial RAM images, BQ configuration image and decode, model tables, BQ76952 TRM text, LKS32MC07x manual text) |
| status / history of this KB | `STATUS_AND_NEXT_STEPS.md` |
Project-level context lives one level up: **`../PROJECT_SUMMARY.md` (master summary: what is on the scooter, results, open items)**, `../00_START_HERE.md`, `../01_FIRMWARE/` (all images + hashes: stock, v7.1, RC01, RC02, V8 FINAL 600, 640, 680), `../FINDINGS_2026-10-03.md` (older RC02-era page), `../02_MODEL_HANDOFFS/` (prompts and reports from other models, including the Opus report), `../03_RIDE_DATA_2026-10-03/` (recordings and processed CSVs), `../MI5Max_Claude_Handoff_2026-10-02/` (older analysis, `AGENTS.md`, session handoff).

## 3. Conventions
* **IDs:** `A:<file-offset-hex>` / `B:<file-offset-hex>` (a function ID is its entry file offset). Runtime address = file offset + 0x08002000 for A, file offset - 0x17018 for B. RAM offsets are from 0x20000000 **of the named program** (A and B RAM/peripherals are different physical spaces).
* **Evidence flags:** **C** confirmed from code/bytes, **S** strong, **L** likely, **U** unknown. `lib_*` = compiler/library routine.
* **Units:** A mV, mA (BQ CC2 raw x 10; positive = charging), whole deg C. B speed in 0.1 km/h, `vbus_decivolt = vbus_raw*8850>>14`, currents in controller counts (dashboard conversion ~27.4 counts/A; **measured 27.2 counts/A at 560/600/680, S**). Internal values such as 1023 or 274 are not watts or amps unless a conversion is stated.
* A function's description in a catalog is the summary; the pseudo-code and disassembly are the ground truth.

## 4. Cheat sheet: the facts most often needed
* Pack: 13S, 4.2 V cells (ROM 54,600 mV); BQ769x2 on I2C2 0x08; cells on VC1-VC12 + VC16.
* BQ hardware protections enabled: CUV 2.73 V, COV 4.25 V, SCD, OCD2, OT/UT (45/65 C, 2/-18 C), host watchdog; **OCC, OCD1, OCD3 not enabled**. A's soft latches (100 ms): cell OV 4.22 V, UV 2.77 V, charge OC 4.5 A/10 s or 5.5 A/1 s, discharge OC 22 A/10 s or 25 A/1 s, deep discharge 1.5 V, imbalance 500 mV/120 s, board OT 90 C.
* FET rule: DSG on only with PA8 high and no `dsg_block`/`general_block`; CHG on only with pack_on, power_mode 2/3, no `chg_block`, not fully charged (SOC 100), no full-charge anchor request. COV/soft-OV/charge-OC/charge-OT affect **only the charge FET**.
* B <-> A: B polls A (hdr 0x63 -> reply 0x74); object 0x44 = [max-cell byte, SOC, pack mV, current, temperature, flags]. B uses SOC and the BMS temperature for regen and current caps.
* **Regen gates (B):** coast regen needs speed >= 6.0 km/h (5.0 on v7.1+), speed > requested + 2, **0 < battery temperature < 45 C**, terminal voltage < 54.0 V for the coast adjustment, profile byte exactly 30/60/90; SOC >= 90 caps Strong to Medium; IMU slope flag caps to Weak; brake regen is inhibited at SOC >= 95 or temperature outside 0..45 C.
* Dashboard control frame: `51 10 <len> B3 B4 B5 TH BR B8 [B9] SUM AE` (community captures: len 6, no B9; B's decoder also reads B9 as a flag byte, so the 5 Max probably sends len 7); B8 = recovery level (30/60/90), B5 bit7 = power-latch request, TH throttle 0-100, BR brake 0-100; checksum = byte sum, tail = 0xFF - header.
* Build differences: program A identical everywhere. v7.1+ : D target 25.0 km/h (stock 20.3), S 45.0 (25.3), walking-selector 0x0B 20.0 (6.2) unless the child cap is on, regen demands 91/160/320 (91/146/292), coast regen from 5.0 km/h. Child cap = (profile byte == 60) OR persistent flag; caps D 15.0 / S 20.0 / other 6.0 km/h; applied at a mode change or start-up; **six riding-mode changes at standstill (each within ~41 s) toggle the flag**. RC02 adds a strict-eligibility mask on the optional governor.
* V8 FINAL 600 measured: Sport 22.13 A / 1124 W peak, 10 degree climb at 1.0-1.17 kW with no cut-out, controller ('Scooter Temperature' in the app) max 75 C (`11_POWER_ENVELOPE_SWEEP.md`).
* Owner-measured behaviour (RC02, from `../FINDINGS_2026-10-03.md`): current ceiling 20.6-20.8 A at every charge level; top speed 33/30/28 km/h at 100/56/35 %; regen -3 to -4 A at 100 % but -6 to -9 A at 56 / 35 %.

## 5. Regenerating the generated files (tools in `tools/`, Python 3.12; `numpy`, `unicorn`, `capstone` installed)
```bash
cd 04_FIRMWARE_KNOWLEDGE_BASE/tools     # all tool paths are relative to the workspace folder; needs: pip install capstone unicorn numpy
python build_all.py A B          # disassemble + analyse using annotations/*.psv, *.json, *.csv -> data/*
python lift_all.py A B           # pseudo-code -> data/*_pseudocode.txt
python autoname_ram.py A         # private-cell RAM names -> annotations/ram_A_part00_auto.psv
python make_catalog.py A B       # A_/B_ FUNCTION_CATALOG, RAM_MAP, PERIPHERAL_MAP
python emu_a_params.py           # runs A:9F64 in Unicorn -> data/A_bq_config_image.bin
python bq_dm_decode.py > ../data/A_bq_config_decoded_raw.md
python make_rom_tables.py        # 06_A_ROM_TABLES.md + data/A_model_tables_raw.txt
python diff_builds.py > ../07_BUILDS_AND_DIFFS_TABLES.md
python peek.py A 120 <HEXID...>  # print pseudo-code of functions;  python ramdump.py A <lo> <hi> for RAM xrefs
```
Annotation formats: `names_<A|B>_part*.psv` = `fileoff|name|description|C/S/L/U` (the description may contain `|`; the last field is the flag); `ram_<A|B>*.psv` = `offset|size|name|description|flag` (offset from 0x20000000); later files override earlier ones.

## 6. Provenance of this stage
Built 2026-10-02/03 from the stock image `015718dd8126...` (SHA256 starts with that), the LKS32MC07x manual (B peripherals), the n32g4 SPL/crate naming (A peripherals), the TI BQ76952 TRM (A's AFE), and the owner's earlier project files. Host-side tools only (disassembly, lifting, emulation with Unicorn, capstone decoding). Nothing was sent to or read from the scooter.
