# Xiaomi Electric Scooter 5 Max: everything we found (as of 2026-10-04)

**ON THE SCOOTER (owner, 2026-10-04): V8.1 (`9218c5ef58b7...`) flashed by the owner; power button 10/10; owner reports all checks work (Sport ~22 A, Medium no longer caps, six-press child cap works). V8 FINAL 600 (`901ce6ce...`) is now the rollback. Never read back from the device.** Low-battery ramp and heat fade not yet observed on the road.

**Status 2026-10-04: V8 FINAL 600 is on the scooter and works. V8.1 CANDIDATE built on the owner's request, not flashed yet.**

This is the owner's own scooter. Claude did read-only firmware analysis and built firmware files offline. **The owner did all the flashing.** Evidence labels: **C** confirmed (bytes, code, or measured), **S** strong evidence, **L** likely, **U** unknown.

## 1. What is on the scooter now
**V8 FINAL 600**: `01_FIRMWARE/1_CURRENT_ON_SCOOTER_V8_FINAL_600/MI5Max_V8_FINAL_600.bin`, SHA-256 `901ce6ce...df9`. This rests on the owner's statement; the file was never read back from the scooter.
* It is RC02 plus two byte changes and the checksums:
  * regen back to stock 91/146/292 (file 0x20020);
  * Sport current cap 150x4 = 600 (file 0x1E02C).
* Everything else is byte-identical to RC02, including the battery processor and the power-button/boot path.
* Tested by the owner on 2026-10-03 (same bytes):
  * power button 10/10 before and after;
  * **22.13 A / 1124 W peak**, sustained mostly 21.4-21.8 A;
  * no cut-out;
  * battery 16 -> 17 C, scooter 36-37 C, app 'Scooter Temperature' 36-37 C (controller; the owner's 'motor ~40 C' was a guess, the app shows no motor temperature).
* **Second report, 2026-10-04 (day after):** works perfectly. About 100 m of climbing over 2.2 km, 'Scooter Temperature' maximum 75 C (controller, not motor; see section 9). Final hill about 10 degrees, Sport, about 20 km/h: **1000-1170 W for the whole climb** (about 90 % of it above 1000 W), no cut-out. That is the 600 cap (22.1 A) at 45-53 V (S). Details: `04_FIRMWARE_KNOWLEDGE_BASE/11_POWER_ENVELOPE_SWEEP.md`.
* Release notes: `01_FIRMWARE/1_CURRENT_ON_SCOOTER_V8_FINAL_600/README_V8_FINAL_600.md`.

**Behaviour vs stock:**
| Setting | Stock | V8 final |
|---|---|---|
| D target / cap | 20.3 km/h / 328 | 25.0 km/h / 400 |
| S target / cap | 25.3 km/h / 493 | 45.0 km/h / 600 |
| Walking | 6.2 km/h | 20 km/h (6 km/h with child cap) |
| Coast regen from | 6.0 km/h | 5.0 km/h |
| Regen strength | stock | stock |

Also new in V8 final:
* child cap: D 15 / S 20 / other 6 km/h, on when recovery = Medium **or** six mode changes at standstill (toggle, saved);
* region-free;
* RC02 governor mask;
* small v7.1 tweaks: low-speed brake 90, thermal derate 1020, direction thresholds 0.

## 2. The hardware (C unless marked)
* **Battery:** T2356-BD4A by De.power, 2024-11; 46.8 V nominal, 54.6 V full, 10.2 Ah, 477 Wh, NMC.
  * Cells: **13S4P** (label code 13INR19/66-4), 18650-size, about 2.55 Ah each (S).
  * The BMS uses a TI BQ769x2 chip; BMS firmware 0108 (from the app).
* **Motor:** Xiaomi rates it 400 W, 1000 W max. The motor cable reads as 16 AWG phase plus 24 AWG hall wires (L, from photo).
* **Firmware image:** 147,456 bytes holding two programs:
  * **A** = battery processor (N32G43x-class + BQ769x2); byte-identical in every build;
  * **B** = motor controller (LKS32MC071, FOC at 15.6 kHz).
  * A and B talk over UART at 19200 baud (17 register objects; SOC, voltage, current and temperature reach B).
* Photos: `05_HARDWARE_PHOTOS/`.

## 3. Power limits: the key result
* The Sport "cap" setting limits battery current. Amps are about setting / 27.2 (**C** in code; **S** scale: matched within ~1 % at 560, 600 and 680).

| Setting | Model | Measured |
|---|---|---|
| 493 (stock) | 18.1 A | |
| 560 (RC02) | 20.6 A | 20.6-20.8 A |
| 600 (final) | 22.1 A | 22.13 A |
| 640 | 23.5 A | |
| 680 | 25.0 A | 25.35 A, then cut-out |

* **The real ceiling is the battery processor's own software limits** (A:FF3C, **C**). Both open the battery output, and then the whole scooter is off:
  * **25 A for 1 s**;
  * **22 A for 10 s without a break**.
  * The counter resets on any 100 ms sample below the level.
  * The latch releases about 10 s after tripping, once current stops. After 3 trips, release needs an extra load/wake condition (L).
* The 680 test hit the 25 A limit uphill (25.35 A). The scooter cut off, came back after 30 s, and the dashboard showed error 10. Error 10 = controller lost dashboard frames, a side effect of the power cut (code meaning **C**, display mapping **L**).
* So **600 is the practical maximum.** 640 trips on a sustained climb, and 680 trips within about 1 s. Both are marked DO NOT FLASH.
* Other limits:
  * hardware BQ trip at 30 mV across the shunt (resistance U);
  * fuse about 40 A (unsourced);
  * controller phase-current limit 1461 counts;
  * without any cap the model peaks at about 41 A.
* Low-charge cap (unchanged): full power above 20 %, ramping down to about half power at 10 % or below.
* Temperature caps (unchanged): battery below 2 C or above 50 C; controller above 1020 counts.
* Top speed is set by battery voltage, not by the cap: about 33 km/h flat at full charge, 29-30 at 56 %, 28 at 35 %.

## 4. Regen
* Gates (C):
  * battery 0 < T < 45 C;
  * recovery value exactly 30/60/90;
  * SOC >= 90 caps Strong to Medium;
  * coast regen off above 54.0 V (that is why regen is weak at full charge);
  * SOC >= 95 blocks brake regen;
  * the IMU slope clamp limits regen to Weak.
* Downhill "rolls from about 30 km/h, regen only from about 22 km/h": the firmware has no speed dead zone; in the emulator nominal regen starts within 0.1 s.
  * The best fit is the **IMU slope clamp** (sets after about 4 s of slope, clears after about 5 s flat; time-based) (S).
  * The alternative is coast demand switched off (temperature or recovery value).
  * Not yet diagnosed on the road: record the app current while it rolls. About -2 to -3 A means the clamp; 0.0x A means demand off.
  * Doc: `04_FIRMWARE_KNOWLEDGE_BASE/10_REGEN_ENTRY_DELAY_ANALYSIS.md`.
* V8 final uses the stock regen strength (owner decision); the higher RC02 strength was not the cause of the delay.

## 5. Power button, child mode, other
* Power-button and boot path are untouched in every build (C, bytes). The button was 10/10 on the owner's tests before and after the 600 flash.
* Child mode:
  * single press = lights; double press = mode;
  * 6 mode changes at standstill toggle the child cap (saved);
  * Medium recovery (60) also activates the cap at the next mode change.
* Region-free bytes came from the v6 build. They did not unlock app features, so the lock is probably in the app or on the server (L).

## 6. Corrections made along the way
* "BMS trips near 30 A" was wrong as a practical limit: A's 22 A / 25 A software latches trip first.
* The battery is 13S4P, not 13S3P.
* 680 is 25.0 A, not 25.8 A.
* The earlier "brake bound −1096 → −1644 regen fix" note was not reproduced.
* The knee at 100 % is about 25.5 km/h, not 20-22.
* The governor-hook downhill hypothesis was retracted.

## 7. Still open
* Regen at normal charge (75/56/35 %) on V8 final, and the downhill delay diagnosis (app current while rolling).
* A much longer steep full-throttle climb on 600: one sustained 10 degree climb at about 1.1 kW passed with no cut-out (2026-10-04), but its duration and the app amps were not recorded. Watch whether 'Scooter Temperature' (controller) approaches 86 C on long hot climbs (V8.1 fade start).
* Riding at low charge (< 20 %) and on a hot day.
* Unknown: dashboard firmware and bootloader, BMS shunt value, fuse rating, exact cell model, IMU sign convention, motor temperature (no sensor: the motor cable has only 3 phase + 5 hall/power wires).
* Not built (owner decided to leave the firmware as is): smooth low-charge ramp (recipe in `11_POWER_ENVELOPE_SWEEP.md`); regen-delay fix; child-mode changes.

## 8. Where everything is
| Path | Contents |
|---|---|
| `01_FIRMWARE/` | `1_CURRENT_ON_SCOOTER_V8_FINAL_600`, `2_ORIGINAL_STOCK`, `3_OLDER/` (v7.1, RC01, RC02, 600/640/680 candidates), README + SHA256SUMS |
| `03_RIDE_DATA_2026-10-03/` | RC02 rides (all charge levels); `V8_tests_2026-10-03_04/` = 600 screen recording + OCR CSV, 680 cut-out screenshot |
| `MI5Max_AI_BUNDLE_2026-10-04.zip` | **Ready-to-send package for another AI** (docs, all firmware images, KB, tools, photos, processed ride data; not the big work folder). `BUNDLE_README.md` inside lists contents |
| `04_FIRMWARE_KNOWLEDGE_BASE/` | Full firmware map for AI/humans: start `FIRMWARE_AT_A_GLANCE.md` (one page), then `00_README_FOR_AI.md`; `tools/fw_image_tool.py` shows layout/checksums/settings of any image. Key docs: 04 feature chains, 06 ROM tables (BMS limits), 07 builds/diffs, 10 regen delay, 11 power sweep + tests |
| `05_HARDWARE_PHOTOS/` | Deck/battery/controller photo, battery label |
| `02_MODEL_HANDOFFS/` | Prompts sent to and reports from other models (Opus, Sol) |
| `MI5Max_Claude_Handoff_2026-10-02/` | Project work: scripts, emulator/simulator, evidence, older reports (name kept, scripts use it) |
| `99_ARCHIVE_SNAPSHOTS/` | Cleanup log 2026-10-04 (duplicates and regenerable files removed), removed-zip manifests, salvaged files, old start page/prompt |
| `FINDINGS_2026-10-03.md` | Earlier one-page findings (RC02 era; superseded by this file) |

## 9. V8.1 candidate and corrections (2026-10-04, later)
**V8.1 CANDIDATE** (`01_FIRMWARE/1b_V8_1_CANDIDATE_not_flashed/MI5Max_V8_1_CANDIDATE.bin`, SHA-256 `9218c5ef58b78d39a172d6a85d5c046d5ff85e4bfaa3e644f1e04c20b4e2f63b`). Built from V8 600 on the owner's request; **not flashed, not hardware tested**. 9 behaviour bytes + 6 checksum bytes; program A and the power/boot path byte-identical (C).
| change | offset | V8 600 -> V8.1 | effect (emulator, C) |
|---|---|---|---|
| low-battery ramp base | 0x1FD96..99 | `FF20EE30` (493) -> `96208000` (600) | no step at 20 % |
| low-battery ramp slope | 0x1FD92 | 0x16 (22/%) -> 0x21 (33/%) | 22.1 A at 20 % -> 20.8 A at 19 % -> 16.0 A at 15 % -> 11.1 A at 11 % -> 10.1 A floor at 10 %; no step at 10 % |
| Medium -> child trigger removed | 0x23824 | `05D0` (beq) -> `00BF` (nop) | profile 60 no longer caps; six-press flag still caps D 15 / S 20 / other 6 |
| heat fade start | 0x1FC90 | 0xFF (1020) -> 0xD8 (864) | full power to 86.4 C |
| heat fade constant | 0x1FEB8 | 3620 -> 3193 (stock) | fade 3193 - 3T: 18.1 A at 90 C, 7.1 A at 100 C, 0 at 106.4 C; no sudden cut |
Unchanged: Sport 600, D 25.0 km/h / 400, walking/eco 20 km/h / 210, regen 91/146/292, coast from 5.0 km/h. D cap left at 400 because 400 vs 328 changes flat-ground range by ~0.3 % (model: 25 km/h ~204 W, 8.2 Wh/km for 81 kg + scooter; speed is the range lever). Release notes and tests: the folder's `README_V8_1_CANDIDATE.md`.

**Corrections:**
* **Heat formula (C):** farm v7.1 changed not only the derate threshold (900 -> 1020) but also the formula constant at 0x1FEB8 (3193 -> 3620; the KB had missed it). So V8 600 fades from 102 C (22.1 A) to ~11.8 A at 110 C and then cuts to ~0.1 A at >= 110 C. Stock fades from 90 C to 0 at 106.4 C.
* **"Motor temperature 75 C" was wrong:** the owner read it on the app's scooter information page, field **"Scooter Temperature"**; the app shows no motor temperature. The controller sends exactly two temperatures in its status frame (byte 6 = `temp_local`/10, the derate sensor; byte 7 = `temp_ntc_a`), both controller-side (C). The motor cable has 3 phase + 5 thin wires (3 hall + supply + ground), no thermistor wire, so the motor temperature is not measured at all (S, from the photo). Which of the two the app shows is U (byte 6 likely). Xiaomi publishes no definition.
