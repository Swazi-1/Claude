# Speed-limit ("child") mode on my Xiaomi Electric Scooter 5 Max — what is known

Labels: **[C]** confirmed (read from the scooter's software and run on a computer simulation of it), **[S]** strong evidence, **[L]** likely, **[U]** unknown. I (the owner) worked these facts out earlier from the scooter's motor-controller software; you do **not** need to look at any software for this task, and no software files are attached. The dashboard's own software is not available to anyone here, so everything about what the dashboard does is **[U]**.

## 1. What I do today (owner report; matches the software)
- Dashboard button: one press = lights on/off; double press = change riding mode; hold 2–3 s = power off (official manual).
- **Six double-presses while the scooter is standing completely still switch speed-limit mode on. Six more switch it off.** It stays on after the scooter is powered off. In the top mode it limits speed to about 20 km/h; caps are about 6 / 15 / 20 km/h for the first / second / third mode. [C]
- The counter only counts mode changes while the wheel is not turning, so it cannot be done while riding. Ordinary mode changes still work at any speed. [C]
- The motor controller never sees button presses; the dashboard works those out and sends the result. [S]

## 2. A second way the software seems to switch the caps on [L]
- The software also applies the same caps when one byte that the dashboard sends to the controller equals 60. That same byte is the **energy-recovery (regenerative braking) level**: 30 / 60 / 90 appear to mean Low / Medium / Strong. I normally use Strong (90), so I have never seen this.
- On the computer simulation: with the byte at 60 the caps apply (about 6.0 / 15.0 / 20.0 km/h by mode); at 30 or 90 they do not; in the original stock software nothing changes. Changing the byte on its own does not apply the cap: it takes effect at the **next riding-mode change** (or at power-on). [C for the simulation, not tested on the scooter]
- **Unknown:** what values the app or dashboard really sends for Low / Medium / Strong; whether the dashboard changes or blocks that byte; whether this link is intended or an accident of how the software was built.

## 3. If the cap switches on while riding (computer simulation of the real controller code with a model of motor, battery and rider) [S]
- Flat road, full throttle at about 29–31 km/h, cap switched on: the controller keeps driving for roughly 2–3 seconds while its internal speed target ramps down (about 5 km/h per second), then **stops driving and coasts**. It does **not** brake hard: the speed falls by at most about 1 km/h per second (drag only), with at most about 4–5 A of gentle regenerative current. It reaches about 20 km/h in roughly 10–14 seconds (at full charge it then holds about 20).
- At 56% charge the model shows an unexplained further slow-down below the cap; treat the settling behaviour as unreliable. The first ten seconds are the reliable part.
- Limits of the model: assumed motor and rider values; not checked against a real ride; dashboard behaviour unknown.

## 4. Public information found so far
- Official 5 Max pages: modes walking ~6, standard 20, sport 25 km/h (global; some countries differ, e.g. an Egypt page lists 6/15/20). [Ride FAQ](https://www.mi.com/global/support/faq/details/KA-509197/); [malfunction FAQ](https://www.mi.com/global/support/faq/details/KA-509209/); [user guide PDF](https://cdn.azams0.fds.api.mi-img.com/xiaomi-b2c-i18n-upload/User-Guide-Upload-mi.com/Personal_Care/60559-Xiaomi-Electric-Scooter5-Max-UserGuide-GL.pdf); button steps transcribed at [Manualslib](https://www.manualslib.fr/manual/995066/Xiaomi-Electric-Scooter-5-Max.html?page=7).
- A shallow search found **no official child/kids mode and no app setting for it on the 5 Max**. Other Xiaomi children's models have speed limiting in their app.
- Community notes describe the dashboard-to-controller serial dialect (frames starting with 0x51, replies 0x61): [bastelpichi notes](https://wiki.bastelpichi.de/uart). Reliability: community, not official.

## 5. Constraints
- My original physical one-press power button must keep working; anything that could affect power on/off, wake or the lights must be flagged first.
- No commands to the scooter, no flashing, nothing that produces a file to flash. This task is analysis, research and a test plan.
- The caps must never make the scooter slow or brake abruptly.
