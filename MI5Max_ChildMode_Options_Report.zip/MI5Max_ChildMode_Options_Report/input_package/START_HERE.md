# START HERE
Read `PROMPT_FOR_OPUS_5_5.md` (the task) and `briefing/CHILD_MODE_SUMMARY.md` (everything known). There are no software files in this package: the task is research, reasoning and a test plan.
