# Prompt for Claude Opus 5.5 — the simplest dependable way to switch on my scooter's speed-limit mode

Attached: `MI5Max_ChildMode_Options_2026-10-03.zip`. Please read `START_HERE.md` and `briefing/CHILD_MODE_SUMMARY.md`. There are no software or firmware files in the package: all the technical facts are written up in the summary, and this task is research, reasoning and a test plan.

## What this is
This is my own Xiaomi Electric Scooter 5 Max. It has a speed-limit mode (I call it child mode) that I currently switch on by double-pressing the dashboard button six times while standing still. I would like a simpler or faster way to switch it on, ideally one that works without stopping, so I can hold the scooter to a low speed when someone else rides it.

## Rules
- Research, reasoning and planning only. Do not send anything to the scooter, do not flash anything, and do not produce any file that could be flashed or any code for the scooter.
- The original physical one-press power button must keep working. If any option could touch power on/off, wake or lights, flag it first.
- The caps must never make the scooter slow or brake abruptly.
- Label every statement **confirmed**, **strong evidence**, **likely** or **unknown**. Never present a guess as a fact. Cite every source with its link and say how reliable it is (official vs community).
- Do not wait for me during the run. At the end tell me what you could not finish.

## Tasks
1. **Check my reasoning.** Read the summary critically. List anything that does not follow from the facts, anything I am over-claiming, and the facts that matter most but are still unknown.
2. **Public research.** Find what is documented about speed limiting, child, kids or lock features on the Xiaomi Electric Scooter 5 Max and its close siblings (4 Pro, Pro 2, 4 Ultra and similar): in the app, on the dashboard, and in community protocol notes. In particular, find out what the app and dashboard send for the three energy-recovery levels (Low / Medium / Strong) on these scooters (for example whether they are 0/1/2 or 30/60/90), and whether the dashboard filters them.
3. **List the realistic ways to get a quicker switch, ranked.** Include at least: (a) setting Medium energy recovery in the app and then changing riding mode once; (b) the existing six double-presses at a standstill; (c) using the built-in walking mode as a manual limit; (d) any app or settings route you find; (e) anything that would need the dashboard side. For each: what would have to be true, what evidence is missing, what could go wrong, how reversible it is, and whether it touches the power-button path.
4. **Safety of switching the cap on while moving.** Using the simulation results in section 3 of the summary and your own reasoning, say whether switching it on while riding is acceptable, what the rider would feel, and what conditions (speed, slope, charge level) matter. Say how far the simulation can be trusted.
5. **A test plan I can follow myself.** Design a short, safe sequence of checks I can do with only the scooter and its app, starting at a standstill and only lowering speed: what to set, what to press, what speeds and readings to expect for each outcome, and what each outcome would mean. Include how to switch it off again.
6. **Recommendation.** Name the single simplest approach most likely to work and safest, and say clearly what you could not determine.

## Deliverables
`CHILD_MODE_OPTIONS_REPORT.md` with a short summary at the top (what you now know, what you do not, what to do next), then one section per task, with evidence labels and cited sources.
