# MI5Max child-mode options: report bundle (2026-10-03)

- `CHILD_MODE_OPTIONS_REPORT.md`: the report (summary, Tasks 1–6, test plan, recommendation).
- `sources/`: plain-text copies of every web page cited, with the URL and whether it is official (Xiaomi) or community. Kept so the quotes can be checked even if the pages change.
- `SHA256SUMS.txt`: hashes of every file in this bundle.

No firmware, no scooter code, nothing flashable is included.
