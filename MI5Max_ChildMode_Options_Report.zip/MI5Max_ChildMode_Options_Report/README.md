# MI5Max child-mode options: report bundle (2026-10-03)

- `CHILD_MODE_OPTIONS_REPORT.md`: the report (summary, Tasks 1–6, test plan, recommendation).
- `sources/`: plain-text copies of every web page cited, with the URL and whether it is official (Xiaomi) or community. Kept so the quotes can be checked even if the pages change.
- `input_package/`: the briefing you supplied (unchanged).
- `SHA256SUMS.txt`: hashes of every file in this bundle, plus the input ZIP.

Not included on purpose: no firmware or `.bin` file, no scooter code, nothing flashable. The separately attached `04_V8_RC02_SPORT35_REVIEW_ONLY_NOT_FLASH_READY.bin` was not analysed and is not in this bundle.
