# Hardware photos (owner, deck opened in December (owner); added 2026-10-04)
* `deck_open_battery_and_controller.jpg`: battery pack (blue) in the deck, connector end, controller box (black) behind it, motor cable printed "16AWG x3C + 24AWG x5C" (as read; L).
* `battery_label_T2356-BD4A_13S4P.jpg`: pack label. T2356-BD4A, De.power Technology, 46.8 V nominal / 54.6 V charge, 10.2 Ah, 477.36 Wh, 2.77 kg, IPX6, cells 13INR19/66-4 (= 13 series x 4 parallel, 18650-size), NMC, made 2024-11, serial TB0G14BJ0102239S57 (matches the app).
