# Downhill regen that "rolls with nothing" from ~30 km/h and starts around ~22 km/h

Date: 2026-10-03. Analysis only: the real motor-controller firmware ran in a host-side emulator inside the project's plant model; nothing was sent to the scooter and no file was built. Labels: **C** confirmed from code/emulation, **S** strong, **L** likely, **U** unknown.

**Owner report (not a measurement):** at every charge level where regen works, coming down the hill at about 30 km/h and releasing the throttle gives no regen (it just rolls); regen starts when speed has dropped to about 22 km/h. Also seen on the earlier (v7.1, higher regen strength) builds.

## 1. Result in one paragraph
**The firmware has no speed window between 30 and 22 km/h in which regen is blocked.** With nominal inputs the real code starts regen about 0.05-0.1 s after the throttle is released and reaches full coast demand in about 0.3 s at every charge level from 35 % to 90 % (table below); the build with higher regen strength is no slower (0.31 s vs 0.29 s). So the delay you feel must come from an **input or state that differs from nominal**. Two such mechanisms are confirmed in the code and produce your symptom without depending on charge: the **IMU slope clamp** (regen forced to the Weak level for several seconds, time-based) and **coast demand switched off** (battery-temperature window or a recovery value other than exactly 30/60/90 - the controller then drops into free-wheel and cannot restart by itself). The first fits "rolls, then regen later" best; which one it is can be told apart with the app's current reading (section 5).

## 2. What happens after throttle release (code path, C)
1. `throttle_mode_block` (every 5.12 ms) sets `requested_speed = 0` (throttle 0..5). `speed_loop` then selects the **coast branch** because speed >= request.
2. `coast_regen_demand` (B:1BDD0) runs when speed > 6.0 km/h: it needs speed - 2.0 km/h > request (true), **0 < battery temperature < 45 C**, and picks the target from the recovery level: Weak 91 / Medium 160 / Strong 320 counts (stock 91 / 146 / 292). Demand `B4` slews up **5 counts per call (5.12 ms)**: full Strong in 64 calls = **0.33 s** (stock 59 calls = 0.30 s).
3. The coast adjustment `BA = (speed - request)/8`, clamped 0..10, is only applied below 54.0 V terminal voltage. While `i_q > -B4` the drive command DA falls by BA per call (up to 10 per 5.12 ms), so DA drops from full scale to the regen level in roughly 0.1-0.2 s. The command then holds `i_q` near `-B4`.
4. The end of the speed loop keeps the motor drive latch (RUN) on while the request is non-zero, or coast demand is non-zero above 6 km/h, or |dc current| > 27 counts, or |i_q| > 18 counts. If none of these hold the latch drops and the PWM outputs go **off** (free-wheel).
5. ISR: `vq_like` follows the command at +/-1 count per PWM period (15.6 kHz), so the command change reaches the motor in about 20 ms.
No step in this chain contains a speed near 22 km/h (the nearest constants are 6.0, 8.0 and 26.0 km/h, none of them regen thresholds; the 26 km/h value only limits cruise engagement).

## 3. Emulator results (S: real firmware, assumed plant)
Set-up: S mode, throttle pinned from 8 km/h on a -4 degree hill, release at 30.0 km/h; plant model of `work/sim_closed_loop_v71_vs_rc02_2026_10_03.py` (motor R, back-EMF, battery OCV + resistance, mass 105 kg); the voltage monitor runs, so the 54.0 V gate input follows the bus; controller reads 0.3 V below the plant voltage (earlier estimate of the app/controller offset); q scale 27.2 counts/A (the value that matched the flat rides). Files: `outputs/RC02_RIDE_OBSERVATIONS/regen_entry_sim_2026-10-03/` (CSV traces + `summary_cases.json`); script `work/sim_regen_entry_2026_10_03.py`. Flat-ground validation reproduced the earlier published numbers exactly (100 %: 20.6 A, 1046 W, knee 24.3, top 33.1 km/h; 56 %: 946 W / 20.9 / 29.8; 35 %: 915 W / 19.9 / 28.9).

| case (v7.1 firmware unless noted) | first negative current after release | coast demand full | mean DC current 2-8 s after | speed 8 s later (from 30.0) |
|---|---|---|---|---|
| nominal 35 % | 0.05 s | 0.31 s | -7.1 A | 27.4 |
| nominal 56 % | 0.06 s | 0.31 s | -6.9 A | 27.4 |
| nominal 75 % | 0.08 s | 0.31 s | -6.6 A | 27.4 |
| nominal 75 %, **stock** targets 91/146/292 | 0.08 s | 0.29 s | -6.4 A | 28.5 |
| nominal 90 % (SOC >= 90: Strong capped to Medium) | 0.10 s | 0.15 s | -4.2 A | 33.5 |
| nominal 95 % (54.0 V gate closed 55 % of the time) | 0.10 s | 0.15 s | -4.2 A | 33.5 |
| nominal 100 % (gate closed 98 %) | 0.10 s | 0.15 s | -1.4 A | 38.0 |
| **slope flag set** (RAM 0x374 = 1, Weak cap), 75 % | 0.08 s | 0.09 s | **-2.9 A** | **36.1 (keeps speeding up)** |
| **battery temperature outside 0..45 C**, 75 % | never | never | **0.0 A, RUN latch off** | 39.8 (keeps speeding up) |
| **recovery value not 30/60/90**, 75 % | never | never | **0.0 A, RUN latch off** | 39.8 |
Reading: at charge levels where regen works, the nominal code brakes at once and holds speed; it does **not** roll for seconds. The two abnormal-input rows are the ones that look like "nothing happens". (The 90-100 % rows show the separate full-charge behaviour: SOC cap plus the 54.0 V gate, as in the earlier analysis.) Higher regen strength changes neither the onset time nor the build time noticeably: demand slews at a fixed 5 counts per call, so 292 -> 320 adds 0.02 s.

## 4. The two mechanisms in detail
**A. IMU slope clamp -> Weak regen for seconds (confirmed code, signature matches the report).** `remote_flag374_filter` (B:1AF94, every 10.24 ms) works only if the dashboard control frame has its flag bit set (byte 9 bit 7 = `decel_detect_enable`). When the filtered incline value `incline_dd = int(-10 * roll_deg)` is below -20 (i.e. roll above +2.0 degrees) it counts up; after **400 calls (about 4.1 s)** it sets `remote_status_flag` (RAM 0x374), which caps the recovery level at Weak (91 counts, 28 % of Strong's 320). It clears only after **500 calls (about 5.1 s)** with the incline above -10 (-1.0 degree), i.e. once the slope has been nearly flat for five seconds. In the emulator Weak regen is about -2.9 A (DC) instead of -6.6 A, and the scooter keeps accelerating on a -4 degree hill, which feels like "nothing". Two possible patterns depending on the (unresolved) sign convention of the estimator:
 * if **descents** read < -2 degrees: regen is strong for the first ~4 s of a descent, then clamped to Weak until the slope has flattened for ~5 s (regen "returns" near the bottom, when speed has fallen);
 * if **climbs** read < -2 degrees: after a climb of more than 4 s the clamp is still set when you crest the hill and start down, and it releases about **5 s** after the slope turns flat or downhill - a fixed delay after the crest, not a speed.
In both cases the delay is **time-based, not speed-based**; the apparent "22 km/h" would be where the speed happened to be then. This flag exists identically in stock and v7.1 (the farm build did not touch it); it only becomes more noticeable because Strong (320) is 3.5 times Weak (91) (stock 292 is 3.2 times).
**B. Coast demand off -> PWM off, no restart (confirmed code).** If any producer condition fails (battery temperature <= 0 or >= 45 C as reported by the BMS, a recovery value other than exactly 30/60/90, SOC/status paths), `B4` stays 0 and as soon as the current decays through zero the speed loop clears the RUN latch; the ISR then switches the outputs off (current exactly 0). In that state `speed_loop` also clears `B4` on every pass (branch 0x1E688), so coast regen **cannot restart** while the throttle is released; it comes back only when something sets RUN (throttle, brake lever, current above 27 counts). This is consistent with "rolls with standby current", but it would not give a regen start at 22 km/h on its own (the brake lever would). The ride recordings show battery temperatures of 14-35 C, inside the window; the BMS reports the **hottest** cell instead of the mean while a hot latch is set, so a hot day or a warm pack after a climb could matter (U).

## 5. How to tell which one it is (no device commands)
* **App current while it "rolls":** about -2 to -3 A (small negative) = Weak clamp (A); **0.0x A** (standby, same as parked) = coast demand off / RUN latch off (B). At 90 % charge and above a standby reading also happens through the voltage gate (section 3, 100 % row), which is a different cause.
* **Time or speed?** Release at a slower speed on the same slope: if regen still comes about 4-5 s after the crest / after the slope eases, it is the slope clamp (time-based); if it always comes at ~22 km/h whatever the time, something not found in the code is involved.
* **Slope sign:** does it happen after a long climb too (clamp set on the climb) or only after a long descent?
* **Mode and cruise:** D or S, and whether the dashboard shows any cruise indicator before the release (hold would keep a high speed request, see the earlier hold analysis).
* **Battery temperature** shown in the app before the run.

## 6. What this means for V8 (analysis only; nothing selected, nothing authorised)
* The regen-strength change is **not** the cause of the delay and cannot be fixed by raising or lowering it.
* If the slope clamp is the cause, the candidate directions are to change how long the clamp holds or which level it caps at, or to make the dashboard's decel-detect bit irrelevant. That is a behaviour trade-off (the clamp appears to be Xiaomi's protection against sustained high regen current on long descents) and needs the owner's decision plus the power-button baseline; it is not a safe "free" fix. The earlier "increase-only ramp" prototype does not address this mechanism at all (it only smooths the 0.3 s coast step).
* If coast demand is switched off by the temperature/recovery-value conditions, the issue is in the BMS-reported temperature or the dashboard value, not in the motor controller.
* Before any change: obtain the app-current observation above; the discriminating information is cheap and removes a guess.

## 7. Caveats
* Plant model, q scale (27.2 counts/A) and the 0.3 V controller/app voltage offset are assumptions; timings in section 2 come from code and are exact, the current values are model outputs.
* The emulator runs the speed loop, limiter, throttle block and voltage monitor on a fixed cadence; it does not run the ISR, the slope filter itself (the flag was set directly), the BMS poll or the dashboard.
* The sign convention of the IMU incline and whether the dashboard sets the decel-detect bit are **unknown**.
* Harness notes: the older closed-loop script never fed the bus-voltage ADC ring and never called the voltage monitor, so the 54.0 V gate input stayed 0 in earlier regen-related runs; the new script feeds the ring and calls the monitor. Flat-ground validations are unaffected (same numbers).
