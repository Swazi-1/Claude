# Feature chains: how the pieces connect (regen, throttle, power, protections, charging, telemetry, caps)

Read this when a question spans functions or the two processors. Each chain lists the ordered links with function IDs (`A:` battery-side, `B:` motor controller), the evidence label (**C** confirmed from code, **S** strong, **L** likely, **U** unknown) and the open questions. RAM offsets are per program. Counts such as 274 or 1023 are internal counts, **not** amps/watts unless a conversion is stated.

Standing rules apply to everything here: analysis only; no device commands, no flashing; the original one-press power button is priority #1; a documented firmware behaviour is not a tuning authorisation.

---
## 0. Timing cheat-sheet
| clock | value | where |
|---|---|---|
| B PWM / FOC ISR | 15.625 kHz (96 MHz, TH0 = 0xC00 center-aligned) | `ISR_MCPWM0` B:1CB14 **C** |
| B limiter + ch9 | every 4th ISR = 3.9 kHz | main loop **C** |
| B scheduler tick | every 16th ISR = **1.024 ms**; "mod5" slots run every 5.12 ms (speed loop, voltage monitor, throttle/mode, IMU), "mod10" every 10.24 ms (flag374 filter, **BMS poll**, direction flags, envelope, governor detector, brake demand, cruise), "mod100" every ~102 ms (status frame TX, NTC, odometer), "mod250" every ~256 ms (dash-loss power-off, temp, service timeout) | `main` B:2292C **C** |
| A SysTick | 1 ms; software timers 1 ms / 10 ms / 100 ms / 500 ms | `SWTIMER_CB_*` **C** |
| A protection latches | **100 ms** per evaluation (slot 1 of the 10-slot round-robin) | `task_protection_and_wdt` A:123D4 **C** |
| A cell statistics | every 50 ms | `task_cell_stats` **C** |
| B -> BMS poll | one request on every 11th visit of the 10.24 ms mod-10 slot (~0.11 s); the toggle logic in `uart1_request_builder` appears to alternate object 0x44 (telemetry) with the other objects, so 0x44 is refreshed roughly every 0.2-0.25 s and the others about every 1.5 s | **L** (derived from code, not measured on the wire) |

---
## 1. Power on / wake / sleep chain  (original button = priority #1)
Physical wiring from the dashboard button to either MCU is **U** (no schematic; "do not label GPIO nets without board evidence"). What the code shows:

**A (battery side), state machine `pack_power_state_machine` A:11DE8 on RAM 0x2E (S/L):**
1. Wake sources, set in IRQs and read here: **PA8** (EXTI both edges; RAM 0x103), **PB9** (EXTI falling; RAM 0x100), **PB7** (= USART1 RX line, EXTI7; counter RAM 0x104, >= 3 edges counts as a real wake), **PB11** (= USART3 RX line, EXTI11 via `wake_pin_filter_pb11`; RAM 0x8A/0x102), the **RTC wake-up timer** (`RTC_IRQHandler` -> `rtc_wakeup_handler`, `wake_source_flags` 1 = timer, 2 = pin), plus pack current > 200 mA.
2. **State 0** (awake after boot or wake): `power_state` (RAM 0x35) = 0, `pack_voltage_ref_init`, update active -> state 4; when not charging and the link flags are clear -> state 1. A BQ-CUV condition (FA1.b4) with no PB9 for 3,000 ticks (30 s), or a BQ-recovery / link-EF request, takes the shutdown path (history event 3, RTC backup to SPI NOR, state 3).
3. **State 1** (idle awake; sleep cycling): goes to state 2 when `pack_ready_check` (A:8834: pack_on, power_state 1, not fully charged, no charge block, no general block) is **true**, or the PB9/PA8 wake flags are set, or >= 3 PB7 edges, or |I| > 200 mA (and sets up EXTI7). Otherwise, if a BQ-CUV latch or `low_soc_poweroff_request` persists for 500 ticks (5 s): `pre_shutdown_pins_and_reinit` (A:5B98: PB15 and PA2 set, peripherals re-initialised so the event can be logged), history event 3 + RTC backup, **state 3**; else `power_mode_step` (A:110FC) cycles sleep: STOP/WFI via `sleep_loop_stop_mode` (A:5CD0) with wake flags in RAM 0x37; after 6,000 idle ticks in its sleep state it logs event 6 and performs a system reset.
4. **State 2** (wake verification, `power_state` = 2): wake activity (PA8 flag, >= 3 PB7 edges or |I| > 200 mA) lasting 4 ticks, or PB9 low / pack_on lasting 5 ticks (the latter also sets `pb14_request` and `wake_no_reset_flag`), calls `wake_full_reinit` (A:5DBC: all pins analog, then the 26-entry pin table, I2C/BQ SLEEP_DISABLE, ADC, SPI1 + NOR release, USART1 re-init) and enters **state 0**; 500 ticks (5 s) with nothing confirmed -> back to state 1.
5. **State 3** (final shutdown, `power_state` = 5): both FETs off, LOAD_DETECT_OFF, LD pin read; if the LD pin stays below 0.40 V for more than 500 ticks: **PB1 pulse + BQ SHUTDOWN() (subcommand 0x0010) sent twice** (the BQ goes into SHUTDOWN mode: pack output dead until a wake/charger); if PB9 is asserted for >= 5 ticks instead: `wake_full_reinit`, state 0, PB1 pulse low and BQ RESET() (0x0012) twice. **State 4:** update mode (waits for the update to finish). **S** (read from code; the hardware meaning of PB1 = BQ RST_SHUT pin is **L**).
5b. **pack_on (RAM 0x107)** is set by `power_on_off_decision` (A:4344): PB9 low for > 60 ticks (10 ms) with the wake filter set, **or** PACK-pin voltage within 1.5 V of the cell sum for > 150 ticks (and PACK pin < 57.5 V). It clears 20 ticks after the release conditions. It gates the CHG FET request and the register flag "pack on".
6. **DSG FET requires PA8 high** (A:4630 reads `GPIOA` bit 8 directly) and `wake_no_reset_flag == 0`. So **PA8 is the pack's "discharge enable / key-on" input** (S: code reads it as a level; **U**: which dashboard net drives it).

**B (motor controller):** boots (`main` B:2292C: `hardware_init`, `startup_calibrate_and_load` waits 100 ticks and measures DC-current zero, self-test of the over-current path B:1E280, IMU probe), then runs. B has its **own power latch output P3.9** (GPIO3 bit 9): high at init; the dashboard control frame byte 5 bit 7 asks to keep it high; after 3 frames with the bit low, or ~480 counts (every 5th tick) of lost frames (`dash_loss_poweroff` B:206E4), B turns the motor outputs off, saves settings once and drops P3.9. B also resets to the bootloader on `system_reset_request` (flag 0x1D5) and via `ISR_WAKE_reset` (IRQ23). **S**
**Warning for any future change:** nothing in B's boot/vector/power-hold code and none of A's power-state RAM (0x02, 0x2C, 0x2D, 0x2F, 0x35, 0x37, 0x100, 0x103, 0x104) may be touched without the full button baseline (project rule from `AGENTS.md`).

---
## 2. Throttle -> speed target -> drive -> limit chain (B)
1. UART0 control frame (see `05_...` 2.1): throttle byte 0..100, brake byte, mode nibble, profile byte. **C**
2. `throttle_mode_block` B:1DDCC (every 5.12 ms): throttle 6..100 -> `requested_speed = applied_reference * throttle / 100`; throttle 0..5 or > 100 -> 0 (or `held_reference` while cruise is active). Mode selector (RAM 0x14D): **0x0B -> env_target 137, target 62 (6.2 km/h, walking)**; **2 -> env 328, target `ctrl_block[0]` = 203 (20.3 km/h, "D")**; **3 -> env 493, target `ctrl_block[+2]` = 253 (25.3 km/h, "S")**; **1/other -> env 274, target 103 (10.3 km/h)**. `applied_reference` ramps toward the target by 1 every 6th call while throttle != 0, snaps when throttle == 0. **C**
3. `speed_loop` B:1E3D0 (5.12 ms): speed from hall period (0.1 km/h units), step = clamp((requested - speed - 10) >> 4, 1, accel_step) with `accel_step = (env_applied - dc_current) >> 3` clamped 1..40 (<= 2 if `vbus_raw` < 753); DRIVE branch (speed < requested): the drive command `deriv_detector_da` (desired q-voltage command) grows by `step` with soft approach inside 2.8 km/h; COAST branch (speed >= requested) and BRAKE branches (see section 4). Drive command is clamped to +/-1023. **C**
4. FOC: q-axis is **voltage-commanded** (drive command ~ Vq), d-axis current reference 0 (`d_axis_regulator` B:1D5B8, no field weakening). `ISR_MCPWM0`: two phase currents reconstructed per sector, Clarke/Park, inverse Park, SVPWM (`svpwm_output`), hall rotor estimator (`rotor_estimator` B:1F660 with 60-degree sector interpolation, angle offsets 0x1A4F forward / 0xE38 reverse). **C**
5. `current_limiter_drive_cmd` B:1D654 (3.9 kHz): `dc_current = (sum ring_dc_current >> 6) - dc_zero_offset`; if `dc_current > env_applied` or `i_q > 1461` (or `i_q < -1826`) the drive command is pulled toward 0 (steps from the excess, derivative term; k = 4/cap 30 below dc 684, k = 2/cap 60 above); regen side: `dc_current < -env` or `i_q < -bound` reduces |drive| (step <= 20). Optional governor (`gov_flag`) limits i_q to RAM 0xE4 starting at 10 and creeping +1 per 6000 calls up to 1461. Over-voltage (`vbus_raw > 1075`) clears `run_latch` and turns MOE off. **C**
6. `envelope_protection` B:1FC0C (every 5th tick) derives `env_applied` from `env_target` (slews +/-1): stall derate (speed < 0.4 km/h for > 110/130/150 calls scales by 80/50/20 /128, fault at 180), local thermal (temp_local > 900: cap = max(0, 3193 - 3T), >= 1100 -> 3), **battery temperature curve from the BMS** (`remote_temp`: T >= 55 or <= -5 -> 274; -5 < T < 2 -> 493 - 31*(2 - T); 50 < T < 55 -> 2693 - 44*T), remote status/error cap 274, **SOC cap** (SOC <= 10 -> 274; 10 < SOC < 20 -> 493 - 22*(20 - SOC)), a long-term current limit for region prefixes 60549/61124 (filtered dc_current > 328 for 60000 calls). **C**
7. Current scale: the dashboard query 0x34 returns `dc_current * 1000 / 274` in 10 mA units (so ~27.4 counts per ampere on that conversion; it has not been verified against a clamp meter). The owner's recordings show a **current ceiling of 20.6-20.8 A in S at 100 / 56 / 35 % charge**, i.e. above env 493 / 27.4 = 18 A, **Resolved 2026-10-04 (S):** the Sport cap sweep measured 27.2 counts/A at 560, 600 and 680 (env/27.2 = app amps within ~1 %); the dashboard's 27.4 is a slightly different conversion.

The two voltage-headroom effects the owner measured (power falling above ~25 km/h; top speed 33/30/28 km/h at 100/56/35 %) come from q-voltage control: back-EMF eats the available bus voltage (**S**, from the earlier simulation work; not a firmware limit).

---
## 3. Protection -> block flag -> FET chain (A)
```
BQ769x2 direct reads (A:1C60)  +  A soft latches (A:11978/11998/119C4, every 100 ms)
        |                                   |
  bq_safety_status_react A:9134  ->  prot flags F72 / FA1 / FAC / FC3 / FCD / FD0  (+ 0xF73 bq-fault bits)
        |
  fault_flag_aggregator A:46EC  ->  chg_block (0x3C), dsg_block (0x3D), general_block (0x3E)
        |
  fet_request_compute A:4630    ->  chg_fet_request (0xA66), dsg_fet_request (0xA65)
        |
  chg_fet_control A:48F8 / dsg_fet_control A:5274  ->  BQ FET_CONTROL / 0x93 DSG_PDSG_OFF / 0x94 CHG_PCHG_OFF, read-back 0x7F
        |
  fet_state_mismatch_check -> sets 0xF73 bit3 if the BQ FET status disagrees for 0x32 ticks
```
**Aggregation (A:46EC), exact bit lists (C):**
* `chg_block` (0x3C) = FA1.b0 (soft cell OV) | FA1.b1 (BQ COV) | FAC.b0 | FC3.b0 | FC3.b1 (soft charge OC L1/L2) | FCD.b0 (charge OT 45 C) | FCD.b1 (charge UT 2 C)
* `dsg_block` (0x3D) = FA1.b3 (soft cell UV 2770 mV) | FA1.b4 (BQ CUV) | FA1.b6 (pack UV level 2) | FC3.b3 | FC3.b4 (soft discharge OC 22 A / 25 A) | FC3.b5 | FC3.b6 (BQ OCD/SCD status) | FCD.b3 (discharge OT 65 C) | FCD.b5 (discharge UT -18 C)
* `general_block` (0x3E) = F72.b0 (imbalance >= 500 mV for 120 s) | F72.b1 (deep discharge < 1500 mV) | F72.b2 (current flowing while CHG FET off) | F72.b3 (current flowing while DSG FET off) | FA1.b7 (cell-voltage plausibility) | FD0.b1 (board OT 90 C) | FD0.b3 (NTC2 implausible) | FCD.b6 (NTC1 implausible) | bq_fault_flags.b2 (BQ I2C not answering)
**FET request rule (A:4630, C):**
* DSG request = 1 unless: `dsg_block` or `general_block`, or `state_in_0_1_4 == 0`, or `wake_no_reset_flag == 1`, or **PA8 is low**.
* CHG request = 1 only if `pack_on == 1` and `power_mode_89` is 2 or 3 and the **model has not raised the full-charge anchor request (RAM 0x1378)**; then forced to 0 by `chg_block`, `general_block`, `state_in_0_1_4 == 0` or the **fully-charged flag (RAM 0x40: SOC = 100 % while pack on)**.
* PB15 is a **charge-inhibit output** driven high by the charge-OT / charge-UT latches (A:FDAC/FE74) and low again on release; it is also set by `pre_shutdown_pins_and_reinit`.
**BQ769x2 hardware layer (S, from the configuration image decoded in `06_A_ROM_TABLES.md` section 7):** CUV 2.73 V, COV 4.25 V, SCD and OCD2 enabled; **OCC and OCD1 and OCD3 not enabled**; temperature OTC 45 / OTD 65 / UTC 2 / UTD -18 C enabled; CHG FET opens on SCD, OCC(disabled), COV, OTC, UTC, host-watchdog; DSG FET opens on SCD, OCD2, OCD1(disabled), CUV, OTD, UTD, host-watchdog.
**Topology inference (L):** the FET masks make **COV a charge-FET-only event** and soft charge-OC / charge-OT / OV only drive `chg_block` (charge FET). If the scooter's regen current returns through the DSG FET (as in a separate-charge-port BMS), none of these cut regen. Evidence from the ride recordings: regen of -6.2 to -8.8 A (app amps, BMS CC2-based) lasted 4.75 s at 35 % charge and ~3 s at 50 % without any cut-off, although A's soft charge-OC L2 (>= 5.5 A for >= 1 s) should have latched `chg_block` (direction state 0 applies whenever CC2 current is positive/charging for > 100 mA). Whether the charge FET is in the regen path at all is therefore **U but likely "no"**. Unit chain used: BQ CC2 raw x 10 = mA (DA Configuration 0x06 -> 10 mA/LSB; `pack_current_signed` = raw*10; sign positive = charging; the app/dashboard shows regen as negative).

---
## 4. Regeneration chain (coast recovery + brake regen) - all gates in one place
Inputs that decide regen strength:

| input | source | used by |
|---|---|---|
| `profile_byte` = 30 / 60 / 90 (Weak/Medium/Strong), accepted only <= 100 | dashboard control frame byte 8 | `coast_regen_demand` |
| speed (0.1 km/h), `requested_speed` | hall rotor estimator, throttle chain | coast + brake branches |
| battery voltage `vbus_decivolt = vbus_raw * 8850 >> 14` (decivolts) | B ADC (`voltage_monitor` B:22F38) | coast regen gate < 540 (54.0 V); over-voltage > 1075 raw (58.1 V) |
| `remote_temp` (BMS temperature, signed C) | BMS object 0x44 byte 6 (sign-magnitude) | coast regen requires 0 < T < 45; brake regen inhibited outside 0..45 |
| `remote_telemetry[1]` = SOC % | BMS object 0x44 byte 1 | coast: SOC >= 90 caps profile at 60; brake: SOC >= 95 inhibits regen braking |
| `remote_status_flag` (RAM 0x374) | B `remote_flag374_filter` (IMU incline: sustained `ram[0x376] < -20` for 400 visits (~4.1 s), released after 500 visits (~5.1 s) of > -10; only when dashboard byte 9 bit 7 enables it) | clamps profile to 30 |
| `remote_state` | BMS link health (0 ok; 3 = no replies for > 300 polls) | brake regen inhibited when > 2; SOC source (BMS vs voltage curve) |
| `ctrl_block[+4/+6/+8]` | region defaults: stock 91 / 146 / 292; farm v7.1 91 / 160 / 320 | coast target current demand for Weak/Medium/Strong |
| brake lever byte | dashboard byte 7 | `active_brake_demand_calc` |

**Coast recovery (`coast_regen_demand` B:1BDD0, runs inside the speed loop when speed > 6.0 km/h) - C:**
1. Applies only if speed >= 6.0 km/h **and** speed - 2.0 km/h > requested speed (i.e. throttle off/low, scooter faster than demanded) **and** 0 < `remote_temp` < 45 C. Otherwise the target is 0 and `coast_demand` slews to 0.
2. Effective profile = `profile_byte`; if `remote_status_flag` and profile > 30 -> 30; if SOC >= 90 and profile > 60 -> 60. **Any `profile_byte` other than exactly 30, 60 or 90 gives target 0 (no coast regen) above 8 km/h.**
3. Speed > 8.0 km/h: `coast_target` = ctrl_block+4 / +6 / +8 for 30 / 60 / 90. For 6.0 < speed <= 8.0 the target is reduced by 20*T/(speed - 6.0), which is >= T over that whole range, so the target is effectively **0 below 8 km/h** (no ramp).
4. `coast_demand` slews toward the target by 5 per call (5.12 ms): ~0.15 s to full.
5. In the speed loop COAST branch (speed >= requested): the extra coast adjustment `coast_adj = (speed - requested)/8` (clamped 0..10) is **only applied when `vbus_decivolt < 540` (54.0 V) and speed > 3.0 km/h**; the drive command is reduced while `i_q > -coast_demand`, else nudged by `i_q`. **At or above 54.0 V terminal voltage coast regen is therefore switched off** - this is the "regen at full charge" ceiling (owner: 53.8-54.3 V at 100 %).
**Brake regen (`active_brake_demand_calc` B:1DCB0 + BRAKE branches of `speed_loop`) - C:** if the brake byte != 0: base = 639 (0x27F) or **1644 (0x66C) when `brake_branch_sel` (RAM 0x10B) is set**; `startup_calibrate_and_load` sets it only for identity prefixes 60549 / 61124 / 60560 (0xEC85 / 0xEEC4 / 0xEC90). In v7.1+ the region-free literal change makes 60549 and 61124 stop matching (60560 still matches), so on those builds the weaker base 639 applies unless the serial prefix is 60560. The owner's serial prefix is **U**, so which base applies on the owner's scooter is **U**. (The earlier project note 'v6 -> v7.1 braking bound -1096 -> -1644' was not reproduced in this stage's stock -> v7.1 diff.) demand = brake*base/100 scaled by 1013/vbus_raw (cap base) + min(speed/5, 50); inhibited (demand 0, flag 0x109) if `remote_temp` outside 0..45 C, `remote_state > 2`, or **SOC >= 95 %** (`brake_soc_block`); low-speed state forces demand 1023. BRAKE branches ramp the drive command by +/-40 per call toward the signed target `-max(active_brake_demand, coast_demand)`.
**BMS-side facts that matter to regen (A):** (a) A does **not** limit regen strength; it only reports SOC/temperature; (b) a DSG-FET opening event (`dsg_block`: UV 2770 mV, CUV, DSG OT 65 C, UT -18 C, discharge OC 22/25 A, BQ OCD/SCD) while regenerating would remove the battery from the bus and the bus voltage would rise -> B over-voltage (`vbus_raw > 1075` ~ 58 V) turns the motor outputs off; (c) the temperature byte the BMS reports is the *hottest* cell NTC if a hot latch (FCD.b0|b2) is set, the *coldest* if a cold latch (FCD.b1|b4) is set, else the mean - so a single cold NTC reading near 0 C removes coast regen (needs T > 0) even while the pack mean is warmer. **S** (code); effect on the owner's pack not observed.
**Detailed emulator study of the downhill "rolls, then regen starts later" symptom: `10_REGEN_ENTRY_DELAY_ANALYSIS.md` (nominal code has no dead zone; slope clamp and coast-demand-off are the two mechanisms that fit).**
**Open hypotheses for the owner's "regen bug" (all U, to be tested, none is a claim):**
 1. IMU-slope flag (`remote_flag374_filter`): on a long descent the incline filter (> ~2 degrees for ~4 s) clamps the selector to 30 (Weak) although Strong is chosen; the roll sign convention (`ram[0x376] = int(-10*roll)`) is unresolved - check which way the farm hill reads.
 2. SOC >= 90 cap (Strong -> Medium) and SOC >= 95 brake-regen block: matches "regen starts to kick in at 95 %".
 3. Terminal voltage >= 54.0 V gate: at a freshly charged pack the voltage under regen can exceed 54.0 V even below 95 % SOC.
 4. Battery temperature outside 0 < T < 45 C (or a single cold NTC) zeroes coast regen.
 5. Profile byte not in {30, 60, 90} (e.g. if the dashboard auto-adjusts recovery on slopes by sending intermediate values - Xiaomi's marketing text claims automatic adjustment) gives coast target 0.

---
## 5. Charging chain (A)
1. Charger connect: `chg_connect_debounce_fsm` (A:4508) debounces the connection (RAM 0x11C..0x124) in power state 0; `pack_charge_ok_check`/`pack_ready_check` decide when charging may start.
2. CHG FET request per section 3 (needs pack_on, power_mode_89 in {2,3}); turned on by `chg_fet_control` (FET_CONTROL idx 2, after `chg_fault_active` check A:9400), off by subcommand 0x94.
3. Limits while charging: soft cell OV 4220 mV (release 4100), BQ COV 4250 mV; soft charge OC 4.5 A for 10 s / 5.5 A for 1 s (mA units), charge OT 45 C / UT 2 C with PB15 inhibit; the 2-D charge-current allowance table (max cell mV x temperature, `06_A_ROM_TABLES.md` section 4) produces the current-limit percent (RAM 0xC89) sent to the USART3 peer. **L** that this reaches a charger.
4. **Termination:** (a) SOC reaches 100 % with pack on -> `full_charged_flag` (RAM 0x40) blocks the CHG request (released 6 ticks after SOC < 100); (b) the SOC model's **full-charge anchor request** (RAM 0x1378) also blocks it. `soc_correction_triggers` (A:11350, every 100 ms) raises it while charging or idle with min cell >= 3600 mV and mean >= 4000 mV and either (i) the OV / BQ-COV / FAC latch is set for > 10 ticks, or (ii) **max cell >= 4150 mV with charge current <= 280 mA while charging for >= 10 ticks (taper end)**. The request lasts 20 ticks (2 s) and is re-evaluated, so charging ends in short top-off pulses; each request also anchors the model SOC to full and logs event 8; (c) hardware COV 4.25 V / soft OV 4.22 V. The mirror-image **low-voltage anchor** (RAM 0x137D) is raised while idle/discharging with max cell < 4250 mV when a UV latch (FA1.b3|b4|b6) is set with no BQ fault for > 10 ticks, or when min cell <= 3000 mV or mean <= 3140 mV for >= 10 ticks (event 9).
5. Balancing is done by the BQ769x2 (relax only; min cell 3800 mV, min delta 50 mV, up to 6 cells, 20 s interval). A does not run its own balancing code (no balance-control writes found). **S**

---
## 6. SOC / telemetry chain
1. BQ cell reads (13 cells) -> `cell_voltage_copy_or_default` (A:8BEC; default 3600 mV when the BQ read fails) -> `cell_stats_publish` (min/mean/max/index, pack mV = sum).
2. CC2 current x 10 -> `pack_current_signed` mA (|I| <= 10 mA -> 0); direction state with 100 mA hysteresis.
3. Generated SOC/SOH model (A:63B8..A:7A30, dispatched by `model_scheduler` A:E658; coulomb counter with a 3,600,000 divisor; OCV tables; anchors at full charge and low voltage) writes SOC through `port_set_soc_x100` (SOC% = round(x/100), remaining capacity = SOC% * capacity/100) and SOH through `port_set_soh`. Persisted via state records in internal flash (pages 0x801F000/0x801F800, 0x38-byte records) and stat records (0x801C800/0x801D000). **S**
4. `bms_register_block_publish` (A:1337C) builds the register image (RAM 0x106E..0x108D; object map in `05_...` 3.3). B polls it over UART1, repackages object 0x44 in its 0x61 status frame type 1 for the dashboard; the dashboard/app display it. B itself uses SOC and temperature for regen and current caps (sections 2 and 4).
5. Logging: 0x28-byte session/event records into the SPI NOR ring at 0x21000, 0x20-byte history records at 0x41000 (CRC8 poly 0x2F), RTC backup copies at 0x50000/0x51000, NTC calibration at 0x30000.

---
## 7. Regional caps and child mode (links to the Opus report)
* **Stock region table (C, program B `region_config_defaults` B:1FFDC):** the first five ASCII digits of the identity/serial string (RAM 0x25D) form a numeric prefix (RAM 0x10). Default (leading '0'/0xFF -> 60559): walking 62 (6.2 km/h), D 203 (20.3), S 253 (25.3), regen demands 91/146/292, vbus limit 1001. For prefixes **60549 / 60558 / 61124** (0xEC85, 0xEC8E, 0xEEC4): mode 2/3 targets **153 and 203 (15.3 and 20.3 km/h)**, vbus limit 1013, ctrl+0xA = 500, and cruise is disabled. So Xiaomi's own firmware carries regional 6 / 15 / 20 km/h limits; the owner's "child cap" numbers (about 6 / 15 / 20) reuse this table. This upgrades the Opus report's "unknown: cap table may be Xiaomi's regional table" to **confirmed** for the numbers (the Egypt web page was not re-checked).
* **Region-free change in the owner's builds:** nine halfwords (0xEC85 / 0xEEC4 -> 0x0000 at file 0x1C6A0, 0x1C6A8, 0x1CB04, 0x1CB08, 0x1DC48, 0x1DC4C, 0x1FED4, 0x1FEDC, 0x200A4) are zeroed in v6/v7.1/RC01/RC02 (from `FINDINGS_2026-10-03.md`).
* **Child cap in the custom builds (from the earlier findings, not re-derived here):** the cap helper tests `profile_byte == 0x3C`; the profile byte (RAM 0x1EC) is the same cell the dashboard fills from the app's energy-recovery selector, so Medium (60) can trigger the caps; they are applied only when the mode block runs (a riding-mode change or start-up); stock firmware has no such check, and stock `coast_regen_demand` gives Weak/Medium/Strong = 30/60/90 exactly as above. Six double-presses toggle the cap in v7.1/RC02 (the dashboard decodes the button; B only sees mode changes).
* What the dashboard really sends for Weak/Medium/Strong on a **5 Max** is still unmeasured; community sources (Opus report) say 0x1E/0x3C/0x5A on Brightway scooters, and the stock B code is consistent: it only recognises exactly 30/60/90, anything else yields no coast regen.

---
## 8. Update / authentication chain
* A: USART1 ASCII `down ...` + XMODEM-style stage in SPI NOR -> descriptor 0x801D800 -> bootloader (not in image) on reset; USART3 challenge/response (custom AES-like scramble) guards the peer link. B: UART0 ASCII/XMODEM/service frames, AES-128 challenge/response (`mcu_rand`/`mcu_key`, default key A0..AF) unlocking service state; commit record at flash 0x1FC00; staging 0xF000. Details in `05_PROTOCOLS_AND_REGISTERS.md`. The dashboard's own key/authentication is outside the image.

---
## 9. "If you change X, what else moves" (reading aid, not advice)
* `profile_byte` semantics -> coast regen, SOC/IMU caps, child-cap trigger in custom builds.
* `ctrl_block+4/+6/+8` -> coast regen strength per level (and the farm v7.1 values).
* `env_target` per mode / envelope caps -> current ceiling, thermal and SOC derating.
* Brake base 639/1644 -> brake regen strength; SOC >= 95 and T-window gates.
* Anything in B that delays boot or the power latch (P3.9) -> one-press power behaviour; anything in A that touches RAM 0x2E/2F/35/107 or PA8/PB9 handling -> pack power state and DSG FET.
* A's FET request rule -> if the DSG FET opens while the motor regenerates, B sees an over-voltage and cuts the outputs.

---
## 10. Temperatures the controller reports and uses (added 2026-10-04)
* Status frame 0x61 type 0 (`uart0_status_frame_tx` B:1D09C) carries exactly two temperatures: **byte 6 = `temp_local` / 10** (clamped 0..255) and **byte 7 = `temp_ntc_a`** (clamped 0..200). **C**
* `temp_local` (RAM 0xC2, tenths) is the input of the thermal derate in `envelope_protection`: above threshold (imm at 0x1FC90 x 4) cap = K - 3T with K the literal at 0x1FEB8 (only reference: ldr at 0x1FCAC), >= 1100 -> cap 3. Stock 900 / 3193; v7.1..V8 600 1020 / 3620; V8.1 864 / 3193. **C**
* `temp_ntc_a` (RAM 0xC4; NTC, 8.2 k pull-up, beta 3950) is only reported. `temp_ntc_b` (0xC6) is not sent. **C**
* No motor-winding sensor: the motor cable is 3 phase + 5 thin wires (3 hall + supply + ground). **S** (photo).
* The app's "Scooter Temperature" (scooter information page) is one of the two controller temperatures; which one is **U** (byte 6 likely). The owner's 75 C maximum (100 m climb, cool day) is therefore a controller temperature.
