"""Generate periph_A.csv: register names for the battery-side processor (Nations N32G43x / N32G432-compatible, Cortex-M4F).
Base addresses and register layouts taken from the n32g4 SVD-derived Rust crate documentation (docs.rs n32g4, n32g432 module), fetched 2026-10-03.
Confidence: layout of the N32G432; the N32G43x family shares it (identical peripheral addresses were observed in the firmware: IWDG key writes at 0x40003000, RTC write-protect keys at 0x40002824, FLASH key 0x45670123/0xCDEF89AB at 0x40022004)."""
import csv, os
HERE = os.path.dirname(os.path.abspath(__file__))
rows = []


def add(base, prefix, regs):
    for off, name in regs:
        rows.append((base + off, "%s_%s" % (prefix, name.upper())))


gpio = [(0x00, "pmode"), (0x04, "potype"), (0x08, "sr_alt"), (0x0C, "pupd"), (0x10, "pid"), (0x14, "pod"), (0x18, "pbsc"), (0x1C, "plock"),
        (0x20, "afl"), (0x24, "afh"), (0x28, "pbc"), (0x2C, "ds"), (0x30, "sr")]
for b, n in ((0x40010800, "GPIOA"), (0x40010C00, "GPIOB"), (0x40011000, "GPIOC"), (0x40011400, "GPIOD")):
    add(b, n, gpio)
add(0x40021000, "RCC", [(0x00, "ctrl"), (0x04, "cfg"), (0x08, "clkint"), (0x0C, "apb2prst"), (0x10, "apb1prst"), (0x14, "ahbpclken"), (0x18, "apb2pclken"),
                        (0x1C, "apb1pclken"), (0x20, "ldctrl"), (0x24, "ctrlsts"), (0x28, "ahbprst"), (0x2C, "cfg2"), (0x30, "cfg3"), (0x34, "rdctrl"),
                        (0x40, "pllhsipre"), (0x44, "sram_ctrlsts")])
add(0x40020800, "ADC1", [(0x00, "sts"), (0x04, "ctrl1"), (0x08, "ctrl2"), (0x0C, "smpr1"), (0x10, "smpr2"), (0x14, "joffset1"), (0x18, "joffset2"), (0x1C, "joffset3"),
                         (0x20, "joffset4"), (0x24, "wdghigh"), (0x28, "wdglow"), (0x2C, "rseq1"), (0x30, "rseq2"), (0x34, "rseq3"), (0x38, "jseq"), (0x3C, "jdat1"),
                         (0x40, "jdat2"), (0x44, "jdat3"), (0x48, "jdat4"), (0x4C, "dat"), (0x50, "difsel"), (0x54, "calfact"), (0x58, "ctrl3"), (0x5C, "sampt3")])
add(0x40020000, "DMA1", [(0x00, "intsts"), (0x04, "intclr")])
for ch in range(8):
    base = 0x40020000 + 0x08 + 0x14 * ch
    add(base, "DMA1_CH%d" % (ch + 1), [(0x00, "chcfg"), (0x04, "txnum"), (0x08, "paddr"), (0x0C, "maddr")])
usart = [(0x00, "sts"), (0x04, "dat"), (0x08, "brcf"), (0x0C, "ctrl1"), (0x10, "ctrl2"), (0x14, "ctrl3"), (0x18, "gtp")]
for b, n in ((0x40013800, "USART1"), (0x40004400, "USART2"), (0x40004800, "USART3")):
    add(b, n, usart)
i2c = [(0x00, "ctrl1"), (0x04, "ctrl2"), (0x08, "oaddr1"), (0x0C, "oaddr2"), (0x10, "dat"), (0x14, "sts1"), (0x18, "sts2"), (0x1C, "clkctrl"), (0x20, "tmrise")]
add(0x40005400, "I2C1", i2c)
add(0x40005800, "I2C2", i2c)
add(0x40022000, "FLASH", [(0x00, "ac"), (0x04, "key"), (0x08, "optkey"), (0x0C, "sts"), (0x10, "ctrl"), (0x14, "addr"), (0x18, "ob2"), (0x1C, "ob"), (0x20, "wrp"), (0x24, "ecc"), (0x30, "cahr")])
add(0x40010400, "EXTI", [(0x00, "imask"), (0x04, "emask"), (0x08, "rt_cfg"), (0x0C, "ft_cfg"), (0x10, "swie"), (0x14, "pend"), (0x18, "ts_sel")])
add(0x40007000, "PWR", [(0x00, "ctrl1"), (0x04, "ctrl2"), (0x08, "ctrl3"), (0x0C, "sts1"), (0x10, "sts2"), (0x14, "stsclr")])
rtc = [(0x00, "tsh"), (0x04, "date"), (0x08, "ctrl"), (0x0C, "initsts"), (0x10, "pre"), (0x14, "wkupt"), (0x1C, "alarma"), (0x20, "alarmb"), (0x24, "wrp"), (0x28, "subs"),
       (0x2C, "sctrl"), (0x30, "tst"), (0x34, "tsd"), (0x38, "tsss"), (0x3C, "calib"), (0x40, "tmpcfg"), (0x44, "alrmass"), (0x48, "alrmbss"), (0x4C, "opt")]
rtc += [(0x50 + 4 * k, "bkp%d" % (k + 1)) for k in range(20)] + [(0xA0, "tscwkupctrl"), (0xA4, "tscwkupcnt")]
add(0x40002800, "RTC", rtc)
add(0x40003000, "IWDG", [(0x00, "key"), (0x04, "prediv"), (0x08, "relv"), (0x0C, "sts")])
add(0x40010000, "AFIO", [(0x00, "rmp_cfg"), (0x04, "exti_cfg1"), (0x08, "exti_cfg2"), (0x0C, "exti_cfg3"), (0x10, "exti_cfg4")])
tim = [(0x00, "ctrl1"), (0x04, "ctrl2"), (0x08, "smctrl"), (0x0C, "dinten"), (0x10, "sts"), (0x14, "evtgen"), (0x18, "ccmod1"), (0x1C, "ccmod2"), (0x20, "ccen"), (0x24, "cnt"),
       (0x28, "psc"), (0x2C, "ar"), (0x30, "repcnt"), (0x34, "ccr1"), (0x38, "ccr2"), (0x3C, "ccr3"), (0x40, "ccr4"), (0x44, "bkdt"), (0x48, "dctrl"), (0x4C, "daddr"), (0x50, "ccmod3")]
for b, n in ((0x40012C00, "TIM1"), (0x40013400, "TIM8"), (0x40000000, "TIM2"), (0x40000400, "TIM3"), (0x40000800, "TIM4"), (0x40000C00, "TIM5"), (0x40001000, "TIM6"), (0x40001400, "TIM7"), (0x40003C00, "TIM9")):
    add(b, n, tim)
spi = [(0x00, "ctrl1"), (0x04, "ctrl2"), (0x08, "sts"), (0x0C, "dat"), (0x10, "crcpoly"), (0x14, "crcrdat"), (0x18, "crctdat"), (0x1C, "i2scfg"), (0x20, "i2sprediv")]
add(0x40013000, "SPI1", spi)
add(0x40013C00, "SPI2", spi)
# core peripherals (Cortex-M4 System Control Space)
scs = {0xE000E010: "SYST_CSR", 0xE000E014: "SYST_RVR", 0xE000E018: "SYST_CVR", 0xE000E100: "NVIC_ISER0", 0xE000E104: "NVIC_ISER1", 0xE000E180: "NVIC_ICER0",
       0xE000E184: "NVIC_ICER1", 0xE000E200: "NVIC_ISPR0", 0xE000E280: "NVIC_ICPR0", 0xE000E400: "NVIC_IPR0", 0xE000ED00: "SCB_CPUID", 0xE000ED04: "SCB_ICSR",
       0xE000ED08: "SCB_VTOR", 0xE000ED0C: "SCB_AIRCR", 0xE000ED10: "SCB_SCR", 0xE000ED14: "SCB_CCR", 0xE000ED88: "SCB_CPACR"}
for a, n in scs.items():
    rows.append((a, n))
seen = {}
for a, n in rows:
    seen.setdefault(a, n)
with open(os.path.join(HERE, "periph_A.csv"), "w", newline="", encoding="utf-8") as fp:
    w = csv.writer(fp)
    w.writerow(["addr", "name", "desc"])
    for a in sorted(seen):
        w.writerow(["0x%08X" % a, seen[a], "N32G432-compatible layout (docs.rs n32g4); SCS from ARM"])
print(len(seen), "registers")
