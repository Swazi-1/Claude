import csv
rows = """
0x18,1,isr_tick_prescale,MCPWM ISR counter; every 16 ISRs sets sched_tick,prior-verified
0x1E,1,sched_tick,scheduler tick flag set by MCPWM ISR (1.0242 ms nominal) consumed by main loop,prior-verified
0x1F,1,run_latch,activity/run latch (motor run enabled),prior-verified
0x1D,1,isr_state,MCPWM ISR state 0..3 (0 off 2 normal),prior-verified
0x30,2,adc0_slot0_raw,phase sample ADC0 DAT0 (OPA1) latest,prior-verified
0x32,2,adc1_slot0_raw,phase sample ADC1 DAT0 (OPA0) latest,prior-verified
0x34,2,adc0_slot1_raw,phase sample ADC0 DAT1 (OPA3) latest,prior-verified
0x48,8,ring_dc_current,ADC0 DAT2 (OPA2) 4-sample ring (left-aligned) DC-like current,prior-verified
0x50,8,ring_vbus,ADC0 DAT3 ext CH5 4-sample ring voltage-like,prior-verified
0x58,8,ring_ntc_a,ADC0 DAT6 ext CH4 gain1 ring NTC A,prior-verified
0x60,8,ring_temp_local,ADC0 DAT5 ext CH7 ring local linear temp C2,prior-verified
0x68,8,ring_avdd,ADC1 DAT6 internal AVDD ring,prior-verified
0x70,8,ring_mcu_temp,ADC1 DAT5 internal MCU temp ring,prior-verified
0x78,8,ring_ch9,ADC1 DAT4 ext CH9 ring,prior-verified
0x80,8,ring_ntc_b,ADC0 DAT4 ext CH8 gain1 ring NTC B,prior-verified
0x8C,2,hall_period,filtered Hall/sector period (ISR counts),prior-verified
0x90,1,gov_flag,governor-detector latched flag byte (RC02 hooks),prior-verified
0x92,1,lowspeed_brake_cnt,low-speed brake special-state accumulation counter (max 100),prior-verified
0xB4,1,flag_b4,fault/self-test flag (self-test result B4),prior-verified
0xB6,1,fault_stall_or_remote_hot,stall/remote-thermal fault flag,prior-verified
0xB7,1,flag_b7,remote thermal fault B7 (consumed by main inhibit),prior-verified
0xB8,1,fault_temp_sensor,local temperature sensor fault,prior-verified
0xB9,1,flag_local_thermal,local thermal flag (C2 above derate entry),prior-verified
0xBA,1,remote_hot_cnt,remote thermal debounce counter,prior-verified
0xBD,1,temp_sensor_invalid_cnt,local temp invalid debounce,prior-verified
0xBE,2,env_target,mode-selected forward envelope BE (current-like units),prior-verified
0xC0,2,stall_cnt,stall-like counter,prior-verified
0xC2,2,temp_local,calibrated local temperature (tenths),prior-verified
0xC4,2,temp_ntc_a,NTC A temperature,prior-verified
0xC6,2,temp_ntc_b,NTC B temperature,prior-verified
0xC8,2,env_protected,protected envelope C8 after clamps,prior-verified
0xCA,2,env_ramped,envelope CA slewed toward BE,prior-verified
0xD4,2,neg_dc_cnt,sustained negative DC-feedback counter,prior-verified
0xD6,1,auth_state_d6,transient authenticated/service flag D6 (nonzero inhibits control),prior-verified
0xD8,1,recovery_clamp_d8,derived recovery clamp 30,prior-verified
0xD9,1,lowspeed_brake_cfg,low-speed braking related setting (D9),prior-verified
0xDA,2,deriv_detector_da,derivative/product detector feeding gov flag,prior-verified
0xDC,2,dc_current,signed DC-like current feedback (ring48 avg>>6 - E8),prior-verified
0xDE,2,neg_dc_env,negative DC-like envelope (-547 / -192),prior-verified
0xE0,2,neg_bound,braking-branch negative feedback bound (E0),prior-verified
0xE8,2,dc_zero_offset,DC-like current zero offset measured at boot,prior-verified
0xEA,2,env_applied,envelope EA slewed toward C8 (current limit compared with dc_current),prior-verified
0xF0,1,flag_lowv_severe,severe low-voltage flag,prior-verified
0xF1,1,flag_highv,high-voltage flag,prior-verified
0xF2,1,flag_lowv_warn,low-voltage warning flag,prior-verified
0xF3,1,soc_like,SOC-like percent (remote or fallback),prior-verified
0xF4,1,fault_ch9,ADC1 CH9 fault F4,prior-verified
0xF5,1,ch9_cnt,ADC1 CH9 low counter,prior-verified
0xF8,2,ch9_avg,ADC1 CH9 averaged value,prior-verified
0xFC,1,lowv_debounce,low-voltage debounce counter,prior-verified
0xFE,2,vbus_raw,voltage-like ADC count (sum>>6),prior-verified
0x10A,1,flag_10a,inhibit condition flag 10A,prior-verified
0x10B,1,brake_branch_sel,selects braking-branch constants (0 vs nonzero),prior-verified
0x10C,1,brake_soc_block,active braking restriction set at SOC>=95,prior-verified
0x10E,2,active_brake_demand,active braking demand,prior-verified
0x11C,2,vq_like,q-axis-like voltage command,prior-verified
0x11E,2,vd_like,d-axis-like voltage command,prior-verified
0x128,2,i_alpha,alpha current,prior-verified
0x12A,2,i_beta,beta current,prior-verified
0x12C,2,v_alpha,inverse-Park alpha voltage,prior-verified
0x12E,2,v_beta,inverse-Park beta voltage,prior-verified
0x130,2,i_d,d-axis current feedback,prior-verified
0x132,2,i_q,q-axis current feedback,prior-verified
0x140,2,drive_cmd,drive command into PWM (cap 1023),prior-verified
0x144,6,phase_zero_offsets,phase current zero offsets (3 x s16),prior-verified
0x14C,1,inhibit_14c,inhibit condition 14C,prior-verified
0x153,1,mode_ramp_cnt,pending mode ramp cadence counter,prior-verified
0x158,2,throttle,expanded throttle byte (0..100),prior-verified
0x15A,2,target_speed,target speed for current mode (0.1 km/h),prior-verified
0x164,1,dir_armed,direction/start-state flag 164,prior-verified
0x165,1,dir_cfg_165,direction cfg flag 165,prior-verified
0x169,1,lowspeed_state_169,auxiliary low-speed state,prior-verified
0x178,2,held_reference,held reference (hold/cruise),prior-verified
0x17A,2,aux_timeout_cnt,aux low-speed timeout counter,prior-verified
0x17C,1,dir_reverse_cnt,direction reverse debounce counter,prior-verified
0x1A4,1,speed_accel_int,speed-trend integrator +-20,derived-from-code
0x1A6,2,speed_kmh10,measured signed speed (0.1 km/h units),prior-verified
0x1AA,2,requested_speed,requested speed = applied_ref*throttle/100,prior-verified
0x1AC,2,speed_trend_ref,slowly-tracking speed reference (+-1 per call),derived-from-code
0x1B2,2,coast_target,coast recovery target demand,prior-verified
0x1B4,2,coast_demand,coast recovery demand (slews by 5),prior-verified
0x1B6,2,brake_target_signed,signed braking target (-max(active,coast)),prior-verified
0x1BA,2,coast_adj,coast adjustment,prior-verified
0x1C2,2,speed_abs_copy,abs speed estimate copy,derived-from-code
0x1C4,2,speed_abs_raw,abs speed from period (0x36CAB/period),prior-verified
0x1C6,2,accel_step,current-error acceleration step,prior-verified
0x1D0,2,applied_reference,applied speed reference (ramped),prior-verified
0x1D6,1,flag_1d6,control flag 1D6,derived-from-code
0x1D7,1,hold_active,hold/cruise-like state flag,prior-verified
0x1DA,1,mode_ready,mode block ready,derived-from-code
0x1EC,1,profile_byte,dashboard frame byte 8 = energy-recovery selector (30/60/90) also child-cap trigger 0x3C,prior-verified
0x1F0,1,throttle_age,throttle frame age counter,prior-verified
0x207,1,special_state_207,low-speed braking special state,prior-verified
0x210,2,vbus_decivolt,FE*8850>>14 voltage telemetry,prior-verified
0x2F6,2,hall_period_copy,period copy used by scheduler functions,prior-verified
0x300,2,ctrl_445_ref,reference compared with ctrl+0x445,derived-from-code
0x310,2,elec_angle,electrical angle,prior-verified
0x31A,2,sin_theta,sine of angle,prior-verified
0x31C,2,cos_theta,cosine of angle,prior-verified
0x327,1,remote_state,UART1 remote state code (freshness),prior-verified
0x328,2,remote_temp,remote signed temperature byte,prior-verified
0x354,4,sysclk_hz,configured system clock (96 MHz),prior-verified
0x374,1,remote_status_flag,remote status flag (clamps recovery selector to 30),prior-verified
0x438,16,ctrl_block,controller parameter block (regen demands at +4/+6/+8),prior-verified
0x445,1,ctrl_445,control byte compared to ram 0x300,derived-from-code
0x498,4,child_state,child-mode state word (0 or 0xC1) v7.1/RC builds,prior-verified
0x8CA,16,remote_telemetry,UART1 selector 0x44 telemetry copy (SOC at +1 -> 0x8CB),prior-verified
0x8D1,1,persist_flags_8d1,persistent flag byte consumed by main inhibit,prior-verified
0x8D2,1,remote_status_8d2,selector44 status byte (mask 0x2C),prior-verified
"""
with open("ram_B.csv", "w", newline="", encoding="utf-8") as fp:
    w = csv.writer(fp)
    w.writerow(["addr", "size", "name", "desc", "conf"])
    for line in rows.strip().splitlines():
        parts = line.split(",")
        off, sz, name = parts[0], parts[1], parts[2]
        conf = parts[-1]
        desc = ",".join(parts[3:-1])
        w.writerow(["0x%08X" % (0x20000000 + int(off, 16)), sz, name, desc, conf])
print("ok")
