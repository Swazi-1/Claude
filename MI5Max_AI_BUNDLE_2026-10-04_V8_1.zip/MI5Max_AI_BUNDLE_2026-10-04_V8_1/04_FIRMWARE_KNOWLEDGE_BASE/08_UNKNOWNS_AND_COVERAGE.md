# Coverage ledger, resolved items, unknowns and suggested next steps

**Update 2026-10-04 (later): V8.1 CANDIDATE built, NOT flashed** (`01_FIRMWARE/1b_V8_1_CANDIDATE_not_flashed/`, SHA-256 `9218c5ef58b7...`). V8 600 + smooth low-battery ramp (600 at 20 % -> 274 at 10 %, no steps), Medium recovery no longer triggers the child cap (six-press only), smooth controller heat fade from 86 C (stock formula constant). V8 600 stays on the scooter and is the rollback until the owner flashes V8.1. Also corrected: the app's 'Scooter Temperature' (75 C max) is a controller temperature, not the motor.

Date of this ledger: 2026-10-03 (status note 2026-10-04: V8 FINAL 600 is on the scooter and works; see `../PROJECT_SUMMARY.md` section 7 for the current open items). Rules in force: analysis/documentation only; no live serial/BLE/device commands; no flashing; no tuning permission inferred from any report; original one-press power button priority #1; V8 FINAL 600 is on the scooter; V8.1 candidate built 2026-10-04, not flashed. Labels: **C** confirmed, **S** strong, **L** likely, **U** unknown.

## 1. Coverage ledger
| item | status |
|---|---|
| Image map (header, A, B, padding) | complete (`01_ARCHITECTURE.md`) |
| Program A code (file 0x1148..0x17567) | **849 / 849 functions named** (598 C, 250 L, 1 U; 22 `lib_*` routines = 1,272 bytes; 827 application functions = 83,248 bytes). Every function body was read from the lifted pseudo-code; ~93 % of the code range is covered by function bodies, the rest is literal pools/alignment/data. |
| Program A RAM | **1,215 / 1,215 cells named** (356 C, 55 S, 804 L); structs/buffers named as ranges |
| Program A data (file 0x17568..0x19224) | identity strings, NTC table, protection thresholds, BQ configuration (via emulation), charge-current table, ASCII command strings, peripheral config tables, model lookup tables **decoded or dumped**; model-table axis units, the scatter-load init data (0x18D48..) and a few small tables **not interpreted** |
| Program B code | **230 / 230 functions named** (132 C, 91 L, 2 S, 1 U, 4 unflagged); 158 application functions = 27,004 bytes; 72 library = 8,250 bytes |
| Program B RAM | **610 / 610 named** (365 C, 111 L, 112 prior-verified, 8 S, 8 U, 6 derived) |
| Peripherals | A: 53 registers resolved (`A_PERIPHERAL_MAP.md`); B: 131 registers (`B_PERIPHERAL_MAP.md`) |
| Protocols | UART0 (dash), UART1/USART1 (B-A, 0x63/0x74), A's 0x90 / 0x6E families, USART3 auth link, XMODEM/ASCII update, AES unlock: documented (`05_...`); the 17-object BMS register map **decoded from the initial RAM image** |
| BQ769x2 hardware configuration | 288-byte image obtained by running A:9F64 in an emulator; protection settings decoded (`06_...` section 7) |
| Builds | byte-level diff of stock / v7.1 / RC01 / RC02 with instruction-level reading of every behavioural patch (`07_...`) |
| Tools | `tools/` (disassembler, analysis, lifter, catalog generators, emulation and table-decoding scripts); regeneration steps in `00_README_FOR_AI.md` |

Rough "how much of the firmware is understood" (project's earlier estimate was ~60 % +/- 15): after this stage **function-level understanding of both programs is complete** (every function has a name and description, ~70 % at confirmed level by count); **behavioural understanding** is good for the control/protection/protocol chains and weaker for the generated SOC/SOH model internals, the exact meaning of several model tables, the dashboard side (not in the image) and the physical wiring.

## 2. Resolved during this stage (do not re-open without new evidence)
* BMS protection flag semantics: every bit of F72 / FA1 / FAC / FC3 / FCD / FD0 and the block aggregation (`04_FEATURE_CHAINS.md` section 3, `06_...` section 3).
* BQ769x2 enabled protections and thresholds (CUV 2.73 V, COV 4.25 V, SCD/OCD2 enabled, OCC/OCD1/OCD3 disabled, OT/UT 45/65/2/-18 C, HWD), 13S cell mapping (VC1..12 + VC16), DA configuration units (10 mA, 10 mV for stack/pack/LD).
* The A <-> B link is a **register read/write protocol**, not just identity: object 0x44 carries SOC, temperature, pack voltage, current and flags that B uses for regen/current limits; B also forwards BMS objects to the dashboard.
* Power chain facts on A: PA8 must be high for the DSG FET; pack_on from PB9-low or PACK-pin tracking; PB15 = charge inhibit; wake sources PA8/PB9/PB7(USART1 RX)/PB11(USART3 RX)/RTC timer.
* Child-cap mechanism (profile byte == 60 OR persistent flag), six-press gesture rules (speed 0, 41 s timeout), per-mode targets and envelopes of v7.1/RC (D 25.0, S 45.0, walking 20.0 uncapped; stock 20.3 / 25.3 / 6.2), regen 91/160/320 and the 5.0 km/h coast entry.
* Stock regional speed table (6.2 / 15.3 / 20.3 km/h for prefixes 60549/60558/61124).
* Corrections to earlier names: `bq_read_ld_pin_voltage`, `bq_read_pack_pin_voltage`, `bq_read_alert_pin_thermistor`, `full_charge_flag_update` / `full_charged_flag` (RAM 0x40), `rtc_wakeup_handler` / `RTC_IRQHandler`, `dsg_oc_report_latch`, `wake_no_reset_flag`.

## 3. Open unknowns (what we still do not know)
| # | unknown | why it matters | how it could be answered (without device commands) |
|---|---|---|---|
| 1 | What the 5 Max dashboard sends for Weak/Medium/Strong (exactly 30/60/90?), and whether it varies it on slopes | Medium-trigger reliability, regen behaviour | owner ride test T3-T5 of the Opus plan; a UART0 capture would be a live-device action (**not authorised**) |
| 2 | Dashboard riding-mode order and what it sends for walking | whether walking is capped/uncapped in the installed build | owner test T2 (count presses: see `09_...` warning) |
| 3 | IMU incline sign (`ram[0x376] = int(-10 * roll)`) vs the farm hill; whether the 4-second slope filter explains weak coast regen on descents | "regen bug" hypothesis 1 | ride log of the hill with the slope sign noted; simulation of the filter against GPS elevation |
| 4 | Real amps per count (B) and the shunt resistance (BQ) | converts counts/mV thresholds to amps | clamp-meter bench measurement (owner), or app current vs counts regression from existing recordings |
| 5 | Is the CHG FET in the regen path? (inference: no) | whether BMS protections can ever cut regen | ride data at 56 / 35 % already shows -6 to -9 A for > 4 s with A's 5.5 A/1 s soft latch; a controlled regen run at 5-6 A steady would pin it down |
| 6 | Dashboard / BLE / app behaviour, button decoding, the beep near 30 km/h | most user-visible behaviours | dashboard firmware not available; U |
| 7 | Whether A:5EE0 (BQ OTP write) can ever run on a configured pack | permanent-write risk assessment | static: it is gated by A:C138 (status vs 0xEB04 signature); full call-chain reachability proof still open |
| 8 | Peer on USART3, meaning of "vehicle data" fields (7 packed words), current-limit percent consumer | link semantics | requires board/schematic or a capture |
| 9 | SOC model internals: units of capacity constants 0x262C / 0x4C58, meaning of each lookup table | explains SOC jumps/anchors | decode model code with the tables (offline); compare with logged SOC from rides |
| 10 | NTC1/NTC2/ALERT-thermistor physical placement | meaning of "board OT", "cold NTC kills regen" | schematic/teardown |
| 11 | Exact effect of the v7.1 direction-threshold patch (3.0/5.0 km/h -> 0) and the thermal-derate threshold change | regen entry on descents | trace `dir_armed`/`lowspeed_latch` consumers (offline) |
| 12 | Exact meaning of each compared RAM cell in the RC02 eligibility routine (0x23950) | RC02 behaviour under non-nominal conditions | finish the cell-by-cell mapping (offline) |
| 13 | Bootloader behaviour (CRC enforcement, entry commands, A:0xE0 + 0x5AA5 path) | update safety | bootloader not in image |
| 14 | Installed image identity | all ride results are attributed to RC02 by owner statement | cannot be read without a device read (**not authorised**) |

## 4. Suggested next steps (none started)
1. **Offline (safe):** finish items 3 (slope filter vs elevation), 11, 12 and 9; extend `04_FEATURE_CHAINS.md` with a regen simulation using the real B functions in the emulator (as done earlier for the speed loop).
2. **Owner rides (already proposed earlier):** regen sweep at about 90 %, 95 %, 75 % charge; repeat the 56 % and 35 % power runs; the Opus T0-T10 plan with the press-counting precaution; log GPS speed and note slope direction.
3. **Documentation upkeep:** after any new analysis, regenerate catalogs (`00_README_FOR_AI.md` section 5), update this ledger and the memory note, refresh the continuation zip.

## 5. Known weak spots in the KB itself
* ~250 A function descriptions and many RAM descriptions are **L**: read from code but not exercised; names with `?`/`unused` mean no reader/writer was found.
* `ram_A_part00_auto.psv` names are generated from the owning function only (meaning unverified).
* Pseudo-code is machine-lifted: check the disassembly for any decisive detail (flag polarity, signed vs unsigned compares).
* The BQ configuration field names outside the protection block come from an automated parse of the TRM text and can be shifted.
* A few older annotation descriptions still mention DMA channel numbers that disagree with the register-block addresses (use `06_...` section 6).
