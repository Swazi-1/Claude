| addr | name | type | raw (LE) | value | TRM min/max/default/unit |
|---|---|---|---|---|---|
| 0x9231 | Min Blow Fuse Voltage | I2 | e015 | 5600 (0x15E0) |  |
| 0x9233 | Fuse Blow Timeout | U1 | 1e | 30 (0x1E) |  |
| 0x9234 | Power Config | H2 | a428 | 10404 (0x28A4) | 0x0000 0xFF 0x00 Hex |
| 0x9236 | REG12 Config | H1 | 0d | 13 (0xD) | 0x00 0xFF 0x00 Hex |
| 0x9237 | REG0 Config | H1 | 01 | 1 (0x1) | 0x00 0xFF 0 -- |
| 0x9238 | HWD Regulator Options | H1 | 24 | 36 (0x24) | 0x00 255 0 s |
| 0x9239 | Comm Type | U1 | 11 | 17 (0x11) | 0x00 0xFF 0x00 Hex |
| 0x923A | I2C Address | U1 | 00 | 0 (0x0) | 0x00 0xFF 0x07 Hex |
| 0x923B | ? | ? | 04 | 4 (0x4) |  |
| 0x923C | SPI Configuration | H1 | 00 | 0 (0x0) | 0x00 0xFF 0x00 Hex |
| 0x923D | Comm Idle Time | U1 | 00 | 0 (0x0) | 0 0xFF 0x00 Hex |
| 0x923E | ? | ? | 01 | 1 (0x1) |  |
| 0x923F | Shutdown Cell Voltage | I2 | 0000 | 0 (0x0) | 0 32767 |
| 0x9241 | Shutdown Stack Voltage | I2 | 5802 | 600 (0x258) | 0 150 1 s |
| 0x9243 | Low V Shutdown Delay | U1 | 0a | 10 (0xA) | 0 127 5 s |
| 0x9244 | Shutdown Temperature | U1 | 55 | 85 (0x55) | 0 250 0 0.25s |
| 0x9245 | Shutdown Temperature Delay | U1 | 0a | 10 (0xA) | 0 32767 5 min |
| 0x9246 | ? | ? | 62 | 98 (0x62) |  |
| 0x9247 | ? | ? | 02 | 2 (0x2) |  |
| 0x9248 | Sleep Current | I2 | 1400 | 20 (0x14) | 0 10mV |
| 0x924A | Voltage Time | U1 | 05 | 5 (0x5) | 1 Hex |
| 0x924B | Wake Comparator Current | I2 | f401 | 500 (0x1F4) | 500 3.3 ms |
| 0x924D | Sleep Hysteresis Time | U1 | 0a | 10 (0xA) | 0 50.6mV |
| 0x924E | ? | ? | b8 | 184 (0xB8) |  |
| 0x924F | ? | ? | 0b | 11 (0xB) |  |
| 0x9250 | ? | ? | 0a | 10 (0xA) |  |
| 0x9251 | ? | ? | 00 | 0 (0x0) |  |
| 0x9252 | FET Off Delay | U1 | 00 | 0 (0x0) | 0 32767 5 s |
| 0x9253 | Shutdown Command Delay | U1 | 00 | 0 (0x0) | 0 500 s |
| 0x9254 | Auto Shutdown Time | U1 | 00 | 0 (0x0) | 0 s |
| 0x9255 | RAM Fail Shutdown Time | U1 | 05 | 5 (0x5) | 0 10mV |
| 0x9256 | Security Settings | H1 | 00 | 0 (0x0) | 0x00 |
| 0x9257 | Unseal Key Step 1 | U2 | 1404 | 1044 (0x414) | 0x0100 |
| 0x9259 | Unseal Key Step 2 | U2 | 7236 | 13938 (0x3672) | 0x0100 |
| 0x925B | Full Access Key Step 1 | U2 | ffff | 65535 (0xFFFF) | 0x0100 |
| 0x925D | Full Access Key Step 2 | U2 | ffff | 65535 (0xFFFF) | 0x0100 |
| 0x925F | Protection Configuration | H2 | 0000 | 0 (0x0) | 0x0000 0xFF 0x07 Hex |
| 0x9261 | Enabled Protections A | U1 | cc | 204 (0xCC) | 0x00 0xFF 0x0D Hex |
| 0x9262 | Enabled Protections B | U1 | 33 | 51 (0x33) | 0x00 32767 0 mV |
| 0x9263 | Enabled Protections C | U1 | 02 | 2 (0x2) | 0x00 255 5 10ms |
| 0x9264 | ? | ? | 00 | 0 (0x0) |  |
| 0x9265 | CHG FET Protections A | U1 | 98 | 152 (0x98) | 0x00 32767 100 userA |
| 0x9266 | CHG FET Protections B | U1 | 11 | 17 (0x11) | 0x00 |
| 0x9267 | CHG FET Protections C | U1 | 02 | 2 (0x2) | 0x00 |
| 0x9268 | ? | ? | 00 | 0 (0x0) |  |
| 0x9269 | DSG FET Protections A | U1 | e4 | 228 (0xE4) | 0x00 |
| 0x926A | DSG FET Protections B | U1 | 22 | 34 (0x22) | 0x00 |
| 0x926B | DSG FET Protections C | U1 | 02 | 2 (0x2) | 0x00 |
| 0x926C | ? | ? | 00 | 0 (0x0) |  |
| 0x926D | Default Alarm Mask | H2 | 0100 | 1 (0x1) | 0x0000 |
| 0x926F | SF Alert Mask A | U1 | 00 | 0 (0x0) | 0x00 |
| 0x9270 | SF Alert Mask B | U1 | 00 | 0 (0x0) | 0x00 |
| 0x9271 | SF Alert Mask C | U1 | 00 | 0 (0x0) | 0x00 |
| 0x9272 | ? | ? | 00 | 0 (0x0) |  |
| 0x9273 | Body Diode Threshold | I2 | 6400 | 100 (0x64) | 0 |
| 0x9275 | CUV Threshold (x50.6 mV) | U1 | 36 | 54 (0x36) |  |
| 0x9276 | CUV Delay (x3.3 ms) | U2 | 2f01 | 303 (0x12F) |  |
| 0x9278 | COV Threshold (x50.6 mV) | U1 | 54 | 84 (0x54) |  |
| 0x9279 | COV Delay (x3.3 ms) | U2 | 5e02 | 606 (0x25E) |  |
| 0x927B | CUV Recovery Hysteresis (x50.6 mV) | U1 | 0b | 11 (0xB) |  |
| 0x927C | COV Recovery Hysteresis (x50.6 mV) | U1 | 03 | 3 (0x3) |  |
| 0x927D | COVL Latch Limit | U1 | 00 | 0 (0x0) |  |
| 0x927E | COVL Counter Dec Delay (s) | U1 | 0a | 10 (0xA) |  |
| 0x927F | COVL Recovery Time (s) | U1 | 0f | 15 (0xF) |  |
| 0x9280 | OCC Threshold (x2 mV) | U1 | 02 | 2 (0x2) |  |
| 0x9281 | OCC Delay (x3.3 ms) | U1 | 04 | 4 (0x4) |  |
| 0x9282 | OCD1 Threshold (x2 mV) | U1 | 04 | 4 (0x4) |  |
| 0x9283 | OCD1 Delay (x3.3 ms) | U1 | 01 | 1 (0x1) |  |
| 0x9284 | OCD2 Threshold (x2 mV) | U1 | 0f | 15 (0xF) |  |
| 0x9285 | OCD2 Delay (x3.3 ms) | U1 | 0f | 15 (0xF) |  |
| 0x9286 | SCD Threshold (enum) | U1 | 05 | 5 (0x5) |  |
| 0x9287 | SCD Delay (x15 us) | U1 | 1f | 31 (0x1F) |  |
| 0x9288 | OCC Recovery Threshold (userA) | I2 | 38ff | -200 (0xFF38) |  |
| 0x928A | OCD3 Threshold (userA) | I2 | 60f0 | -4000 (0xF060) |  |
| 0x928C | OCD3 Delay (s) | U1 | 02 | 2 (0x2) |  |
| 0x928D | OCD Recovery Threshold (userA) | I2 | 9cff | -100 (0xFF9C) |  |
| 0x928F | OCDL Latch Limit | U1 | 00 | 0 (0x0) |  |
| 0x9290 | OCDL Counter Dec Delay (s) | U1 | 0a | 10 (0xA) |  |
| 0x9291 | OCDL Recovery Time (s) | U1 | 0f | 15 (0xF) |  |
| 0x9292 | OCDL Recovery Threshold (userA) | I2 | c800 | 200 (0xC8) |  |
| 0x9294 | SCD Recovery Time (s) | U1 | 06 | 6 (0x6) |  |
| 0x9295 | SCDL Latch Limit | U1 | 00 | 0 (0x0) |  |
| 0x9296 | SCDL Counter Dec Delay (s) | U1 | 0a | 10 (0xA) |  |
| 0x9297 | SCDL Recovery Time (s) | U1 | 0f | 15 (0xF) |  |
| 0x9298 | SCDL Recovery Threshold (userA) | I2 | c800 | 200 (0xC8) |  |
| 0x929A | OTC Threshold (C) | I1 | 2d | 45 (0x2D) |  |
| 0x929B | OTC Delay (s) | U1 | 03 | 3 (0x3) |  |
| 0x929C | OTC Recovery (C) | I1 | 28 | 40 (0x28) |  |
| 0x929D | OTD Threshold (C) | I1 | 41 | 65 (0x41) |  |
| 0x929E | OTD Delay (s) | U1 | 05 | 5 (0x5) |  |
| 0x929F | OTD Recovery (C) | I1 | 3c | 60 (0x3C) |  |
| 0x92A0 | OTF Threshold (C) | U1 | 50 | 80 (0x50) |  |
| 0x92A1 | OTF Delay (s) | U1 | 02 | 2 (0x2) |  |
| 0x92A2 | OTF Recovery (C) | U1 | 41 | 65 (0x41) |  |
| 0x92A3 | OTINT Threshold (C) | I1 | 55 | 85 (0x55) |  |
| 0x92A4 | OTINT Delay (s) | U1 | 02 | 2 (0x2) |  |
| 0x92A5 | OTINT Recovery (C) | I1 | 50 | 80 (0x50) |  |
| 0x92A6 | UTC Threshold (C) | I1 | 02 | 2 (0x2) |  |
| 0x92A7 | UTC Delay (s) | U1 | 03 | 3 (0x3) |  |
| 0x92A8 | UTC Recovery (C) | I1 | 05 | 5 (0x5) |  |
| 0x92A9 | UTD Threshold (C) | I1 | ee | -18 (0xEE) |  |
| 0x92AA | UTD Delay (s) | U1 | 05 | 5 (0x5) |  |
| 0x92AB | UTD Recovery (C) | I1 | f0 | -16 (0xF0) |  |
| 0x92AC | UTINT Threshold (C) | I1 | ec | -20 (0xEC) |  |
| 0x92AD | UTINT Delay (s) | U1 | 02 | 2 (0x2) |  |
| 0x92AE | UTINT Recovery (C) | I1 | f1 | -15 (0xF1) |  |
| 0x92AF | Protections Recovery Time (s) | U1 | 02 | 2 (0x2) |  |
| 0x92B0 | OCC PACK-TOS Delta (10 mV) | I2 | c800 | 200 (0xC8) |  |
| 0x92B2 | HWD Delay (s) | U2 | bc02 | 700 (0x2BC) |  |
| 0x92B4 | Load Detect Active Time (s) | U1 | 00 | 0 (0x0) |  |
| 0x92B5 | Load Detect Retry Delay (s) | U1 | 00 | 0 (0x0) |  |
| 0x92B6 | Load Detect Timeout (hrs) | U2 | 0000 | 0 (0x0) |  |
| 0x92B8 | ? | ? | 90 | 144 (0x90) |  |
| 0x92B9 | ? | ? | 01 | 1 (0x1) |  |
| 0x92BA | Charge Threshold | I2 | fa00 | 250 (0xFA) | -32768 255 5 s |
| 0x92BC | Delay | U2 | 0807 | 1800 (0x708) | 0 32767 5 |
| 0x92BE | Reset | I2 | 0100 | 1 (0x1) | 0 255 10 |
| 0x92C0 | Enabled PF A | U1 | 00 | 0 (0x0) | 0x00 |
| 0x92C1 | Enabled PF B | U1 | 00 | 0 (0x0) | 0x00 |
| 0x92C2 | Enabled PF C | U1 | 0f | 15 (0xF) | 0x00 |
| 0x92C3 | Enabled PF D | U1 | 00 | 0 (0x0) | 0x00 |
| 0x92C4 | PF Alert Mask A | U1 | 00 | 0 (0x0) | 0x00 |
| 0x92C5 | PF Alert Mask B | U1 | 00 | 0 (0x0) | 0x00 |
| 0x92C6 | PF Alert Mask C | U1 | 00 | 0 (0x0) | 0x00 |
| 0x92C7 | PF Alert Mask D | U1 | 00 | 0 (0x0) | 0x00 |
| 0x92C8 | Threshold | I2 | dc05 | 1500 (0x5DC) | 0 5500 5 |
| 0x92CA | Delay | U1 | 02 | 2 (0x2) | 0 3700 |
| 0x92CB | Threshold | I2 | 9808 | 2200 (0x898) | 0 |
| 0x92CD | Delay | U1 | 05 | 5 (0x5) | 0 |
| 0x92CE | Threshold | I2 | 9411 | 4500 (0x1194) | 0 |
| 0x92D0 | Delay | U1 | 05 | 5 (0x5) | 0 |
| 0x92D1 | Threshold | I2 | f401 | 500 (0x1F4) | 0 |
| 0x92D3 | Delay | U1 | 05 | 5 (0x5) | 0 |
| 0x92D4 | Threshold | I2 | 1027 | 10000 (0x2710) | -32768 |
| 0x92D6 | Delay | U1 | 05 | 5 (0x5) | 0 |
| 0x92D7 | Threshold | I2 | 0083 | -32000 (0x8300) | -32768 |
| 0x92D9 | Delay | U1 | 05 | 5 (0x5) | 0 |
| 0x92DA | Threshold | I1 | 41 | 65 (0x41) | -40 |
| 0x92DB | Delay | U1 | 05 | 5 (0x5) | 0 |
| 0x92DC | Threshold | U1 | 55 | 85 (0x55) | 0 |
| 0x92DD | Delay | U1 | 05 | 5 (0x5) | 0 |
| 0x92DE | Check Voltage | I2 | ac0d | 3500 (0xDAC) | 0 |
| 0x92E0 | Max Relax Current | I2 | 0a00 | 10 (0xA) | 10 |
| 0x92E2 | Threshold | I2 | f401 | 500 (0x1F4) | 0 |
| 0x92E4 | Delay | U1 | 05 | 5 (0x5) | 0 |
| 0x92E5 | Relax Min Duration | U2 | 6400 | 100 (0x64) | 0 |
| 0x92E7 | Check Voltage | I2 | 740e | 3700 (0xE74) | 0 |
| 0x92E9 | Min Active Current | I2 | 3200 | 50 (0x32) | 10 5500 200 mV |
| 0x92EB | Threshold | I2 | c800 | 200 (0xC8) | 0 5000 20 mA |
| 0x92ED | Delay | U1 | 05 | 5 (0x5) | 0 -10 -20 mA |
| 0x92EE | OFF Threshold | I2 | 1400 | 20 (0x14) | 10 32767 100 -- |
| 0x92F0 | OFF Delay | U1 | 05 | 5 (0x5) | 0 255 5 s |
| 0x92F1 | OFF Threshold | I2 | ecff | -20 (0xFFEC) | -5000 255 5 s |
| 0x92F3 | OFF Delay | U1 | 05 | 5 (0x5) | 0 0xFFFF 0x00 Hex |
| 0x92F4 | Fail Threshold | I2 | 6400 | 100 (0x64) | 1 0xFFFF 0x3672 Hex |
| 0x92F6 | Delay | U1 | 05 | 5 (0x5) | 0 0xFFFF |
| 0x92F7 | Delay | U1 | 05 | 5 (0x5) | 0 |
| 0x92F8 | Delay | U1 | 05 | 5 (0x5) | 0 |
| 0x92F9 | Delay | U1 | 05 | 5 (0x5) | 0 |
| 0x92FA | CFETOFF Pin Config | H1 | 00 | 0 (0x0) | 0x00 0xFF 0x05 Hex |
| 0x92FB | DFETOFF Pin Config | H1 | 00 | 0 (0x0) | 0x00 255 80 Num |
| 0x92FC | ALERT Pin Config | H1 | aa | 170 (0xAA) | 0x00 0xFF 0x88 Hex |
| 0x92FD | TS1 Config | H1 | 07 | 7 (0x7) | 0x00 0xFF 0x00 Hex |
| 0x92FE | TS2 Config | H1 | 00 | 0 (0x0) | 0x00 0xFF 0xD5 Hex |
| 0x92FF | TS3 Config | H1 | 00 | 0 (0x0) | 0x00 0xFF 0xE4 Hex |
| 0x9300 | HDQ Pin Config | H1 | 00 | 0 (0x0) | 0x00 0xFF 0xE2 Hex |
| 0x9301 | DCHG Pin Config | H1 | 00 | 0 (0x0) | 0x00 0xFFFF 0xF800 Hex |
| 0x9302 | DDSG Pin Config | H1 | 00 | 0 (0x0) | 0x00 0xFF 0xF7 Hex |
| 0x9303 | DA Configuration | H1 | 06 | 6 (0x6) | 0x00 0xFF 0x5F Hex |
| 0x9304 | Vcell Mode | H2 | ff8f | 36863 (0x8FFF) | 0x0000 0xFF 0x00 Hex |
| 0x9306 | ? | ? | 00 | 0 (0x0) |  |
| 0x9307 | CC3 Samples | U1 | 50 | 80 (0x50) | 2 0xFF 0x00 Hex |
| 0x9308 | FET Options | H1 | 2e | 46 (0x2E) | 0x00 |
| 0x9309 | Chg Pump Control | U1 | 01 | 1 (0x1) | 0x00 |
| 0x930A | Precharge Start Voltage | I2 | 0000 | 0 (0x0) | 0 |
| 0x930C | Precharge Stop Voltage | I2 | 0000 | 0 (0x0) | 0 |
| 0x930E | Predischarge Timeout | U1 | 00 | 0 (0x0) | 0 |
| 0x930F | Predischarge Stop Delta | U1 | 00 | 0 (0x0) | 0 |
| 0x9310 | Dsg Current Threshold | I2 | 0a00 | 10 (0xA) | 0 |
| 0x9312 | Chg Current Threshold | I2 | 0a00 | 10 (0xA) | 0 255 5 s |
| 0x9314 | Check Time | U1 | 14 | 20 (0x14) | 0 m |
| 0x9315 | Cell 1 Interconnect | I2 | 0000 | 0 (0x0) | 0 32767 0 |
| 0x9317 | Cell 2 Interconnect | I2 | 0000 | 0 (0x0) | 0 32767 0 m |
| 0x9319 | Cell 3 Interconnect | I2 | 0000 | 0 (0x0) | 0 32767 0 m |
| 0x931B | Cell 4 Interconnect | I2 | 0000 | 0 (0x0) | 0 32767 0 m |
| 0x931D | Cell 5 Interconnect | I2 | 0000 | 0 (0x0) | 0 32767 0 m |
| 0x931F | Cell 6 Interconnect | I2 | 0000 | 0 (0x0) | 0 32767 0 m |
| 0x9321 | Cell 7 Interconnect | I2 | 0000 | 0 (0x0) | 0 32767 0 m |
| 0x9323 | Cell 8 Interconnect | I2 | 0000 | 0 (0x0) | 0 32767 0 m |
| 0x9325 | Cell 9 Interconnect | I2 | 0000 | 0 (0x0) | 0 32767 0 m |
| 0x9327 | Cell 10 Interconnect | I2 | 0000 | 0 (0x0) | 0 32767 0 m |
| 0x9329 | Cell 11 Interconnect | I2 | 0000 | 0 (0x0) | 0 32767 0 m |
| 0x932B | Cell 12 Interconnect | I2 | 0000 | 0 (0x0) | 0 32767 0 m |
| 0x932D | Cell 13 Interconnect | I2 | 0000 | 0 (0x0) | 0 32767 0 m |
| 0x932F | Cell 14 Interconnect | I2 | 0000 | 0 (0x0) | 0 32767 0 m |
| 0x9331 | Cell 15 Interconnect | I2 | 0000 | 0 (0x0) | 0 32767 0 m |
| 0x9333 | Cell 16 Interconnect | I2 | 0000 | 0 (0x0) | 0 32767 0 m |
| 0x9335 | Balancing Configuration | H1 | 03 | 3 (0x3) | 0x00 0xFF 0x00 Hex |
| 0x9336 | Min Cell Temp | I1 | ec | -20 (0xEC) | -128 127 -20 C |
| 0x9337 | Max Cell Temp | I1 | 3c | 60 (0x3C) | -128 127 60 C |
| 0x9338 | Max Internal Temp | I1 | 46 | 70 (0x46) | -128 127 70 C |
| 0x9339 | Cell Balance Interval | U1 | 14 | 20 (0x14) | 1 255 20 s |
| 0x933A | Cell Balance Max Cells | U1 | 06 | 6 (0x6) | 0 16 1 Num |
| 0x933B | ? | ? | d8 | 216 (0xD8) |  |
| 0x933C | ? | ? | 0e | 14 (0xE) |  |
| 0x933D | ? | ? | 32 | 50 (0x32) |  |
| 0x933E | ? | ? | 14 | 20 (0x14) |  |
| 0x933F | Cell Balance Min Cell V (Relax) | I2 | d80e | 3800 (0xED8) | 0 5000 3900 mV |
| 0x9341 | Cell Balance Min Delta (Relax) | U1 | 32 | 50 (0x32) | 0 255 40 mV |
| 0x9342 | ? | ? | 14 | 20 (0x14) |  |
| 0x9343 | Mfg Status Init | H2 | 5000 | 80 (0x50) | 0x0000 0xFFFF 0x0040 Hex |
| 0x9345 | ? | ? | 00 | 0 (0x0) |  |
| 0x9346 | ? | ? | 00 | 0 (0x0) |  |
| 0x9347 | ? | ? | 00 | 0 (0x0) |  |
| 0x9348 | ? | ? | 00 | 0 (0x0) |  |
| 0x9349 | ? | ? | 00 | 0 (0x0) |  |
| 0x934A | ? | ? | 00 | 0 (0x0) |  |
| 0x934B | ? | ? | 00 | 0 (0x0) |  |
| 0x934C | ? | ? | 00 | 0 (0x0) |  |
| 0x934D | ? | ? | 00 | 0 (0x0) |  |
| 0x934E | ? | ? | 00 | 0 (0x0) |  |
| 0x934F | ? | ? | 00 | 0 (0x0) |  |
| 0x9350 | ? | ? | 00 | 0 (0x0) |  |
