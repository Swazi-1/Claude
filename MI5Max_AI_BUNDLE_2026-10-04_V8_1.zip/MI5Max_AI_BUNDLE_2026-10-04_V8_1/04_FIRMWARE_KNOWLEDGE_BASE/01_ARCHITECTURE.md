# Architecture: hardware, image layout, boot flow

Evidence labels: **C** confirmed from code/bytes, **S** strong, **L** likely, **U** unknown. The dashboard firmware, the bootloader and the schematic are **not available**; anything about them is inference.

## 1. System picture
```
 +-----------------+  button, lights, display        +---------------------------------------------+
 | dashboard MCU   |  (firmware NOT available)        |  scooter body                                |
 +--------+--------+                                  |                                              |
          | UART0 19200                               |   battery pack 13S (13 x 4.2 V = 54.6 V)     |
          v                                           |   +-- BQ769x2 AFE (I2C2 addr 0x08)           |
 +------------------+   UART1 19200 (hdr 0x63/0x74)   |   +-- A: N32G43x-class Cortex-M4F (BMS)      |
 | B  LKS32MC071    |<------------------------------->|        USART1 19200 / USART3 4800            |
 |  Cortex-M0 FOC   |                                 |        SPI1 -> NOR flash (log/history/update)|
 |  motor controller|-- hall x3, phase currents, DC link current/voltage, NTCs, IMU (I2C0 0x6B)      |
 +------------------+                                 +---------------------------------------------+
```
* The update package ("the .bin", 147,456 = 0x24000 bytes) contains **two firmware programs for two different processors** plus small headers. Program **A** (battery side) is byte-identical in all known builds (stock, farm v7.1, RC01, RC02, V8 FINAL 600 and its 640/680 variants); all differences are in program **B** and the header (647 bytes in RC02 vs stock, in 40 runs; from the earlier work).
* Identical numeric RAM/peripheral addresses in A and B are **different physical spaces** (e.g. 0x40013000 is SPI-like in A, DSP/CORDIC in B).

## 2. Image layout (file offsets)
| file range | content | notes |
|---|---|---|
| 0x0000..0x002D | outer package header (starts `00 02 38 00 ...`, contains ASCII `0108` at 0x12, CRC fields) | CRC calculation established earlier (C); enforcement by the bootloader unknown |
| 0x002E..0x07FF | 0xFF | |
| 0x0800..0x080C | A-package header: ASCII `DEPRD5C` + `01 88 00 B9 FE` | the same string `DEPRD5C` is what A's update receiver compares against (ROM 0x8017A0C/0x8017A10) **C** |
| 0x080D..0x0FFF | 0xFF | |
| **0x1000..0x19223** | **program A** (Cortex-M4F): vector table at 0x1000 (initial SP 0x20004E40, reset 0x0800315D), code, then tables/strings/packed data; runtime address = file + 0x08002000 (app base 0x08003000) | internal flash 0x08000000..0x08002FFF (bootloader) is **not** in the image **U** |
| 0x19224..0x197FF | 0xFF | |
| 0x19800..0x19817 | B header | |
| **0x19818..0x2381B** | **program B** (Cortex-M0): vector table at 0x19818, runtime = file - 0x17018 (so vectors at 0x2800), code and tables | B flash 128 KB, RAM 12 KB (LKS32MC071CBT8) |
| 0x2381C..0x23FFF | 0xFF | |

Runtime-only flash pages (written by the running programs, not part of the image): A internal flash pages 0x801C800 / 0x801D000 (0x20-byte stat records), 0x801D800 (0x14-byte update descriptor), 0x801E000 / 0x801E800 (settings, CRC16 at +0x7FE), 0x801F000 / 0x801F800 (0x38-byte model state records); B flash pages 0x1F200 (IMU calibration), 0x1F800 (identity/serial), 0x1FA00 (settings), 0x1FC00 (update commit record), staging 0xF000.. Both programs do their own wear-levelling by appending records / alternating pages.

## 3. Program A (battery side)  - details in `03_PROGRAM_A_BMS.md`
* MCU: Cortex-M4F (FPU enabled in SystemInit), Nations N32G43x-class (peripheral names from the n32g4 SPL: RCC, EXTI, USART, DMA, I2C, SPI, ADC, RTC, IWDG). SystemInit A:11CB4: FPU on, clock config (HSI -> PLL ~96 MHz, fallback 4 MHz), VTOR = 0x08003000. **C/L**
* Main: `main` A:1707A -> `swtimer_start_defaults` A:9A44 (software timers), `boot_init_b` A:36F4, `main_init_a` A:3034 (clock, 1 ms SysTick, RTC, I2C driver, USART1+DMA, ADC, SPI1, IWDG), `app_init_sequence` A:1DF4 (BQ init, params, SPI log init, RTC read ...), then loop `swtimer_dispatch` A:4CBC. Almost everything runs from four software-timer callbacks (1 / 10 / 100 / 500 ms). **C**
* Interrupts used: SysTick (1 ms software-timer tick), EXTI0 and EXTI4 (clear-only), EXTI9_5 (line 7 = PB7 = USART1 RX activity, line 8 = PA8, line 9 = PB9), EXTI15_10 (line 11 = PB11 = USART3 RX activity), **RTC wake-up timer** (`RTC_IRQHandler` -> `rtc_wakeup_handler`; sleep wake source 1 = timer, 2 = pin), I2C2 event/error (recovery handlers), USART1, USART3 (IDLE-line DMA receive), two DMA wrappers. All other vectors point to endless-loop handlers (HardFault etc. are traps). **C** (vector table decode; names in catalog)
* Pins observed in code (labels from function use; the physical nets are **U**): PA4 SPI CS, PA5 SCK, PA6 MISO, PA7 MOSI (NOR flash); PB6/PB7 USART1 TX/RX (PB7 is also the EXTI7 wake line); PB10/PB11 USART3 TX/RX (PB11 EXTI11 wake); **PA8** wake / discharge-enable input (EXTI both edges, level read for the DSG FET request); **PB9** low-active input / wake (EXTI falling; pack-on request); **PB14** output (`pb14_ctrl_logic`); **PB15** output = charge-inhibit (set on charge OT/UT) and part of `pre_shutdown_pins_and_reinit`; **PB1** output pulsed for the BQ reset/shutdown handshake; **PA2** output set in `pre_shutdown_pins_and_reinit`; PB10 is configured as output low in the sleep pin table; all other pins are put to analog input in sleep (`gpio_all_analog`, table at ROM 0x80199D4, 16 entries). **C/L**
* BQ769x2 on I2C2, 7-bit address 0x08; pack = 13 series cells wired to VC1..VC12 + VC16. **C**
* External NOR flash (JEDEC C84014 / C84013 / A14014 = GigaDevice GD25Q80-class, 1 MB) on SPI1: event log, history, RTC backup, NTC calibration and update staging. **C**

## 4. Program B (motor controller)  - details in `02_PROGRAM_B_MOTOR_CONTROLLER.md`
* MCU: **LKS32MC071CBT8** (Linko), Cortex-M0, 96 MHz, 128 KB flash / 12 KB RAM; peripheral names from the LKS32MC07x manual (MCPWM0, ADC0/ADC1 with DMA-like rings, HALL0, UART0/UART1, I2C0, DSP0 (CORDIC/divider/sqrt), CRC0, IWDG, comparators for the hardware over-current path). **C**
* Three-phase BLDC drive with Hall sensors: field-oriented control, q-axis voltage-commanded, d-axis current reference zero, SVPWM at 15.625 kHz, dead-time compensation. **C**
* Peripheral roles seen in code: IMU on I2C0 (device 0x6B, WHO_AM_I 0x6A, LSM6DS-class); UART0 to the dashboard; UART1 to the BMS (A); GPIO3 bit 9 = power latch; GPIO2 bits 3/10/12 = software-PWM/toggle outputs (light-like outputs, **L**); DAC0 value 203 sets the hardware over-current comparator threshold (lowered to 51 during the self-test).

## 5. Boot flow summary
* **A:** reset -> `SystemInit` -> `main` as above; sleeping/power states are driven by `pack_power_state_machine` (A:11DE8) from the 10 ms task (see `04_FEATURE_CHAINS.md` section 1).
* **B:** `Reset_Handler` B:1999C -> `SystemInit` B:1FFC8 (VTOR = 0x2800, clock) -> `__main` -> `main` B:2292C: `hardware_init`, `startup_calibrate_and_load` (load settings/identity/calibration, measure DC-current zero, self-test), IMU probe, then the scheduler loop driven by the MCPWM ISR. **C**
* Update: both programs implement their own receivers (A: USART1 ASCII + XMODEM-style into the SPI NOR then descriptor in internal flash; B: UART0 service frames / XMODEM into staging flash 0xF000 + commit record 0x1FC00). Both rely on a bootloader that is not in the image **U**.

## 6. Conventions used across the KB
* IDs: `A:<file-offset-hex>` / `B:<file-offset-hex>`; runtime = file + 0x08002000 for A, file - 0x17018 for B. Names are stored in `annotations/names_A_part*.psv`, `names_B_part*.psv`; RAM in `ram_A_part*.psv`, `ram_B*.psv`; peripherals in `periph_*.csv`; regenerate catalogs with `tools/` (see `00_README_FOR_AI.md`).
* Units: A: mV, mA (BQ CC2 x 10), whole degrees C unless stated; B: speed in 0.1 km/h, voltage in raw ADC counts or decivolts (`vbus_raw * 8850 >> 14`), currents in controller counts (~27.4 on the dashboard's conversion; measured 27.2 counts/A at 560/600/680, S), temperatures per sensor routine.
* Sign conventions: A current positive = charging (BQ convention), direction state 0 = charge / 1 = discharge / 2 = idle; the app/dashboard shows regen as negative current. IMU incline cell `ram[0x376] = int(-10 * roll_deg)`; which physical direction is positive is **U**.
