# Program A: the battery-side BMS firmware (Cortex-M4F + BQ769x2)

Coverage: **all 849 functions are named** (`annotations/names_A_part01..09.psv`; 564 flagged C, 249 L, rest mostly small/lib); **all 1,215 RAM cells are named** (`ram_A_part00_auto.psv` = 173 private single-owner cells, `ram_A_part01..03.psv` hand-written). Catalogs: `A_FUNCTION_CATALOG.md`, `A_RAM_MAP.md`, `A_PERIPHERAL_MAP.md`. Pseudo-code: `data/A_pseudocode.txt` (24,839 lines, machine-lifted, verify against `data/A_annotated_disassembly.txt`). Program A is **byte-identical in stock / v7.1 / RC01 / RC02**. Labels: **C** confirmed, **S** strong, **L** likely, **U** unknown.

## 1. What it is
A battery-management firmware around a **TI BQ769x2 analog front end** (7-bit I2C address 0x08, on I2C2) for a **13-series pack (VC1..VC12 + VC16)**. It supervises cell voltages/temperatures/current, decides when the discharge (DSG) and charge (CHG) FETs may be on, estimates SOC/SOH with a generated coulomb/OCV model, keeps logs in an external SPI NOR flash, exposes a register map to the motor controller (B) and the app/dashboard, handles sleep/wake and the firmware-update and authentication links. The pack's full voltage constant in ROM is 54,600 mV (= 13 x 4.2 V).

## 2. Function index by address range (IDs are `A:<file offset hex>`)
| range | content |
|---|---|
| 0x1148..0x1580 | C runtime: `__main`, scatter-load/decompress, soft-float (double add/sub), memcpy/memset/strlen/rand |
| 0x1580..0x2D00 | ADC/DMA setup, BQ direct-command readers (`bq_read_*`), BQ init (`bq_afe_init`), I2C helpers, USART1/3 init, RCC/clock wrappers, EXTI setup |
| 0x2D00..0x3F00 | I2C2 init, `main_init_a`, GPIO table init (`gpio_table_init` A:332C), SysTick init, event flag setters (`ev_set_84_bN`, `ev_set_88_bN`), `ev_dispatch_84` |
| 0x3F00..0x5000 | `usart3_link_tx_sequencer` (A:3F00), power-state decisions (`power_on_off_decision` A:4344, `chg_connect_debounce_fsm` A:4508), `fault_flag_aggregator` A:46EC, `fet_request_compute` A:4630, `chg_fet_control` A:48F8, `rx` frame handling (A:4A30/4A4C/4B04), software timers (A:4BC0..4CBC) |
| 0x5000..0x63B2 | DMA/EXTI wrappers, `dsg_fet_control` A:5274, `link_status_pack_send`, registry (A:583C, A:5DD8), `pre_shutdown_pins_and_reinit` A:5B98, `power_rail_sequence_a`, `wake_full_reinit` A:5DBC, `bq_otp_write_path` A:5EE0 (gated), stress-time state |
| 0x63B8..0x8BEC | **generated SOC/SOH model** (A:63B8 .. A:7A30: `coulomb_counter_step`, `soc_model_*`, `soh_*`, `ocv_rest_tracker`...), `current_limit_curves` A:7494, flash data-page driver (A:7FDC), SPI NOR driver (A:82F0 erase, 8380 read, 84A0 program), GPIO/EXTI SPL, calendar (`calendar_days_since` A:8938), model port getters (A:8D90..8F58), `cell_voltage_copy_or_default` A:8BEC |
| 0x8F7C..0xC6A4 | BQ fault latching (`bq_safety_status_react` A:9134), I2C drivers (A:AF94, B978, BB14), parameter defaults (A:9B44..9DDC), flash record logs, `rx_frame_router` A:A6B0, power-mode transitions, `bq_config_image_write` A:C158, RCC SPL |
| 0xC708..0x105C4 | RCC clocks, RTC, SPI-flash logs/persistence (event ring, history, RTC backup), update/auth link (A:DDC4..E0B4), model dispatch (`model_scheduler` A:E658, model init A:EC70..F038), the **software protection state machines** (A:F1EC deep discharge, F290/F304 FET-mismatch current faults, F36C/F5C4 NTC plausibility, F40C imbalance, F694 cell plausibility, F994 charge OC, FBF8 cell OV, FCD0 cell UV, FDAC/FE74 charge OT/UT + PB15, FF3C discharge OC, 103B8 discharge OT, 10468 discharge UT) |
| 0x105C4..0x11CAC | pack UV level 2, board OT, SPI1 driver, clock config, model port setters (A:10E5C..110E4), `power_mode_step` A:110FC, `internal_resistance_estimator`, `soc_correction_triggers` A:11350, `model_init_sequence` A:11894, protection groups (A:11978/11998/119C4), `spi_flash_buffered_write` A:119E4 |
| 0x11CB4..0x1330C | `SystemInit`, **`pack_power_state_machine` A:11DE8**, the four software-timer callbacks (A:12A64 1 ms, 129B4 10 ms, 128E4 100 ms, 12A78 500 ms) and their task lists, NTC conversion A:12804, USART1/3 IRQ + queues |
| 0x13376..0x177D6 | `bms_register_block_publish` A:1337C (+ init A:139FC), history log, XMODEM-style update receiver (A:15588..15FFC), table interpolation (A:16FDE), `main` A:1707A |
| 0x17568..0x19224 | **data, not code**: identity strings (0x17575), NTC table (0x17B3C), thresholds (0x17D90..), model lookup tables (OCV and discharge-curve families, 0x17E7A..0x18D0C; `06_A_ROM_TABLES.md` section 8), ASCII commands (0x1893C), peripheral config tables (0x187A8..), scatter-load init data (0x18D48), limit curves (0x18C2C..0x18D0C) |

## 3. Scheduler (what runs when)  **C**
* `main` loops `swtimer_dispatch`; six software-timer slots (RAM 0x164C, 16 bytes each) driven by a 1 ms SysTick counter.
* **1 ms** (`SWTIMER_CB_1ms` A:12A64 -> `task1ms_comms`): USART1/USART3 TX start, RX frame parse, wake-pin filter (only in power states where valid).
* **10 ms** (A:129B4): `task10ms_main` A:12470 = `pack_power_state_machine`, `power_state_flags_update`, `model_scheduler`, in states 0/1: `model_init_sequence`, `fault_flag_aggregator`, `pb14_ctrl_logic`, scheduled BQ accessors, `power_mode_state_machine`; in 0/1/2: `power_on_off_decision`. Plus a 10-slot round-robin (RAM 0xB58): settings flush / I2C timeout arm (0,5), events+persist / **protection + IWDG feed (1)**, limit curves (2), stress time (3), cell statistics (4, 9).
* **100 ms** (A:128E4): load detect + FET management (`task_load_detect_and_fets` A:1238C), and two round-robins: 5 entries (I2C object recovery, BQ-present debounce, ...) and 10 entries (UV command, energy logs, temperature stats, model 6CCC/70D8/11350/6978 steps, BQ init part 2 + RTC read, ...).
* **500 ms** (A:12A78): persist flush of all counters (state 0 only), charger-connect debounce, BQ status re-read, I/O polls.
* IWDG started in `main_init_a` (0xFFF); fed from the 10 ms protection task (states 0, 1, 2, 4) and `settings_housekeeping`.

## 4. Key state variables (A RAM; full list in `A_RAM_MAP.md`)
| RAM | name | meaning |
|---|---|---|
| 0x2E / 0x2F / 0x35 | `pack_pwr_state` / `power_mode_state` / `power_state` | top-level pack on/off machine, power-mode (sleep) machine, MCU power state (1 active, 2 brief wake, 3 shutdown/sleep, 4 update, 5 other) |
| 0x80 | `current_dir_state` | 0 charging, 1 discharging, 2 idle (100 mA hysteresis) |
| 0x107 | `pack_on` | output enabled |
| 0x3C / 0x3D / 0x3E | `chg_block` / `dsg_block` / `general_block` | aggregated fault blocks |
| 0xA65 / 0xA66 | `dsg_fet_request` / `chg_fet_request` | FET requests (`04_FEATURE_CHAINS.md` section 3) |
| 0xF72, 0xFA1, 0xFAC, 0xFC3, 0xFCD, 0xFD0, 0xF73 | `prot_flags_*`, `bq_fault_flags` | soft latches + BQ-derived flags (bit tables in `06_A_ROM_TABLES.md` section 3 and `04_...` section 3) |
| 0xF10.. | `cell_mv[13]` | cell voltages (mV) |
| 0xF95 / 0xF99 / 0xF9B / 0xF9D | `pack_mv` / `cell_mean_mv` / `cell_min_mv` / `cell_max_mv` | statistics |
| 0xFBB / 0xFBF | `pack_current_signed` / `pack_current_abs` | mA (BQ CC2 x 10; + = charging) |
| 0xFC7..0xFCC | `temp_mean_c`, `temp_min_c`, `temp_max_c`, `temp_max_recorded` | temperatures (whole C) |
| 0xFD3 / 0xFD4 / 0xFDB / 0xFDF | `soc_percent` / `soh_percent` / `full_capacity` / `remaining_capacity` | model outputs |
| 0x1344..0x13CA | `port_*` | variables exchanged with the generated model code |
| 0x13CE..0x14ED | `param_image` | 288-byte BQ769x2 data-memory image |
| 0x15F9..0x164B | `bq_*` | BQ769x2 direct-command register image |
| 0x106E..0x108D | `reg_*` | the externally visible register block |
| 0x164C | `swtimer_slots` | software timers |
| 0x16AD..0x1F01 | USART buffers/rings | 3 x 0x98 B slots per ring |

## 5. Protections and FET control
See `04_FEATURE_CHAINS.md` section 3 (aggregation, FET request rule) and `06_A_ROM_TABLES.md` sections 3 and 7 (soft thresholds and the BQ hardware configuration). Highlights: two layers (BQ hardware: CUV 2.73 V, COV 4.25 V, SCD/OCD2, OT/UT 45/65/2/-18 C, host watchdog; A soft latches evaluated every 100 ms: OV 4.22 V, UV 2.77 V, deep discharge 1.5 V, imbalance 500 mV/120 s, OC charge 4.5/5.5 A, OC discharge 22/25 A, temperature, board 90 C, spread 8 C); block flags -> FET requests -> BQ subcommands; PB15 charge inhibit.

## 6. BQ769x2 interface and configuration
* Driver: I2C2 polled + IRQ (A:AF94 init, B978/BB14 transfers, recovery A:9714/96DC), optional CRC8 (poly 0x07) transactions through function pointers at RAM 0xEF0/0xEF4; direct commands in `bq_read_*`; subcommands via `bq_cmd_write16` (A:1BDC); data memory read A:CEE0, write A:155AC, block write A:280C (30 bytes in two 15-byte chunks plus checksum/length registers 0x60/0x61).
* `bq_afe_init` (A:1CF6): config patch (A:11C5E writes 0x11 bytes at data memory 0x9239 + subcommand 0x29BC), delays, subcommand 0x9A, `bq_otp_configured_check` (A:C138: status cache vs signature 0xEB04), `bms_params_init_wrap` (A:C200 -> A:9F64), `bq_config_image_write` (A:C158), `bq_otp_write_path` (A:5EE0, CFGUPDATE + OTP_WRITE 0xA1 - **reachability on a configured pack: U**; gated by A:C138), status read.
* Configuration image: see `06_A_ROM_TABLES.md` section 7 (obtained by emulating A:9F64).
* Calibration checks: data-memory 0x91A0/91A2/91A4/91B2 read back three times each; 0x91A2 valid range 0x7D00..0x8CA0 else rewritten with 0x84D0 (`bq_ld_gain_check_91a2`).
* Load detect: `load_detect_control` A:A7EC issues LOAD_DETECT_ON/OFF (0x9E/0x9F) and judges the LD pin (< 4000 x 10 mV for > 10 samples -> load present).

## 7. SOC / SOH model
Generated code (A:63B8..A:7A30 + A:E160..E808, A:EA64): coulomb counter step with a 3,600,000 divisor (`coulomb_counter_step` A:6618), OCV rest tracking, SOC state machine (A:6838/69E4/6CCC...), SOH degradation and capacity steps, current-zero calibration steps, two-timer latches; inputs/outputs go through ~60 tiny getter/setter "port" functions (A:8D90..8F58, A:10E5C..110E4, A:164D4..1657C) around RAM 0x1344..0x13CA. Anchors from `soc_correction_triggers` A:11350 (section 5 of `04_FEATURE_CHAINS.md`). Persistence: state records (0x38 bytes) in internal flash pages 0x801F000/0x801F800 appended by `persist_model_event_a/b/c`; flush flags (RAM 0x8C bits 9..18) map to counters: bit9 0xF77 fault count, 10 0xFAA UV count, 11 0xFC4, 12 0xFCC max temp, 13 0xF79 charge energy, 14 0xF7D discharge energy, 15 0xF81 resistance, 16 0xF85, 17 0xF8F stress times, 18 0xF93. The model's lookup tables are in the 0x17E7A..0x18D0C data region (`06_A_ROM_TABLES.md` section 8; **unit/meaning of the capacity constants 0x262C / 0x4C58: U**).

## 8. Registers published (what the dashboard/app/B can read)
The 17-object register map and the exact field layout are in `05_PROTOCOLS_AND_REGISTERS.md` section 3.3. The main telemetry object 0x44 = [max-cell byte, SOC %, pack mV BE, current (10 mA, sign-magnitude) BE, temperature (sign-magnitude), flags BE].

## 9. Storage (A)  **C/S**
| medium | address | content |
|---|---|---|
| internal flash | 0x801C800 / 0x801D000 | 0x20-byte statistics records (marker 0xAA, mirrored pages, slot index RAM 0x7D) |
| internal flash | 0x801D800 | 0x14-byte image descriptor (flag, length, CRC) for the updater |
| internal flash | 0x801E000 / 0x801E800 | settings pages (CRC16 at +0x7FE) |
| internal flash | 0x801F000 / 0x801F800 | 0x38-byte model state records (slot index RAM 0x7C) |
| SPI NOR (GD25Q80 class) | 0x20000 | event-log header; ring 0x21000..0x25E20 of 0x28-byte records (session start/stop, SOC anchors (events 8/9), power-down events...) |
| | 0x30000 | NTC calibration block (CRC checked) |
| | 0x40000 | history header; ring 0x41000..0x45000 of 0x20-byte records (CRC8 poly 0x2F) |
| | 0x50000 / 0x51000 | redundant RTC backup (8 bytes + CRC8) |
| | (staging) | firmware-update data (2 KB buffer, 4 KB sector erase, CRC16 check) |

## 10. Known gaps / things not to over-trust
* ~249 function names and many flag-bit meanings are **L** (read from code, not exercised). Names such as `get_ram_f6a` are placeholders.
* The meaning of the ROM tables between 0x17E98 and 0x18D0C (model OCV curve, discharge-curve families, breakpoint axes) is only partly decoded (shapes known, axis units not) (`06_A_ROM_TABLES.md`).
* No schematic: pin roles are inferred from code (`01_ARCHITECTURE.md` section 3).
* DMA channel numbers in a few older descriptions (e.g. "DMA1 ch5") are inconsistent; use the register-block addresses in `06_A_ROM_TABLES.md` section 6 (USART1 RX 0x40020094 / TX 0x40020080; USART3 RX 0x4002006C / TX 0x40020058).
* Corrections made during this stage: A:20C4 reads the LD pin (BQ 0x38), A:2138 the PACK pin (0x36), A:2358 the ALERT-pin thermistor (0x70); RAM 0x40 is the *fully-charged* flag (not a discharge-enable debounce); A:3168 is the RTC wake-up handler (not a PB14 EXTI); A:14CAC is a *discharge* over-current report latch (not charge).
