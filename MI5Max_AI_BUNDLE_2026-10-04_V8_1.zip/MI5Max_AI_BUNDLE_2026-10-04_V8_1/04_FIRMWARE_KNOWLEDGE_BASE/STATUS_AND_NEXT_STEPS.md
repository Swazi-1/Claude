# Firmware KB status (updated 2026-10-03, second stretch)

**Update 2026-10-04 (later): V8.1 CANDIDATE built, NOT flashed** (`01_FIRMWARE/1b_V8_1_CANDIDATE_not_flashed/`, SHA-256 `9218c5ef58b7...`). V8 600 + smooth low-battery ramp (600 at 20 % -> 274 at 10 %, no steps), Medium recovery no longer triggers the child cap (six-press only), smooth controller heat fade from 86 C (stock formula constant). V8 600 stays on the scooter and is the rollback until the owner flashes V8.1. Also corrected: the app's 'Scooter Temperature' (75 C max) is a controller temperature, not the motor.

**Wrap-up 2026-10-04:** V8 FINAL 600 is on the scooter and works (22.1 A cap, 1.0-1.17 kW on a 10 degree climb, controller ('Scooter Temperature' in the app) max 75 C, no cut-out). Owner decided to leave the firmware as it is. Master summary: `../PROJECT_SUMMARY.md`. The text below is the older 2026-10-03 status, kept for the headline findings.

Standing rules: analysis/documentation only; no device commands, no flashing by Claude; original power button first; keep confirmed/strong/likely/unknown separate. **V8 FINAL 600 exists (2026-10-04): `01_FIRMWARE/1_CURRENT_ON_SCOOTER_V8_FINAL_600/`** (RC02 + stock regen + Sport 600; owner flashed and rode it). Power ceiling = A's soft latches 22 A/10 s and 25 A/1 s (`11_POWER_ENVELOPE_SWEEP.md`).

## State: the KB is complete at the planned level
**Start with `00_README_FOR_AI.md`** (it indexes everything). Delivered in this stretch (after the first stretch's tools + program B + program A read-through):
* Pipeline re-run for A: `A_FUNCTION_CATALOG.md`, `A_RAM_MAP.md`, `A_PERIPHERAL_MAP.md` generated; **849/849 A functions and 1,215/1,215 A RAM cells named**; B 230/230 functions, 610/610 RAM.
* Loader fix: `.psv` descriptions may contain `|`; last field is the C/S/L/U flag.
* Docs: `00_README_FOR_AI.md`, `01_ARCHITECTURE.md`, `02_PROGRAM_B_MOTOR_CONTROLLER.md`, `03_PROGRAM_A_BMS.md`, `04_FEATURE_CHAINS.md` (regen, power, protections->FETs, charging, telemetry, caps), `05_PROTOCOLS_AND_REGISTERS.md` (all frame formats + the decoded 17-object BMS register map), `06_A_ROM_TABLES.md` (thresholds, NTC, charge-current table, model tables, **BQ769x2 configuration decoded by running A's parameter builder in the Unicorn emulator**), `07_BUILDS_AND_DIFFS.md` (+ generated tables; instruction-level patch reading), `08_UNKNOWNS_AND_COVERAGE.md`, `09_OPUS_CHILDMODE_CROSSCHECK.md`.
* The Opus child-mode report (extracted to `../02_MODEL_HANDOFFS/Opus_ChildMode_Options_Report/`) was checked against the code (`09_...`).
* New tools: `autoname_ram.py`, `ramdump.py`, `romconst.py`, `protsum.py`, `emu_a_params.py`, `bq_dm_decode.py`, `make_rom_tables.py`, `diff_builds.py` (+ `unicorn`, `capstone` installed for the owner's "install what you need" rule).

## Headline findings of this stretch (details in the docs)
1. **A <-> B is a register protocol:** B polls A for 17 objects; object 0x44 gives SOC, pack V, current, temperature, flags; B uses SOC and the BMS temperature to gate/cap regen and current.
2. **Regen gates (B):** 0 < battery T < 45 C, terminal voltage < 54.0 V (coast adjustment), profile byte exactly 30/60/90, SOC >= 90 caps Strong to Medium, SOC >= 95 blocks brake regen, IMU slope flag caps to Weak.
3. **BQ769x2 config recovered:** CUV 2.73 V, COV 4.25 V, SCD/OCD2, OT/UT 45/65/2/-18 C enabled; OCC/OCD1/OCD3 disabled; 13S on VC1-12 + VC16; COV/OCC act on the **charge FET only**; A's soft latches (100 ms) mirror and extend them.
4. **Custom builds (v7.1/RC):** D target 25.0, S 45.0 km/h (stock 20.3/25.3), walking selector 20.0 km/h unless child cap; child cap = profile byte 60 **OR** persistent flag; six standstill mode changes within ~41 s toggle the flag; regen 91/160/320, coast regen from 5.0 km/h. Program A is byte-identical in all builds.
5. **Open puzzle:** ride data show regen of -6 to -9 A for > 4 s at 35/50 % charge although A's soft charge-OC latch (>= 5.5 A for 1 s) should have blocked the charge FET -> the charge FET is probably not in the regen path (inference).

6. **Downhill regen delay (new):** the real firmware in the emulator regenerates 0.05-0.1 s after release at 30 km/h at all charge levels 35-90 %; the "rolls then regen later" symptom needs an abnormal input: the IMU slope clamp to Weak (time-based: sets after ~4 s, clears after ~5 s of flat) or coast demand off (temperature window / recovery value) -> see `10_REGEN_ENTRY_DELAY_ANALYSIS.md`. Higher regen strength is not the cause.

## Still open (see `08_UNKNOWNS_AND_COVERAGE.md` for the full table)
Dashboard values/mode order on a 5 Max, IMU sign vs the hill, real amps per count, SOC-model table units, RC02 eligibility-routine cell map, bootloader, installed-image identity. Offline next steps: slope-filter vs elevation study, regen simulation with the real B functions, finish `lut`/model table decoding.

## Housekeeping
* Regenerate everything: see `00_README_FOR_AI.md` section 5.
* Memory notes: `memory/project_firmware_kb_status.md` (updated).
* Optional (needs the owner's go): owner-ride tests (regen sweep ~90/95/75 % SOC, repeat 56/35 % runs, Opus T0-T10 with the press-counting precaution), sending an Opus child-mode package, refreshing the large continuation zip.
