# A RAM map (symbolic names, accessors)

RAM base 0x20000000 (offsets shown). Names come from annotations (ram_A*.csv/psv); conf C/S/L/U as above. `R` = functions reading, `W` = functions writing (by name or ID).

| offset | size | name | conf | meaning | readers | writers | const-writes |
|---|---|---|---|---|---|---|---|
| 0x0 | 1 | flag_bq_recovery_done | L | set to 1 by bq_fault_response_1 after four BQ re-init cycles; read by pack_power_state_machine | pack_power_state_machine | pack_power_state_machine, bq_fault_response_1 | 0,1 |
| 0x1 | 1 | wake_no_reset_flag | L | A:108D8 sets 1 when RCC_CTRLSTS reset-cause flags (bits 31..24) are all clear (wake from STOP without reset), 0 if any flag is set; while 1 the DSG FET request is held off (A:4630); cleared by pack_power_state_machine when PA8 stayed high >4 ticks in state 0 or before final shutdown in state 2 | pack_power_state_machine, fet_request_compute | vbus_wake_flag_update, pack_power_state_machine | 0,1 |
| 0x2 | 2 | power_mode_step_2 | C | private state of power_mode_step (only this function touches it) | power_mode_step | power_mode_step | 0 |
| 0x4 | 2 | power_mode_step_4 | C | private state of power_mode_step (only this function touches it) | power_mode_step | power_mode_step | 0 |
| 0x8 | 4 | power_tick_08 | L | tick counter incremented in power_mode_step; set to 0x10E0 (4320) by pack_voltage_ref_init; cleared by low_soc_poweroff_request | power_mode_step, low_soc_poweroff_request | power_mode_step, pack_voltage_ref_init, low_soc_poweroff_request | 0,10E0 |
| 0xC | 4 | ir_tick_counter | L | tick counter of internal_resistance_estimator (period 0x870 ticks); cleared by pack_voltage_ref_init | power_mode_step, internal_resistance_estimator | power_mode_step, internal_resistance_estimator, pack_voltage_ref_init | 0 |
| 0x10 | 4 | pack_mv_reference | L | reference pack voltage for internal_resistance_estimator (follows 0xF95 while no voltage drop is seen) | internal_resistance_estimator | internal_resistance_estimator, pack_voltage_ref_init | - |
| 0x14 | 4 | pack_power_state_machine_14 | C | private state of pack_power_state_machine (only this function touches it) | pack_power_state_machine | pack_power_state_machine | 0 |
| 0x18 | 2 | pack_power_state_machine_18 | C | private state of pack_power_state_machine (only this function touches it) | pack_power_state_machine | pack_power_state_machine | 0 |
| 0x1A | 2 | pack_power_state_machine_1A | C | private state of pack_power_state_machine (only this function touches it) | pack_power_state_machine | pack_power_state_machine | 0 |
| 0x1C | 2 | pack_power_state_machine_1C | C | private state of pack_power_state_machine (only this function touches it) | pack_power_state_machine | pack_power_state_machine | 0 |
| 0x1E | 2 | pack_power_state_machine_1E | C | private state of pack_power_state_machine (only this function touches it) | pack_power_state_machine | pack_power_state_machine | 0 |
| 0x20 | 2 | pack_power_state_machine_20 | C | private state of pack_power_state_machine (only this function touches it) | pack_power_state_machine | pack_power_state_machine | 0 |
| 0x22 | 2 | pack_power_state_machine_22 | C | private state of pack_power_state_machine (only this function touches it) | pack_power_state_machine | pack_power_state_machine | 0 |
| 0x24 | 2 | pack_power_state_machine_24 | C | private state of pack_power_state_machine (only this function touches it) | pack_power_state_machine | pack_power_state_machine | 0 |
| 0x26 | 2 | pack_power_state_machine_26 | C | private state of pack_power_state_machine (only this function touches it) | pack_power_state_machine | pack_power_state_machine | 0 |
| 0x28 | 2 | pack_power_state_machine_28 | C | private state of pack_power_state_machine (only this function touches it) | pack_power_state_machine | pack_power_state_machine | 0 |
| 0x2A | 2 | pack_power_state_machine_2A | C | private state of pack_power_state_machine (only this function touches it) | pack_power_state_machine | pack_power_state_machine | 0 |
| 0x2C | 1 | power_mode_step_2C | C | private state of power_mode_step (only this function touches it) | power_mode_step | power_mode_step | 2 |
| 0x2D | 1 | power_mode_step_2D | C | private state of power_mode_step (only this function touches it) | power_mode_step | power_mode_step | 0 |
| 0x2E | 1 | pack_pwr_state | L | top-level pack on/off state machine (A:11DE8): 0 idle/wait, 1 pre-connect, 2 wake-hold, 3 final shutdown (PB1 pulse + BQ shutdown), 4 wait update | power_state_flags_update, pack_power_state_machine, rtc_wakeup_handler, load_detect_control | pack_power_state_machine | 0,1,2,3 |
| 0x2F | 1 | power_mode_state | L | power-mode state machine (A:110FC): 0 enter sleep, 1 sleeping, 2 short measurement wake, 3 active | power_mode_step, rtc_wakeup_handler | power_mode_step, pack_power_state_machine | 0,1,2,3 |
| 0x30 | 1 | pack_power_state_machine_30 | C | private state of pack_power_state_machine (only this function touches it; written once, never read) | - | pack_power_state_machine | 0 |
| 0x31 | 1 | session_flag_31 | L | 1 while a power-on session is fresh; when 1 the reported age in days is 0 (A:1337C); mirrored into 0xF76 | power_state_flags_update, bms_register_block_publish, power_on_session_logic, chg_connect_debounce_fsm | power_on_session_logic | 0,1 |
| 0x33 | 1 | aux_flag_33 | L | mirrored into 0xF75 by power_state_flags_update | power_state_flags_update | - | - |
| 0x35 | 1 | power_state | S | MCU power state: 1 active, 2 brief wake, 3 shutdown/sleep, 4 update/boot mode, 5 other; gates nearly every periodic task | task_load_detect_and_fets, task_protection_and_wdt, task_limit_curves, task_stress_time, task10ms_main | power_mode_step, pack_power_state_machine, task_chg_connect | 0,1,2,3 |
| 0x36 | 1 | state_in_0_1_4 | L | 1 when pack_pwr_state is 0, 1 or 4 | fet_request_compute | power_state_flags_update | 0,1 |
| 0x37 | 1 | wake_source_flags | L | set by EXTI/timer wake: 1 timer, 2 pin | power_mode_step, sleep_loop_stop_mode | power_mode_step, rtc_wakeup_handler | 0,1,2 |
| 0x39 | 1 | fault_flag_39_unused | L | written by fault_flag_aggregator (A:46EC); no reader found | - | fault_flag_aggregator | 0,1 |
| 0x3A | 1 | fault_flag_3A_unused | L | written by fault_flag_aggregator; no reader found | - | fault_flag_aggregator | 0,1 |
| 0x3B | 1 | fault_flag_3B_unused | L | written by fault_flag_aggregator; no reader found | - | fault_flag_aggregator | 0,1 |
| 0x3C | 1 | chg_block | S | 1 = charging must be blocked (aggregate of charge-side latches); read by fet_request_compute and pack_ready_check | fet_request_compute, fault_flag_aggregator, pack_ready_check, port_get_any_block_flag | fault_flag_aggregator | 0,1 |
| 0x3D | 1 | dsg_block | S | 1 = discharge must be blocked (aggregate of discharge-side latches); read by fet_request_compute | fet_request_compute, fault_flag_aggregator | fault_flag_aggregator | 0,1 |
| 0x3E | 1 | general_block | L | 1 = general fault block (aggregate), blocks both directions in fet_request_compute | fet_request_compute, fault_flag_aggregator, pack_ready_check, port_get_any_block_flag | fault_flag_aggregator | 0,1 |
| 0x3F | 1 | sleep_stop_flag | L | written by sleep_loop_stop_mode, read by rtc_wakeup_handler | rtc_wakeup_handler | sleep_loop_stop_mode | - |
| 0x40 | 1 | full_charged_flag | S | fully charged: 1 when SOC = 100 % while pack_on (A:8160); cleared 6 ticks after SOC < 100; blocks the CHG FET request (A:4630) and pack_ready_check; reported as register-block flag bit 12 | get_full_charged_flag | full_charge_flag_update | 0 |
| 0x41 | 1 | full_charged_clear_cnt | L | ticks with SOC < 100 before the full-charged flag clears | full_charge_flag_update | full_charge_flag_update | 0 |
| 0x42 | 1 | power_on_session_cnt | L | counter in power_on_session_logic | power_on_session_logic | power_on_session_logic | 0 |
| 0x44 | 1 | temp_ntc1_c | C | NTC1 temperature in whole degrees C (signed); fallback 25 (0x19) | bms_register_block_publish, history_record_build, ntc_correction_calc, ntc1_plausibility | cell_voltage_copy_or_default | 19 |
| 0x45 | 1 | temp_ntc2_c | C | NTC2 temperature in whole degrees C (signed) | bms_register_block_publish, history_record_build, ntc1_plausibility | ntc1_read_convert | - |
| 0x46 | 2 | cell_voltage_copy_or_default_46 | C | private state of cell_voltage_copy_or_default (only this function touches it; written once, never read) | - | cell_voltage_copy_or_default | FA |
| 0x48 | 2 | ntc1_read_convert_48 | C | private state of ntc1_read_convert (only this function touches it; written once, never read) | - | ntc1_read_convert | 0 |
| 0x4A | 5 | temp_stats | C | statistics over the two NTC temps (A:50B0): +0 mean, +1 min, +2 max, +3 argmin, +4 argmax; copied to 0xFC7..0xFCB by A:1093C | temps_copy_and_track_max | - | - |
| 0x4B | 1 | temp_stats+0x1 | C | (inside temp_stats) | temps_copy_and_track_max | - | - |
| 0x4C | 1 | temp_stats+0x2 | C | (inside temp_stats) | temps_copy_and_track_max | - | - |
| 0x4D | 1 | temp_stats+0x3 | C | (inside temp_stats) | temps_copy_and_track_max | - | - |
| 0x4E | 1 | temp_stats+0x4 | C | (inside temp_stats) | temps_copy_and_track_max | - | - |
| 0x52 | 1 | cell_voltage_copy_or_default_52 | C | private state of cell_voltage_copy_or_default (only this function touches it; written once, never read) | - | cell_voltage_copy_or_default | - |
| 0x59 | 1 | chg_energy_log_active | L | energy_counter_charge_log running flag | energy_counter_charge_log | energy_counter_charge_log, state_record_unpack_a | 0,1 |
| 0x5A | 1 | dsg_energy_log_active | L | energy_counter_discharge_log running flag | energy_counter_discharge_log | energy_counter_discharge_log, state_record_unpack_a | 0,1 |
| 0x5C | 2 | ntc1_adc_filt | L | filtered ADC count of NTC1 (ntc1_read_convert) | ntc1_read_convert | ntc1_read_convert | - |
| 0x5E | 2 | ntc2_adc_filt | L | filtered ADC count of NTC2 (ntc2_read_convert) | ntc2_read_convert | ntc2_read_convert | - |
| 0x60 | 1 | temps_copy_and_track_max_60 | C | private state of temps_copy_and_track_max (only this function touches it) | temps_copy_and_track_max | temps_copy_and_track_max | 0 |
| 0x64 | 4 | chg_energy_acc_a | L | charge-energy accumulator part a (energy_counter_charge_log) | energy_counter_charge_log | energy_counter_charge_log | - |
| 0x68 | 4 | chg_energy_acc_b | L | charge-energy accumulator part b | energy_counter_charge_log | energy_counter_charge_log | - |
| 0x6C | 4 | dsg_energy_acc_a | L | discharge-energy accumulator part a (energy_counter_discharge_log) | energy_counter_discharge_log | energy_counter_discharge_log | - |
| 0x70 | 4 | dsg_energy_acc_b | L | discharge-energy accumulator part b | energy_counter_discharge_log | energy_counter_discharge_log | - |
| 0x74 | 2 | stress_time_state12_74 | C | private state of stress_time_state12 (only this function touches it) | stress_time_state12 | stress_time_state12 | 0 |
| 0x76 | 2 | stress_time_state12_76 | C | private state of stress_time_state12 (only this function touches it) | stress_time_state12 | stress_time_state12 | 0 |
| 0x78 | 2 | stress_time_state0_78 | C | private state of stress_time_state0 (only this function touches it) | stress_time_state0 | stress_time_state0 | - |
| 0x7A | 1 | moving_average_10_7A | C | private state of moving_average_10 (only this function touches it) | moving_average_10 | moving_average_10 | - |
| 0x7B | 1 | moving_average_10_7B | C | private state of moving_average_10 (only this function touches it) | moving_average_10 | moving_average_10 | 0 |
| 0x7C | 1 | log_slot_idx_1F000 | L | slot index of the 0x38-byte state record pages 0x801F000/0x801F800 | state_log_append_1f000 | state_log_append_1f000 | 0 |
| 0x7D | 1 | log_slot_idx_1C800 | L | slot index of the 0x20-byte stat record pages 0x801C800/0x801D000 | state_log_append_1c800 | state_log_append_1c800 | 0 |
| 0x80 | 1 | current_dir_state | S | pack current direction: 0 charging, 1 discharging, 2 idle (A:15588, 100 mA threshold); 27 readers | dsg_ut_latch, pack_uv_level2_latch, soc_correction_triggers, sleep_counter_update, pack_power_state_machine | - | - |
| 0x82 | 2 | settings_pending_bits | L | settings housekeeping page-dirty bits (A:C368) | settings_housekeeping | settings_block_load, settings_housekeeping | 0 |
| 0x84 | 2 | ev_pending_84 | S | pending model/persist events set by ev_set_84_bN (bit0 soc acc, 1 persist a, 2 persist b(1350), 3 persist b(134C), 4 persist c(1356), 5 persist c(1354), 6 event 1357); dispatched by A:3CAC | ev_set_84_b1, ev_set_84_b0, ev_set_84_b2, ev_set_84_b3, ev_set_84_b6 | ev_set_84_b1, ev_set_84_b0, ev_set_84_b2, ev_set_84_b3, ev_set_84_b6 | - |
| 0x86 | 2 | calib_dirty_86 | L | calibration block apply flag (A:calibration_block_apply / bms_new_second_housekeeping) | calibration_block_apply | calibration_block_apply, bms_new_second_housekeeping | 0,1 |
| 0x88 | 1 | housekeeping_pending_88 | L | bit mask of pending settings housekeeping (ev_set_88_bN); bit4 = write 0x54-byte block at 0x1004 to settings page 4 | task_settings_flush, ev_set_88_b2, ev_set_88_b4, ev_set_88_b0, ev_set_88_b5 | ev_set_88_b2, ev_set_88_b4, ev_set_88_b0, ev_set_88_b5, ev_set_88_b4_dup | - |
| 0x89 | 1 | power_mode_89 | L | state byte of power_mode_state_machine (0/1/2) | power_mode_state_machine, fet_request_compute | power_mode_state_machine | 0,1,2 |
| 0x8A | 1 | wake_pb11_state | L | filtered PB11 wake-pin state (wake_pin_filter_pb11); 1 = asserted | power_mode_state_machine, usart3_link_tx_sequencer, power_on_off_decision | wake_pin_filter_pb11, power_on_off_decision | 0,1 |
| 0x8C | 4 | persist_request_flags | S | bit mask of counters to flush to flash: bit9 0xF77, 10 0xFAA, 11 0xFC4, 12 0xFCC, 13 0xF79, 14 0xF7D, 15 0xF81, 16 0xF85, 17 0xF8F, 18 0xF93 | temps_copy_and_track_max, internal_resistance_estimator, persist_request_bit9, persist_request_bit11, persist_request_bit10 | temps_copy_and_track_max, internal_resistance_estimator, persist_request_bit9, persist_request_bit11, persist_request_bit10 | - |
| 0x90 | 8 | status_pkt_90 | L | status packet header built by A:1337C: [0]=0xD8,[1]=0xD9,[2..3]=age days,[4..5]=0xF6A,[6]=wake-pin counter 0x104,[7]=0xEF | - | bms_register_block_publish | - |
| 0x91 | 1 | status_pkt_90+0x1 | L | (inside status_pkt_90) | - | bms_register_block_publish | - |
| 0x92 | 2 | status_pkt_90+0x2 | L | (inside status_pkt_90) | - | bms_register_block_publish | - |
| 0x94 | 2 | status_pkt_90+0x4 | L | (inside status_pkt_90) | - | bms_register_block_publish | - |
| 0x96 | 1 | status_pkt_90+0x6 | L | (inside status_pkt_90) | - | bms_register_block_publish | - |
| 0x97 | 1 | status_pkt_90+0x7 | L | (inside status_pkt_90) | - | bms_register_block_publish | - |
| 0x98 | 7 | rtc_datetime | L | RTC fields from rtc_read_datetime: +0 sec, +1 min, +2 hour, +3 day of month, +4 month, +5 year-2000, +6 weekday | bms_register_block_publish, bms_register_block_init, history_record_build, session_event_logger, ble_pkt_assemble | bms_register_block_init, history_record_build, session_event_logger, ram98_copy7, calendar_days_since | - |
| 0x99 | 1 | rtc_datetime+0x1 | L | (inside rtc_datetime) | bms_register_block_publish, bms_register_block_init, history_record_build, session_event_logger, eventlog_build_record | - | - |
| 0x9A | 1 | rtc_datetime+0x2 | L | (inside rtc_datetime) | bms_register_block_publish, bms_register_block_init, history_record_build, session_event_logger, calendar_days_since | - | - |
| 0x9B | 1 | rtc_datetime+0x3 | L | (inside rtc_datetime) | bms_register_block_publish, bms_register_block_init, history_record_build, session_event_logger, calendar_days_since | - | - |
| 0x9C | 1 | rtc_datetime+0x4 | L | (inside rtc_datetime) | bms_register_block_publish, bms_register_block_init, history_record_build, session_event_logger, ble_pkt_assemble | bms_register_block_init, history_record_build, session_event_logger, ram98_copy7, calendar_days_since | - |
| 0x9D | 1 | rtc_datetime+0x5 | L | (inside rtc_datetime) | bms_register_block_publish, bms_register_block_init, history_record_build, session_event_logger, calendar_days_since | - | - |
| 0x9E | 1 | rtc_datetime+0x6 | L | (inside rtc_datetime) | bms_register_block_publish, bms_register_block_init, ble_pkt_assemble | bms_register_block_init, history_record_build, session_event_logger, ram98_copy7, calendar_days_since | - |
| 0xA6 | 1 | ntc_cal_state | L | NTC calibration/CRC state flag (ntc_validate_crc / ntc_offset_load) | ntc1_read_convert, ntc2_read_convert | ntc_correction_calc, ntc_validate_crc, ntc_offset_load | 0 |
| 0xCC | 4 | flash_crc32 | L | CRC32 of the application flash region (crc32_of_flash) | - | crc32_of_flash | - |
| 0xD0 | 4 | image_crc32 | L | CRC32 result of image_crc32_check | - | image_crc32_check | - |
| 0xD8 | 1 | link_state_D8 | L | link/status byte 0 (init = 1); copied to status_pkt_90[0] | pack_power_state_machine, bms_register_block_publish | pack_power_state_machine, bms_register_block_init, link_reset_flags | 1 |
| 0xD9 | 1 | link_state_D9 | L | link/status byte 1 (init = 0) | pack_power_state_machine, bms_register_block_publish | bms_register_block_init, link_reset_flags | 0 |
| 0xDA | 7 | link_datetime_pkt | L | date/time packet for link_status_pack_send: [0..1]=year (BE, 2000+), [2]=month/weekday<<4, [3]=day, [4]=hour (bit6 PM, bit7 raw-hours flag), [5]=minute, [6]=second | link_status_pack_send | bms_register_block_publish, bms_register_block_init | - |
| 0xDB | 1 | link_datetime_pkt+0x1 | L | (inside link_datetime_pkt) | link_status_pack_send | bms_register_block_publish, bms_register_block_init | - |
| 0xDC | 1 | link_datetime_pkt+0x2 | L | (inside link_datetime_pkt) | bms_register_block_publish, bms_register_block_init, link_status_pack_send | bms_register_block_publish, bms_register_block_init | - |
| 0xDD | 1 | link_datetime_pkt+0x3 | L | (inside link_datetime_pkt) | link_status_pack_send | bms_register_block_publish, bms_register_block_init | - |
| 0xDE | 1 | link_datetime_pkt+0x4 | L | (inside link_datetime_pkt) | bms_register_block_publish, bms_register_block_init, link_status_pack_send | bms_register_block_publish, bms_register_block_init | - |
| 0xDF | 1 | link_datetime_pkt+0x5 | L | (inside link_datetime_pkt) | link_status_pack_send | bms_register_block_publish, bms_register_block_init | - |
| 0xE0 | 1 | link_datetime_pkt+0x6 | L | (inside link_datetime_pkt) | link_status_pack_send | bms_register_block_publish, bms_register_block_init | - |
| 0xE1 | 7 | id_string_a | L | 7 ASCII bytes copied from ROM 0x8019575 (identity/version text, starts "0108") | - | bms_register_block_init | 38303130 |
| 0xE5 | 2 | id_string_a+0x4 | L | (inside id_string_a) | - | bms_register_block_init | - |
| 0xE7 | 1 | id_string_a+0x6 | L | (inside id_string_a) | - | bms_register_block_init | - |
| 0xE8 | 7 | id_string_b | L | 7 ASCII bytes copied from ROM 0x801957C (identity/version text, starts "0101") | - | bms_register_block_init | 31303130 |
| 0xEC | 1 | id_string_b+0x4 | L | (inside id_string_b) | - | bms_register_block_init, decode_date_0x1032 | - |
| 0xED | 1 | id_string_b+0x5 | L | (inside id_string_b) | - | decode_date_0x1032 | - |
| 0xEE | 1 | id_string_b+0x6 | L | (inside id_string_b) | - | bms_register_block_init, decode_date_0x1032 | - |
| 0xEF | 1 | link_flag_EF | L | status flag copied to status_pkt_90[7] | pack_power_state_machine, bms_register_block_publish | pack_power_state_machine, bms_register_block_init | 0 |
| 0xF0 | 4 | bms_register_block_publish_F0 | C | private state of bms_register_block_publish (only this function touches it; written once, never read) | - | bms_register_block_publish, bms_register_block_init | 0 |
| 0xF1 | 1 | bms_register_block_publish_F1 | C | private state of bms_register_block_publish (only this function touches it; written once, never read) | - | bms_register_block_publish | - |
| 0xF2 | 1 | bms_register_block_publish_F2 | C | private state of bms_register_block_publish (only this function touches it; written once, never read) | - | bms_register_block_publish | - |
| 0xF3 | 1 | bms_register_block_publish_F3 | C | private state of bms_register_block_publish (only this function touches it; written once, never read) | - | bms_register_block_publish | - |
| 0xF4 | 4 | bms_register_block_publish_F4 | C | private state of bms_register_block_publish (only this function touches it; written once, never read) | - | bms_register_block_publish, bms_register_block_init | 0 |
| 0xF5 | 1 | bms_register_block_publish_F5 | C | private state of bms_register_block_publish (only this function touches it; written once, never read) | - | bms_register_block_publish | - |
| 0xF6 | 1 | bms_register_block_publish_F6 | C | private state of bms_register_block_publish (only this function touches it; written once, never read) | - | bms_register_block_publish | - |
| 0xF7 | 1 | bms_register_block_publish_F7 | C | private state of bms_register_block_publish (only this function touches it; written once, never read) | - | bms_register_block_publish | - |
| 0xF8 | 1 | bms_new_second_housekeeping_F8 | C | private state of bms_new_second_housekeeping (only this function touches it) | bms_new_second_housekeeping | bms_register_block_init, bms_new_second_housekeeping | 0 |
| 0xF9 | 1 | ntc1_abs_for_pkt | L | absolute value of NTC1 temperature (sign-magnitude) for the link packet | - | bms_register_block_publish | - |
| 0xFA | 1 | ntc2_abs_for_pkt | L | NTC2 magnitude for the link packet | - | bms_register_block_publish | - |
| 0xFC | 4 | publish_f73_counter | L | counts 0..50 while 0xF73 != 0; reaching 50 raises register flag bit 10 (comm fail) | bms_register_block_publish | bms_register_block_publish | 0,32 |
| 0x100 | 1 | wake_flag_pb9 | L | set in EXTI9_5 (PB9 edge); cleared by pack_power_state_machine | pack_power_state_machine, sleep_loop_stop_mode | pack_power_state_machine, EXTI9_5_IRQHandler | 0,1 |
| 0x102 | 1 | wake_flag_pb11 | L | set/cleared by EXTI line 11 / wake_pin_filter_pb11 | wake_pin_filter_pb11, exti_line11_handler | wake_pin_filter_pb11, exti_line11_handler | 0,1 |
| 0x103 | 1 | wake_flag_pa8 | L | set in EXTI9_5 (PA8 edge) | pack_power_state_machine, sleep_loop_stop_mode | pack_power_state_machine, EXTI9_5_IRQHandler | 0,1 |
| 0x104 | 1 | wake_flag_pb7_cnt | L | PB7 wake counter (0..10), set in EXTI9_5; reported in status_pkt_90[6] | pack_power_state_machine, bms_register_block_publish, EXTI9_5_IRQHandler, sleep_loop_stop_mode | pack_power_state_machine, EXTI9_5_IRQHandler | 0,A |
| 0x106 | 1 | load_present_state | L | load-detect result: 0 no load, 1 load present, 2 not applicable (DSG FET on / detection disabled) | sw_overcurrent_discharge_levels | load_detect_control | 0,1,2 |
| 0x107 | 1 | pack_on | S | 1 = pack output considered switched on (set by power_on_off_decision after PB9 low >60 ticks or PACK pin within 1.5 V of cell sum for >150 ticks; cleared after 20 ticks of release); register flag bit 13 | pack_power_state_machine, bms_register_block_publish, power_on_session_logic, power_mode_state_machine, power_on_off_decision | power_on_off_decision | 0,1 |
| 0x10A | 1 | pb9_low_cnt | L | 10 ms ticks PB9 has been low (turn-on debounce, trips >60) | power_on_off_decision | power_on_off_decision | 0 |
| 0x10B | 1 | pack_pin_near_cnt | L | 10 ms ticks PACK pin within 1.5 V of cell sum (trips >150) | power_on_off_decision | power_on_off_decision | 0 |
| 0x10C | 2 | pack_off_cnt | L | ticks until pack_on is cleared (trips >20); then GPIO tables 0x801A863/0x801A84F re-initialised, 0xA64=1 | power_on_off_decision | power_on_off_decision | 0 |
| 0x110 | 4 | pack_pin_mv | L | PACK pin voltage x10 (BQ cmd 0x36 value 0x162B x 10); the 57,500 (0xE09C) limit blocks turn-on | power_on_off_decision | power_on_off_decision | - |
| 0x114 | 1 | load_detect_up_cnt | L | samples with LD pin < 4000 (0xFA0) x10 (>10 sets 0x106=1) | load_detect_control | load_detect_control | 0 |
| 0x115 | 1 | load_detect_down_cnt | L | samples with LD pin >= 4000 (>10 clears 0x106) | load_detect_control | load_detect_control | 0 |
| 0x116 | 2 | wake_pin_filter_pb11_116 | C | private state of wake_pin_filter_pb11 (only this function touches it) | wake_pin_filter_pb11 | wake_pin_filter_pb11 | 0 |
| 0x118 | 1 | wake_pin_filter_pb11_118 | C | private state of wake_pin_filter_pb11 (only this function touches it) | wake_pin_filter_pb11 | wake_pin_filter_pb11 | 0 |
| 0x11C | 1 | chg_connect_event | L | charger-connect event flag (set_chg_event_flag, chg_connect_debounce_fsm) | chg_connect_debounce_fsm | set_chg_event_flag, chg_connect_debounce_fsm, persisted_state_load | 0 |
| 0x11D | 1 | chg_connect_debounce_fsm_11D | C | private state of chg_connect_debounce_fsm (only this function touches it) | chg_connect_debounce_fsm | chg_connect_debounce_fsm | 0,1,2 |
| 0x11E | 1 | chg_connect_debounce_fsm_11E | C | private state of chg_connect_debounce_fsm (only this function touches it) | chg_connect_debounce_fsm | chg_connect_debounce_fsm | 0 |
| 0x120 | 2 | chg_connect_debounce_fsm_120 | C | private state of chg_connect_debounce_fsm (only this function touches it) | chg_connect_debounce_fsm | chg_connect_debounce_fsm | 0 |
| 0x122 | 2 | chg_connect_debounce_fsm_122 | C | private state of chg_connect_debounce_fsm (only this function touches it) | chg_connect_debounce_fsm | chg_connect_debounce_fsm | 0 |
| 0x124 | 1 | chg_connect_debounce_fsm_124 | C | private state of chg_connect_debounce_fsm (only this function touches it) | chg_connect_debounce_fsm | chg_connect_debounce_fsm | 0 |
| 0x128 | 1 | reply_pending | L | a reply is pending (cleared by reply_pending_timeout after 10 ticks) | reply_pending_timeout, get_ram_128 | reply_pending_timeout, frame_dispatch_generic | 0,1 |
| 0x129 | 1 | rx_proto_type | L | protocol class chosen by rx_frame_router: 1 BLE/dash(0x90), 3 motor link(0x63), 4 protocol N(0x6E) | rx_frame_router | clear_frame_handler_ptrs, rx_frame_router | 0,1,3,4 |
| 0x12C | 16 | frame_handler_ptrs | C | 4 words set by rx_frame_router: [0]=buffer/state pointer, [1]=parse function, [2]=execute function, [3]=build function (e.g. 0x8005839=A:3838 parse, 0x80074DD=A:54DC, 0x800DD51=A:BD50) | frame_dispatch_generic | clear_frame_handler_ptrs, rx_frame_router | 0,200010B8,20001154,200011F3 |
| 0x130 | 4 | frame_handler_ptrs+0x4 | C | (inside frame_handler_ptrs) | frame_dispatch_generic | clear_frame_handler_ptrs, rx_frame_router | 0,8005839,80074DD,800DD51 |
| 0x134 | 4 | frame_handler_ptrs+0x8 | C | (inside frame_handler_ptrs) | frame_dispatch_generic | clear_frame_handler_ptrs, rx_frame_router | 0,8005701,80073FD,800DCC1 |
| 0x138 | 4 | frame_handler_ptrs+0xC | C | (inside frame_handler_ptrs) | frame_dispatch_generic | clear_frame_handler_ptrs, rx_frame_router | 0,80058ED,80076BD,800DE6D |
| 0x13C | 1 | reply_timeout_ctr | L | 10-tick reply timeout counter | reply_pending_timeout | reply_pending_timeout, frame_dispatch_generic | 0 |
| 0x13D | 1 | reg_lookup_exec_13D | C | private state of reg_lookup_exec (only this function touches it) | reg_lookup_exec | - | - |
| 0x142 | 1 | ev_flag_142 | L | event flag cleared by ev_clear_142 | ev_clear_142 | ev_clear_142 | 0 |
| 0x7D4 | 1 | protocolN_exec_7D4 | C | private state of protocolN_exec (only this function touches it) | protocolN_exec | - | - |
| 0x7D5 | 1 | registry_write_object_7D5 | C | private state of registry_write_object (only this function touches it) | registry_write_object | - | - |
| 0x9B4 | 1 | link3_state | L | USART3 auth/handshake link state (0..3) used by usart3_link_tx_sequencer, link_frame_rx_parse | usart3_link_tx_sequencer, link_frame_rx_parse | power_mode_state_machine, usart3_link_tx_sequencer, link_frame_rx_parse | 0,1,2,3 |
| 0x9B5 | 1 | link3_substate | L | USART3 link sub-state; also set by power_mode_state_machine and link_cmd_9_a_b | power_mode_state_machine | power_mode_state_machine, usart3_link_tx_sequencer, link_cmd_9_a_b | 0,1,2,3 |
| 0x9B8 | 4 | link_serial_9B8 | L | serial/identity words written by link_cmd_5_set_serial and compared by link_auth_response_check | link_auth_response_check, link_cmd_5_set_serial | link_cmd_5_set_serial | - |
| 0x9BC | 1 | link3_tx_flag | L | usart3_link_tx_sequencer flag, also cleared by link_frame_rx_parse | usart3_link_tx_sequencer | usart3_link_tx_sequencer, link_frame_rx_parse | 0 |
| 0x9BD | 1 | usart3_link_tx_sequencer_9BD | C | private state of usart3_link_tx_sequencer (only this function touches it) | usart3_link_tx_sequencer | usart3_link_tx_sequencer | 0 |
| 0x9BE | 2 | usart3_link_tx_sequencer_9BE | C | private state of usart3_link_tx_sequencer (only this function touches it) | usart3_link_tx_sequencer | usart3_link_tx_sequencer | 0 |
| 0x9C0 | 1 | dsg_oc_flag_9C0 | L | flag set by set_flag_9c0, read by sw_overcurrent_discharge_levels | sw_overcurrent_discharge_levels | set_flag_9c0, sw_overcurrent_discharge_levels | 0,1 |
| 0x9C2 | 1 | load_detect_gate | L | written by sw_overcurrent_discharge_levels; load detection only runs when >= 3 | load_detect_control, sw_overcurrent_discharge_levels | sw_overcurrent_discharge_levels | 0 |
| 0x9C4 | 2 | soft_cuv_mean_level_9C4 | C | private state of soft_cuv_mean_level (only this function touches it) | soft_cuv_mean_level | soft_cuv_mean_level | 0 |
| 0x9C6 | 2 | soft_cuv_mean_level_9C6 | C | private state of soft_cuv_mean_level (only this function touches it) | soft_cuv_mean_level | soft_cuv_mean_level | 0 |
| 0x9C8 | 2 | soft_cuv_level_9C8 | C | private state of soft_cuv_level (only this function touches it) | soft_cuv_level | soft_cuv_level | 0 |
| 0x9CA | 2 | soft_cuv_level_9CA | C | private state of soft_cuv_level (only this function touches it) | soft_cuv_level | soft_cuv_level | 0 |
| 0x9CC | 2 | dsg_oc_report_latch_9CC | C | private state of dsg_oc_report_latch (only this function touches it) | dsg_oc_report_latch | dsg_oc_report_latch | 0 |
| 0x9CE | 2 | dsg_oc_report_latch_9CE | C | private state of dsg_oc_report_latch (only this function touches it) | dsg_oc_report_latch | dsg_oc_report_latch | 0 |
| 0x9D0 | 2 | dsg_ot_hysteresis_9D0 | C | private state of dsg_ot_hysteresis (only this function touches it) | dsg_ot_hysteresis | dsg_ot_hysteresis | 0 |
| 0x9D2 | 2 | dsg_ot_hysteresis_9D2 | C | private state of dsg_ot_hysteresis (only this function touches it) | dsg_ot_hysteresis | dsg_ot_hysteresis | 0 |
| 0x9D4 | 2 | dsg_ut_hysteresis_9D4 | C | private state of dsg_ut_hysteresis (only this function touches it) | dsg_ut_hysteresis | dsg_ut_hysteresis | 0 |
| 0x9D6 | 2 | dsg_ut_hysteresis_9D6 | C | private state of dsg_ut_hysteresis (only this function touches it) | dsg_ut_hysteresis | dsg_ut_hysteresis | 0 |
| 0x9D8 | 2 | ntc2_ot_latch_9D8 | C | private state of ntc2_ot_latch (only this function touches it) | ntc2_ot_latch | ntc2_ot_latch | 0 |
| 0x9DA | 2 | ntc2_ot_latch_9DA | C | private state of ntc2_ot_latch (only this function touches it) | ntc2_ot_latch | ntc2_ot_latch | 0 |
| 0x9DC | 2 | temp_spread_latch_9DC | C | private state of temp_spread_latch (only this function touches it) | temp_spread_latch | temp_spread_latch | 0 |
| 0x9DE | 2 | temp_spread_latch_9DE | C | private state of temp_spread_latch (only this function touches it) | temp_spread_latch | temp_spread_latch | 0 |
| 0x9E0 | 2 | soft_cell_overvoltage_9E0 | C | private state of soft_cell_overvoltage (only this function touches it) | soft_cell_overvoltage | soft_cell_overvoltage | 0 |
| 0x9E2 | 2 | soft_cell_overvoltage_9E2 | C | private state of soft_cell_overvoltage (only this function touches it) | soft_cell_overvoltage | soft_cell_overvoltage | 0 |
| 0x9E4 | 2 | board_ot_latch_9E4 | C | private state of board_ot_latch (only this function touches it) | board_ot_latch | board_ot_latch | 0 |
| 0x9E6 | 2 | board_ot_latch_9E6 | C | private state of board_ot_latch (only this function touches it) | board_ot_latch | board_ot_latch | 0 |
| 0x9E8 | 2 | dsg_ot_latch_9E8 | C | private state of dsg_ot_latch (only this function touches it) | dsg_ot_latch | dsg_ot_latch | 0 |
| 0x9EA | 2 | dsg_ot_latch_9EA | C | private state of dsg_ot_latch (only this function touches it) | dsg_ot_latch | dsg_ot_latch | 0 |
| 0x9EC | 2 | dsg_ut_latch_9EC | C | private state of dsg_ut_latch (only this function touches it) | dsg_ut_latch | dsg_ut_latch | 0 |
| 0x9EE | 2 | dsg_ut_latch_9EE | C | private state of dsg_ut_latch (only this function touches it) | dsg_ut_latch | dsg_ut_latch | 0 |
| 0x9F0 | 2 | chg_ut_pb15_inhibit_9F0 | C | private state of chg_ut_pb15_inhibit (only this function touches it) | chg_ut_pb15_inhibit | chg_ut_pb15_inhibit | 0 |
| 0x9F2 | 2 | chg_ut_pb15_inhibit_9F2 | C | private state of chg_ut_pb15_inhibit (only this function touches it) | chg_ut_pb15_inhibit | chg_ut_pb15_inhibit | 0 |
| 0x9F4 | 2 | chg_ot_pb15_inhibit_9F4 | C | private state of chg_ot_pb15_inhibit (only this function touches it) | chg_ot_pb15_inhibit | chg_ot_pb15_inhibit | 0 |
| 0x9F6 | 2 | chg_ot_pb15_inhibit_9F6 | C | private state of chg_ot_pb15_inhibit (only this function touches it) | chg_ot_pb15_inhibit | chg_ot_pb15_inhibit | 0 |
| 0x9F8 | 2 | pack_uv_level2_latch_9F8 | C | private state of pack_uv_level2_latch (only this function touches it) | pack_uv_level2_latch | pack_uv_level2_latch | 0 |
| 0x9FA | 2 | pack_uv_level2_latch_9FA | C | private state of pack_uv_level2_latch (only this function touches it) | pack_uv_level2_latch | pack_uv_level2_latch | 0 |
| 0x9FC | 2 | soft_cell_undervoltage_9FC | C | private state of soft_cell_undervoltage (only this function touches it) | soft_cell_undervoltage | soft_cell_undervoltage | 0 |
| 0x9FE | 2 | soft_cell_undervoltage_9FE | C | private state of soft_cell_undervoltage (only this function touches it) | soft_cell_undervoltage | soft_cell_undervoltage | 0 |
| 0xA00 | 2 | sw_overcurrent_charge_levels_A00 | C | private state of sw_overcurrent_charge_levels (only this function touches it) | sw_overcurrent_charge_levels | sw_overcurrent_charge_levels | 0 |
| 0xA02 | 2 | sw_overcurrent_charge_levels_A02 | C | private state of sw_overcurrent_charge_levels (only this function touches it) | sw_overcurrent_charge_levels | sw_overcurrent_charge_levels | 0 |
| 0xA04 | 2 | sw_overcurrent_charge_levels_A04 | C | private state of sw_overcurrent_charge_levels (only this function touches it) | sw_overcurrent_charge_levels | sw_overcurrent_charge_levels | 0 |
| 0xA06 | 2 | sw_overcurrent_charge_levels_A06 | C | private state of sw_overcurrent_charge_levels (only this function touches it) | sw_overcurrent_charge_levels | sw_overcurrent_charge_levels | 0 |
| 0xA08 | 2 | sw_overcurrent_charge_levels_A08 | C | private state of sw_overcurrent_charge_levels (only this function touches it) | sw_overcurrent_charge_levels | sw_overcurrent_charge_levels | 0 |
| 0xA0A | 2 | sw_overcurrent_charge_levels_A0A | C | private state of sw_overcurrent_charge_levels (only this function touches it) | sw_overcurrent_charge_levels | sw_overcurrent_charge_levels | 0 |
| 0xA0C | 1 | sw_overcurrent_charge_levels_A0C | C | private state of sw_overcurrent_charge_levels (only this function touches it) | sw_overcurrent_charge_levels | sw_overcurrent_charge_levels | 0 |
| 0xA0E | 2 | sw_overcurrent_discharge_levels_A0E | C | private state of sw_overcurrent_discharge_levels (only this function touches it) | sw_overcurrent_discharge_levels | sw_overcurrent_discharge_levels | 0 |
| 0xA10 | 2 | sw_overcurrent_discharge_levels_A10 | C | private state of sw_overcurrent_discharge_levels (only this function touches it) | sw_overcurrent_discharge_levels | sw_overcurrent_discharge_levels | 0 |
| 0xA12 | 2 | sw_overcurrent_discharge_levels_A12 | C | private state of sw_overcurrent_discharge_levels (only this function touches it) | sw_overcurrent_discharge_levels | sw_overcurrent_discharge_levels | 0 |
| 0xA14 | 2 | sw_overcurrent_discharge_levels_A14 | C | private state of sw_overcurrent_discharge_levels (only this function touches it) | sw_overcurrent_discharge_levels | sw_overcurrent_discharge_levels | 0 |
| 0xA16 | 2 | sw_overcurrent_discharge_levels_A16 | C | private state of sw_overcurrent_discharge_levels (only this function touches it) | sw_overcurrent_discharge_levels | sw_overcurrent_discharge_levels | 0 |
| 0xA18 | 2 | sw_overcurrent_discharge_levels_A18 | C | private state of sw_overcurrent_discharge_levels (only this function touches it) | sw_overcurrent_discharge_levels | sw_overcurrent_discharge_levels | 0 |
| 0xA1A | 2 | sw_overcurrent_discharge_levels_A1A | C | private state of sw_overcurrent_discharge_levels (only this function touches it) | sw_overcurrent_discharge_levels | sw_overcurrent_discharge_levels | 0 |
| 0xA1C | 2 | sw_overcurrent_discharge_levels_A1C | C | private state of sw_overcurrent_discharge_levels (only this function touches it) | sw_overcurrent_discharge_levels | sw_overcurrent_discharge_levels | 0 |
| 0xA1E | 2 | sw_overcurrent_discharge_levels_A1E | C | private state of sw_overcurrent_discharge_levels (only this function touches it) | sw_overcurrent_discharge_levels | sw_overcurrent_discharge_levels | 0 |
| 0xA20 | 2 | sw_overcurrent_discharge_levels_A20 | C | private state of sw_overcurrent_discharge_levels (only this function touches it) | sw_overcurrent_discharge_levels | sw_overcurrent_discharge_levels | - |
| 0xA22 | 2 | deep_discharge_latch_A22 | C | private state of deep_discharge_latch (only this function touches it) | deep_discharge_latch | deep_discharge_latch | 0 |
| 0xA24 | 2 | deep_discharge_latch_A24 | C | private state of deep_discharge_latch (only this function touches it) | deep_discharge_latch | deep_discharge_latch | 0 |
| 0xA26 | 2 | cell_imbalance_levels_A26 | C | private state of cell_imbalance_levels (only this function touches it) | cell_imbalance_levels | cell_imbalance_levels | 0 |
| 0xA28 | 2 | cell_imbalance_levels_A28 | C | private state of cell_imbalance_levels (only this function touches it) | cell_imbalance_levels | cell_imbalance_levels | 0 |
| 0xA2A | 2 | cell_imbalance_levels_A2A | C | private state of cell_imbalance_levels (only this function touches it) | cell_imbalance_levels | cell_imbalance_levels | 0 |
| 0xA2C | 2 | cell_imbalance_levels_A2C | C | private state of cell_imbalance_levels (only this function touches it) | cell_imbalance_levels | cell_imbalance_levels | 0 |
| 0xA2E | 2 | fault_chg_current_when_chg_off_A2E | C | private state of fault_chg_current_when_chg_off (only this function touches it) | fault_chg_current_when_chg_off | fault_chg_current_when_chg_off | 0 |
| 0xA30 | 2 | fault_dsg_current_when_dsg_off_A30 | C | private state of fault_dsg_current_when_dsg_off (only this function touches it) | fault_dsg_current_when_dsg_off | fault_dsg_current_when_dsg_off | 0 |
| 0xA36 | 2 | ntc2_plausibility_A36 | C | private state of ntc2_plausibility (only this function touches it) | ntc2_plausibility | ntc2_plausibility | 0 |
| 0xA38 | 2 | ntc2_plausibility_A38 | C | private state of ntc2_plausibility (only this function touches it) | ntc2_plausibility | ntc2_plausibility | 0 |
| 0xA3A | 2 | ntc1_plausibility_A3A | C | private state of ntc1_plausibility (only this function touches it) | ntc1_plausibility | ntc1_plausibility | 0 |
| 0xA3C | 2 | ntc1_plausibility_A3C | C | private state of ntc1_plausibility (only this function touches it) | ntc1_plausibility | ntc1_plausibility | 0 |
| 0xA3E | 1 | bq_status_react_a | L | state byte of bq_safety_status_react | bq_safety_status_react | bq_safety_status_react | - |
| 0xA3F | 1 | bq_safety_status_react_A3F | C | private state of bq_safety_status_react (only this function touches it) | bq_safety_status_react | bq_safety_status_react | - |
| 0xA40 | 1 | status_bit4_clear_timer_A40 | C | private state of status_bit4_clear_timer (only this function touches it) | status_bit4_clear_timer | status_bit4_clear_timer | 0 |
| 0xA41 | 1 | status_bit_clear_timers_A41 | C | private state of status_bit_clear_timers (only this function touches it) | status_bit_clear_timers | status_bit_clear_timers | 0 |
| 0xA42 | 1 | bq_safety_status_react_A42 | C | private state of bq_safety_status_react (only this function touches it) | bq_safety_status_react | bq_safety_status_react | 0 |
| 0xA43 | 4 | model_state_aux_a43 | L | cleared by model_state_reset; no reader | - | model_state_reset | 0 |
| 0xA48 | 1 | model_event_persisted | L | set to 1 by persist_model_event_a/b/c when a state record was saved | model_init_sequence | persist_model_event_a, persist_model_event_b, persist_model_event_c, model_init_sequence, calibration_block_apply | 0,1 |
| 0xA49 | 1 | model_enabled | S | SOC/SOH model enabled (set at end of model_init_sequence); gates the model tasks | task_model_6ccc, task_model_70d8, task_model_11350, task_model_6978, model_scheduler | model_init_sequence | 0,1 |
| 0xA4C | 4 | rest_wake_counter | L | wake-cycle/rest counter (sleep_counter_update, sleep_loop_stop_mode); also exported as model input 0x1379 | sleep_counter_update, sleep_loop_stop_mode, port_get_sleep_ctr | port_set_13a6, sleep_counter_update, sleep_loop_stop_mode | 0 |
| 0xA50 | 1 | model_state_dirty | L | set by port_set_13c9; task_events_and_persist then persists the model state | task_events_and_persist | port_set_13c9, task_events_and_persist | 0 |
| 0xA51 | 1 | model_init_state | L | model_init_sequence state: 0 reset, 1 wait, 2 check, 3 model input gather, 4 enable | model_init_sequence | model_init_sequence | 0,1,2,3 |
| 0xA52 | 2 | model_init_sequence_A52 | C | private state of model_init_sequence (only this function touches it) | model_init_sequence | model_init_sequence | 0 |
| 0xA54 | 1 | model_init_sequence_A54 | C | private state of model_init_sequence (only this function touches it) | model_init_sequence | model_init_sequence | 0 |
| 0xA55 | 1 | soc_correction_triggers_A55 | C | private state of soc_correction_triggers (only this function touches it) | soc_correction_triggers | soc_correction_triggers | 0 |
| 0xA56 | 2 | soc_correction_triggers_A56 | C | private state of soc_correction_triggers (only this function touches it) | soc_correction_triggers | soc_correction_triggers | 0 |
| 0xA58 | 1 | soc_correction_triggers_A58 | C | private state of soc_correction_triggers (only this function touches it) | soc_correction_triggers | soc_correction_triggers | 0 |
| 0xA59 | 1 | soc_correction_triggers_A59 | C | private state of soc_correction_triggers (only this function touches it) | soc_correction_triggers | soc_correction_triggers | 0 |
| 0xA5A | 1 | soc_correction_triggers_A5A | C | private state of soc_correction_triggers (only this function touches it) | soc_correction_triggers | soc_correction_triggers | 0 |
| 0xA5B | 1 | soc_correction_triggers_A5B | C | private state of soc_correction_triggers (only this function touches it) | soc_correction_triggers | soc_correction_triggers | 0 |
| 0xA5C | 2 | soc_correction_triggers_A5C | C | private state of soc_correction_triggers (only this function touches it) | soc_correction_triggers | soc_correction_triggers | 0,1 |
| 0xA5E | 2 | soc_correction_triggers_A5E | C | private state of soc_correction_triggers (only this function touches it) | soc_correction_triggers | soc_correction_triggers | 0,1 |
| 0xA60 | 1 | sleep_counter_update_A60 | C | private state of sleep_counter_update (only this function touches it) | sleep_counter_update | sleep_counter_update | 0 |
| 0xA61 | 1 | sleep_counter_update_A61 | C | private state of sleep_counter_update (only this function touches it) | sleep_counter_update | sleep_counter_update | 0 |
| 0xA62 | 1 | model_scheduler_A62 | C | private state of model_scheduler (only this function touches it) | model_scheduler | model_scheduler | 0 |
| 0xA64 | 1 | pb14_request | L | PB14 output request (written by power_mode_step, pack_power_state_machine, power_on_off_decision; consumed by pb14_ctrl_logic) | pb14_ctrl_logic | power_mode_step, pack_power_state_machine, power_on_off_decision, pb14_ctrl_logic | 0,1 |
| 0xA65 | 1 | dsg_fet_request | S | requested DSG FET state from fet_request_compute (1 = on) | dsg_fet_control, fet_state_mismatch_check | fet_request_compute | 0,1 |
| 0xA66 | 1 | chg_fet_request | S | requested CHG FET state from fet_request_compute (1 = on) | chg_fet_control, fet_state_mismatch_check | fet_request_compute | 0,1 |
| 0xA67 | 1 | fet_poll_state | L | fet_status_poll state | fet_status_poll | fet_status_poll | 0 |
| 0xA68 | 2 | fet_mismatch_timer | L | time FET status disagrees with request (fet_state_mismatch_check; sets 0xF73 bit3 at 0x32) | fet_state_mismatch_check | fet_state_mismatch_check | 0,32 |
| 0xA6C | 1 | pb14_ctrl_logic_A6C | C | private state of pb14_ctrl_logic (only this function touches it) | pb14_ctrl_logic | pb14_ctrl_logic | 0 |
| 0xA6E | 2 | pb14_ctrl_logic_A6E | C | private state of pb14_ctrl_logic (only this function touches it) | pb14_ctrl_logic | pb14_ctrl_logic | 0 |
| 0xA71 | 1 | bq_sleep_retry_cnt | L | retry counter shared by bq_fault_response_2 and bq_sleep_disable_retry | bq_fault_response_2, bq_sleep_disable_retry | bq_fault_response_2, bq_sleep_disable_retry | - |
| 0xA72 | 1 | temp_fault_flags | L | bits0-3 temperature fault latches (cleared by temp_fault_flags_clear) | temp_fault_flags_clear, filter_input_a2, cell_voltage_copy_or_default | temp_fault_flags_clear, filter_input_a2, cell_voltage_copy_or_default | - |
| 0xA73 | 1 | bq_present | L | BQ769x2 answering on I2C (bq_present_debounce); gates pack_charge_ok_check | pack_charge_ok_check, get_ram_a73 | bq_present_debounce | 0,1 |
| 0xA74 | 1 | filter_input_a2_A74 | C | private state of filter_input_a2 (only this function touches it) | filter_input_a2 | filter_input_a2 | 0 |
| 0xA75 | 1 | bq_present_debounce_A75 | C | private state of bq_present_debounce (only this function touches it) | bq_present_debounce | bq_present_debounce | 0 |
| 0xA76 | 1 | bq_present_debounce_A76 | C | private state of bq_present_debounce (only this function touches it) | bq_present_debounce | bq_present_debounce | 0 |
| 0xA77 | 1 | bq_fault_response_1_A77 | C | private state of bq_fault_response_1 (only this function touches it) | bq_fault_response_1 | bq_fault_response_1 | 0 |
| 0xA78 | 1 | bq_fault_response_1_A78 | C | private state of bq_fault_response_1 (only this function touches it) | bq_fault_response_1 | bq_fault_response_1 | 0,1 |
| 0xA79 | 1 | bq_fault_response_1_A79 | C | private state of bq_fault_response_1 (only this function touches it) | bq_fault_response_1 | bq_fault_response_1 | 0 |
| 0xA7A | 1 | bq_fault_response_2_A7A | C | private state of bq_fault_response_2 (only this function touches it) | bq_fault_response_2 | bq_fault_response_2 | 0 |
| 0xA7C | 2 | bq_status_cache | L | cached BQ status word (re-read by task_bq_status_check if 0 or 0xFFFF) | task_bq_status_check, bq_read_0x05_status, bq_otp_configured_check | bq_read_0x05_status, bq_otp_write_path | 0,1 |
| 0xAC8 | 4 | accessor_fail_mask | L | bit mask of scheduled BQ accessors that failed (scheduled_accessor_dispatch) | accessor_fail_mask_nonzero, scheduled_accessor_dispatch | scheduled_accessor_dispatch | - |
| 0xACC | 4 | safety_status_a_packed | L | packed Safety Status A flags (safety_status_flags_pack) | - | safety_status_flags_pack | - |
| 0xAD0 | 4 | safety_status_b_packed | L | packed Safety Status B flags | - | safety_status_flags_pack | - |
| 0xAD4 | 4 | safety_alert_a_packed | L | packed Safety Alert A flags (safety_alert_flags_pack) | - | safety_alert_flags_pack | - |
| 0xAD8 | 4 | safety_alert_b_packed | L | packed Safety Alert B flags | - | safety_alert_flags_pack | - |
| 0xB42 | 2 | bq_read_dsg_status_B42 | C | private state of bq_read_dsg_status (only this function touches it) | bq_read_dsg_status | bq_read_dsg_status | - |
| 0xB44 | 1 | undervolt_cmd_0x9335_B44 | C | private state of undervolt_cmd_0x9335 (only this function touches it) | undervolt_cmd_0x9335 | undervolt_cmd_0x9335 | 0,1 |
| 0xB48 | 4 | scheduled_accessor_dispatch_B48 | C | private state of scheduled_accessor_dispatch (only this function touches it) | scheduled_accessor_dispatch | scheduled_accessor_dispatch | 0 |
| 0xB4C | 4 | swtimer_now | C | software-timer tick counter (1 ms; wraps near 0xFFC91170) | swtimer_tick, swtimer_arm, swtimer_dispatch | swtimer_init, swtimer_tick | 0 |
| 0xB50 | 4 | swtimer_dispatch_B50 | C | private state of swtimer_dispatch (only this function touches it) | swtimer_dispatch | swtimer_dispatch | - |
| 0xB54 | 4 | swtimer_dispatch_B54 | C | private state of swtimer_dispatch (only this function touches it) | swtimer_dispatch | swtimer_dispatch | - |
| 0xB58 | 1 | rr_idx_10ms | C | round-robin index of the 10 ms task list (SWTIMER_CB_10ms) | SWTIMER_CB_10ms | SWTIMER_CB_10ms | 0 |
| 0xB59 | 1 | rr_idx_100ms_b | C | round-robin index (10-entry list) of SWTIMER_CB_100ms | SWTIMER_CB_100ms | SWTIMER_CB_100ms | 0 |
| 0xB5A | 1 | rr_idx_100ms_a | C | round-robin index (5-entry list) of SWTIMER_CB_100ms | SWTIMER_CB_100ms | SWTIMER_CB_100ms | 0 |
| 0xB5B | 1 | rr_idx_500ms | C | round-robin index of the 500 ms list | SWTIMER_CB_500ms | SWTIMER_CB_500ms | 0 |
| 0xB5C | 2 | irq_lock_depth | L | nesting depth for irq_lock/irq_unlock | irq_lock, irq_unlock | irq_lock, irq_unlock | 0 |
| 0xB64 | 1 | i2c_bus_state | L | per-bus state nibbles: I2C1 low, I2C2 high | i2c_bus_state_set, i2c2_init, i2c_master_write_locked, i2c_state_poll | i2c_bus_state_set, i2c2_init, i2c_state_poll | - |
| 0xB65 | 1 | i2c_status_bits | L | I2C error/status bits | i2c_state_poll, i2c_set_status_bit | i2c_state_poll, i2c_set_status_bit | - |
| 0xB71 | 1 | i2c_master_write_polled_B71 | C | private state of i2c_master_write_polled (only this function touches it) | i2c_master_write_polled | i2c_master_write_polled | - |
| 0xB72 | 1 | i2c2_init_B72 | C | private state of i2c2_init (only this function touches it) | i2c2_init | i2c2_init | - |
| 0xB73 | 1 | i2c_state_poll_B73 | C | private state of i2c_state_poll (only this function touches it) | i2c_state_poll | i2c_state_poll | 0 |
| 0xB74 | 2 | rtc_wake_accum | L | timer used by rtc_wakeup_handler | rtc_wakeup_handler | rtc_wakeup_handler | 0 |
| 0xB76 | 1 | usart_tx_busy | C | bit0 = USART1 DMA TX busy, bit2 = USART3 DMA TX busy | usart1_tx_start, usart3_tx_start, dma1_ch4_isr, dma1_ch5_isr | usart1_tx_start, usart3_tx_start, dma1_ch4_isr, dma1_ch5_isr | - |
| 0xB78 | 2 | usart_idle_len_b78 | L | cleared in both USART IRQ handlers; no reader | - | USART1_IRQHandler, USART3_IRQHandler | 0 |
| 0xB7A | 2 | usart1_tx_timeout | C | USART1 TX busy timeout counter (200 ticks) | usart1_tx_start | usart1_tx_start | 0 |
| 0xB7C | 2 | usart3_tx_timeout | C | USART3 TX busy timeout counter | usart3_tx_start | usart3_tx_start | 0 |
| 0xB82 | 1 | adc_ready | C | 1 once ADC channels are configured and conversions are running | get_ram_b82 | adc_init_calibrate, adc_init_channels | 0,1 |
| 0xB84 | 2 | ntc_adc_filtered | L | median/average of the NTC ADC samples (adc_read_temp_value) | adc_read_temp_value | adc_read_temp_value | - |
| 0xB88 | 4 | sysclk_hz_fallback | L | 4,000,000 when HSI start-up fails (0x3D0900), else unused | - | clock_config_hsi_pll_96 | 3D0900 |
| 0xB8C | 1 | update_active | C | update (XMODEM) session active | get_update_active, update_timeout_tick | xmodem_session_start, update_timeout_tick | 0,1 |
| 0xC7E | 1 | update_mode_requested | C | an update was requested over the link | get_update_mode_requested | link_frame_execute, update_timeout_tick | 0,1 |
| 0xC7F | 1 | xmodem_data_started | L | XMODEM data phase started | link_frame_execute, update_finish_reset, xmodem_sequence_check | xmodem_state_reset, xmodem_pkt_data | 0,1 |
| 0xC80 | 4 | update_timeout_ctr | L | update session inactivity counter (update_timeout_tick) | update_timeout_tick | update_timeout_tick | - |
| 0xC84 | 1 | update_finish_flag | L | update finished, reset pending | update_finish_reset | update_finish_reset | 0 |
| 0xC85 | 4 | limit_state_aux_c85 | L | cleared by limit_state_reset; no reader | - | limit_state_reset | 0 |
| 0xC89 | 2 | current_limit_percent | C | current-limit percent 0..10000 from the limit-curve block (port_set_c89_limit); read by usart3_link_tx_sequencer | usart3_link_tx_sequencer | port_set_c89_limit | - |
| 0xC8B | 2 | limit_curve_output | C | signed limit-curve output (port_set_c8b / port_get_limit_curve_c8b) | port_get_limit_curve_c8b | port_set_c8b | - |
| 0xC8D | 1 | spi_flash_absent | C | 1 = external SPI NOR not detected (spi_flash_identify) | spi_flash_absent_flag | spi_flash_identify | 0,1 |
| 0xC90 | 2 | session_event_logger_C90 | C | private state of session_event_logger (only this function touches it) | session_event_logger | session_event_logger | - |
| 0xC94 | 4 | session_event_logger_C94 | C | private state of session_event_logger (only this function touches it) | session_event_logger | session_event_logger | - |
| 0xC98 | 2 | session_event_logger_C98 | C | private state of session_event_logger (only this function touches it) | session_event_logger | session_event_logger | 0 |
| 0xC9A | 1 | session_event_logger_C9A | C | private state of session_event_logger (only this function touches it) | session_event_logger | session_event_logger | 0 |
| 0xC9B | 1 | session_event_logger_C9B | C | private state of session_event_logger (only this function touches it) | session_event_logger | session_event_logger | 0 |
| 0xC9C | 1 | ntc_offset_load_C9C | C | private state of ntc_offset_load (only this function touches it) | ntc_offset_load | - | - |
| 0xCA0 | 4 | ntc_cal_word | L | NTC calibration word/offset (ntc_cal_block_write, ntc_offset_load) | ntc_validate_crc, ntc_offset_load, ntc_calibration_block_read | ntc_cal_block_write | - |
| 0xCA8 | 4 | eventlog_scan_addr | L | event-log address cursor (start 0x21000) | eventlog_advance | eventlog_advance | 21000 |
| 0xCAC | 1 | history_event_pending | L | history_event_commit pending flag (cleared by history_buffer_clear) | history_event_commit | history_event_commit, history_buffer_clear | 0,1 |
| 0xCAD | 1 | history_fault_score_track_CAD | C | private state of history_fault_score_track (only this function touches it; written once, never read) | - | history_fault_score_track | 1,2 |
| 0xCAE | 2 | history_fault_score_track_CAE | C | private state of history_fault_score_track (only this function touches it) | history_fault_score_track | history_fault_score_track | - |
| 0xCB0 | 1 | history_record_build_CB0 | C | private state of history_record_build (only this function touches it) | history_record_build | history_record_build | 0,1,3 |
| 0xCB1 | 1 | history_record_build_CB1 | C | private state of history_record_build (only this function touches it) | history_record_build | history_record_build | 0 |
| 0xCB2 | 1 | history_event_commit_CB2 | C | private state of history_event_commit (only this function touches it) | history_event_commit | history_event_commit | 0 |
| 0xCB3 | 1 | rtc_set_in_b0 | L | input byte for rtc_set_from_0xCB3 and uart1_reply_builder_0x74 (filled through a pointer path) | uart1_reply_builder_0x74, rtc_set_from_0xCB3 | - | - |
| 0xCB4 | 1 | rtc_set_in_b1 | L | input byte, see 0xCB3 | uart1_reply_builder_0x74, rtc_set_from_0xCB3 | - | - |
| 0xCB5 | 1 | rtc_get_to_0xCB5_CB5 | C | private state of rtc_get_to_0xCB5 (only this function touches it; written once, never read) | - | rtc_get_to_0xCB5 | - |
| 0xCB6 | 1 | rtc_get_to_0xCB5_CB6 | C | private state of rtc_get_to_0xCB5 (only this function touches it; written once, never read) | - | rtc_get_to_0xCB5 | - |
| 0xDD8 | 16 | i2c_driver_obj_bq | L | I2C driver object for the BQ769x2 bus (I2C2); used by i2c_driver_init/i2c1_recover/i2c2_recover | sleep_loop_stop_mode, i2c1_recover, i2c2_recover | - | - |
| 0xDDC | 4 | i2c_driver_obj_bq+0x4 | L | (inside i2c_driver_obj_bq) | sleep_loop_stop_mode, i2c1_recover, i2c2_recover | - | - |
| 0xDE0 | 4 | i2c_driver_obj_bq+0x8 | L | (inside i2c_driver_obj_bq) | sleep_loop_stop_mode, i2c1_recover, i2c2_recover | - | - |
| 0xDE4 | 4 | i2c_driver_obj_bq+0xC | L | (inside i2c_driver_obj_bq) | sleep_loop_stop_mode, i2c1_recover, i2c2_recover | - | - |
| 0xEE8 | 4 | i2c2_recover_cfg | L | I2C2 recovery config pointer | i2c2_recover | - | - |
| 0xEEC | 4 | i2c1_recover_cfg | L | I2C1 recovery config pointer | i2c1_recover | - | - |
| 0xEF0 | 4 | bq_i2c_read_crc_fn | L | function pointer to the I2C transaction used by bq_i2c_read_crc (CRC-enabled reads) | bq_i2c_read_crc | - | - |
| 0xEF4 | 4 | bq_i2c_write_crc_fn | L | function pointer used by bq_i2c_write_crc | bq_i2c_write_crc | - | - |
| 0xEF8 | 1 | i2c_err_flag | L | I2C error interrupt flag | i2c_error_irq | i2c_error_irq, i2c_event_irq | 0 |
| 0xEF9 | 1 | i2c_busy_flag | L | I2C transaction busy flag | i2c_event_irq, i2c_wait_ready | i2c_master_write_read, i2c_master_write | 0,1 |
| 0xEFA | 1 | i2c_done_flag | L | I2C event done flag | i2c_event_irq | i2c_event_irq, i2c_wait_ready | 0,1 |
| 0xEFB | 1 | i2c_dir_flag | L | I2C direction/mode flag | i2c_event_irq | i2c_master_write_read, i2c_master_write | - |
| 0xEFC | 4 | i2c_wait_timeout | L | I2C wait counter (init 10000) | i2c_wait_done, i2c_wait_ready | i2c_wait_done, i2c_wait_ready | 10000 |
| 0xF08 | 2 | i2c_event_irq_F08 | C | private state of i2c_event_irq (only this function touches it) | i2c_event_irq | i2c_event_irq | 3E8 |
| 0xF0A | 1 | i2c_master_write_read_F0A | C | private state of i2c_master_write_read (only this function touches it) | i2c_master_write_read | i2c_master_write_read | 0 |
| 0xF0B | 1 | i2c_master_write_F0B | C | private state of i2c_master_write (only this function touches it) | i2c_master_write | i2c_master_write | 0 |
| 0xF0C | 4 | rand_state | C | LCG state of lib_rand (seed from lib_srand) | lib_rand | lib_rand, lib_srand | - |
| 0xF10 | 26 | cell_mv | S | 13 cell voltages in mV (u16 x13): cells 1..12 = BQ Cell1..Cell12, cell 13 = BQ Cell16 (VC16); written by cell_voltage_copy_or_default (default when BQ read fails) | - | cell_voltage_copy_or_default | - |
| 0xF12 | 2 | cell_mv+0x2 | S | (inside cell_mv) | - | cell_voltage_copy_or_default | - |
| 0xF14 | 2 | cell_mv+0x4 | S | (inside cell_mv) | - | cell_voltage_copy_or_default | - |
| 0xF16 | 2 | cell_mv+0x6 | S | (inside cell_mv) | - | cell_voltage_copy_or_default | - |
| 0xF18 | 2 | cell_mv+0x8 | S | (inside cell_mv) | - | cell_voltage_copy_or_default | - |
| 0xF1A | 2 | cell_mv+0xA | S | (inside cell_mv) | - | cell_voltage_copy_or_default | - |
| 0xF1C | 2 | cell_mv+0xC | S | (inside cell_mv) | - | cell_voltage_copy_or_default | - |
| 0xF1E | 2 | cell_mv+0xE | S | (inside cell_mv) | - | cell_voltage_copy_or_default | - |
| 0xF20 | 2 | cell_mv+0x10 | S | (inside cell_mv) | - | cell_voltage_copy_or_default | - |
| 0xF22 | 2 | cell_mv+0x12 | S | (inside cell_mv) | - | cell_voltage_copy_or_default | - |
| 0xF24 | 2 | cell_mv+0x14 | S | (inside cell_mv) | - | cell_voltage_copy_or_default | - |
| 0xF26 | 2 | cell_mv+0x16 | S | (inside cell_mv) | - | cell_voltage_copy_or_default | - |
| 0xF28 | 2 | cell_mv+0x18 | S | (inside cell_mv) | - | cell_voltage_copy_or_default | - |
| 0xF2C | 4 | cell_sum_mv | C | sum of cell voltages (mV); source of 0xF95 | cell_stats_publish | - | - |
| 0xF30 | 2 | cell_mean_mv_calc | C | mean of cells (statistics result) | cell_stats_publish | - | - |
| 0xF32 | 2 | cell_min_mv_calc | C | minimum cell (statistics result) | cell_stats_publish | - | - |
| 0xF34 | 2 | cell_max_mv_calc | C | maximum cell (statistics result) | cell_stats_publish | - | - |
| 0xF36 | 1 | cell_min_idx_calc | C | index of minimum cell | cell_stats_publish | - | - |
| 0xF37 | 1 | cell_max_idx_calc | C | index of maximum cell | cell_stats_publish | - | - |
| 0xF64 | 4 | ref_date_a | L | persisted reference date a (year/month/day bytes) for calendar_days_since | calendar_days_since | persisted_state_load, persist_reference_date_a, persist_reference_date_b, persist_elapsed_days | - |
| 0xF66 | 1 | ref_date_a+0x2 | L | (inside ref_date_a) | calendar_days_since | - | - |
| 0xF67 | 1 | ref_date_a+0x3 | L | (inside ref_date_a) | calendar_days_since | - | - |
| 0xF68 | 4 | ref_date_b | L | persisted reference date b | calendar_days_since | persisted_state_load, persist_reference_date_a, persist_reference_date_b, persist_elapsed_days | - |
| 0xF6A | 4 | elapsed_days | L | persisted elapsed-days count (read by persist_elapsed_days); reported in status_pkt_90[4..5] | get_ram_f6a, persist_elapsed_days | - | - |
| 0xF6C | 4 | ref_date_c | L | persisted reference date c | - | persisted_state_load, persist_reference_date_a, persist_reference_date_b, persist_elapsed_days | - |
| 0xF70 | 1 | settings_page_sel | L | settings page selector (settings_page_read/write/block_load) | settings_page_read, settings_page_write, settings_block_load | settings_page_read, settings_page_write, settings_block_load | - |
| 0xF71 | 1 | fet_state_F71 | L | FET/path state flags: bit0 = discharge path on (skips load detect), bit2 = charge path on (blocks power-on); written by chg_fet_control, dsg_fet_control, power_rail_sequence_a | power_on_off_decision, chg_fet_control, dsg_fet_control, power_rail_sequence_a, pb14_ctrl_logic | chg_fet_control, dsg_fet_control, power_rail_sequence_a, pb14_ctrl_logic, fet_status_poll | - |
| 0xF72 | 1 | prot_flags_F72 | L | protection latch byte F72; bits 4..7 feed register flag bit 11 (imbalance) | bms_register_block_publish, history_record_build, history_fault_score_track, session_event_logger, persist_deep_discharge_flag | bms_new_second_housekeeping, persisted_state_load, deep_discharge_latch, fault_chg_current_when_chg_off, fault_dsg_current_when_dsg_off | - |
| 0xF73 | 1 | bq_fault_flags | S | bit2 = BQ I2C not answering (set by bq_fault_response_1), bit3 = FET not following request (A:C02C) | soc_correction_triggers, bms_register_block_publish, history_record_build, history_fault_score_track, session_event_logger | bq_fault_response_1, fet_state_mismatch_check | - |
| 0xF75 | 1 | aux_mirror_F75 | L | copy of 0x33 | - | power_state_flags_update | - |
| 0xF76 | 1 | session_mirror_F76 | L | copy of 0x31 | - | power_state_flags_update | - |
| 0xF77 | 2 | fault_count_F77 | L | persisted fault counter (flush bit 9) | session_event_logger, faultcount_slot_save | session_event_logger, persisted_state_load | - |
| 0xF79 | 4 | chg_energy_total | S | accumulated charge energy; register block publishes F79/2 (3 bytes); flush bit 13 | bms_register_block_publish, energy_counter_charge_log, stats_slot_save | bms_new_second_housekeeping, energy_counter_charge_log, persisted_state_load | 0 |
| 0xF7D | 4 | dsg_energy_total | S | accumulated discharge energy; publishes F7D/1000 rounded (2 bytes); flush bit 14 | bms_register_block_publish, energy_counter_discharge_log, stats_slot_save | bms_new_second_housekeeping, energy_counter_discharge_log, persisted_state_load | 0 |
| 0xF81 | 4 | internal_resistance | L | internal-resistance-like estimate (clamped 0x78..0x2710); publishes F81/40; flush bit 15 | internal_resistance_estimator, bms_register_block_publish, stats_slot_save | internal_resistance_estimator, bms_register_block_publish, bms_new_second_housekeeping, persisted_state_load | 28,78,2710 |
| 0xF85 | 4 | stress_time_a | L | time-in-stress counter a (stress_time_state0); flush bit 16 | bms_register_block_publish, stress_time_state0, stats_slot_save | bms_register_block_publish, bms_new_second_housekeeping, stress_time_state0, persisted_state_load | 0,9EB10 |
| 0xF89 | 6 | stress_flags | L | per-state stress bits written by stress_time_state12 | bms_register_block_publish | stress_time_state12 | - |
| 0xF8A | 1 | stress_flags+0x1 | L | (inside stress_flags) | bms_register_block_publish | stress_time_state12 | - |
| 0xF8B | 1 | stress_flags+0x2 | L | (inside stress_flags) | bms_register_block_publish | stress_time_state12 | - |
| 0xF8C | 1 | stress_flags+0x3 | L | (inside stress_flags) | bms_register_block_publish | stress_time_state12 | - |
| 0xF8D | 1 | stress_flags+0x4 | L | (inside stress_flags) | bms_register_block_publish | stress_time_state12 | - |
| 0xF8E | 1 | stress_flags+0x5 | L | (inside stress_flags) | bms_register_block_publish | stress_time_state12 | - |
| 0xF8F | 4 | stress_time_b | L | time-in-stress counter b; flush bit 17 | stress_time_state12, stats_slot_save | bms_new_second_housekeeping, stress_time_state12, persisted_state_load | 0,FFFFFFF |
| 0xF93 | 2 | counter_F93 | L | persisted counter F93 (flush bit 18) | bms_new_second_housekeeping, stats_slot_save | bms_new_second_housekeeping, persisted_state_load | - |
| 0xF95 | 2 | pack_mv | S | pack voltage in mV (sum of cells), written by cell_stats_publish | internal_resistance_estimator, bms_register_block_publish, session_event_logger, pack_voltage_ref_init, power_on_off_decision | cell_stats_publish | - |
| 0xF99 | 2 | cell_mean_mv | S | mean cell voltage mV | pack_uv_level2_latch, soc_correction_triggers, soft_cuv_mean_level, cell_voltage_plausibility | cell_stats_publish | - |
| 0xF9B | 2 | cell_min_mv | S | minimum cell voltage mV | soc_correction_triggers, history_record_build, soft_cuv_level, session_event_logger, status_bit4_clear_timer | cell_stats_publish | - |
| 0xF9D | 2 | cell_max_mv | S | maximum cell voltage mV | soc_correction_triggers, bms_register_block_publish, history_record_build, session_event_logger, pack_charge_ok_check | cell_stats_publish | - |
| 0xF9F | 1 | cell_min_idx | S | index of minimum cell | history_record_build | cell_stats_publish | - |
| 0xFA0 | 1 | cell_max_idx | S | index of maximum cell | history_record_build | cell_stats_publish | - |
| 0xFA1 | 1 | prot_flags_FA1 | L | cell-voltage protection latches (OV soft, UV soft, UV mean, level-2); bits 2/5 feed register flag bit 7 (UV), bits 0/1 feed bit 6 (OV) | pack_uv_level2_latch, soc_correction_triggers, pack_power_state_machine, bms_register_block_publish, history_record_build | pack_uv_level2_latch, soft_cuv_level, soft_cuv_mean_level, status_bit_clear_timers, status_bit4_clear_timer | - |
| 0xFA2 | 4 | bq_dsg_status_FA2 | L | stored DSG status word (bq_read_dsg_status_store) | undervolt_cmd_0x9335 | bq_read_dsg_status_store | - |
| 0xFA6 | 4 | cell_plaus_timer | L | cell voltage plausibility timer | cell_voltage_plausibility | cell_voltage_plausibility | - |
| 0xFAA | 2 | uv_event_count | S | persisted undervoltage event counter; published in register block 0x1089; flush bit 10 | bms_register_block_publish, bq_safety_status_react, faultcount_slot_save | bms_new_second_housekeeping, bq_safety_status_react, persisted_state_load | 0 |
| 0xFAC | 1 | prot_flags_FAC | L | BQ safety-status derived latches; feeds register flag bit 6 | soc_correction_triggers, bms_register_block_publish, session_event_logger, status_bit_clear_timers, fault_flag_aggregator | status_bit_clear_timers, bq_safety_status_react | - |
| 0xFAD | 2 | bq_cal_91A0 | C | BQ data-memory 0x91A0 value (calibration check) | - | bq_ld_gain_check_91a0 | - |
| 0xFAF | 2 | bq_cal_91A2 | C | BQ data-memory 0x91A2 value; valid 0x7D00..0x8CA0 else rewritten to 0x84D0 | - | bq_ld_gain_check_91a2 | - |
| 0xFB1 | 2 | bq_cal_91A4 | C | BQ data-memory 0x91A4 value | - | bq_ld_gain_check_91a4 | - |
| 0xFB3 | 2 | bq_cal_91B2 | C | BQ data-memory 0x91B2 value | - | bq_ld_gain_check_91b2 | - |
| 0xFB9 | 2 | ld_pin_raw | L | copy of LD pin reading 0x162D (load_detect_control) | - | load_detect_control | - |
| 0xFBB | 4 | pack_current_signed | L | signed pack current (positive = charging?; units likely mA); sign convention not verified | history_record_build, session_event_logger, stats_update_10hz, cell_voltage_copy_or_default, port_get_current_signed | bms_state_init, cell_voltage_copy_or_default | 0 |
| 0xFBF | 4 | pack_current_abs | L | absolute pack current | pack_uv_level2_latch, soc_correction_triggers, pack_power_state_machine, soft_cuv_level, dsg_ot_hysteresis | bms_state_init, cell_voltage_copy_or_default | 0 |
| 0xFC3 | 1 | prot_flags_FC3 | L | overcurrent latches; bit2 feeds register flag bit 5 (discharge OC), bits0/1 feed bit 4 (charge OC) | bms_register_block_publish, history_record_build, history_fault_score_track, dsg_oc_report_latch, session_event_logger | dsg_oc_report_latch, bms_state_init, bq_safety_status_react, sw_overcurrent_charge_levels, sw_overcurrent_discharge_levels | 0 |
| 0xFC4 | 2 | counter_FC4 | L | persisted counter FC4 (flush bit 11) | faultcount_slot_save | persisted_state_load | - |
| 0xFC7 | 1 | temp_mean_c | S | mean temperature (whole C) | bms_register_block_publish | temps_copy_and_track_max, bms_state_init | 0 |
| 0xFC8 | 1 | temp_min_c | S | coldest NTC temperature (whole C, signed) | dsg_ut_latch, bms_register_block_publish, temp_spread_latch, dsg_ut_hysteresis, session_event_logger | temps_copy_and_track_max | - |
| 0xFC9 | 1 | temp_max_c | S | hottest NTC temperature (whole C, signed) | dsg_ot_latch, temps_copy_and_track_max, bms_register_block_publish, temp_spread_latch, dsg_ot_hysteresis | temps_copy_and_track_max | - |
| 0xFCA | 1 | temp_argmin | L | index of coldest sensor | - | temps_copy_and_track_max | - |
| 0xFCB | 1 | temp_argmax | L | index of hottest sensor | - | temps_copy_and_track_max, bms_state_init | 0 |
| 0xFCC | 1 | temp_max_recorded | L | highest temperature ever recorded (persisted; flush bit 12) | temps_copy_and_track_max, faultcount_slot_save | temps_copy_and_track_max, persisted_state_load | - |
| 0xFCD | 1 | prot_flags_FCD | L | temperature latches: bit0/bit2 hot, bit1/bit4 cold -> register flags bits 0..3; bit6 = NTC1 unhealthy | dsg_ot_latch, dsg_ut_latch, temps_copy_and_track_max, bms_register_block_publish, history_record_build | dsg_ot_latch, dsg_ut_latch, dsg_ot_hysteresis, dsg_ut_hysteresis, bq_safety_status_react | - |
| 0xFCE | 1 | temp_ntc1_default | L | 25 C default used when NTC1 invalid | - | temp_fault_flags_clear | 19 |
| 0xFCF | 1 | temp_ntc2_board | L | NTC2 / board temperature (25 default) | board_ot_latch, history_record_build, ntc2_ot_latch, ntc2_plausibility | temp_fault_flags_clear, bms_state_init, ntc2_read_convert | 0,19 |
| 0xFD0 | 1 | prot_flags_FD0 | L | board / NTC2 / spread latches; bits feed register flags 8 and 9 | board_ot_latch, bms_register_block_publish, history_record_build, history_fault_score_track, temp_spread_latch | board_ot_latch, temp_spread_latch, ntc2_ot_latch, ntc2_plausibility | - |
| 0xFD3 | 1 | soc_percent | S | state of charge 0..100 (port_set_soc_x100 = round(r0/100)) | port_set_soc_x100, port_set_capacity, bms_register_block_publish, history_record_build, session_event_logger | port_set_soc_x100 | - |
| 0xFD4 | 1 | soh_percent | S | state of health percent (port_set_soh) | bms_register_block_publish | port_set_soh | - |
| 0xFD5 | 2 | cycle_count | L | cycle/age counter (port_set_cycle_ctr); published in register block 0x1077 | bms_register_block_publish, session_event_logger, eventlog_build_record | port_set_cycle_ctr | - |
| 0xFD7 | 4 | capacity_ref_fd7 | L | reference capacity value (init 10000); published /10 in register block 0x108C | bms_register_block_publish | bms_state_init | 2710 |
| 0xFDB | 4 | full_capacity | L | full-charge capacity (port_set_capacity); published /10 at 0x107B (unit unconfirmed) | port_set_soc_x100, port_set_capacity, bms_register_block_publish, session_event_logger, eventlog_build_record | port_set_capacity | - |
| 0xFDF | 4 | remaining_capacity | L | SOC% x capacity/100; published /10 at 0x1079 | bms_register_block_publish, session_event_logger, eventlog_build_record | port_set_soc_x100, port_set_capacity | - |
| 0xFE7 | 1 | power_mode_state_machine_FE7 | C | private state of power_mode_state_machine (only this function touches it; written once, never read) | - | power_mode_state_machine | - |
| 0xFE8 | 1 | power_mode_state_machine_FE8 | C | private state of power_mode_state_machine (only this function touches it; written once, never read) | - | power_mode_state_machine | - |
| 0xFE9 | 4 | link3_cmd3_value | L | value written by link_cmd_3_set_value | - | link_cmd_3_set_value | - |
| 0xFED | 4 | link3_serial | L | serial written by link_cmd_5_set_serial | - | link_cmd_5_set_serial | - |
| 0xFF1 | 1 | link3_auth_stage | L | auth response check result stage (0/1/2) | - | link_auth_response_check | 0,1,2 |
| 0xFF2 | 2 | peer_val_a | L | peer vehicle data field, 12 bits (link_cmd_7_vehicle_data, from words at 0x1232) | - | link_cmd_7_vehicle_data | - |
| 0xFF4 | 2 | peer_val_b | L | peer vehicle data field, 10 bits | - | link_cmd_7_vehicle_data | - |
| 0xFF6 | 1 | peer_val_c | L | peer vehicle data field, 6 bits | - | link_cmd_7_vehicle_data | - |
| 0xFF7 | 2 | peer_val_d | L | peer vehicle data field, 12 bits | - | link_cmd_7_vehicle_data | - |
| 0xFF9 | 2 | peer_val_e | L | peer vehicle data field (12 bits, >>4) | - | link_cmd_7_vehicle_data | - |
| 0xFFB | 2 | peer_val_f | L | peer vehicle data field, 10 bits | - | link_cmd_7_vehicle_data | - |
| 0xFFD | 2 | peer_val_g | L | peer vehicle data field, 10 bits | - | link_cmd_7_vehicle_data | - |
| 0xFFF | 2 | link3_tx_a | L | USART3 sequencer working value | - | usart3_link_tx_sequencer | - |
| 0x1001 | 2 | link3_tx_b | L | USART3 sequencer working value | - | usart3_link_tx_sequencer | - |
| 0x1004 | 84 | settings_block_1004 | L | 0x54-byte settings block written to settings page 4 by settings_housekeeping | - | - | - |
| 0x1032 | 2 | date_code_1032 | L | date code decoded by decode_date_0x1032 | decode_date_0x1032 | - | - |
| 0x1058 | 4 | ev_payload_soc_acc | L | payload for event bit0 (A:11668) | ev_dispatch_84 | - | - |
| 0x105C | 4 | ev_payload_persist_a | L | payload for event bit1 (persist_model_event_a); bms_new_second_housekeeping writes it | ev_dispatch_84, calibration_block_apply | bms_new_second_housekeeping | 0 |
| 0x1060 | 4 | ev_payload_persist_b1 | L | payload for event bit2 (persist_model_event_b with 0x1350) | ev_dispatch_84 | - | - |
| 0x1064 | 4 | ev_payload_persist_b2 | L | payload for event bit3 (persist_model_event_b with 0x134C) | ev_dispatch_84 | - | - |
| 0x1068 | 2 | ev_payload_persist_c1 | L | payload for event bit4 (persist_model_event_c with 0x1356); init 0x3E8 | ev_dispatch_84, calibration_block_apply | bms_new_second_housekeeping | 3E8 |
| 0x106A | 1 | ev_payload_persist_c2_b | L | byte payload for event bit5 | ev_dispatch_84 | - | - |
| 0x106B | 2 | ev_payload_1357 | L | payload for event bit6 (A:11888 -> 0x1357) | ev_dispatch_84 | - | - |
| 0x106E | 1 | reg_max_cell_x | L | byte = max cell mV / 10 + 6 (truncated to 8 bits; meaning/units unconfirmed) | - | bms_register_block_publish, bms_register_block_init | 0 |
| 0x106F | 1 | reg_soc_percent | S | SOC percent (copy of 0xFD3) | - | bms_register_block_publish | - |
| 0x1070 | 2 | reg_pack_mv | S | pack voltage mV, big endian (copy of 0xF95) | - | bms_register_block_publish | - |
| 0x1071 | 1 | reg_pack_mv+0x1 | S | (inside reg_pack_mv) | - | bms_register_block_publish | - |
| 0x1072 | 2 | reg_current_sm | L | averaged current, sign-magnitude (bit15 = sign), from BQ CC2 reading 0x162F (moving average x10 /10) | - | bms_register_block_publish, bms_register_block_init | 0 |
| 0x1073 | 1 | reg_current_sm+0x1 | L | (inside reg_current_sm) | - | bms_register_block_publish | - |
| 0x1074 | 1 | reg_temp_sm | S | temperature, sign-magnitude (bit7 = sign): coldest if cold latch, hottest if hot latch, else mean | - | bms_register_block_publish | - |
| 0x1075 | 2 | reg_flags | S | flag word: b15 charging, b14 discharging, b13 pack on, b12 fully charged, b11 imbalance, b10 comm fail, b9 temp-sensor fault (FD0.b3/FCD.b6), b8 temperature spread >= 8 C (FD0.b2), b7 UV (FA1.b2/b5), b6 OV (FA1.b0/b1/FAC.b0), b5 discharge OC report (FC3.b2), b4 charge OC (FC3.b0/b1), b3 FCD.b4, b2 FCD.b2, b1 FCD.b1, b0 FCD.b0 | bms_register_block_publish | bms_register_block_publish | - |
| 0x1076 | 1 | reg_flags+0x1 | S | (inside reg_flags) | - | bms_register_block_init | 0 |
| 0x1077 | 2 | reg_cycle_count | S | cycle counter BE (0xFD5) | - | bms_register_block_publish | - |
| 0x1078 | 1 | reg_cycle_count+0x1 | S | (inside reg_cycle_count) | - | bms_register_block_publish | - |
| 0x1079 | 2 | reg_remaining_cap | L | remaining capacity /10 BE (0xFDF/10) | - | bms_register_block_publish | - |
| 0x107A | 1 | reg_remaining_cap+0x1 | L | (inside reg_remaining_cap) | - | bms_register_block_publish | - |
| 0x107B | 2 | reg_full_cap | L | full capacity /10 BE (0xFDB/10) | - | bms_register_block_publish | - |
| 0x107C | 1 | reg_full_cap+0x1 | L | (inside reg_full_cap) | - | bms_register_block_publish | - |
| 0x107D | 2 | reg_age_days | L | days since reference date BE (calendar_days_since) | - | bms_register_block_publish | - |
| 0x107E | 1 | reg_age_days+0x1 | L | (inside reg_age_days) | - | bms_register_block_publish | - |
| 0x107F | 2 | reg_elapsed_days | L | 0xF6A value BE | - | bms_register_block_publish | - |
| 0x1080 | 1 | reg_elapsed_days+0x1 | L | (inside reg_elapsed_days) | - | bms_register_block_publish | - |
| 0x1081 | 2 | reg_rom_const | L | constant from ROM 0x8019C42 (design value?) | - | bms_register_block_publish | - |
| 0x1082 | 1 | reg_rom_const+0x1 | L | (inside reg_rom_const) | - | bms_register_block_publish | - |
| 0x1083 | 1 | reg_soh_percent | S | SOH percent (0xFD4) | - | bms_register_block_publish | - |
| 0x1084 | 3 | reg_chg_energy | L | charge energy (0xF79/2 rounded) 24-bit BE | - | bms_register_block_publish, bms_register_block_init | 0 |
| 0x1085 | 1 | reg_chg_energy+0x1 | L | (inside reg_chg_energy) | - | bms_register_block_publish | - |
| 0x1086 | 1 | reg_chg_energy+0x2 | L | (inside reg_chg_energy) | - | bms_register_block_publish | - |
| 0x1087 | 2 | reg_dsg_energy | L | discharge energy (0xF7D/1000 rounded) BE | - | bms_register_block_publish | - |
| 0x1088 | 1 | reg_dsg_energy+0x1 | L | (inside reg_dsg_energy) | - | bms_register_block_publish, bms_register_block_init | 0 |
| 0x1089 | 2 | reg_uv_count | S | undervoltage event counter BE (0xFAA) | - | bms_register_block_publish | - |
| 0x108A | 1 | reg_uv_count+0x1 | S | (inside reg_uv_count) | - | bms_register_block_publish | - |
| 0x108B | 1 | reg_resistance | L | internal resistance estimate /40 (0xF81) | - | bms_register_block_publish | - |
| 0x108C | 2 | reg_capacity_ref | L | 0xFD7/10 BE | - | bms_register_block_publish, bms_register_block_init | 0 |
| 0x108D | 1 | reg_capacity_ref+0x1 | L | (inside reg_capacity_ref) | - | bms_register_block_publish | - |
| 0x10B8 | 4 | ble_parse_state | L | BLE/dash frame parse state (ble_frame_parse) | ble_frame_parse | ble_frame_parse | - |
| 0x10B9 | 1 | ble_parse_state+0x1 | L | (inside ble_parse_state) | ble_frame_parse | ble_frame_parse | - |
| 0x10BA | 1 | ble_parse_state+0x2 | L | (inside ble_parse_state) | - | ble_frame_parse | - |
| 0x10BB | 1 | ble_parse_state+0x3 | L | (inside ble_parse_state) | ble_frame_parse | ble_frame_parse | - |
| 0x1152 | 2 | ble_parse_state2 | L | BLE/dash frame parse state | ble_frame_parse | ble_frame_parse | - |
| 0x1153 | 1 | ble_parse_state2+0x1 | L | (inside ble_parse_state2) | ble_frame_parse | ble_frame_parse | - |
| 0x1154 | 9 | protoN_parse_state | L | protocol N (0x6E) frame parse state (protocolN_parse) | protocolN_parse | protocolN_parse | - |
| 0x1155 | 1 | protoN_parse_state+0x1 | L | (inside protoN_parse_state) | protocolN_parse | protocolN_parse | - |
| 0x1156 | 1 | protoN_parse_state+0x2 | L | (inside protoN_parse_state) | - | protocolN_parse | - |
| 0x1157 | 1 | protoN_parse_state+0x3 | L | (inside protoN_parse_state) | - | protocolN_parse | - |
| 0x1158 | 1 | protoN_parse_state+0x4 | L | (inside protoN_parse_state) | - | protocolN_parse | - |
| 0x1159 | 1 | protoN_parse_state+0x5 | L | (inside protoN_parse_state) | - | protocolN_parse | - |
| 0x115A | 1 | protoN_parse_state+0x6 | L | (inside protoN_parse_state) | protocolN_parse | protocolN_parse | - |
| 0x115B | 1 | protoN_parse_state+0x7 | L | (inside protoN_parse_state) | - | protocolN_parse | - |
| 0x115C | 1 | protoN_parse_state+0x8 | L | (inside protoN_parse_state) | - | protocolN_parse | - |
| 0x11F1 | 2 | protoN_parse_state2 | L | protocol N parse state | protocolN_parse | protocolN_parse | - |
| 0x11F2 | 1 | protoN_parse_state2+0x1 | L | (inside protoN_parse_state2) | protocolN_parse | protocolN_parse | - |
| 0x11F3 | 4 | motor_link_parse_state | L | motor-controller link parse state (uart_frame_parse_min4_max40; len 3..0x10 const) | - | uart_frame_parse_min4_max40 | 3,10 |
| 0x11F4 | 1 | motor_link_parse_state+0x1 | L | (inside motor_link_parse_state) | uart_frame_parse_min4_max40 | uart_frame_parse_min4_max40 | - |
| 0x11F5 | 1 | motor_link_parse_state+0x2 | L | (inside motor_link_parse_state) | - | uart_frame_parse_min4_max40 | - |
| 0x11F6 | 1 | motor_link_parse_state+0x3 | L | (inside motor_link_parse_state) | uart_frame_parse_min4_max40 | uart_frame_parse_min4_max40 | - |
| 0x1220 | 2 | motor_link_parse_state2 | L | motor-controller link parse state | uart_frame_parse_min4_max40 | uart_frame_parse_min4_max40 | - |
| 0x1221 | 1 | motor_link_parse_state2+0x1 | L | (inside motor_link_parse_state2) | uart_frame_parse_min4_max40 | uart_frame_parse_min4_max40 | - |
| 0x1232 | 28 | peer_words_1232 | L | 7 big-endian 32-bit words from USART3 peer command 7 (vehicle data), unpacked into 0xFF2..0xFFD | link_cmd_7_vehicle_data | - | - |
| 0x1236 | 2 | peer_words_1232+0x4 | L | (inside peer_words_1232) | usart3_link_tx_sequencer, link_cmd_7_vehicle_data | - | - |
| 0x1237 | 2 | peer_words_1232+0x5 | L | (inside peer_words_1232) | usart3_link_tx_sequencer, link_cmd_7_vehicle_data | - | - |
| 0x1238 | 2 | peer_words_1232+0x6 | L | (inside peer_words_1232) | usart3_link_tx_sequencer, link_cmd_7_vehicle_data | - | - |
| 0x123A | 2 | peer_words_1232+0x8 | L | (inside peer_words_1232) | usart3_link_tx_sequencer, link_cmd_7_vehicle_data | - | - |
| 0x123B | 2 | peer_words_1232+0x9 | L | (inside peer_words_1232) | usart3_link_tx_sequencer, link_cmd_7_vehicle_data | - | - |
| 0x123C | 2 | peer_words_1232+0xA | L | (inside peer_words_1232) | usart3_link_tx_sequencer, link_cmd_7_vehicle_data | - | - |
| 0x1250 | 12 | limits_init_words | L | limit values set by limits_init (0xFE, 0xFE, 0x102, 0x102, 0xA, 2) | - | limits_init | FE |
| 0x1252 | 2 | limits_init_words+0x2 | L | (inside limits_init_words) | - | limits_init | FE |
| 0x1256 | 2 | limits_init_words+0x6 | L | (inside limits_init_words) | - | limits_init | 102 |
| 0x1258 | 2 | limits_init_words+0x8 | L | (inside limits_init_words) | - | limits_init | 102 |
| 0x125A | 2 | limits_init_words+0xA | L | (inside limits_init_words) | - | limits_init | A |
| 0x125C | 2 | limits_init_125C | C | private state of limits_init (only this function touches it; written once, never read) | - | limits_init | 2 |
| 0x1260 | 4 | link_boot_cmd_words | L | bootloader entry command words compared in bootloader_entry_commands (0xE0 magic 0x5AA5 path) | bootloader_entry_commands | - | - |
| 0x1262 | 2 | link_boot_cmd_words+0x2 | L | (inside link_boot_cmd_words) | bootloader_entry_commands | - | - |
| 0x128B | 4 | soh_deg_acc_a | L | soh_degradation_step accumulator | soh_degradation_step | soh_degradation_step, model_state_reset | 0 |
| 0x128F | 4 | model_timer_latch_a | L | model_two_timer_latches timer a | model_two_timer_latches | model_input_gather, model_state_reset | 0 |
| 0x1293 | 4 | model_timer_latch_b | L | model_two_timer_latches timer b | model_two_timer_latches | model_input_gather, model_state_reset | 0 |
| 0x1297 | 4 | model_age_acc | L | model_age_counter_step accumulator | model_age_counter_step | model_input_gather, model_state_reset | 0 |
| 0x129B | 4 | soh_deg_acc_b | L | soh_degradation_step accumulator (second) | soh_degradation_step | model_input_gather, model_state_reset | 0 |
| 0x129F | 4 | model_cur_zero_acc | L | model_current_zero_cal_step accumulator (init 0xFFFFFFFE after reset) | model_current_zero_cal_step | model_current_zero_cal_step, model_state_reset | 0,FFFFFFFE |
| 0x12A3 | 4 | soc_ocv_acc | L | soc_model_ocv_update / soc_coulomb_integrate shared accumulator | soc_model_ocv_update | soc_model_ocv_update, soc_coulomb_integrate, model_state_reset | 0 |
| 0x12A7 | 2 | soc_sm_timer | L | soc_model_state_machine timer | soc_model_state_machine | soc_model_state_machine, model_state_reset | 0 |
| 0x12A9 | 2 | soh_degradation_step_12A9 | C | private state of soh_degradation_step (only this function touches it) | soh_degradation_step | soh_degradation_step, model_state_reset | 0 |
| 0x12AB | 2 | soh_deg_timer_b | L | soh_degradation_step timer (init 0x3E8 in model_input_gather) | soh_degradation_step | model_input_gather, model_state_reset | 0,3E8 |
| 0x12AD | 2 | age_timer | L | model_age_counter_step timer | model_age_counter_step | model_input_gather, model_state_reset | 0 |
| 0x12AF | 2 | soh_capacity_percent_step_12AF | C | private state of soh_capacity_percent_step (only this function touches it) | soh_capacity_percent_step | soh_capacity_percent_step, model_state_reset | 0 |
| 0x12B1 | 2 | model_age_counter_step_12B1 | C | private state of model_age_counter_step (only this function touches it) | model_age_counter_step | model_age_counter_step, model_state_reset | 0 |
| 0x12B3 | 2 | soc_sm_timer_b | L | soc_model_state_machine timer (init 0xFFFE) | soc_model_state_machine | soc_model_ocv_update, model_state_reset | 0,FFFE |
| 0x12B5 | 1 | soh_degradation_step_12B5 | C | private state of soh_degradation_step (only this function touches it) | soh_degradation_step | soh_degradation_step, model_state_reset | 0 |
| 0x12B6 | 1 | soh_flag_b6 | L | soh_degradation_step flag | soh_degradation_step | model_input_gather, model_state_reset | 0 |
| 0x12B7 | 1 | soh_flag_b7 | L | soh_degradation_step flag | soh_degradation_step | model_current_zero_cal_step, model_state_reset | 0 |
| 0x12B8 | 1 | soc_flag_b8 | L | written by soh_capacity_percent_step, read by soc_model_ocv_update and soc_model_state_machine | soc_model_ocv_update, soc_model_state_machine | soh_capacity_percent_step | - |
| 0x12B9 | 1 | soc_model_ocv_update_12B9 | C | private state of soc_model_ocv_update (only this function touches it) | soc_model_ocv_update | soc_model_ocv_update, model_state_reset | 0,1 |
| 0x12BA | 4 | soc_sm_value | L | soc_model_state_machine value | soc_model_state_machine | soc_model_state_machine | - |
| 0x12BE | 4 | model_age_counter_step_12BE | C | private state of model_age_counter_step (only this function touches it) | model_age_counter_step | model_age_counter_step | - |
| 0x12C2 | 16 | coulomb_step_state | L | coulomb_counter_step state words (4 x 32-bit: 12C2, 12C6, 12CA, 12CE) | coulomb_counter_step | coulomb_counter_step | - |
| 0x12C6 | 4 | coulomb_step_state+0x4 | L | (inside coulomb_step_state) | coulomb_counter_step | coulomb_counter_step | - |
| 0x12CA | 4 | coulomb_step_state+0x8 | L | (inside coulomb_step_state) | coulomb_counter_step | coulomb_counter_step | - |
| 0x12CE | 4 | coulomb_step_state+0xC | L | (inside coulomb_step_state) | coulomb_counter_step | coulomb_counter_step | - |
| 0x12D2 | 4 | soc_ocv_value | L | soc_model_ocv_update value | soc_model_ocv_update | soc_model_ocv_update | - |
| 0x12D6 | 8 | model_timer_pair | L | model_two_timer_latches counters (12D6, 12DA) | model_two_timer_latches | model_two_timer_latches | - |
| 0x12DA | 4 | model_timer_pair+0x4 | L | (inside model_timer_pair) | model_two_timer_latches | model_two_timer_latches | - |
| 0x12DE | 8 | coulomb_step_state2 | L | coulomb_counter_step state words (12DE, 12E2) | coulomb_counter_step | coulomb_counter_step | - |
| 0x12E2 | 4 | coulomb_step_state2+0x4 | L | (inside coulomb_step_state2) | coulomb_counter_step | coulomb_counter_step | - |
| 0x12E6 | 4 | ocv_rest_timer | L | ocv_rest_tracker rest timer (init 0x105F after reset) | ocv_rest_tracker | soh_capacity_percent_step, ocv_rest_tracker, model_state_reset | 0,105F |
| 0x12EA | 4 | soh_degradation_step_12EA | C | private state of soh_degradation_step (only this function touches it) | soh_degradation_step | soh_degradation_step, model_state_reset | 0 |
| 0x12EE | 4 | model_current_zero_cal_step_12EE | C | private state of model_current_zero_cal_step (only this function touches it) | model_current_zero_cal_step | model_current_zero_cal_step, model_state_reset | 0 |
| 0x12F2 | 4 | model_current_zero_cal_step_12F2 | C | private state of model_current_zero_cal_step (only this function touches it) | model_current_zero_cal_step | model_current_zero_cal_step, model_state_reset | 0 |
| 0x12F6 | 4 | model_current_zero_cal_step_12F6 | C | private state of model_current_zero_cal_step (only this function touches it) | model_current_zero_cal_step | model_current_zero_cal_step, model_state_reset | 0 |
| 0x12FA | 4 | ocv_rest_acc2 | L | ocv_rest_tracker second accumulator | ocv_rest_tracker | soh_capacity_percent_step, ocv_rest_tracker, model_state_reset | 0 |
| 0x12FE | 4 | soc_charge_acc | L | SOC coulomb accumulator (soc_coulomb_integrate) | soc_model_ocv_update, soc_coulomb_integrate | soc_model_ocv_update, soc_coulomb_integrate, model_state_reset | 0 |
| 0x1302 | 2 | model_dt_a | L | model_change_detect / model_dt_latch_step a | model_change_detect | model_dt_latch_step, model_change_detect, model_state_reset | 0 |
| 0x1304 | 2 | soh_degradation_step_1304 | C | private state of soh_degradation_step (only this function touches it) | soh_degradation_step | soh_degradation_step, model_state_reset | 0 |
| 0x1306 | 2 | ocv_rest_a | L | ocv_rest_tracker value a | ocv_rest_tracker | soh_capacity_percent_step, ocv_rest_tracker, model_state_reset | 0 |
| 0x1308 | 2 | ocv_rest_b | L | ocv_rest_tracker value b | ocv_rest_tracker | soh_capacity_percent_step, ocv_rest_tracker, model_state_reset | 0 |
| 0x130A | 2 | model_dt_b | L | model_change_detect / model_dt_latch_step b | model_change_detect | model_dt_latch_step, model_change_detect, model_state_reset | 0 |
| 0x130C | 1 | coulomb_step_flag | L | coulomb_counter_step flag | coulomb_counter_step | coulomb_counter_step | - |
| 0x130D | 3 | soc_sm_flags | L | soc_model_state_machine state bytes (130D..130F) | soc_model_state_machine | soc_model_state_machine, model_state_reset | 0,1 |
| 0x130E | 1 | soc_sm_flags+0x1 | L | (inside soc_sm_flags) | soc_model_state_machine | soc_model_state_machine, model_state_reset | 0,1 |
| 0x130F | 1 | soc_sm_flags+0x2 | L | (inside soc_sm_flags) | soc_model_state_machine | soc_model_state_machine, model_state_reset | 0,1,2,3 |
| 0x1310 | 1 | soc_sm_state | L | soc_model_state_machine main state | soc_model_state_machine | soc_model_state_machine, model_settle_check, model_state_reset | 0 |
| 0x1311 | 7 | soh_deg_flags | L | soh_degradation_step state bytes (1311..1317) | soh_degradation_step | soh_degradation_step, model_state_reset | 0,1 |
| 0x1312 | 1 | soh_deg_flags+0x1 | L | (inside soh_deg_flags) | soh_degradation_step | soh_degradation_step, model_state_reset | 0,2,3,4 |
| 0x1313 | 1 | soh_deg_flags+0x2 | L | (inside soh_deg_flags) | soh_degradation_step | soh_degradation_step, model_state_reset | 0 |
| 0x1314 | 1 | soh_deg_flags+0x3 | L | (inside soh_deg_flags) | soh_degradation_step | soh_degradation_step, model_state_reset | 0,1 |
| 0x1315 | 1 | soh_deg_flags+0x4 | L | (inside soh_deg_flags) | soh_degradation_step | soh_degradation_step, model_state_reset | 0,1,2 |
| 0x1316 | 1 | soh_deg_flags+0x5 | L | (inside soh_deg_flags) | soh_degradation_step | soh_degradation_step, model_state_reset | 0,1 |
| 0x1317 | 1 | soh_deg_flags+0x6 | L | (inside soh_deg_flags) | soh_degradation_step | soh_degradation_step, model_state_reset | 0,1,2 |
| 0x1318 | 4 | model_latch_flags | L | model_two_timer_latches state bytes (1318..131B) | model_two_timer_latches | model_two_timer_latches, model_state_reset | 0,1 |
| 0x1319 | 1 | model_latch_flags+0x1 | L | (inside model_latch_flags) | model_two_timer_latches | model_two_timer_latches, model_state_reset | 0,1,2 |
| 0x131A | 1 | model_latch_flags+0x2 | L | (inside model_latch_flags) | model_two_timer_latches | model_two_timer_latches, model_state_reset | 0,1 |
| 0x131B | 1 | model_latch_flags+0x3 | L | (inside model_latch_flags) | model_two_timer_latches | model_two_timer_latches, model_state_reset | 0,1,2 |
| 0x131C | 3 | cur_zero_flags | L | model_current_zero_cal_step state bytes (131C..131E) | model_current_zero_cal_step | model_current_zero_cal_step, model_state_reset | 0,1 |
| 0x131D | 1 | cur_zero_flags+0x1 | L | (inside cur_zero_flags) | model_current_zero_cal_step | model_current_zero_cal_step, model_state_reset | 0,2,3 |
| 0x131E | 1 | cur_zero_flags+0x2 | L | (inside cur_zero_flags) | model_current_zero_cal_step | model_current_zero_cal_step, model_state_reset | 0 |
| 0x131F | 2 | soh_cap_flags | L | soh_capacity_percent_step state bytes | soh_capacity_percent_step | soh_capacity_percent_step, model_state_reset | 0,1 |
| 0x1320 | 1 | soh_cap_flags+0x1 | L | (inside soh_cap_flags) | soh_capacity_percent_step | soh_capacity_percent_step, model_state_reset | 0,1,2,3 |
| 0x1321 | 1 | ocv_rest_flag | L | ocv_rest_tracker flag | ocv_rest_tracker | soh_capacity_percent_step, ocv_rest_tracker, model_state_reset | 0 |
| 0x1322 | 2 | dt_latch_flags | L | model_dt_latch_step state bytes | model_dt_latch_step | model_dt_latch_step, model_state_reset | 0,1 |
| 0x1323 | 1 | dt_latch_flags+0x1 | L | (inside dt_latch_flags) | model_dt_latch_step | model_dt_latch_step, model_state_reset | 0,1,2 |
| 0x1324 | 3 | age_step_flags | L | model_age_counter_step state bytes | model_age_counter_step | model_age_counter_step, model_state_reset | 0,1 |
| 0x1325 | 1 | age_step_flags+0x1 | L | (inside age_step_flags) | model_age_counter_step | model_age_counter_step, model_state_reset | 0,1 |
| 0x1326 | 1 | age_step_flags+0x2 | L | (inside age_step_flags) | model_age_counter_step | model_age_counter_step, model_state_reset | 0,1,2 |
| 0x1327 | 4 | soc_ocv_flags | L | soc_model_ocv_update state bytes (1327..132A) | soc_model_ocv_update | soc_model_ocv_update, model_state_reset | 0,1 |
| 0x1328 | 1 | soc_ocv_flags+0x1 | L | (inside soc_ocv_flags) | soc_model_ocv_update | soc_model_ocv_update, model_state_reset | 0,1 |
| 0x1329 | 1 | soc_ocv_flags+0x2 | L | (inside soc_ocv_flags) | soc_model_ocv_update | soc_model_ocv_update, model_state_reset | 0,2,3,4 |
| 0x132A | 1 | soc_ocv_flags+0x3 | L | (inside soc_ocv_flags) | soc_model_ocv_update | soc_model_ocv_update, model_state_reset | 0 |
| 0x1344 | 4 | port_soc_charge_acc | C | 32-bit charge/SOC accumulator (A:10E5C set, A:8D90 get) | port_get_soc_charge_acc | port_set_soc_charge_acc, model_ports_clear | 0 |
| 0x1348 | 4 | port_1348 | C | 32-bit model port (event param, A:10F30 set) | port_get_1348 | port_set_1348, model_ports_clear | 0 |
| 0x134C | 4 | port_134c | C | 32-bit model port (event param for persist_model_event_b) | ev_dispatch_84, port_get_134c, eventlog_build_record | port_set_134c, model_ports_clear | 0 |
| 0x1350 | 4 | port_1350 | C | 32-bit model port (event param for persist_model_event_b) | ev_dispatch_84, port_get_1350, eventlog_build_record | port_set_1350, model_ports_clear | 0 |
| 0x1354 | 2 | port_1354 | C | 16-bit model port (persist_model_event_c param) | ev_dispatch_84, port_get_1354 | port_set_1354, model_ports_clear | 0 |
| 0x1356 | 1 | port_1356 | C | byte model port (persist_model_event_c param) | ev_dispatch_84, port_get_1356 | port_set_1356, model_ports_clear | 0 |
| 0x1357 | 2 | port_soc_x100_1357 | L | SOC in 0.01 % units (0..10000) as seen by soc_correction_triggers | soc_correction_triggers, port_get_1357 | port_set_1357, model_ports_clear | 0 |
| 0x1359 | 1 | port_model_init_gave_up | L | set to 1 when model_init_sequence gives up waiting for pack-charge-ok | port_get_1359 | model_init_sequence, model_ports_clear | 0,1 |
| 0x135A | 2 | port_max_cell_mv | C | max cell mV copy (A:8ECC) | port_get_max_cell_mv, eventlog_build_record | port_get_max_cell_mv, model_ports_clear | 0 |
| 0x135C | 2 | port_min_cell_mv | C | min cell mV copy (A:8EE8) | port_get_min_cell_mv, eventlog_build_record | port_get_min_cell_mv, model_ports_clear | 0 |
| 0x135E | 2 | port_temp_min_c | C | coldest temperature, sign-extended whole C (A:8F58) | port_get_temp_min_c | port_get_temp_min_c, model_ports_clear | 0 |
| 0x1360 | 1 | port_flag_1360 | C | model input flag (A:8E38) | port_get_1360 | model_ports_clear, state_record_unpack_a | 0,1 |
| 0x1361 | 4 | port_1361 | C | model input (model_port_1361) | model_port_1361 | model_ports_clear, state_record_unpack_a | 0 |
| 0x1365 | 4 | port_1365 | C | model input (model_port_1365) | model_port_1365 | model_ports_clear, state_record_unpack_a | 0 |
| 0x1369 | 1 | port_flag_1369 | C | model input flag (A:8E2C) | port_get_1369, eventlog_build_record | model_ports_clear, state_record_unpack_a | 0,1 |
| 0x136A | 4 | port_136a | L | model input (energy counters read it) | model_port_136a, energy_counter_discharge_log, energy_counter_charge_log | model_ports_clear, state_record_unpack_a | 0 |
| 0x136E | 2 | port_136e | L | model input | model_port_136e | model_ports_clear, state_record_unpack_a | 0 |
| 0x1370 | 1 | port_flag_1370 | C | model input flag (A:8E44) | port_get_1370, eventlog_build_record | model_ports_clear, state_record_unpack_a | 0,1 |
| 0x1371 | 2 | port_1371 | L | model input (init 0x3E8 in state record) | model_port_1371 | model_ports_clear, state_record_unpack_a | 0,3E8 |
| 0x1373 | 1 | port_1373 | L | model input byte | model_port_1373 | model_ports_clear, state_record_unpack_a | 0 |
| 0x1374 | 4 | port_current_signed | C | signed pack current copy for the model (A:8F24) | port_get_current_signed | port_get_current_signed, model_ports_clear | 0 |
| 0x1378 | 1 | port_full_anchor_req | S | request: apply full-charge anchor to the model (raised by soc_correction_triggers) | soc_correction_triggers, port_get_1378_full_anchor | soc_correction_triggers, model_ports_clear | 0,1 |
| 0x1379 | 4 | port_rest_counter | C | copy of 0xA4C for the model (A:8EB4) | port_get_sleep_ctr | port_get_sleep_ctr, model_ports_clear | 0 |
| 0x137D | 1 | port_low_anchor_req | S | request: apply low-voltage anchor to the model | soc_correction_triggers, port_get_137d_low_anchor | soc_correction_triggers, model_ports_clear | 0,1 |
| 0x137E | 2 | port_const_920 | C | constant 0x398 (920) written by A:8E9C | port_get_const_920 | port_get_const_920, model_ports_clear | 0,398 |
| 0x1380 | 4 | port_1380 | L | model input (state record unpack) | model_port_1380 | state_record_unpack_a | - |
| 0x1384 | 1 | flag_1384 | C | set by A:10FF8 | - | flag_set_1384 | - |
| 0x1385 | 2 | port_1385 | C | model port | port_get_1385 | port_set_1385 | - |
| 0x1387 | 2 | port_1387 | C | model port | port_get_1387 | port_set_1387 | - |
| 0x1389 | 1 | flag_1389 | C | set by A:10FB0 | - | flag_set_1389 | - |
| 0x138A | 4 | port_current_a | L | model current input (port_get_138a_current) | port_get_138a_current | port_set_138a | - |
| 0x138E | 4 | port_138e | C | model port | port_get_138e | port_set_138e | - |
| 0x1392 | 4 | port_1392 | C | model port | port_get_1392 | port_set_1392 | - |
| 0x1396 | 4 | port_1396 | C | model port | port_get_1396 | port_set_1396 | - |
| 0x139A | 1 | flag_139a | C | set by A:10FEC | - | flag_set_139a | - |
| 0x139B | 4 | model_persist_139b | L | persisted model value (state record word 1) | persist_model_event_a, persist_model_event_c, port_get_139b, calibration_block_apply, state_record_pack_save | port_set_139b | - |
| 0x139F | 4 | model_persist_139f | L | persisted model value (state record word 2) | persist_model_event_a, persist_model_event_c, port_get_139f, calibration_block_apply, state_record_pack_save | port_set_139f | - |
| 0x13A3 | 1 | flag_13a3 | C | A:10FA4 | - | flag_set_13a3 | - |
| 0x13A4 | 2 | port_13a4 | L | SOC +-10000 clamp result (A:10EAC) | port_get_13a4 | port_set_13a4 | - |
| 0x13A6 | 1 | port_13a6 | L | setting it to 1 clears rest counter 0xA4C | port_get_13a6 | port_set_13a6 | - |
| 0x13A7 | 1 | flag_13a7 | C | A:11010 | - | flag_set_13a7 | - |
| 0x13A8 | 2 | port_13a8 | C | model port | port_get_13a8 | port_set_13a8 | - |
| 0x13AA | 1 | flag_13aa | C | A:1101C | - | flag_set_13aa | - |
| 0x13AB | 2 | port_soc_x100_13ab | L | SOC in 0.01 % units (set with 0xFD3/0xFDF by A:10ED0) | port_get_13ab | port_set_soc_x100 | - |
| 0x13AD | 1 | flag_13ad | C | A:10FD4 | - | flag_set_13ad | - |
| 0x13AE | 2 | port_13ae | C | A:11028 | - | port_set_13ae | - |
| 0x13B0 | 1 | flag_13b0 | C | A:10FBC | - | flag_set_13b0 | - |
| 0x13B1 | 2 | model_persist_13b1 | L | persisted model value | persist_model_event_b, persist_model_event_c, state_record_pack_save | port_set_13b1 | - |
| 0x13B3 | 4 | cycle_ctr_mirror | L | cycle/age counter mirror (also 0xFD5) | persist_model_event_b, persist_model_event_c, port_get_13b3, state_record_pack_save | port_set_cycle_ctr | - |
| 0x13B7 | 1 | flag_13b7 | C | A:10FE0 | - | flag_set_13b7 | - |
| 0x13B8 | 4 | port_13b8 | C | model port | port_get_13b8 | port_set_13b8 | - |
| 0x13BC | 1 | flag_13bc | C | A:11004 | - | flag_set_13bc | - |
| 0x13BD | 4 | capacity_mirror | L | copy of full capacity (A:11034) | - | port_set_capacity | - |
| 0x13C1 | 2 | port_13c1 | C | model port | port_get_13c1 | port_set_13c1 | - |
| 0x13C3 | 2 | soh_permille | L | SOH in permille | port_get_soh_permille | port_set_soh | - |
| 0x13C5 | 2 | model_persist_13c5 | L | persisted model value | persist_model_event_a, persist_model_event_b, state_record_pack_save | port_set_13c5 | - |
| 0x13C7 | 1 | model_persist_13c7 | L | persisted model value | persist_model_event_a, persist_model_event_b, calibration_block_apply, state_record_pack_save | port_set_13c7 | - |
| 0x13C8 | 1 | flag_13c8 | C | A:10FC8 | - | flag_set_13c8 | - |
| 0x13C9 | 1 | model_state_valid | L | model state valid flag (also sets 0xA50) | port_set_13c9, persist_model_state_if_enabled | port_set_13c9 | - |
| 0x13CA | 4 | port_13ca | C | state record field (A:10E68) | state_record_pack_save | port_set_13ca | - |
| 0x13CE | 276 | param_image | L | expanded parameter image 0x13CE..0x14E1 built by bms_params_expand_A/B/C and bms_params_copy_P/E from the default groups below; per-field meaning not decoded (BMS/model configuration) | - | bms_params_expand_C | - |
| 0x13D0 | 1 | param_image+0x2 | L | (inside param_image) | - | bms_params_expand_C | - |
| 0x13D1 | 2 | param_image+0x3 | L | (inside param_image) | - | bms_params_expand_C | - |
| 0x13D3 | 1 | param_image+0x5 | L | (inside param_image) | - | bms_params_expand_C | - |
| 0x13D4 | 1 | param_image+0x6 | L | (inside param_image) | - | bms_params_expand_C | - |
| 0x13D5 | 1 | param_image+0x7 | L | (inside param_image) | - | bms_params_expand_C | - |
| 0x13D6 | 1 | param_image+0x8 | L | (inside param_image) | - | bms_params_expand_C | - |
| 0x13D7 | 1 | param_image+0x9 | L | (inside param_image) | - | bms_params_expand_C | - |
| 0x13D8 | 1 | param_image+0xA | L | (inside param_image) | - | bms_params_fixed_bytes | 4 |
| 0x13D9 | 1 | param_image+0xB | L | (inside param_image) | - | bms_params_expand_C | - |
| 0x13DA | 1 | param_image+0xC | L | (inside param_image) | - | bms_params_expand_C | - |
| 0x13DB | 1 | param_image+0xD | L | (inside param_image) | - | bms_params_fixed_bytes | 1 |
| 0x13DC | 2 | param_image+0xE | L | (inside param_image) | - | bms_params_expand_A | - |
| 0x13DE | 2 | param_image+0x10 | L | (inside param_image) | - | bms_params_expand_A | - |
| 0x13E0 | 1 | param_image+0x12 | L | (inside param_image) | - | bms_params_expand_A | - |
| 0x13E1 | 1 | param_image+0x13 | L | (inside param_image) | - | bms_params_expand_A | - |
| 0x13E2 | 1 | param_image+0x14 | L | (inside param_image) | - | bms_params_expand_A | - |
| 0x13E3 | 1 | param_image+0x15 | L | (inside param_image) | - | bms_params_fixed_bytes | 62 |
| 0x13E4 | 1 | param_image+0x16 | L | (inside param_image) | - | bms_params_fixed_bytes | 2 |
| 0x13E5 | 2 | param_image+0x17 | L | (inside param_image) | - | bms_params_expand_A | - |
| 0x13E7 | 1 | param_image+0x19 | L | (inside param_image) | - | bms_params_expand_A | - |
| 0x13E8 | 2 | param_image+0x1A | L | (inside param_image) | - | bms_params_expand_A | - |
| 0x13EA | 1 | param_image+0x1C | L | (inside param_image) | - | bms_params_expand_A | - |
| 0x13EB | 2 | param_image+0x1D | L | (inside param_image) | - | bms_params_expand_A | - |
| 0x13ED | 1 | param_image+0x1F | L | (inside param_image) | - | bms_params_expand_A | - |
| 0x13EE | 1 | param_image+0x20 | L | (inside param_image) | - | bms_params_expand_A | - |
| 0x13F1 | 1 | param_image+0x23 | L | (inside param_image) | - | bms_params_expand_A | - |
| 0x13F2 | 1 | param_image+0x24 | L | (inside param_image) | - | bms_params_expand_A | - |
| 0x13F3 | 1 | param_image+0x25 | L | (inside param_image) | - | bms_params_copy_E | - |
| 0x13F4 | 2 | param_image+0x26 | L | (inside param_image) | - | bms_params_copy_E | - |
| 0x13F6 | 2 | param_image+0x28 | L | (inside param_image) | - | bms_params_copy_E | - |
| 0x13F8 | 2 | param_image+0x2A | L | (inside param_image) | - | bms_params_copy_E | - |
| 0x13FA | 2 | param_image+0x2C | L | (inside param_image) | - | bms_params_copy_E | - |
| 0x13FC | 2 | param_image+0x2E | L | (inside param_image) | - | bms_params_expand_C | - |
| 0x13FE | 1 | param_image+0x30 | L | (inside param_image) | - | bms_params_expand_C | - |
| 0x13FF | 1 | param_image+0x31 | L | (inside param_image) | - | bms_params_expand_C | - |
| 0x1400 | 1 | param_image+0x32 | L | (inside param_image) | - | bms_params_expand_C | - |
| 0x1401 | 1 | param_image+0x33 | L | (inside param_image) | - | bms_params_fixed_bytes | 0 |
| 0x1402 | 1 | param_image+0x34 | L | (inside param_image) | - | bms_params_expand_C | - |
| 0x1403 | 1 | param_image+0x35 | L | (inside param_image) | - | bms_params_expand_C | - |
| 0x1404 | 1 | param_image+0x36 | L | (inside param_image) | - | bms_params_expand_C | - |
| 0x1405 | 1 | param_image+0x37 | L | (inside param_image) | - | bms_params_fixed_bytes | 0 |
| 0x1406 | 1 | param_image+0x38 | L | (inside param_image) | - | bms_params_expand_C | - |
| 0x1407 | 1 | param_image+0x39 | L | (inside param_image) | - | bms_params_expand_C | - |
| 0x1408 | 1 | param_image+0x3A | L | (inside param_image) | - | bms_params_expand_C | - |
| 0x1409 | 1 | param_image+0x3B | L | (inside param_image) | - | bms_params_fixed_bytes | 0 |
| 0x140A | 2 | param_image+0x3C | L | (inside param_image) | - | bms_params_expand_C | - |
| 0x140C | 1 | param_image+0x3E | L | (inside param_image) | - | bms_params_expand_C | - |
| 0x140D | 1 | param_image+0x3F | L | (inside param_image) | - | bms_params_expand_C | - |
| 0x140E | 1 | param_image+0x40 | L | (inside param_image) | - | bms_params_expand_C | - |
| 0x140F | 1 | param_image+0x41 | L | (inside param_image) | - | bms_params_fixed_bytes | 0 |
| 0x1410 | 2 | param_image+0x42 | L | (inside param_image) | - | bms_params_expand_C | - |
| 0x1412 | 1 | param_image+0x44 | L | (inside param_image) | - | bms_params_expand_B | - |
| 0x1413 | 2 | param_image+0x45 | L | (inside param_image) | - | bms_params_expand_B | - |
| 0x1415 | 1 | param_image+0x47 | L | (inside param_image) | - | bms_params_expand_B | - |
| 0x1416 | 2 | param_image+0x48 | L | (inside param_image) | - | bms_params_expand_B | - |
| 0x1418 | 1 | param_image+0x4A | L | (inside param_image) | - | bms_params_expand_B | - |
| 0x1419 | 1 | param_image+0x4B | L | (inside param_image) | - | bms_params_expand_B | - |
| 0x141A | 1 | param_image+0x4C | L | (inside param_image) | - | bms_params_expand_B | - |
| 0x141B | 1 | param_image+0x4D | L | (inside param_image) | - | bms_params_expand_B | - |
| 0x141C | 1 | param_image+0x4E | L | (inside param_image) | - | bms_params_expand_B | - |
| 0x141D | 1 | param_image+0x4F | L | (inside param_image) | - | bms_params_expand_B | - |
| 0x141E | 1 | param_image+0x50 | L | (inside param_image) | - | bms_params_expand_B | - |
| 0x141F | 1 | param_image+0x51 | L | (inside param_image) | - | bms_params_expand_B | - |
| 0x1420 | 1 | param_image+0x52 | L | (inside param_image) | - | bms_params_expand_B | - |
| 0x1421 | 1 | param_image+0x53 | L | (inside param_image) | - | bms_params_expand_B | - |
| 0x1422 | 1 | param_image+0x54 | L | (inside param_image) | - | bms_params_expand_B | - |
| 0x1423 | 1 | param_image+0x55 | L | (inside param_image) | - | bms_params_expand_B | - |
| 0x1424 | 1 | param_image+0x56 | L | (inside param_image) | - | bms_params_expand_B | - |
| 0x1425 | 2 | param_image+0x57 | L | (inside param_image) | - | bms_params_expand_B | - |
| 0x1427 | 2 | param_image+0x59 | L | (inside param_image) | - | bms_params_expand_B | - |
| 0x1429 | 1 | param_image+0x5B | L | (inside param_image) | - | bms_params_expand_B | - |
| 0x142A | 2 | param_image+0x5C | L | (inside param_image) | - | bms_params_expand_B | - |
| 0x142C | 1 | param_image+0x5E | L | (inside param_image) | - | bms_params_expand_B | - |
| 0x142D | 1 | param_image+0x5F | L | (inside param_image) | - | bms_params_expand_B | - |
| 0x142E | 1 | param_image+0x60 | L | (inside param_image) | - | bms_params_expand_B | - |
| 0x142F | 2 | param_image+0x61 | L | (inside param_image) | - | bms_params_expand_B | - |
| 0x1431 | 1 | param_image+0x63 | L | (inside param_image) | - | bms_params_expand_B | - |
| 0x1432 | 1 | param_image+0x64 | L | (inside param_image) | - | bms_params_expand_B | - |
| 0x1433 | 1 | param_image+0x65 | L | (inside param_image) | - | bms_params_expand_B | - |
| 0x1434 | 1 | param_image+0x66 | L | (inside param_image) | - | bms_params_expand_B | - |
| 0x1435 | 2 | param_image+0x67 | L | (inside param_image) | - | bms_params_expand_B | - |
| 0x1437 | 1 | param_image+0x69 | L | (inside param_image) | - | bms_params_expand_B | - |
| 0x1438 | 1 | param_image+0x6A | L | (inside param_image) | - | bms_params_expand_B | - |
| 0x1439 | 1 | param_image+0x6B | L | (inside param_image) | - | bms_params_expand_B | - |
| 0x143A | 1 | param_image+0x6C | L | (inside param_image) | - | bms_params_expand_B | - |
| 0x143B | 1 | param_image+0x6D | L | (inside param_image) | - | bms_params_expand_B | - |
| 0x143C | 1 | param_image+0x6E | L | (inside param_image) | - | bms_params_expand_B | - |
| 0x143D | 1 | param_image+0x6F | L | (inside param_image) | - | bms_params_expand_B | - |
| 0x143E | 1 | param_image+0x70 | L | (inside param_image) | - | bms_params_expand_B | - |
| 0x143F | 1 | param_image+0x71 | L | (inside param_image) | - | bms_params_expand_B | - |
| 0x1440 | 1 | param_image+0x72 | L | (inside param_image) | - | bms_params_expand_B | - |
| 0x1441 | 1 | param_image+0x73 | L | (inside param_image) | - | bms_params_expand_B | - |
| 0x1442 | 1 | param_image+0x74 | L | (inside param_image) | - | bms_params_expand_B | - |
| 0x1443 | 1 | param_image+0x75 | L | (inside param_image) | - | bms_params_expand_B | - |
| 0x1444 | 1 | param_image+0x76 | L | (inside param_image) | - | bms_params_expand_B | - |
| 0x1445 | 1 | param_image+0x77 | L | (inside param_image) | - | bms_params_expand_B | - |
| 0x1446 | 1 | param_image+0x78 | L | (inside param_image) | - | bms_params_expand_B | - |
| 0x1447 | 1 | param_image+0x79 | L | (inside param_image) | - | bms_params_expand_B | - |
| 0x1448 | 1 | param_image+0x7A | L | (inside param_image) | - | bms_params_expand_B | - |
| 0x1449 | 1 | param_image+0x7B | L | (inside param_image) | - | bms_params_expand_B | - |
| 0x144A | 1 | param_image+0x7C | L | (inside param_image) | - | bms_params_expand_B | - |
| 0x144B | 1 | param_image+0x7D | L | (inside param_image) | - | bms_params_expand_B | - |
| 0x144C | 1 | param_image+0x7E | L | (inside param_image) | - | bms_params_expand_B | - |
| 0x144D | 1 | param_image+0x7F | L | (inside param_image) | - | bms_params_expand_B | - |
| 0x144E | 1 | param_image+0x80 | L | (inside param_image) | - | bms_params_expand_B | - |
| 0x144F | 2 | param_image+0x81 | L | (inside param_image) | - | bms_params_expand_B | - |
| 0x1451 | 1 | param_image+0x83 | L | (inside param_image) | - | bms_params_expand_B | - |
| 0x1452 | 1 | param_image+0x84 | L | (inside param_image) | - | bms_params_expand_B | - |
| 0x1453 | 2 | param_image+0x85 | L | (inside param_image) | - | bms_params_expand_B | - |
| 0x1455 | 1 | param_image+0x87 | L | (inside param_image) | - | bms_params_fixed_bytes | 90 |
| 0x1456 | 1 | param_image+0x88 | L | (inside param_image) | - | bms_params_fixed_bytes | 1 |
| 0x1457 | 2 | param_image+0x89 | L | (inside param_image) | - | bms_params_expand_B | - |
| 0x1459 | 2 | param_image+0x8B | L | (inside param_image) | - | bms_params_expand_B | - |
| 0x145B | 2 | param_image+0x8D | L | (inside param_image) | - | bms_params_expand_B | - |
| 0x145D | 1 | param_image+0x8F | L | (inside param_image) | - | bms_params_expand_C | - |
| 0x145E | 1 | param_image+0x90 | L | (inside param_image) | - | bms_params_expand_C | - |
| 0x145F | 1 | param_image+0x91 | L | (inside param_image) | - | bms_params_expand_C | - |
| 0x1460 | 1 | param_image+0x92 | L | (inside param_image) | - | bms_params_expand_C | - |
| 0x1461 | 1 | param_image+0x93 | L | (inside param_image) | - | bms_params_expand_C | - |
| 0x1462 | 1 | param_image+0x94 | L | (inside param_image) | - | bms_params_expand_C | - |
| 0x1463 | 1 | param_image+0x95 | L | (inside param_image) | - | bms_params_expand_C | - |
| 0x1464 | 1 | param_image+0x96 | L | (inside param_image) | - | bms_params_expand_C | - |
| 0x1465 | 2 | param_image+0x97 | L | (inside param_image) | - | bms_params_copy_P | - |
| 0x1467 | 1 | param_image+0x99 | L | (inside param_image) | - | bms_params_copy_P | - |
| 0x1468 | 2 | param_image+0x9A | L | (inside param_image) | - | bms_params_copy_P | - |
| 0x146A | 1 | param_image+0x9C | L | (inside param_image) | - | bms_params_copy_P | - |
| 0x146B | 2 | param_image+0x9D | L | (inside param_image) | - | bms_params_copy_P | - |
| 0x146D | 1 | param_image+0x9F | L | (inside param_image) | - | bms_params_copy_P | - |
| 0x146E | 2 | param_image+0xA0 | L | (inside param_image) | - | bms_params_copy_P | - |
| 0x1470 | 1 | param_image+0xA2 | L | (inside param_image) | - | bms_params_copy_P | - |
| 0x1471 | 2 | param_image+0xA3 | L | (inside param_image) | - | bms_params_copy_P | - |
| 0x1473 | 1 | param_image+0xA5 | L | (inside param_image) | - | bms_params_copy_P | - |
| 0x1474 | 2 | param_image+0xA6 | L | (inside param_image) | - | bms_params_copy_P | - |
| 0x1476 | 1 | param_image+0xA8 | L | (inside param_image) | - | bms_params_copy_P | - |
| 0x1477 | 1 | param_image+0xA9 | L | (inside param_image) | - | bms_params_copy_P | - |
| 0x1478 | 1 | param_image+0xAA | L | (inside param_image) | - | bms_params_copy_P | - |
| 0x1479 | 1 | param_image+0xAB | L | (inside param_image) | - | bms_params_copy_P | - |
| 0x147A | 1 | param_image+0xAC | L | (inside param_image) | - | bms_params_copy_P | - |
| 0x147B | 2 | param_image+0xAD | L | (inside param_image) | - | bms_params_copy_P | - |
| 0x147D | 2 | param_image+0xAF | L | (inside param_image) | - | bms_params_copy_P | - |
| 0x147F | 2 | param_image+0xB1 | L | (inside param_image) | - | bms_params_copy_P | - |
| 0x1481 | 1 | param_image+0xB3 | L | (inside param_image) | - | bms_params_copy_P | - |
| 0x1482 | 2 | param_image+0xB4 | L | (inside param_image) | - | bms_params_copy_P | - |
| 0x1484 | 2 | param_image+0xB6 | L | (inside param_image) | - | bms_params_copy_P | - |
| 0x1486 | 2 | param_image+0xB8 | L | (inside param_image) | - | bms_params_copy_P | - |
| 0x1488 | 2 | param_image+0xBA | L | (inside param_image) | - | bms_params_copy_P | - |
| 0x148A | 1 | param_image+0xBC | L | (inside param_image) | - | bms_params_copy_P | - |
| 0x148B | 2 | param_image+0xBD | L | (inside param_image) | - | bms_params_copy_P | - |
| 0x148D | 1 | param_image+0xBF | L | (inside param_image) | - | bms_params_copy_P | - |
| 0x148E | 2 | param_image+0xC0 | L | (inside param_image) | - | bms_params_copy_P | - |
| 0x1490 | 1 | param_image+0xC2 | L | (inside param_image) | - | bms_params_copy_P | - |
| 0x1491 | 2 | param_image+0xC3 | L | (inside param_image) | - | bms_params_copy_P | - |
| 0x1493 | 1 | param_image+0xC5 | L | (inside param_image) | - | bms_params_copy_P | - |
| 0x1494 | 1 | param_image+0xC6 | L | (inside param_image) | - | bms_params_copy_P | - |
| 0x1495 | 1 | param_image+0xC7 | L | (inside param_image) | - | bms_params_copy_P | - |
| 0x1496 | 1 | param_image+0xC8 | L | (inside param_image) | - | bms_params_copy_P | - |
| 0x1497 | 1 | param_image+0xC9 | L | (inside param_image) | - | bms_params_expand_C | - |
| 0x1498 | 1 | param_image+0xCA | L | (inside param_image) | - | bms_params_expand_C | - |
| 0x1499 | 1 | param_image+0xCB | L | (inside param_image) | - | bms_params_expand_C | - |
| 0x149A | 1 | param_image+0xCC | L | (inside param_image) | - | bms_params_expand_C | - |
| 0x149B | 1 | param_image+0xCD | L | (inside param_image) | - | bms_params_expand_C | - |
| 0x149C | 1 | param_image+0xCE | L | (inside param_image) | - | bms_params_expand_C | - |
| 0x149D | 1 | param_image+0xCF | L | (inside param_image) | - | bms_params_expand_C | - |
| 0x149E | 1 | param_image+0xD0 | L | (inside param_image) | - | bms_params_expand_C | - |
| 0x149F | 1 | param_image+0xD1 | L | (inside param_image) | - | bms_params_expand_C | - |
| 0x14A0 | 1 | param_image+0xD2 | L | (inside param_image) | - | bms_params_expand_C | - |
| 0x14A1 | 2 | param_image+0xD3 | L | (inside param_image) | - | bms_params_expand_C | - |
| 0x14A3 | 1 | param_image+0xD5 | L | (inside param_image) | - | bms_params_fixed_bytes | 0 |
| 0x14A4 | 1 | param_image+0xD6 | L | (inside param_image) | - | bms_params_expand_C | - |
| 0x14A5 | 1 | param_image+0xD7 | L | (inside param_image) | - | bms_params_expand_C | - |
| 0x14A6 | 1 | param_image+0xD8 | L | (inside param_image) | - | bms_params_expand_C | - |
| 0x14A7 | 2 | param_image+0xD9 | L | (inside param_image) | - | bms_params_expand_C | - |
| 0x14A9 | 2 | param_image+0xDB | L | (inside param_image) | - | bms_params_expand_C | - |
| 0x14AB | 1 | param_image+0xDD | L | (inside param_image) | - | bms_params_expand_C | - |
| 0x14AC | 1 | param_image+0xDE | L | (inside param_image) | - | bms_params_expand_C | - |
| 0x14AD | 1 | param_image+0xDF | L | (inside param_image) | - | bms_params_expand_C | - |
| 0x14AE | 1 | param_image+0xE0 | L | (inside param_image) | - | bms_params_expand_C | - |
| 0x14AF | 2 | param_image+0xE1 | L | (inside param_image) | - | bms_params_expand_C | - |
| 0x14B1 | 1 | param_image+0xE3 | L | (inside param_image) | - | bms_params_expand_C | - |
| 0x14B2 | 2 | param_image+0xE4 | L | (inside param_image) | - | bms_params_expand_C | - |
| 0x14B4 | 2 | param_image+0xE6 | L | (inside param_image) | - | bms_params_expand_C | - |
| 0x14B6 | 2 | param_image+0xE8 | L | (inside param_image) | - | bms_params_expand_C | - |
| 0x14B8 | 2 | param_image+0xEA | L | (inside param_image) | - | bms_params_expand_C | - |
| 0x14BA | 2 | param_image+0xEC | L | (inside param_image) | - | bms_params_expand_C | - |
| 0x14BC | 2 | param_image+0xEE | L | (inside param_image) | - | bms_params_expand_C | - |
| 0x14BE | 2 | param_image+0xF0 | L | (inside param_image) | - | bms_params_expand_C | - |
| 0x14C0 | 2 | param_image+0xF2 | L | (inside param_image) | - | bms_params_expand_C | - |
| 0x14C2 | 2 | param_image+0xF4 | L | (inside param_image) | - | bms_params_expand_C | - |
| 0x14C4 | 2 | param_image+0xF6 | L | (inside param_image) | - | bms_params_expand_C | - |
| 0x14C6 | 2 | param_image+0xF8 | L | (inside param_image) | - | bms_params_expand_C | - |
| 0x14C8 | 2 | param_image+0xFA | L | (inside param_image) | - | bms_params_expand_C | - |
| 0x14CA | 2 | param_image+0xFC | L | (inside param_image) | - | bms_params_expand_C | - |
| 0x14CC | 2 | param_image+0xFE | L | (inside param_image) | - | bms_params_expand_C | - |
| 0x14CE | 2 | param_image+0x100 | L | (inside param_image) | - | bms_params_expand_C | - |
| 0x14D0 | 2 | param_image+0x102 | L | (inside param_image) | - | bms_params_expand_C | - |
| 0x14D2 | 1 | param_image+0x104 | L | (inside param_image) | - | bms_params_expand_C | - |
| 0x14D3 | 1 | param_image+0x105 | L | (inside param_image) | - | bms_params_expand_C | - |
| 0x14D4 | 1 | param_image+0x106 | L | (inside param_image) | - | bms_params_expand_C | - |
| 0x14D5 | 1 | param_image+0x107 | L | (inside param_image) | - | bms_params_expand_C | - |
| 0x14D6 | 1 | param_image+0x108 | L | (inside param_image) | - | bms_params_expand_C | - |
| 0x14D7 | 1 | param_image+0x109 | L | (inside param_image) | - | bms_params_expand_C | - |
| 0x14D8 | 2 | param_image+0x10A | L | (inside param_image) | - | bms_params_expand_C | - |
| 0x14DA | 1 | param_image+0x10C | L | (inside param_image) | - | bms_params_expand_C | - |
| 0x14DB | 1 | param_image+0x10D | L | (inside param_image) | - | bms_params_expand_C | - |
| 0x14DC | 2 | param_image+0x10E | L | (inside param_image) | - | bms_params_expand_C | - |
| 0x14DE | 1 | param_image+0x110 | L | (inside param_image) | - | bms_params_expand_C | - |
| 0x14DF | 1 | param_image+0x111 | L | (inside param_image) | - | bms_params_expand_C | - |
| 0x14E0 | 2 | param_image+0x112 | L | (inside param_image) | - | bms_params_expand_C | - |
| 0x14E2 | 12 | param_fixed_words | L | three fixed zero words written by bms_params_fixed_bytes | - | bms_params_fixed_bytes | 0 |
| 0x14E6 | 4 | param_fixed_words+0x4 | L | (inside param_fixed_words) | - | bms_params_fixed_bytes | 0 |
| 0x14EA | 4 | param_fixed_words+0x8 | L | (inside param_fixed_words) | - | bms_params_fixed_bytes | 0 |
| 0x14EE | 112 | defaults_group_C | L | default parameter group C (bms_defaults_group_C): includes 0xDAC0, 0x28A4, 0x8FFF, 0x2E, repeated 0/1/0x14 fields; source for bms_params_expand_C | bms_params_expand_C | bms_defaults_group_C | DAC0 |
| 0x14F0 | 1 | defaults_group_C+0x2 | L | (inside defaults_group_C) | bms_params_expand_C | bms_defaults_group_C | 1E |
| 0x14F1 | 2 | defaults_group_C+0x3 | L | (inside defaults_group_C) | bms_params_expand_C | bms_defaults_group_C | 28A4 |
| 0x14F3 | 1 | defaults_group_C+0x5 | L | (inside defaults_group_C) | bms_params_expand_C | bms_defaults_group_C | D |
| 0x14F4 | 1 | defaults_group_C+0x6 | L | (inside defaults_group_C) | bms_params_expand_C | bms_defaults_group_C | 1 |
| 0x14F5 | 1 | defaults_group_C+0x7 | L | (inside defaults_group_C) | bms_params_expand_C | bms_defaults_group_C | 24 |
| 0x14F6 | 1 | defaults_group_C+0x8 | L | (inside defaults_group_C) | bms_params_expand_C | bms_defaults_group_C | 11 |
| 0x14F7 | 1 | defaults_group_C+0x9 | L | (inside defaults_group_C) | bms_params_expand_C | bms_defaults_group_C | 0 |
| 0x14F8 | 1 | defaults_group_C+0xA | L | (inside defaults_group_C) | bms_params_expand_C | bms_defaults_group_C | 0 |
| 0x14F9 | 1 | defaults_group_C+0xB | L | (inside defaults_group_C) | bms_params_expand_C | bms_defaults_group_C | 0 |
| 0x14FA | 1 | defaults_group_C+0xC | L | (inside defaults_group_C) | bms_params_expand_C | bms_defaults_group_C | 0 |
| 0x14FB | 1 | defaults_group_C+0xD | L | (inside defaults_group_C) | bms_params_expand_C | bms_defaults_group_C | 0 |
| 0x14FC | 1 | defaults_group_C+0xE | L | (inside defaults_group_C) | bms_params_expand_C | bms_defaults_group_C | AA |
| 0x14FD | 1 | defaults_group_C+0xF | L | (inside defaults_group_C) | bms_params_expand_C | bms_defaults_group_C | 7 |
| 0x14FE | 1 | defaults_group_C+0x10 | L | (inside defaults_group_C) | bms_params_expand_C | bms_defaults_group_C | 0 |
| 0x14FF | 1 | defaults_group_C+0x11 | L | (inside defaults_group_C) | bms_params_expand_C | bms_defaults_group_C | 0 |
| 0x1500 | 1 | defaults_group_C+0x12 | L | (inside defaults_group_C) | bms_params_expand_C | bms_defaults_group_C | 0 |
| 0x1501 | 1 | defaults_group_C+0x13 | L | (inside defaults_group_C) | bms_params_expand_C | bms_defaults_group_C | 0 |
| 0x1502 | 1 | defaults_group_C+0x14 | L | (inside defaults_group_C) | bms_params_expand_C | bms_defaults_group_C | 0 |
| 0x1503 | 1 | defaults_group_C+0x15 | L | (inside defaults_group_C) | bms_params_expand_C | bms_defaults_group_C | 6 |
| 0x1504 | 2 | defaults_group_C+0x16 | L | (inside defaults_group_C) | bms_params_expand_C | bms_defaults_group_C | 8FFF |
| 0x1506 | 1 | defaults_group_C+0x18 | L | (inside defaults_group_C) | bms_params_expand_C | bms_defaults_group_C | 50 |
| 0x1507 | 2 | defaults_group_C+0x19 | L | (inside defaults_group_C) | bms_params_expand_C | bms_defaults_group_C | 0 |
| 0x1509 | 1 | defaults_group_C+0x1B | L | (inside defaults_group_C) | bms_params_expand_C | bms_defaults_group_C | CC |
| 0x150A | 1 | defaults_group_C+0x1C | L | (inside defaults_group_C) | bms_params_expand_C | bms_defaults_group_C | 33 |
| 0x150B | 1 | defaults_group_C+0x1D | L | (inside defaults_group_C) | bms_params_expand_C | bms_defaults_group_C | 2 |
| 0x150C | 1 | defaults_group_C+0x1E | L | (inside defaults_group_C) | bms_params_expand_C | bms_defaults_group_C | 98 |
| 0x150D | 1 | defaults_group_C+0x1F | L | (inside defaults_group_C) | bms_params_expand_C | bms_defaults_group_C | 11 |
| 0x150E | 1 | defaults_group_C+0x20 | L | (inside defaults_group_C) | bms_params_expand_C | bms_defaults_group_C | 2 |
| 0x150F | 1 | defaults_group_C+0x21 | L | (inside defaults_group_C) | bms_params_expand_C | bms_defaults_group_C | E4 |
| 0x1510 | 1 | defaults_group_C+0x22 | L | (inside defaults_group_C) | bms_params_expand_C | bms_defaults_group_C | 22 |
| 0x1511 | 1 | defaults_group_C+0x23 | L | (inside defaults_group_C) | bms_params_expand_C | bms_defaults_group_C | 2 |
| 0x1512 | 2 | defaults_group_C+0x24 | L | (inside defaults_group_C) | bms_params_expand_C | bms_defaults_group_C | 64 |
| 0x1514 | 2 | defaults_group_C+0x26 | L | (inside defaults_group_C) | bms_params_expand_C | bms_defaults_group_C | 1 |
| 0x1516 | 1 | defaults_group_C+0x28 | L | (inside defaults_group_C) | bms_params_expand_C | bms_defaults_group_C | 0 |
| 0x1517 | 1 | defaults_group_C+0x29 | L | (inside defaults_group_C) | bms_params_expand_C | bms_defaults_group_C | 0 |
| 0x1518 | 1 | defaults_group_C+0x2A | L | (inside defaults_group_C) | bms_params_expand_C | bms_defaults_group_C | 0 |
| 0x1519 | 1 | defaults_group_C+0x2B | L | (inside defaults_group_C) | bms_params_expand_C | bms_defaults_group_C | 0 |
| 0x151A | 1 | defaults_group_C+0x2C | L | (inside defaults_group_C) | bms_params_expand_C | bms_defaults_group_C | 0 |
| 0x151B | 1 | defaults_group_C+0x2D | L | (inside defaults_group_C) | bms_params_expand_C | bms_defaults_group_C | 0 |
| 0x151C | 1 | defaults_group_C+0x2E | L | (inside defaults_group_C) | bms_params_expand_C | bms_defaults_group_C | 0 |
| 0x151D | 1 | defaults_group_C+0x2F | L | (inside defaults_group_C) | bms_params_expand_C | bms_defaults_group_C | 0 |
| 0x151E | 1 | defaults_group_C+0x30 | L | (inside defaults_group_C) | bms_params_expand_C | bms_defaults_group_C | 0 |
| 0x151F | 1 | defaults_group_C+0x31 | L | (inside defaults_group_C) | bms_params_expand_C | bms_defaults_group_C | F |
| 0x1520 | 1 | defaults_group_C+0x32 | L | (inside defaults_group_C) | bms_params_expand_C | bms_defaults_group_C | 0 |
| 0x1521 | 1 | defaults_group_C+0x33 | L | (inside defaults_group_C) | bms_params_expand_C | bms_defaults_group_C | 2E |
| 0x1522 | 1 | defaults_group_C+0x34 | L | (inside defaults_group_C) | bms_params_expand_C | bms_defaults_group_C | 1 |
| 0x1523 | 2 | defaults_group_C+0x35 | L | (inside defaults_group_C) | bms_params_expand_C | bms_defaults_group_C | 0 |
| 0x1525 | 2 | defaults_group_C+0x37 | L | (inside defaults_group_C) | bms_params_expand_C | bms_defaults_group_C | 0 |
| 0x1527 | 1 | defaults_group_C+0x39 | L | (inside defaults_group_C) | bms_params_expand_C | bms_defaults_group_C | 0 |
| 0x1528 | 1 | defaults_group_C+0x3A | L | (inside defaults_group_C) | bms_params_expand_C | bms_defaults_group_C | 0 |
| 0x1529 | 1 | defaults_group_C+0x3B | L | (inside defaults_group_C) | bms_params_expand_C | bms_defaults_group_C | A |
| 0x152B | 2 | defaults_group_C+0x3D | L | (inside defaults_group_C) | bms_params_expand_C | bms_defaults_group_C | A |
| 0x152D | 1 | defaults_group_C+0x3F | L | (inside defaults_group_C) | bms_params_expand_C | bms_defaults_group_C | 14 |
| 0x152E | 2 | defaults_group_C+0x40 | L | (inside defaults_group_C) | bms_params_expand_C | bms_defaults_group_C | 0 |
| 0x1530 | 2 | defaults_group_C+0x42 | L | (inside defaults_group_C) | bms_params_expand_C | bms_defaults_group_C | 0 |
| 0x1532 | 2 | defaults_group_C+0x44 | L | (inside defaults_group_C) | bms_params_expand_C | bms_defaults_group_C | 0 |
| 0x1534 | 2 | defaults_group_C+0x46 | L | (inside defaults_group_C) | bms_params_expand_C | bms_defaults_group_C | 0 |
| 0x1536 | 2 | defaults_group_C+0x48 | L | (inside defaults_group_C) | bms_params_expand_C | bms_defaults_group_C | 0 |
| 0x1538 | 2 | defaults_group_C+0x4A | L | (inside defaults_group_C) | bms_params_expand_C | bms_defaults_group_C | 0 |
| 0x153A | 2 | defaults_group_C+0x4C | L | (inside defaults_group_C) | bms_params_expand_C | bms_defaults_group_C | 0 |
| 0x153C | 2 | defaults_group_C+0x4E | L | (inside defaults_group_C) | bms_params_expand_C | bms_defaults_group_C | 0 |
| 0x153E | 2 | defaults_group_C+0x50 | L | (inside defaults_group_C) | bms_params_expand_C | bms_defaults_group_C | 0 |
| 0x1540 | 2 | defaults_group_C+0x52 | L | (inside defaults_group_C) | bms_params_expand_C | bms_defaults_group_C | 0 |
| 0x1542 | 2 | defaults_group_C+0x54 | L | (inside defaults_group_C) | bms_params_expand_C | bms_defaults_group_C | 0 |
| 0x1544 | 2 | defaults_group_C+0x56 | L | (inside defaults_group_C) | bms_params_expand_C | bms_defaults_group_C | 0 |
| 0x1546 | 2 | defaults_group_C+0x58 | L | (inside defaults_group_C) | bms_params_expand_C | bms_defaults_group_C | 0 |
| 0x1548 | 2 | defaults_group_C+0x5A | L | (inside defaults_group_C) | bms_params_expand_C | bms_defaults_group_C | 0 |
| 0x154A | 2 | defaults_group_C+0x5C | L | (inside defaults_group_C) | bms_params_expand_C | bms_defaults_group_C | 0 |
| 0x154C | 2 | defaults_group_C+0x5E | L | (inside defaults_group_C) | bms_params_expand_C | bms_defaults_group_C | 0 |
| 0x154E | 2 | defaults_group_C+0x60 | L | (inside defaults_group_C) | bms_params_expand_C | bms_defaults_group_C | 50 |
| 0x1550 | 1 | defaults_group_C+0x62 | L | (inside defaults_group_C) | bms_params_expand_C | bms_defaults_group_C | 3 |
| 0x1551 | 1 | defaults_group_C+0x63 | L | (inside defaults_group_C) | bms_params_expand_C | bms_defaults_group_C | EC |
| 0x1552 | 1 | defaults_group_C+0x64 | L | (inside defaults_group_C) | bms_params_expand_C | bms_defaults_group_C | 3C |
| 0x1553 | 1 | defaults_group_C+0x65 | L | (inside defaults_group_C) | bms_params_expand_C | bms_defaults_group_C | 46 |
| 0x1554 | 1 | defaults_group_C+0x66 | L | (inside defaults_group_C) | bms_params_expand_C | bms_defaults_group_C | 14 |
| 0x1555 | 1 | defaults_group_C+0x67 | L | (inside defaults_group_C) | bms_params_expand_C | bms_defaults_group_C | 6 |
| 0x1556 | 2 | defaults_group_C+0x68 | L | (inside defaults_group_C) | bms_params_expand_C | bms_defaults_group_C | ED8 |
| 0x1558 | 1 | defaults_group_C+0x6A | L | (inside defaults_group_C) | bms_params_expand_C | bms_defaults_group_C | 32 |
| 0x1559 | 1 | defaults_group_C+0x6B | L | (inside defaults_group_C) | bms_params_expand_C | bms_defaults_group_C | 14 |
| 0x155A | 2 | defaults_group_C+0x6C | L | (inside defaults_group_C) | bms_params_expand_C | bms_defaults_group_C | ED8 |
| 0x155C | 1 | defaults_group_C+0x6E | L | (inside defaults_group_C) | bms_params_expand_C | bms_defaults_group_C | 32 |
| 0x155D | 1 | defaults_group_C+0x6F | L | (inside defaults_group_C) | bms_params_expand_C | bms_defaults_group_C | 14 |
| 0x155E | 21 | defaults_group_A | L | default parameter group A (bms_defaults_group_A): 0x1770 (6000), 0x1F4, 0x7530 (30000) and small counts; source for bms_params_expand_A | bms_params_expand_A | bms_defaults_group_A | 0 |
| 0x1560 | 2 | defaults_group_A+0x2 | L | (inside defaults_group_A) | bms_params_expand_A | bms_defaults_group_A | 1770 |
| 0x1562 | 1 | defaults_group_A+0x4 | L | (inside defaults_group_A) | bms_params_expand_A | bms_defaults_group_A | A |
| 0x1563 | 1 | defaults_group_A+0x5 | L | (inside defaults_group_A) | bms_params_expand_A | bms_defaults_group_A | 55 |
| 0x1564 | 1 | defaults_group_A+0x6 | L | (inside defaults_group_A) | bms_params_expand_A | bms_defaults_group_A | A |
| 0x1565 | 1 | defaults_group_A+0x7 | L | (inside defaults_group_A) | bms_params_expand_A | bms_defaults_group_A, bms_params_expand_A | 0 |
| 0x1566 | 1 | defaults_group_A+0x8 | L | (inside defaults_group_A) | bms_params_expand_A | bms_defaults_group_A, bms_params_expand_A | 0 |
| 0x1567 | 1 | defaults_group_A+0x9 | L | (inside defaults_group_A) | bms_params_expand_A | bms_defaults_group_A | 0 |
| 0x1568 | 1 | defaults_group_A+0xA | L | (inside defaults_group_A) | bms_params_expand_A | bms_defaults_group_A | 5 |
| 0x1569 | 2 | defaults_group_A+0xB | L | (inside defaults_group_A) | bms_params_expand_A | bms_defaults_group_A | 14 |
| 0x156B | 1 | defaults_group_A+0xD | L | (inside defaults_group_A) | bms_params_expand_A | bms_defaults_group_A | 5 |
| 0x156C | 2 | defaults_group_A+0xE | L | (inside defaults_group_A) | bms_params_expand_A | bms_defaults_group_A | 1F4 |
| 0x156E | 1 | defaults_group_A+0x10 | L | (inside defaults_group_A) | bms_params_expand_A | bms_defaults_group_A | A |
| 0x156F | 2 | defaults_group_A+0x11 | L | (inside defaults_group_A) | bms_params_expand_A | bms_defaults_group_A | 7530 |
| 0x1571 | 2 | defaults_group_A+0x13 | L | (inside defaults_group_A) | bms_params_expand_A | bms_defaults_group_A | 64 |
| 0x1573 | 73 | defaults_group_B | L | default parameter group B (bms_defaults_group_B): includes 0x12F, 0x25E, 0xFFFFFF38 (-200), 0x7D0, 0xF060, 0xFFFFFF9C (-100), 0x2BC, 0x708; source for bms_params_expand_B | bms_params_expand_B | bms_defaults_group_B | 36 |
| 0x1574 | 2 | defaults_group_B+0x1 | L | (inside defaults_group_B) | bms_params_expand_B | bms_defaults_group_B | 12F |
| 0x1576 | 1 | defaults_group_B+0x3 | L | (inside defaults_group_B) | bms_params_expand_B | bms_defaults_group_B | B |
| 0x1577 | 1 | defaults_group_B+0x4 | L | (inside defaults_group_B) | bms_params_expand_B | bms_defaults_group_B | 54 |
| 0x1578 | 2 | defaults_group_B+0x5 | L | (inside defaults_group_B) | bms_params_expand_B | bms_defaults_group_B | 25E |
| 0x157A | 1 | defaults_group_B+0x7 | L | (inside defaults_group_B) | bms_params_expand_B | bms_defaults_group_B | 3 |
| 0x157B | 1 | defaults_group_B+0x8 | L | (inside defaults_group_B) | bms_params_expand_B | bms_defaults_group_B | 0 |
| 0x157C | 1 | defaults_group_B+0x9 | L | (inside defaults_group_B) | bms_params_expand_B | bms_defaults_group_B | A |
| 0x157D | 1 | defaults_group_B+0xA | L | (inside defaults_group_B) | bms_params_expand_B | bms_defaults_group_B | F |
| 0x157E | 1 | defaults_group_B+0xB | L | (inside defaults_group_B) | bms_params_expand_B | bms_defaults_group_B | 4 |
| 0x157F | 1 | defaults_group_B+0xC | L | (inside defaults_group_B) | bms_params_expand_B | bms_defaults_group_B | 4 |
| 0x1580 | 2 | defaults_group_B+0xD | L | (inside defaults_group_B) | bms_params_expand_B | bms_defaults_group_B | FFFFFF38 |
| 0x1582 | 2 | defaults_group_B+0xF | L | (inside defaults_group_B) | bms_params_expand_B | bms_defaults_group_B | 7D0 |
| 0x1584 | 1 | defaults_group_B+0x11 | L | (inside defaults_group_B) | bms_params_expand_B | bms_defaults_group_B | 8 |
| 0x1585 | 1 | defaults_group_B+0x12 | L | (inside defaults_group_B) | bms_params_expand_B | bms_defaults_group_B | 1 |
| 0x1586 | 1 | defaults_group_B+0x13 | L | (inside defaults_group_B) | bms_params_expand_B | bms_defaults_group_B | 1E |
| 0x1587 | 1 | defaults_group_B+0x14 | L | (inside defaults_group_B) | bms_params_expand_B | bms_defaults_group_B | F |
| 0x1588 | 1 | defaults_group_B+0x15 | L | (inside defaults_group_B) | bms_params_expand_B | bms_defaults_group_B | 5 |
| 0x1589 | 1 | defaults_group_B+0x16 | L | (inside defaults_group_B) | bms_params_expand_B | bms_defaults_group_B | 1E |
| 0x158A | 1 | defaults_group_B+0x17 | L | (inside defaults_group_B) | bms_params_expand_B | bms_defaults_group_B | 6 |
| 0x158B | 2 | defaults_group_B+0x18 | L | (inside defaults_group_B) | bms_params_expand_B | bms_defaults_group_B | F060 |
| 0x158D | 1 | defaults_group_B+0x1A | L | (inside defaults_group_B) | bms_params_expand_B | bms_defaults_group_B | 2 |
| 0x158E | 2 | defaults_group_B+0x1B | L | (inside defaults_group_B) | bms_params_expand_B | bms_defaults_group_B | FFFFFF9C |
| 0x1590 | 1 | defaults_group_B+0x1D | L | (inside defaults_group_B) | bms_params_expand_B | bms_defaults_group_B | 0 |
| 0x1591 | 1 | defaults_group_B+0x1E | L | (inside defaults_group_B) | bms_params_expand_B | bms_defaults_group_B | A |
| 0x1592 | 1 | defaults_group_B+0x1F | L | (inside defaults_group_B) | bms_params_expand_B | bms_defaults_group_B | F |
| 0x1593 | 2 | defaults_group_B+0x20 | L | (inside defaults_group_B) | bms_params_expand_B | bms_defaults_group_B | C8 |
| 0x1595 | 1 | defaults_group_B+0x22 | L | (inside defaults_group_B) | bms_params_expand_B | bms_defaults_group_B | 0 |
| 0x1596 | 1 | defaults_group_B+0x23 | L | (inside defaults_group_B) | bms_params_expand_B | bms_defaults_group_B | A |
| 0x1597 | 1 | defaults_group_B+0x24 | L | (inside defaults_group_B) | bms_params_expand_B | bms_defaults_group_B | F |
| 0x1598 | 2 | defaults_group_B+0x25 | L | (inside defaults_group_B) | bms_params_expand_B | bms_defaults_group_B | C8 |
| 0x159A | 1 | defaults_group_B+0x27 | L | (inside defaults_group_B) | bms_params_expand_B | bms_defaults_group_B | 2D |
| 0x159B | 1 | defaults_group_B+0x28 | L | (inside defaults_group_B) | bms_params_expand_B | bms_defaults_group_B | 3 |
| 0x159C | 1 | defaults_group_B+0x29 | L | (inside defaults_group_B) | bms_params_expand_B | bms_defaults_group_B | 28 |
| 0x159D | 1 | defaults_group_B+0x2A | L | (inside defaults_group_B) | bms_params_expand_B | bms_defaults_group_B | 41 |
| 0x159E | 1 | defaults_group_B+0x2B | L | (inside defaults_group_B) | bms_params_expand_B | bms_defaults_group_B | 5 |
| 0x159F | 1 | defaults_group_B+0x2C | L | (inside defaults_group_B) | bms_params_expand_B | bms_defaults_group_B | 3C |
| 0x15A0 | 1 | defaults_group_B+0x2D | L | (inside defaults_group_B) | bms_params_expand_B | bms_defaults_group_B | 50 |
| 0x15A1 | 1 | defaults_group_B+0x2E | L | (inside defaults_group_B) | bms_params_expand_B | bms_defaults_group_B | 2 |
| 0x15A2 | 1 | defaults_group_B+0x2F | L | (inside defaults_group_B) | bms_params_expand_B | bms_defaults_group_B | 41 |
| 0x15A3 | 1 | defaults_group_B+0x30 | L | (inside defaults_group_B) | bms_params_expand_B | bms_defaults_group_B | 55 |
| 0x15A4 | 1 | defaults_group_B+0x31 | L | (inside defaults_group_B) | bms_params_expand_B | bms_defaults_group_B | 2 |
| 0x15A5 | 1 | defaults_group_B+0x32 | L | (inside defaults_group_B) | bms_params_expand_B | bms_defaults_group_B | 50 |
| 0x15A6 | 1 | defaults_group_B+0x33 | L | (inside defaults_group_B) | bms_params_expand_B | bms_defaults_group_B | 2 |
| 0x15A7 | 1 | defaults_group_B+0x34 | L | (inside defaults_group_B) | bms_params_expand_B | bms_defaults_group_B | 3 |
| 0x15A8 | 1 | defaults_group_B+0x35 | L | (inside defaults_group_B) | bms_params_expand_B | bms_defaults_group_B | 5 |
| 0x15A9 | 1 | defaults_group_B+0x36 | L | (inside defaults_group_B) | bms_params_expand_B | bms_defaults_group_B | EE |
| 0x15AA | 1 | defaults_group_B+0x37 | L | (inside defaults_group_B) | bms_params_expand_B | bms_defaults_group_B | 5 |
| 0x15AB | 1 | defaults_group_B+0x38 | L | (inside defaults_group_B) | bms_params_expand_B | bms_defaults_group_B | F0 |
| 0x15AC | 1 | defaults_group_B+0x39 | L | (inside defaults_group_B) | bms_params_expand_B | bms_defaults_group_B | EC |
| 0x15AD | 1 | defaults_group_B+0x3A | L | (inside defaults_group_B) | bms_params_expand_B | bms_defaults_group_B | 2 |
| 0x15AE | 1 | defaults_group_B+0x3B | L | (inside defaults_group_B) | bms_params_expand_B | bms_defaults_group_B | F1 |
| 0x15AF | 1 | defaults_group_B+0x3C | L | (inside defaults_group_B) | bms_params_expand_B | bms_defaults_group_B | 2 |
| 0x15B0 | 2 | defaults_group_B+0x3D | L | (inside defaults_group_B) | bms_params_expand_B | bms_defaults_group_B | 2BC |
| 0x15B2 | 1 | defaults_group_B+0x3F | L | (inside defaults_group_B) | bms_params_expand_B | bms_defaults_group_B | 0 |
| 0x15B3 | 1 | defaults_group_B+0x40 | L | (inside defaults_group_B) | bms_params_expand_B | bms_defaults_group_B | 0 |
| 0x15B4 | 2 | defaults_group_B+0x41 | L | (inside defaults_group_B) | bms_params_expand_B | bms_defaults_group_B | 0 |
| 0x15B6 | 2 | defaults_group_B+0x43 | L | (inside defaults_group_B) | bms_params_expand_B | bms_defaults_group_B | FA |
| 0x15B8 | 2 | defaults_group_B+0x45 | L | (inside defaults_group_B) | bms_params_expand_B | bms_defaults_group_B | 708 |
| 0x15BA | 2 | defaults_group_B+0x47 | L | (inside defaults_group_B) | bms_params_expand_B | bms_defaults_group_B | 1 |
| 0x15BC | 50 | defaults_group_P | L | default parameter group P: 0x5DC, 0x898, 0x1194, 0x2710, 0x8300, 0xDAC, 0xE74, 0xFFFFFFEC, each followed by a mode byte 5; source for bms_params_copy_P | bms_params_copy_P | bms_defaults_group_P | 5DC |
| 0x15BE | 1 | defaults_group_P+0x2 | L | (inside defaults_group_P) | bms_params_copy_P | bms_defaults_group_P | 2 |
| 0x15BF | 2 | defaults_group_P+0x3 | L | (inside defaults_group_P) | bms_params_copy_P | bms_defaults_group_P | 898 |
| 0x15C1 | 1 | defaults_group_P+0x5 | L | (inside defaults_group_P) | bms_params_copy_P | bms_defaults_group_P | 5 |
| 0x15C2 | 2 | defaults_group_P+0x6 | L | (inside defaults_group_P) | bms_params_copy_P | bms_defaults_group_P | 1194 |
| 0x15C4 | 1 | defaults_group_P+0x8 | L | (inside defaults_group_P) | bms_params_copy_P | bms_defaults_group_P | 5 |
| 0x15C5 | 2 | defaults_group_P+0x9 | L | (inside defaults_group_P) | bms_params_copy_P | bms_defaults_group_P | 1F4 |
| 0x15C7 | 1 | defaults_group_P+0xB | L | (inside defaults_group_P) | bms_params_copy_P | bms_defaults_group_P | 5 |
| 0x15C8 | 2 | defaults_group_P+0xC | L | (inside defaults_group_P) | bms_params_copy_P | bms_defaults_group_P | 2710 |
| 0x15CA | 1 | defaults_group_P+0xE | L | (inside defaults_group_P) | bms_params_copy_P | bms_defaults_group_P | 5 |
| 0x15CB | 2 | defaults_group_P+0xF | L | (inside defaults_group_P) | bms_params_copy_P | bms_defaults_group_P | 8300 |
| 0x15CD | 1 | defaults_group_P+0x11 | L | (inside defaults_group_P) | bms_params_copy_P | bms_defaults_group_P | 5 |
| 0x15CE | 1 | defaults_group_P+0x12 | L | (inside defaults_group_P) | bms_params_copy_P | bms_defaults_group_P | 41 |
| 0x15CF | 1 | defaults_group_P+0x13 | L | (inside defaults_group_P) | bms_params_copy_P | bms_defaults_group_P | 5 |
| 0x15D0 | 1 | defaults_group_P+0x14 | L | (inside defaults_group_P) | bms_params_copy_P | bms_defaults_group_P | 55 |
| 0x15D1 | 1 | defaults_group_P+0x15 | L | (inside defaults_group_P) | bms_params_copy_P | bms_defaults_group_P | 5 |
| 0x15D2 | 2 | defaults_group_P+0x16 | L | (inside defaults_group_P) | bms_params_copy_P | bms_defaults_group_P | DAC |
| 0x15D4 | 2 | defaults_group_P+0x18 | L | (inside defaults_group_P) | bms_params_copy_P | bms_defaults_group_P | A |
| 0x15D6 | 2 | defaults_group_P+0x1A | L | (inside defaults_group_P) | bms_params_copy_P | bms_defaults_group_P | 1F4 |
| 0x15D8 | 1 | defaults_group_P+0x1C | L | (inside defaults_group_P) | bms_params_copy_P | bms_defaults_group_P | 5 |
| 0x15D9 | 2 | defaults_group_P+0x1D | L | (inside defaults_group_P) | bms_params_copy_P | bms_defaults_group_P | 64 |
| 0x15DB | 2 | defaults_group_P+0x1F | L | (inside defaults_group_P) | bms_params_copy_P | bms_defaults_group_P | E74 |
| 0x15DD | 2 | defaults_group_P+0x21 | L | (inside defaults_group_P) | bms_params_copy_P | bms_defaults_group_P | 32 |
| 0x15DF | 2 | defaults_group_P+0x23 | L | (inside defaults_group_P) | bms_params_copy_P | bms_defaults_group_P | C8 |
| 0x15E1 | 1 | defaults_group_P+0x25 | L | (inside defaults_group_P) | bms_params_copy_P | bms_defaults_group_P | 5 |
| 0x15E2 | 2 | defaults_group_P+0x26 | L | (inside defaults_group_P) | bms_params_copy_P | bms_defaults_group_P | 14 |
| 0x15E4 | 1 | defaults_group_P+0x28 | L | (inside defaults_group_P) | bms_params_copy_P | bms_defaults_group_P | 5 |
| 0x15E5 | 2 | defaults_group_P+0x29 | L | (inside defaults_group_P) | bms_params_copy_P | bms_defaults_group_P | FFFFFFEC |
| 0x15E7 | 1 | defaults_group_P+0x2B | L | (inside defaults_group_P) | bms_params_copy_P | bms_defaults_group_P | 5 |
| 0x15E8 | 2 | defaults_group_P+0x2C | L | (inside defaults_group_P) | bms_params_copy_P | bms_defaults_group_P | 64 |
| 0x15EA | 1 | defaults_group_P+0x2E | L | (inside defaults_group_P) | bms_params_copy_P | bms_defaults_group_P | 5 |
| 0x15EB | 1 | defaults_group_P+0x2F | L | (inside defaults_group_P) | bms_params_copy_P | bms_defaults_group_P | 5 |
| 0x15EC | 1 | defaults_group_P+0x30 | L | (inside defaults_group_P) | bms_params_copy_P | bms_defaults_group_P | 5 |
| 0x15ED | 1 | defaults_group_P+0x31 | L | (inside defaults_group_P) | bms_params_copy_P | bms_defaults_group_P | 5 |
| 0x15EE | 11 | defaults_group_E | L | default parameter group E: 0x414 (1044), 0x3672 (13938), 0xFFFF, 0xFFFF; source for bms_params_copy_E | bms_params_copy_E | bms_defaults_group_E | 0 |
| 0x15EF | 2 | defaults_group_E+0x1 | L | (inside defaults_group_E) | bms_params_copy_E | bms_defaults_group_E | 414 |
| 0x15F1 | 2 | defaults_group_E+0x3 | L | (inside defaults_group_E) | bms_params_copy_E | bms_defaults_group_E | 3672 |
| 0x15F3 | 2 | defaults_group_E+0x5 | L | (inside defaults_group_E) | bms_params_copy_E | bms_defaults_group_E | FFFF |
| 0x15F5 | 2 | defaults_group_E+0x7 | L | (inside defaults_group_E) | bms_params_copy_E | bms_defaults_group_E | FFFF |
| 0x15F9 | 1 | bq_safety_alert_a | L | Safety Alert A (cmd 0x02) | safety_alert_flags_pack | - | - |
| 0x15FA | 1 | bq_safety_status_a | S | Safety Status A (cmd 0x03): b2 CUV, b3 COV, b4 OCC, b5 OCD1, b6 OCD2, b7 SCD | status_bit_clear_timers, safety_status_flags_pack, bq_safety_status_react, chg_fault_active, dsg_fault_active | - | - |
| 0x15FB | 1 | bq_safety_alert_b | L | Safety Alert B (cmd 0x04) | safety_alert_flags_pack | - | - |
| 0x15FC | 1 | bq_safety_status_b | S | Safety Status B (cmd 0x05): b0 UTC, b1 UTD, b4 OTC, b5 OTD, b7 OTF | safety_status_flags_pack, bq_safety_status_react, chg_fault_active, dsg_fault_active | - | - |
| 0x15FE | 1 | bq_safety_status_c | S | Safety Status C (cmd 0x07) | safety_alert_flags_pack, safety_status_flags_pack, bq_safety_status_react, dsg_fault_active | - | - |
| 0x1600 | 2 | bq_img_1600 | L | BQ image word used by safety_status_flags_pack | safety_status_flags_pack | - | - |
| 0x1602 | 2 | bq_img_1602 | L | BQ image word used by safety_status_flags_pack | safety_status_flags_pack | - | - |
| 0x1604 | 2 | bq_img_1604 | L | BQ image word used by safety_status_flags_pack | safety_status_flags_pack | - | - |
| 0x1607 | 2 | bq_battery_status | C | Battery Status (cmd 0x12) | - | - | - |
| 0x1608 | 1 | bq_battery_status+0x1 | C | (inside bq_battery_status) | status_bit_clear_timers, safety_status_flags_pack, bq_safety_status_react | - | - |
| 0x1609 | 2 | bq_cell1_mv | C | Cell 1 voltage (cmd 0x14), mV | cell_voltage_copy_or_default | - | - |
| 0x160B | 2 | bq_cell2_mv | C | Cell 2 (cmd 0x16) | cell_voltage_copy_or_default | - | - |
| 0x160D | 2 | bq_cell3_mv | C | Cell 3 (cmd 0x18) | cell_voltage_copy_or_default | - | - |
| 0x160F | 2 | bq_cell4_mv | C | Cell 4 (cmd 0x1A) | cell_voltage_copy_or_default | - | - |
| 0x1611 | 2 | bq_cell5_mv | C | Cell 5 (cmd 0x1C) | cell_voltage_copy_or_default | - | - |
| 0x1613 | 2 | bq_cell6_mv | C | Cell 6 (cmd 0x1E) | cell_voltage_copy_or_default | - | - |
| 0x1615 | 2 | bq_cell7_mv | C | Cell 7 (cmd 0x20) | cell_voltage_copy_or_default | - | - |
| 0x1617 | 2 | bq_cell8_mv | C | Cell 8 (cmd 0x22) | cell_voltage_copy_or_default | - | - |
| 0x1619 | 2 | bq_cell9_mv | C | Cell 9 (cmd 0x24) | cell_voltage_copy_or_default | - | - |
| 0x161B | 2 | bq_cell10_mv | C | Cell 10 (cmd 0x26) | cell_voltage_copy_or_default | - | - |
| 0x161D | 2 | bq_cell11_mv | C | Cell 11 (cmd 0x28) | cell_voltage_copy_or_default | - | - |
| 0x161F | 2 | bq_cell12_mv | C | Cell 12 (cmd 0x2A) | cell_voltage_copy_or_default | - | - |
| 0x1621 | 2 | bq_cell16_mv | C | Cell 16 (cmd 0x32) = the 13th series cell on this pack (13S wired to VC1..VC12 + VC16) | cell_voltage_copy_or_default | - | - |
| 0x162B | 2 | bq_pack_pin_v | C | PACK pin voltage (cmd 0x36), 10 mV units | history_record_build, power_on_off_decision, pb14_ctrl_logic | - | - |
| 0x162D | 2 | bq_ld_pin_v | C | LD pin voltage (cmd 0x38), 10 mV units; load detection and FET/load logic | pack_power_state_machine, load_detect_control | - | - |
| 0x162F | 2 | bq_cc2_current | C | CC2 current (cmd 0x3A), signed; averaged into the reg_current field | bms_register_block_publish, cell_voltage_copy_or_default | - | - |
| 0x1637 | 2 | cell_voltage_copy_or_default_1637 | C | private state of cell_voltage_copy_or_default (only this function touches it) | cell_voltage_copy_or_default | - | - |
| 0x163F | 2 | bq_alert_pin_thermistor | C | ALERT-pin thermistor temperature (cmd 0x70), 0.1 K units | cell_voltage_copy_or_default | - | - |
| 0x164B | 1 | bq_fet_status | C | FET Status (cmd 0x7F): bit0 CHG, bit1 PCHG, bit2 DSG, bit3 PDSG, ALRT pin bit | chg_fet_control, dsg_fet_control, fet_status_poll | - | - |
| 0x164C | 96 | swtimer_slots | C | 6 software-timer slots x 16 bytes: +0 active, +1 fired, +4 expiry tick (-1 none); armed by swtimer_arm, scanned by swtimer_tick | - | - | - |
| 0x16AD | 150 | usart1_rx_dma_buf | C | USART1 DMA receive buffer (0x96 bytes) | - | - | - |
| 0x1743 | 1 | usart1_tx_bitmap | C | USART1 TX ring slot-in-use bitmap | usart1_tx_start, usart1_tx_enqueue, dma1_ch4_isr | usart1_tx_enqueue, dma1_ch4_isr | - |
| 0x1744 | 1 | usart1_tx_index | C | USART1 TX ring next index | usart1_tx_start, usart1_tx_enqueue, dma1_ch4_isr | usart1_tx_start | - |
| 0x1745 | 456 | usart1_tx_slots | C | USART1 TX ring: 3 slots x 0x98 | - | - | - |
| 0x190D | 1 | usart1_rx_bitmap | C | USART1 RX ring slot-in-use bitmap | USART1_IRQHandler, usart1_rx_dequeue | USART1_IRQHandler, usart1_rx_dequeue | - |
| 0x190E | 1 | usart1_rx_index | C | USART1 RX ring read index | USART1_IRQHandler, usart1_rx_dequeue | usart1_rx_dequeue | - |
| 0x190F | 456 | usart1_rx_slots | C | USART1 RX ring: 3 slots x 0x98 (len u16 + data) | - | - | - |
| 0x1AD8 | 150 | usart3_rx_dma_buf | C | USART3 DMA receive buffer (0x96 bytes) | - | - | - |
| 0x1B6E | 1 | usart3_tx_bitmap | C | USART3 TX ring bitmap | usart3_tx_start, usartN_tx_enqueue, dma1_ch5_isr | usartN_tx_enqueue, dma1_ch5_isr | - |
| 0x1B6F | 1 | usart3_tx_index | C | USART3 TX ring next index | usart3_tx_start, usartN_tx_enqueue, dma1_ch5_isr | usart3_tx_start | - |
| 0x1B70 | 456 | usart3_tx_slots | C | USART3 TX ring: 3 slots x 0x98 | - | - | - |
| 0x1D38 | 1 | usart3_rx_bitmap | C | USART3 RX ring bitmap | USART3_IRQHandler, usart3_rx_dequeue | USART3_IRQHandler, usart3_rx_dequeue | - |
| 0x1D39 | 1 | usart3_rx_index | C | USART3 RX ring index | USART3_IRQHandler, usart3_rx_dequeue | usart3_rx_dequeue | - |
| 0x1D3A | 456 | usart3_rx_slots | C | USART3 RX ring: 3 slots x 0x98 | - | - | - |
| 0x1F10 | 3 | xfer_frame_hdr | L | link frame validation bytes (link_frame_validate_xmodem_or_ascii) | link_frame_validate_xmodem_or_ascii | link_frame_validate_xmodem_or_ascii | - |
| 0x1F11 | 1 | xfer_frame_hdr+0x1 | L | (inside xfer_frame_hdr) | xmodem_header2_check, link_frame_validate_xmodem_or_ascii, xmodem_pkt_header, xmodem_sequence_check | link_frame_validate_xmodem_or_ascii | - |
| 0x1F12 | 1 | xfer_frame_hdr+0x2 | L | (inside xfer_frame_hdr) | link_frame_validate_xmodem_or_ascii | link_frame_validate_xmodem_or_ascii | - |
| 0x1F1F | 6 | xfer_pkt_hdr | L | XMODEM packet header bytes (SOH, seq, ~seq, ...) | xmodem_pkt_header | - | - |
| 0x1F20 | 1 | xfer_pkt_hdr+0x1 | L | (inside xfer_pkt_hdr) | xmodem_pkt_header | - | - |
| 0x1F21 | 1 | xfer_pkt_hdr+0x2 | L | (inside xfer_pkt_hdr) | xmodem_pkt_header | - | - |
| 0x1F22 | 1 | xfer_pkt_hdr+0x3 | L | (inside xfer_pkt_hdr) | xmodem_pkt_header | - | - |
| 0x1F23 | 1 | xfer_pkt_hdr+0x4 | L | (inside xfer_pkt_hdr) | xmodem_pkt_header | - | - |
| 0x1F24 | 1 | xfer_pkt_hdr+0x5 | L | (inside xfer_pkt_hdr) | xmodem_pkt_header | - | - |
| 0x1FA9 | 1 | xfer_frame_kind | L | frame kind (xmodem vs ASCII command) | xmodem_header2_check, link_frame_validate_xmodem_or_ascii, xmodem_pkt_data | link_frame_validate_xmodem_or_ascii | - |
| 0x1FAA | 2 | link_frame_validate_xmodem_or_ascii_1FAA | C | private state of link_frame_validate_xmodem_or_ascii (only this function touches it) | link_frame_validate_xmodem_or_ascii | link_frame_validate_xmodem_or_ascii | - |
| 0x1FAC | 1 | xfer_state | L | link/XMODEM state: 0..3 | link_frame_execute, xmodem_ack_commit | link_frame_execute, xmodem_sequence_check | 0,1,2,3 |
| 0x1FAD | 1 | link_frame_flag_a | L | link frame validation result flag | link_frame_execute | link_frame_validate_xmodem_or_ascii | 0,1 |
| 0x1FAE | 1 | link_frame_flag_b | L | link frame validation result flag | link_frame_execute | link_frame_validate_xmodem_or_ascii | - |
| 0x1FAF | 1 | xmodem_phase | L | XMODEM phase: 0 idle, 1 started, 2 data, 3 finishing | status_reply_text_copy, xmodem_ack_commit | xmodem_session_start, xmodem_header2_check, xmodem_state_reset, link_frame_execute, xmodem_pkt_header | 0,1,2,3 |
| 0x1FB0 | 2 | xmodem_rx_len | L | received packet byte count | xmodem_header2_check, xmodem_pkt_data | xmodem_header2_check, xmodem_state_reset, xmodem_pkt_data | 0 |
| 0x1FB2 | 2 | xmodem_seq_expected | L | expected sequence number | xmodem_pkt_data, xmodem_sequence_check, xmodem_ack_commit | xmodem_state_reset, xmodem_sequence_check | 0 |
| 0x1FB4 | 2 | xmodem_seq_last | L | last accepted sequence number | xmodem_sequence_check | xmodem_state_reset, xmodem_ack_commit | 0 |
| 0x1FB6 | 2 | xmodem_hdr_marker | L | header marker (init 0xFF) | xmodem_pkt_header, xmodem_pkt_data, xmodem_sequence_check | xmodem_state_reset, xmodem_pkt_header | FF |
| 0x1FB8 | 2 | xmodem_blocks_staged | L | 128-byte blocks staged to SPI flash buffer | spi_flash_buffered_write, xmodem_pkt_data, xmodem_sequence_check, xmodem_ack_commit | xmodem_state_reset, xmodem_sequence_check | 0 |
| 0x1FBA | 2 | xmodem_ack_commit_1FBA | C | private state of xmodem_ack_commit (only this function touches it; written once, never read) | - | xmodem_state_reset, xmodem_ack_commit | 0 |
| 0x1FBC | 4 | xmodem_total_bytes | L | total bytes received | xmodem_pkt_header | xmodem_state_reset, xmodem_pkt_header | 0 |
| 0x1FC0 | 2 | xmodem_pkt_len | L | current packet length | xmodem_pkt_data | xmodem_state_reset, xmodem_pkt_header | 0 |
| 0x1FC4 | 4 | xmodem_crc_acc | L | CRC accumulator / expected CRC | xmodem_header2_check, xmodem_pkt_data | xmodem_header2_check, xmodem_state_reset | 0 |
| 0x1FC8 | 2 | xmodem_header2_check_1FC8 | C | private state of xmodem_header2_check (only this function touches it; written once, never read) | - | xmodem_header2_check, xmodem_state_reset | 0 |
| 0x1FCA | 4 | xmodem_aux_a | L | cleared by xmodem_state_reset; no reader | - | xmodem_state_reset | 0 |
| 0x1FCE | 4 | xmodem_aux_b | L | cleared by xmodem_state_reset; no reader | - | xmodem_state_reset | 0 |
| 0x1FD2 | 2 | xmodem_aux_c | L | cleared by xmodem_state_reset; no reader | - | xmodem_state_reset | 0 |
| 0x1FD4 | 2048 | spi_stage_buf | C | 2 KB staging buffer used by spi_flash_buffered_write (A:119E4) | - | - | - |
| 0x27D4 | 4 | spi_stage_fill | C | bytes currently in spi_stage_buf | spi_flash_buffered_write | spi_flash_buffered_write | - |
| 0x27D8 | 4 | spi_stage_remaining | C | bytes remaining in the 2 KB window (init 0x800) | spi_flash_buffered_write | spi_flash_buffered_write, spi_stage_buffers_reset | 800 |
| 0x27DC | 4 | spi_stage_sector_addr | C | SPI flash sector address being filled | spi_flash_buffered_write | spi_flash_buffered_write | - |
| 0x2FEC | 4 | limit_curve_min_ref | L | limit-curve running minimum (init 0x7FFFFFFF / 0x80000000) | current_limit_curves | current_limit_curves | 7FFFFFFF,80000000 |
| 0x2FF0 | 10 | limit_curve_state_a | L | limit-curve state words (2FF0..2FF8) | current_limit_curves | current_limit_curves | - |
| 0x2FF2 | 2 | limit_curve_state_a+0x2 | L | (inside limit_curve_state_a) | current_limit_curves | current_limit_curves | 0,2710 |
| 0x2FF4 | 2 | limit_curve_state_a+0x4 | L | (inside limit_curve_state_a) | current_limit_curves | current_limit_curves | - |
| 0x2FF6 | 2 | limit_curve_state_a+0x6 | L | (inside limit_curve_state_a) | current_limit_curves | current_limit_curves | - |
| 0x2FF8 | 2 | limit_curve_state_a+0x8 | L | (inside limit_curve_state_a) | current_limit_curves | current_limit_curves | - |
| 0x2FFA | 4 | limit_curve_step_ref | L | limit step-down reference (limit_step_down) | limit_step_down | current_limit_curves | - |
| 0x2FFE | 2 | limit_curve_flags | L | limit curve flags | current_limit_curves, limit_state_reset | current_limit_curves, limit_state_reset | - |
| 0x2FFF | 1 | limit_curve_flags+0x1 | L | (inside limit_curve_flags) | current_limit_curves, limit_state_reset | current_limit_curves, limit_state_reset | - |
| 0x3000 | 14 | limit_curve_state_b | L | limit-curve state words (3000..300C) | current_limit_curves | current_limit_curves | - |
| 0x3002 | 2 | limit_curve_state_b+0x2 | L | (inside limit_curve_state_b) | current_limit_curves | current_limit_curves | - |
| 0x3004 | 2 | limit_curve_state_b+0x4 | L | (inside limit_curve_state_b) | current_limit_curves | current_limit_curves | - |
| 0x3006 | 2 | limit_curve_state_b+0x6 | L | (inside limit_curve_state_b) | current_limit_curves | current_limit_curves | - |
| 0x3008 | 2 | limit_curve_state_b+0x8 | L | (inside limit_curve_state_b) | current_limit_curves | current_limit_curves | - |
| 0x300A | 2 | limit_curve_state_b+0xA | L | (inside limit_curve_state_b) | current_limit_curves | current_limit_curves | - |
| 0x300C | 2 | limit_curve_state_b+0xC | L | (inside limit_curve_state_b) | current_limit_curves | current_limit_curves | - |
| 0x300E | 1 | limit_curve_active | L | limit-curve active flag (set by current_limit_curves, cleared by limit_state_reset) | current_limit_curves, limit_step_down | current_limit_curves, limit_step_down, limit_state_reset | 0,1 |
| 0x300F | 2 | port_temp_max_x10 | C | hottest temperature x10 (A:8E50) | port_get_temp_max_x10 | port_get_temp_max_x10 | - |
| 0x3011 | 2 | port_temp_min_x10 | C | coldest temperature x10 (A:8E70) | port_get_temp_min_x10 | port_get_temp_min_x10 | - |
| 0x3013 | 1 | port_any_block | L | 1 if chg_block or general_block set (A:8DE4) | port_get_any_block_flag | port_get_any_block_flag | 0,1 |
| 0x301D | 2 | port_soh_permille_copy | C | SOH permille copy (A:8F40) | port_get_soh_permille | port_get_soh_permille | - |
| 0x301F | 2 | port_const_4200 | L | constant 4200 (A:8F04): 4.2 V per-cell full voltage | port_get_const_4200 | port_get_const_4200 | 1068 |
| 0x3024 | 40 | session_event_rec | C | 0x28-byte event record built by session_event_logger (written to the SPI event ring at 0x21000) | - | session_event_logger | 0 |
| 0x3026 | 1 | session_event_rec+0x2 | C | (inside session_event_rec) | - | session_event_logger | - |
| 0x3027 | 1 | session_event_rec+0x3 | C | (inside session_event_rec) | - | session_event_logger | - |
| 0x3028 | 1 | session_event_rec+0x4 | C | (inside session_event_rec) | - | session_event_logger | - |
| 0x3029 | 1 | session_event_rec+0x5 | C | (inside session_event_rec) | - | session_event_logger | - |
| 0x302A | 1 | session_event_rec+0x6 | C | (inside session_event_rec) | - | session_event_logger | - |
| 0x302B | 1 | session_event_rec+0x7 | C | (inside session_event_rec) | - | session_event_logger | - |
| 0x302C | 4 | session_event_rec+0x8 | C | (inside session_event_rec) | - | session_event_logger | - |
| 0x3030 | 2 | session_event_rec+0xC | C | (inside session_event_rec) | - | session_event_logger | - |
| 0x3032 | 2 | session_event_rec+0xE | C | (inside session_event_rec) | - | session_event_logger | - |
| 0x3034 | 4 | session_event_rec+0x10 | C | (inside session_event_rec) | - | session_event_logger | - |
| 0x3038 | 1 | session_event_rec+0x14 | C | (inside session_event_rec) | - | session_event_logger | - |
| 0x3039 | 1 | session_event_rec+0x15 | C | (inside session_event_rec) | - | session_event_logger | - |
| 0x303A | 2 | session_event_rec+0x16 | C | (inside session_event_rec) | - | session_event_logger | - |
| 0x303C | 4 | session_event_rec+0x18 | C | (inside session_event_rec) | - | session_event_logger | - |
| 0x3040 | 4 | session_event_rec+0x1C | C | (inside session_event_rec) | - | session_event_logger | - |
| 0x3044 | 4 | session_event_rec+0x20 | C | (inside session_event_rec) | - | session_event_logger | - |
| 0x3048 | 2 | session_event_rec+0x24 | C | (inside session_event_rec) | - | session_event_logger | 0 |
| 0x304A | 2 | session_event_rec+0x26 | C | (inside session_event_rec) | - | session_event_logger | 0 |
| 0x304C | 12 | eventlog_hdr | C | event-log header: head/tail/count addresses (init 0x21000); validated by eventlog_header_validate | eventlog_record_write, eventlog_advance, eventlog_header_validate | eventlog_record_write, spi_flash_init_id, eventlog_header_validate | 0 |
| 0x3050 | 4 | eventlog_hdr+0x4 | C | (inside eventlog_hdr) | eventlog_record_write, eventlog_advance, eventlog_header_validate | eventlog_record_write, spi_flash_init_id, eventlog_header_validate | 21000 |
| 0x3054 | 2 | eventlog_hdr+0x8 | C | (inside eventlog_hdr) | eventlog_record_write, eventlog_header_validate | eventlog_record_write, spi_flash_init_id, eventlog_header_validate | 21000 |
| 0x3058 | 4 | eventlog_hdr_crc | L | event-log header checksum | eventlog_read_header | eventlog_header_write | - |
| 0x305C | 40 | eventlog_rec | C | 0x28-byte record built by eventlog_build_record | - | eventlog_build_record | - |
| 0x305E | 1 | eventlog_rec+0x2 | C | (inside eventlog_rec) | - | eventlog_build_record | - |
| 0x305F | 1 | eventlog_rec+0x3 | C | (inside eventlog_rec) | - | eventlog_build_record | - |
| 0x3060 | 1 | eventlog_rec+0x4 | C | (inside eventlog_rec) | - | eventlog_build_record | - |
| 0x3061 | 1 | eventlog_rec+0x5 | C | (inside eventlog_rec) | - | eventlog_build_record | - |
| 0x3062 | 1 | eventlog_rec+0x6 | C | (inside eventlog_rec) | - | eventlog_build_record | - |
| 0x3063 | 1 | eventlog_rec+0x7 | C | (inside eventlog_rec) | - | eventlog_build_record | - |
| 0x3064 | 4 | eventlog_rec+0x8 | C | (inside eventlog_rec) | - | eventlog_build_record | - |
| 0x3068 | 2 | eventlog_rec+0xC | C | (inside eventlog_rec) | - | eventlog_build_record | - |
| 0x306A | 2 | eventlog_rec+0xE | C | (inside eventlog_rec) | - | eventlog_build_record | - |
| 0x306C | 4 | eventlog_rec+0x10 | C | (inside eventlog_rec) | - | eventlog_build_record | - |
| 0x3070 | 1 | eventlog_rec+0x14 | C | (inside eventlog_rec) | - | eventlog_build_record | - |
| 0x3071 | 1 | eventlog_rec+0x15 | C | (inside eventlog_rec) | - | eventlog_build_record | - |
| 0x3072 | 2 | eventlog_rec+0x16 | C | (inside eventlog_rec) | - | eventlog_build_record | - |
| 0x3074 | 4 | eventlog_rec+0x18 | C | (inside eventlog_rec) | - | eventlog_build_record | - |
| 0x3078 | 4 | eventlog_rec+0x1C | C | (inside eventlog_rec) | - | eventlog_build_record | - |
| 0x307C | 4 | eventlog_rec+0x20 | C | (inside eventlog_rec) | - | eventlog_build_record | - |
| 0x3080 | 4 | eventlog_read_state | L | state of eventlog_read_record | - | eventlog_read_record, eventlog_build_record | 0,1 |
| 0x3082 | 2 | eventlog_read_state+0x2 | L | (inside eventlog_read_state) | eventlog_read_record | eventlog_build_record | 0 |
| 0x3084 | 32 | history_rec | C | 0x20-byte history record built by history_record_build (CRC8 poly 0x2F in last byte) | - | history_record_build | - |
| 0x3085 | 1 | history_rec+0x1 | C | (inside history_rec) | - | history_record_build | - |
| 0x3086 | 1 | history_rec+0x2 | C | (inside history_rec) | - | history_record_build | - |
| 0x3087 | 1 | history_rec+0x3 | C | (inside history_rec) | - | history_record_build | - |
| 0x3088 | 1 | history_rec+0x4 | C | (inside history_rec) | - | history_record_build | - |
| 0x3089 | 1 | history_rec+0x5 | C | (inside history_rec) | - | history_record_build | - |
| 0x308A | 1 | history_rec+0x6 | C | (inside history_rec) | - | history_record_build | 0,2,4 |
| 0x308B | 1 | history_rec+0x7 | C | (inside history_rec) | history_record_build | history_record_build | 0 |
| 0x308C | 1 | history_rec+0x8 | C | (inside history_rec) | - | history_record_build | - |
| 0x308D | 1 | history_rec+0x9 | C | (inside history_rec) | - | history_record_build | - |
| 0x308E | 1 | history_rec+0xA | C | (inside history_rec) | - | history_record_build | - |
| 0x308F | 1 | history_rec+0xB | C | (inside history_rec) | - | history_record_build | - |
| 0x3090 | 1 | history_rec+0xC | C | (inside history_rec) | - | history_record_build | - |
| 0x3091 | 1 | history_rec+0xD | C | (inside history_rec) | - | history_record_build | - |
| 0x3092 | 1 | history_rec+0xE | C | (inside history_rec) | - | history_record_build | - |
| 0x3093 | 1 | history_rec+0xF | C | (inside history_rec) | - | history_record_build | - |
| 0x3094 | 1 | history_rec+0x10 | C | (inside history_rec) | - | history_record_build | - |
| 0x3095 | 1 | history_rec+0x11 | C | (inside history_rec) | - | history_record_build | - |
| 0x3096 | 1 | history_rec+0x12 | C | (inside history_rec) | - | history_record_build | - |
| 0x3097 | 1 | history_rec+0x13 | C | (inside history_rec) | - | history_record_build | - |
| 0x3098 | 1 | history_rec+0x14 | C | (inside history_rec) | - | history_record_build | - |
| 0x3099 | 1 | history_rec+0x15 | C | (inside history_rec) | - | history_record_build | - |
| 0x309A | 1 | history_rec+0x16 | C | (inside history_rec) | - | history_record_build | - |
| 0x309B | 1 | history_rec+0x17 | C | (inside history_rec) | - | history_record_build | - |
| 0x309C | 1 | history_rec+0x18 | C | (inside history_rec) | - | history_record_build | - |
| 0x30CF | 12 | history_hdr | C | history ring header (init 0x41000) | history_get_record, history_header_validate, history_record_append, rtc_get_to_0xCB5 | history_header_init, history_header_validate, history_record_append | 0 |
| 0x30D1 | 4 | history_hdr+0x2 | C | (inside history_hdr) | history_get_record, history_header_validate, history_record_append | history_header_init, history_header_validate, history_record_append | 41000 |
| 0x30D5 | 2 | history_hdr+0x6 | C | (inside history_hdr) | history_header_validate, history_record_append | history_header_init, history_header_validate, history_record_append | 41000 |
| 0x30D9 | 4 | history_hdr_crc | L | history header checksum | history_header_read | history_header_write | - |
| 0x30F5 | 1 | history_crc8_tmp | L | CRC8 scratch for history_read_record_crc8 | history_read_record_crc8 | - | - |
