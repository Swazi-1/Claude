# Firmware at a glance (Xiaomi Electric Scooter 5 Max): read this, then go deeper

**Update 2026-10-04 (later): V8.1 CANDIDATE built, NOT flashed** (`01_FIRMWARE/1b_V8_1_CANDIDATE_not_flashed/`, SHA-256 `9218c5ef58b7...`). V8 600 + smooth low-battery ramp (600 at 20 % -> 274 at 10 %, no steps), Medium recovery no longer triggers the child cap (six-press only), smooth controller heat fade from 86 C (stock formula constant). V8 600 stays on the scooter and is the rollback until the owner flashes V8.1. Also corrected: the app's 'Scooter Temperature' (75 C max) is a controller temperature, not the motor.

One-page map of **everything in the firmware image** and where the details are. Current as of **2026-10-04**. Labels: **C** confirmed (code/bytes/measured), **S** strong, **L** likely, **U** unknown. This is the owner's own scooter; this project is analysis plus offline build files. **The owner flashes; an AI never flashes or sends device commands.**

## 1. The image in one table (147,456 bytes = 0x24000; file offsets)
| file range | what it is |
|---|---|
| 0x0000..0x002D | outer package header (ASCII `0108` at 0x12; **outer CRC16 at bytes 10..11**) |
| 0x0800..0x080C | A-package header (`DEPRD5C` + 5 bytes) |
| **0x1000..0x19223** | **Program A = the battery-management system (BMS)**: Cortex-M4F (Nations N32G43x-class) + TI BQ769x2 chip. Runtime address = file + 0x08002000. **Byte-identical in every build.** |
| 0x19800..0x19817 | B header: **body length u32 at 0x19800 (0xA404)**, **inner CRC32 u32 LE at 0x19804** |
| **0x19818..0x2381B** | **Program B = the motor controller**: LKS32MC071 (Cortex-M0), field-oriented control at 15.625 kHz. Runtime address = file - 0x17018. **All differences between builds are here.** |
| 0x2381C..0x23FFF | 0xFF padding; custom builds put 0.3-0.6 KB of added code at 0x2381C..0x23A97 (child cap helper 0x2381C, six-press hook 0x23858, init helper 0x23918, RC02 governor mask 0x23950) |

Not in the image and not available: dashboard MCU firmware, bootloader, schematic (**U**).

**Checksums (C, reproduced on all 7 images):** inner = CRC-32/MPEG-2 (poly 0x04C11DB7, init 0xFFFFFFFF, no reflection, no xor-out) over `file[0x19818 : 0x19818+0xA404]` padded with 0xFF to a multiple of 4, stored little-endian at 0x19804; outer = CRC-16/XMODEM (`binascii.crc_hqx(file[0x19800:], 0)`) stored big-endian at bytes 10..11. Tool: `tools/fw_image_tool.py` (`info`, `diff`, `recrc`; standard library only).

## 2. The builds (all in `../01_FIRMWARE/`, full hashes in `../01_FIRMWARE/SHA256SUMS.txt`)
| build | SHA-256 (first 12) | what it is | status |
|---|---|---|---|
| **stock** | 015718dd8126 | original Xiaomi: D 20.3 / S 25.3 km/h, Sport cap 493, regen 91/146/292 | comparison base |
| farm v7.1 | b4c64d8464db | stock + 98 B in program B (D 25.0 / S 45.0 targets, envelopes 400/560, regen 91/160/320, coast regen from 5.0 km/h, region-free literals, thermal derate 1020 + formula constant 3620 (0x1FEB8), child cap + six-press gesture) | ridden earlier, rollback |
| RC01 | 1c58131d6be7 | v7.1 + child-cap min fix | never ridden |
| RC02 | f1037de2f08b | RC01 + governor mask (2 hooks + 328-byte routine) | was on the scooter until 2026-10-03; main rollback |
| **V8 FINAL 600** | **901ce6cea8fa** | **RC02 + regen back to stock (0x20020: A0->92) + Sport cap 600 (0x1E02C: 8C->96) + new CRCs. 8 bytes differ from RC02.** | **ON THE SCOOTER, works** (owner decision 2026-10-04: leave as is) |
| V8.1 CANDIDATE | 9218c5ef58b7 | V8 600 + 0x1FD92/0x1FD96 smooth low-battery ramp, 0x23824 Medium->child trigger removed, 0x1FC90 + 0x1FEB8 smooth heat fade from 86 C | built 2026-10-04, **not flashed** |
| 640 / 680 | 9b1c7a52fc92 / 8d1e5c427739 | Sport cap 640 / 680 | **DO NOT FLASH**: trip the battery's 22 A/10 s and 25 A/1 s latches (680 cut out at 25.35 A) |

Program A is byte-identical in all of them. Stock vs V8 FINAL: 646 bytes differ (7 header, 105 in B, 534 appended code). Instruction-level reading: `07_BUILDS_AND_DIFFS.md`.

## 3. Where each setting lives (file offsets; V8 FINAL values)
| setting | where | value |
|---|---|---|
| Sport (S) current cap | 0x1E02C (`movs r0,#imm`; imm x 4) | 0x96 x 4 = **600 counts = 22.1 A** (amps = counts / 27.2) |
| D / S / walking speed targets, D / walking current caps | `throttle_mode_block` B:1DDCC, bytes 0x1E00A..0x1E02F | D 25.0 km/h, cap 400; S 45.0 (real top speed ~33 km/h is set by battery voltage); walking 20.0 km/h, cap 210 (child cap: D 15 / S 20 / other 6 km/h) |
| Regen demand weak / medium / strong | 0x2001C / 0x20020 (medium imm; strong = imm x 2) | 91 / 146 / 292 (stock values) |
| Coast regen start speed | 0x1BDDE (`cmp r3,#imm`, 0.1 km/h) | 0x32 = 5.0 km/h (stock 6.0) |
| Low-speed brake count | 0x1C1BC | 0x5A (stock 0x1E) |
| Thermal derate threshold | 0x1FC90 (imm x 4) + formula constant 0x1FEB8 | 0xFF x 4 = 1020, cap = 3620 - 3T (stock 900 / 3193; V8.1 864 / 3193); T = `temp_local` in 0.1 C (L) |
| Low-charge current cap (SOC < 20 %) | B:1FD82..1FD9C; base 493 at 0x1FD96/98 | unchanged stock logic; below 20 % SOC the V8 600 behaves like stock (step 22.1 -> 17.3 A at 20 -> 19 %) |
| Region-free literals | 9 halfwords (0x1C6A0 ... 0x200A4) | 0x0000 (stock 0xEC85/0xEEC4) |
| Child cap | appended helper 0x2381C (+ flag word RAM 0x20000498 = 0xC1); six-press hook 0x23858 | on when profile byte 60 (recovery Medium) OR the flag; six mode changes at standstill toggle the flag |
| Battery discharge latches | program A, `sw_overcurrent_discharge_levels` A:FF3C | **>= 25 A for 1.0 s, or >= 22 A for 10 s (uninterrupted; any 100 ms sample below resets the count) -> discharge FET opens, whole scooter off** |
| Battery charge latch | A:F994 | >= 5.5 A for 1 s or 4.5 A for 10 s |

**Never touch:** A's power/sleep RAM (0x02, 0x2C, 0x2D, 0x2F, 0x35, 0x37, 0x100, 0x103, 0x104), A's protection limits, B's boot and power-latch code (power-latch bit GPIO3.9; `startup_calibrate_and_load` B:1C53C, `dash_loss_poweroff` B:206E4). If the original one-press power button stops working, the scooter cannot be re-flashed.

## 4. What the two programs do (30 seconds each)
**Program A (BMS).** Boots into a 1 ms timer scheduler (`main` A:1707A -> `main_init_a` A:3034 -> `app_init_sequence` A:1DF4 -> `swtimer_dispatch` A:4CBC; four callbacks at 1/10/100/500 ms). Configures the BQ769x2 (hardware protections: cell UV 2.73 V, OV 4.25 V, short-circuit, discharge OC2 30 mV, OT/UT), decides when the discharge and charge FETs may be on (`dsg_fet_control` A:5274, `chg_fet_control` A:48F8, `pack_power_state_machine` A:11DE8), estimates SOC/SOH (`soc_model_*`, `soc_coulomb_integrate` A:EA64), logs to an SPI NOR flash, and publishes a **17-object register map** to B over UART1 (`bms_register_block_publish` A:1337C; object 0x44 = max-cell byte, SOC, pack mV, current, temperature, flags). Its own software latches sit on top of the BQ chip (cell OV 4.22 V, UV 2.77 V, board OT 90 C, and the discharge/charge over-current latches above).

**Program B (motor controller).** `main` B:2292C -> `hardware_init` B:1C6AC -> `startup_calibrate_and_load` B:1C53C -> scheduler driven by the motor-PWM interrupt (`ISR_MCPWM0` B:1CB14: field-oriented current loop, hall rotor estimator B:1F660, SVPWM). Command path: dashboard control frame (UART0, decoder B:20A14: throttle, brake, mode, recovery level) -> `throttle_mode_block` B:1DDCC (requested speed, mode caps, child cap) -> `speed_loop` B:1E3D0 (drive command; coast/brake branches) -> `current_limiter_drive_cmd` B:1D654 (limits by `env_applied`), with `envelope_protection` B:1FC0C (stall, thermal, battery-temperature and SOC derating). Regen: `coast_regen_demand` B:1BDD0, `active_brake_demand_calc` B:1DCB0, IMU slope clamp `remote_flag374_filter` B:1AF94, voltage gate in `voltage_monitor` B:22F38. Also: cruise hold B:1D9C0, governor detector B:2036C, IMU attitude B:22058, region defaults B:1FFDC, and the update/service receivers (UART0 ASCII `down`, XMODEM, AES unlock).

**The link.** B polls A over UART1 at 19200 baud (header 0x63, reply 0x74); B uses A's SOC and temperature to cap current and gate regen. Dashboard link: UART0 at 19200 (control frame `51 10 ...`, status frame 0x61 about every 102 ms). Details: `05_PROTOCOLS_AND_REGISTERS.md`.

## 5. Hardware and the measured facts (owner's scooter)
* Pack T2356-BD4A (De.power, 2024-11): **13S4P** NMC 18650-size cells, 46.8 V nominal / 54.6 V full, 10.2 Ah, 477 Wh (label photo in `../05_HARDWARE_PHOTOS/`). BMS firmware 0108 (from the app). Motor: Xiaomi spec 400 W rated / 1000 W max; 16 AWG phase cable (L). Shunt value, fuse rating and exact cell model: **U**.
* **Power.** Sport battery current = cap / 27.2 counts per amp (matched within about 1 % at 560, 600 and 680). 600 gave 22.13 A / 1124 W peak; 680 gave 25.35 A and then a cut-out. **600 is the practical maximum** because of A's 22 A/10 s and 25 A/1 s latches. 2026-10-04: a sustained 10 degree climb at 1.0-1.17 kW, controller ('Scooter Temperature' in the app) max 75 C, no cut-out.
* **Regen gates (B).** Speed >= 5 km/h; battery temperature 0..45 C; recovery value exactly 30/60/90; SOC >= 90 caps Strong to Medium; coast adjustment only below 54.0 V (weak regen at full charge); brake regen blocked at SOC >= 95; IMU slope clamp caps to Weak. The downhill "rolls from about 30 km/h" delay is undiagnosed (best fit: slope clamp; it needs the app current while rolling). See `10_REGEN_ENTRY_DELAY_ANALYSIS.md`.
* Top speed follows battery voltage, not the cap: about 33 km/h flat at 100 %, 29-30 at 56 %, 28 at 35 %.

## 6. Where to go next
| need | open |
|---|---|
| everything we found, status, results, open items | `../PROJECT_SUMMARY.md` |
| question -> file index, conventions, cheat sheet, regenerate commands | `00_README_FOR_AI.md` |
| hardware, image layout, boot | `01_ARCHITECTURE.md` |
| B / A internals | `02_PROGRAM_B_MOTOR_CONTROLLER.md`, `03_PROGRAM_A_BMS.md` |
| power on/off, throttle -> motor, protections -> FETs, regen gates, charging, caps | `04_FEATURE_CHAINS.md` |
| every function / RAM cell / peripheral register | `A_` and `B_` `FUNCTION_CATALOG.md`, `RAM_MAP.md`, `PERIPHERAL_MAP.md` |
| real code | `data/A_pseudocode.txt`, `data/B_pseudocode.txt`, `data/*_annotated_disassembly.txt` |
| power sweep, 600/640/680 tests, battery limits | `11_POWER_ENVELOPE_SWEEP.md` |
| what is still unknown | `08_UNKNOWNS_AND_COVERAGE.md` |

To see the layout, both checksums and the key settings of any image: `python tools/fw_image_tool.py info <image.bin>`. IDs: `A:<hex>` / `B:<hex>` = function entry file offset.

## 7. Working rules for an AI continuing this
1. Default to analysis and documentation. Build a firmware file only when the owner explicitly asks, in a NEW folder, never overwriting; the owner flashes.
2. The original one-press power button is priority #1: power path byte-identical, owner button test before and after any flash.
3. Do not change A's protection limits. Do not offer 640/680 or higher Sport caps.
4. Keep C/S/L/U separate; preserve originals and evidence; save findings as Markdown; explain simply; give short progress updates.
