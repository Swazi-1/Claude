# Sport power envelope (the "xxx x4" value) - how high before something else limits? (2026-10-03)

Analysis only (host-side emulator running the real RC02 motor-controller code in the project's plant model; nothing sent to the scooter, no file built).

**Where:** Sport envelope is set at file 0x1E02C: stock `255+238 = 493`; v7.1 and RC02 `140 x 4 = 560` (`movs r0,#0x8C; lsls r0,#2`). 150x4 = 600 (byte 0x96), 160x4 = 640 (0xA0), 170x4 = 680 (0xAA). **C**

**Scale (S):** controller counts per amp ~27.2. RC02's 560 gave 20.6 A in the model, matching the owner's measured 20.6 A ceiling at 100/56/35 % charge. So ceiling A ~ envelope / 27.2.

**Sweep (model, RC02, DC battery current / peak power, flat from 8 km/h, 100 % = 54.1 V):**
| envelope | DC current | power | phase current (limit 1461 counts) |
|---|---|---|---|
| 493 (stock) | 18.1 A | 0.93 kW | 808 |
| 560 (RC02) | 20.6 A | 1.05 kW | 860 |
| 600 (150x4) | 22.1 A | 1.12 kW | 889 |
| 640 (160x4) | 23.5 A | 1.19 kW | 916 |
| 700 | 25.8 A | 1.29 kW | 954 |
| 800 | 29.4 A | 1.45 kW | 1011 |
| 900 | 33.1 A | 1.61 kW | 1061 |
| >= 1000 | 34.6 A (plant-limited) | 1.68 kW | 1086 |
Steep hill at 35 % charge reaches 41.7 A / 1309 counts at env 1200.

**Firmware-side limits:** the envelope caps DC current until about 900 (flat, full pack) - above ~1000 the motor/battery model, not the cap, sets the current. Fixed firmware limits: phase current 1461 counts (not reached below env ~1200), drive command +/-1023, hardware over-current comparator (DAC0 threshold 203; its amp equivalent is **U**). **C/S**

**What the firmware cannot tell us (U):** the BMS shunt resistance (OCD2 trip is 30 mV, SCD enabled; amps unknown), MOSFET/wire/fuse ratings, connector and motor heating. A true "blow-up" current cannot be derived from the firmware alone. The cap value is also reduced below 20 % charge and at temperature extremes (see 04_FEATURE_CHAINS.md section 2.6).

## Owner's first ride on the 600 candidate (screen recording, 90 s, 100 % charge, 16-17 C battery; OCR of the app's Battery info page, `03_RIDE_DATA_2026-10-03/V8_tests_2026-10-03_04/V8_600_first_ride_screen_recording_ocr.csv`, OCR may misread single digits)
* Peak **22.13 A / 1124 W** at the start of the first pull; sustained 21-22.3 A for ~5-7 s per pull; later peak 22.31 A / 1118 W. Model predicted 22.1 A / 1.116 kW (error ~1 %), so the 27.2 counts/A scale holds at this level. **S**
* Pack voltage 54.0 V at rest sagged to 49.9-50.8 V at 22 A. No trip, no error. App "Scooter Temperature" 36-37 C (controller; the app has no motor temperature). Battery 16 -> 17 C.
* Regen in the recording peaked at only -2.5 to -3.2 A with pack voltage 53.3-54.1 V (100 % -> 99 %): this is the known full-charge regen limit (SOC >= 90 cap + 54.0 V gate), not a test of normal regen. Regen at ~75/56/35 % charge still untested on this build.

## Battery label (owner photos, taken December, deck opened; battery serial/date match the app)
* Pack T2356-BD4A (Xiaomi spec page says T2336), made by De.power Technology, 2024-11. Nominal 46.8 V, charge 54.6 V, 10.2 Ah, 477.36 Wh, 2.77 kg, IPX6. Chemistry NMC (Ni/Co/Mn) with natural graphite. **C** (read from the photo)
* Cell designation **13INR19/66-4** = 13 in series x **4 in parallel** (19 x 66 mm cylindrical, i.e. 18650-class). So ~2.55 Ah per cell. This **corrects my earlier guess of 13S3P / 3.4 Ah**. **S** (IEC naming reading)
* Per cell at the pack current: 22 A / 4 = 5.5 A; 28 A / 4 = 7 A. The exact cell model is not on the label, so cell ratings stay **U**.
* Motor cable text read from the photo: 16 AWG x 3 + 24 AWG x 5 (phase + hall). Model phase current at 600 is ~38 A peak amplitude at ~22 A DC. **L**
* BMS board / fuse / shunt are inside the pack and not visible in the photos: still **U**.

## 680 test: cut-off at 25.35 A explained (owner report 2026-10-04, screenshot of the app at the moment of disconnect)
* Owner flashed the 680 build. Start and flat/uphill acceleration worked; full throttle uphill cut the whole scooter off (Bluetooth disconnected). Last app reading: **25.35 A, 50.07 V, 1269 W, 98 %, battery 18 C**. After waiting 30 s the scooter powered on normally.
* Model had predicted 25.0 A for 680, so the amps scale holds (error ~1 %).
* **Cause (C for thresholds, S for counter semantics): A's software discharge over-current latches** (`sw_overcurrent_discharge_levels` A:FF3C, table in `06_A_ROM_TABLES.md` section 3): **L2: discharge >= 25,000 mA for 10 ticks (1.0 s) -> dsg_block** (DSG FET opens, whole scooter dead); released 100 ticks (10 s) after latching and only once discharge stops. **L1: >= 22,000 mA for 100 ticks (10 s) -> dsg_block**, same release. The earlier "BMS trips near 30 A" estimate (BQ OCD2 30 mV, shunt unknown) was **wrong as a practical limit**: A's own latches trip first.
* Consequences: sustained limit is < 22 A for 10 s and < 25 A for 1 s. 600 (peak 22.1-22.3 A, ran ~5-7 s with readings mostly just under 22 A) sits at the edge of L1; 640 (23.5 A) would trip L1 after ~10 s of continuous full-throttle load; 680 (25 A) trips L2 after ~1 s. Whether the 10-tick/100-tick counters reset when current dips below the level is not verified (U).
* Not damage: this is the designed protection; the scooter recovered.
* Counter semantics checked in code (A:FF3C, 2026-10-04): each 100 ms sample >= threshold increments the counter, any sample below sets it to 0 -> only uninterrupted current trips (C). Release after the hold time while not discharging; after 3 trips (retry counter) release additionally needs a load/wake flag (L).

## Low-charge cap (B:1FD82..1FD9C, read 2026-10-04; analysis only, nothing built)
* Code (C): `SOC < 20`: if `SOC > 10` cap = 493 - 22 x (20 - SOC) (`movs r0,#0xFF; adds r0,#0xEE` at file 0x1FD96/98, `movs r0,#0x16` for 22, `cmp #0x14` for 20); else the cap stays at the earlier value 274. env_applied = min(env_target, cap). SOC comes from the BMS (object 0x44).
* Because 493 is below V8's 600, **below 20 % V8 behaves exactly like stock**; above 20 % it has +22 % current. Result: a **step at 20 -> 19 %**: 22.1 A -> 17.3 A (-22 %), stock only 18.1 -> 17.3 A (-4 %). At 15 %: 14.1 A; at <= 10 %: 10.1 A (about 440 W), same as stock.
* Possible later change (L, not built): replace `movs r0,#0xFF; adds r0,#0xEE` with `movs r0,#0x96; lsls r0,r0,#2` (same size, base 600): ramp 22.1 A at 20 % -> 21.2 A at 19 % -> 18.0 A at 15 % -> floor 10.1 A at <= 10 % (the jump 14.8 -> 10.1 A between 11 and 10 % remains). All currents stay below A's 22 A / 10 s latch. Model loaded pack voltage >= ~42.5 V at 20 %, above the controller's low-voltage warning (~40.1 V, raw 743) and accel-limit (~40.7 V, raw 753). Needs another flash: owner's call.
* Model note: the SOC->OCV table (A's 21-point curve) understates pack voltage near full by ~1.5 V; use the low-charge numbers for ratios, not exact watts.

## Owner ride report, day after the 600 flash (2026-10-04, owner's words and numbers; no screenshot or app amps supplied)
* Verdict: V8 FINAL 600 "works perfectly", clearly more power on altitude gain than before.
* Route 1: about 100 m of elevation gain over 2.2 km; **'Scooter Temperature' maximum 75 C** (owner confirmed 2026-10-04: three dots -> scooter information page; this is a controller temperature, see `04_FEATURE_CHAINS.md` section 10).
* Route 2, final hill: about 10 degrees (owner wrote "10 grad"; degrees vs percent not stated), Sport, about 20 km/h. Power was about **1100 W for the whole climb**, about 90 % of the time above 1000 W, range **1000-1170 W**. No cut-out, no error reported.
* Reading (S): 1.0-1.17 kW is what the 600 cap gives. 22.1 A x 45 V = 1.0 kW and 22.1 A x 53 V = 1.17 kW, so the whole range is explained by current held at the cap while pack voltage moved between about 45 and 53 V (54 V at rest, sagging under load, lower at lower charge). No amps were reported, so the cap itself is not read directly this time.
* Power-latch result (S): a sustained climb at about 1.1 kW did **not** trip A's 22 A / 10 s latch. That fits the code (any 100 ms sample below 22 A resets the counter, and the earlier recording showed readings dipping to 21.4-21.8 A). Climb duration and charge level were not given (**U**), so a much longer climb at low charge is still unproven.
* Temperature: the 75 C is the controller, not the motor (corrected 2026-10-04). Firmware side: the only thermal derate found in B is on a controller-side local temperature (`envelope_protection`, V8 threshold 1020 vs stock 900, units **L**), not on the motor; no motor-winding limit was found in the code (**U**), and the motor's own rating is not known. Context: 1.1 kW electrical is above Xiaomi's 400 W rated figure and near its 1000 W max, so the thing to watch on longer climbs is whether the motor temperature keeps rising past this ride's 75 C.
* Decision (owner, 2026-10-04): **leave the firmware as it is (V8 FINAL 600).** The optional smooth low-charge ramp above is not built.
