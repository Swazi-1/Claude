"""fwkb_lift: per-function pseudo-C lifter (auto-generated reading aid; the disassembly stays authoritative).
Block-local symbolic evaluation, liveness-based spills at block ends, condition recovery from cmp/flag-setters."""
import re, collections
from fwkb_analysis import *
import capstone.arm_const as AC

GP = ["r%d" % k for k in range(13)] + ["lr"]
COND_FLIP = {"eq": "ne", "ne": "eq", "hs": "lo", "cs": "cc", "lo": "hs", "cc": "cs", "hi": "ls", "ls": "hi", "ge": "lt", "lt": "ge", "gt": "le", "le": "gt", "mi": "pl", "pl": "mi", "vs": "vc", "vc": "vs"}
CC_BY_ID = {AC.ARM_CC_EQ: "eq", AC.ARM_CC_NE: "ne", AC.ARM_CC_HS: "hs", AC.ARM_CC_LO: "lo", AC.ARM_CC_MI: "mi", AC.ARM_CC_PL: "pl",
            AC.ARM_CC_VS: "vs", AC.ARM_CC_VC: "vc", AC.ARM_CC_HI: "hi", AC.ARM_CC_LS: "ls", AC.ARM_CC_GE: "ge", AC.ARM_CC_LT: "lt",
            AC.ARM_CC_GT: "gt", AC.ARM_CC_LE: "le"}
M32 = 0xFFFFFFFF


def s32(v):
    v &= M32
    return v - (1 << 32) if v & 0x80000000 else v


class E:
    """expression node"""
    __slots__ = ("kind", "val", "text", "prec", "op", "args")

    def __init__(self, kind, text, prec=100, val=None, op=None, args=()):
        self.kind, self.text, self.prec, self.val, self.op, self.args = kind, text, prec, val, op, args

    def __str__(self):
        return self.text

    def wrap(self, p):
        return "(%s)" % self.text if self.prec < p else self.text


def C(v):
    v &= M32
    if v >= 0xFFFFFF00:
        t = "-%d" % (0x100000000 - v)
    elif v < 10:
        t = "%d" % v
    else:
        t = "0x%X" % v
    return E("c", t, 100 if v < 0xFFFFFF00 else 90, v)


def V(name):
    return E("v", name, 100)


def unop(op, a):
    if a.kind == "c":
        if op == "~":
            return C(~a.val)
        if op == "-":
            return C(-a.val)
    return E("op", "%s%s" % (op, a.wrap(90)), 90, None, op, (a,))


PREC = {"*": 70, "/": 70, "%": 70, "+": 60, "-": 60, "<<": 55, ">>": 55, "<": 50, ">": 50, "<=": 50, ">=": 50, "==": 45, "!=": 45, "&": 40, "^": 38, "|": 36, "&&": 30, "||": 25}


def binop(op, a, b, signed_shift=False):
    # constant folding
    if a.kind == "c" and b.kind == "c":
        x, y = a.val, b.val
        r = None
        if op == "+": r = x + y
        elif op == "-": r = x - y
        elif op == "*": r = x * y
        elif op == "&": r = x & y
        elif op == "|": r = x | y
        elif op == "^": r = x ^ y
        elif op == "<<": r = (x << y) if y < 32 else 0
        elif op == ">>": r = (s32(x) >> min(y, 31)) if signed_shift else (x >> y if y < 32 else 0)
        if r is not None:
            return C(r)
    # identities
    if op in ("+", "|", "^") and b.kind == "c" and b.val == 0:
        return a
    if op in ("+", "|", "^") and a.kind == "c" and a.val == 0:
        return b
    if op == "-" and b.kind == "c" and b.val == 0:
        return a
    if op == "&" and b.kind == "c" and b.val == M32:
        return a
    # bit-field idiom: (x << a) >> b  with b >= a (logical)
    if op == ">>" and not signed_shift and b.kind == "c" and a.kind == "op" and a.op == "<<" and a.args[1].kind == "c"             and a.args[1].val < b.val and not (b.val in (16, 24) and a.args[1].val == b.val):
        sh = b.val - a.args[1].val
        mask = (1 << (32 - b.val)) - 1
        inner = a.args[0]
        r = binop(">>", inner, C(sh)) if sh else inner
        return binop("&", r, C(mask))
    # extension idioms
    if op == ">>" and b.kind == "c" and a.kind == "op" and a.op == "<<" and a.args[1].kind == "c" and a.args[1].val == b.val and b.val in (16, 24):
        inner = a.args[0]
        if signed_shift:
            return E("op", "(s%d)%s" % (32 - b.val, inner.wrap(90)), 90, None, "sext", (inner,))
        return E("op", "(u%d)%s" % (32 - b.val, inner.wrap(90)), 90, None, "zext", (inner,))
    # a + (-c) -> a - c
    if op == "+" and b.kind == "c" and b.val >= 0xFFFFFF00:
        return binop("-", a, C(-s32(b.val)))
    if op == "-" and b.kind == "c" and b.val >= 0xFFFFFF00:
        return binop("+", a, C(-s32(b.val)))
    p = PREC[op]
    text = "%s %s %s" % (a.wrap(p), op, b.wrap(p + 1))
    e = E("op", text, p, None, op, (a, b))
    return e


def ext(kind, a):
    if a.kind == "c":
        v = a.val
        if kind == "u8": return C(v & 0xFF)
        if kind == "u16": return C(v & 0xFFFF)
        if kind == "s8": return C((v & 0xFF) - 0x100 if v & 0x80 else v & 0xFF)
        if kind == "s16": return C((v & 0xFFFF) - 0x10000 if v & 0x8000 else v & 0xFFFF)
    # idempotence
    if a.kind == "op" and a.op in ("zext", "sext") and a.text.startswith("(%s)" % kind):
        return a
    return E("op", "(%s)%s" % (kind, a.wrap(90)), 90, None, "zext" if kind[0] == "u" else "sext", (a,))


class Lifter:
    def __init__(self, an, namer, names):
        self.an = an
        self.d = an.d
        self.core = an.core
        self.img = an.img
        self.data = an.data
        self.namer = namer
        self.names = names
        self.livein = {}      # func entry -> set of arg regs (r0-r3)
        self.retuse = {}      # func entry -> returns value?
        self.tmp = 0

    # ---------- use/def ----------
    def usedef(self, i, f=None, o=None):
        mb = i.mnemonic.split(".")[0]
        try:
            rd, wr = i.regs_access()
        except Exception:
            rd, wr = [], []
        use = {REGN.get(i.reg_name(r), i.reg_name(r)) for r in rd}
        df = {REGN.get(i.reg_name(r), i.reg_name(r)) for r in wr}
        use = {u for u in use if u in GP}
        df = {u for u in df if u in GP}
        if mb in ("bl", "blx"):
            tgt = None
            if i.operands and i.operands[0].type == ARM_OP_IMM:
                tgt = self.core.fo(i.operands[0].imm)
            elif o is not None and o in self.an.resolved_calls:
                tgt = self.an.resolved_calls[o]
            if tgt is not None and tgt in self.livein:
                use = set(self.livein[tgt])
            else:
                use = {"r0", "r1", "r2", "r3"} if True else use
            if i.operands and i.operands[0].type == ARM_OP_REG:
                use.add(REGN.get(i.reg_name(i.operands[0].reg), i.reg_name(i.operands[0].reg)))
            df = {"r0", "r1", "r2", "r3", "r12", "lr"}
        if mb in ("push",):
            df = set()
        if mb in ("pop",) or (mb.startswith("ldm") and any(op.type == ARM_OP_REG and op.reg == ARM_REG_PC for op in i.operands)):
            use = set()
        if is_cond(i) and mb not in ("b", "bx", "cbz", "cbnz"):
            use |= df
        return use, df

    # ---------- blocks ----------
    def split_blocks(self, f):
        d = self.d
        offs = sorted(f.blocks)
        leaders = {f.entry}
        for o in offs:
            for s in d.block_targets.get(o, ()):
                pass
        for t, srcs in d.block_targets.items():
            if t in f.blocks:
                leaders.add(t)
        for o in offs:
            k = d.kind.get(o)
            if k in ("b", "bcc", "ret", "ijmp", "tbl", "switch8", "stop"):
                nxt = o + d.instr[o]
                if nxt in f.blocks:
                    leaders.add(nxt)
        blocks = []
        cur = None
        for o in offs:
            if o in leaders or cur is None or (cur and cur[-1] + d.instr[cur[-1]] != o):
                cur = [o]
                blocks.append(cur)
            else:
                cur.append(o)
        return blocks

    def liveness(self, f, blocks):
        d = self.d
        bidx = {b[0]: n for n, b in enumerate(blocks)}
        blk_of = {}
        for n, b in enumerate(blocks):
            for o in b:
                blk_of[o] = n
        use_b, def_b = [], []
        succ_b = []
        for b in blocks:
            u, df = set(), set()
            for o in b:
                i = self.img.dec(o)
                ui, di = self.usedef(i, f, o)
                u |= (ui - df)
                df |= di
            use_b.append(u)
            def_b.append(df)
            last = b[-1]
            ss = set()
            for s in d.succ.get(last, ()):
                if s in blk_of and s in bidx:
                    ss.add(bidx[s])
                elif s in blk_of:
                    ss.add(blk_of[s])
            k = d.kind.get(last)
            if k in ("seq", "bl", "blx"):
                nxt = last + d.instr[last]
                if nxt in bidx:
                    ss.add(bidx[nxt])
            succ_b.append(ss)
        live_in = [set() for _ in blocks]
        live_out = [set() for _ in blocks]
        changed = True
        while changed:
            changed = False
            for n in range(len(blocks) - 1, -1, -1):
                lo = set()
                last = blocks[n][-1]
                k = d.kind.get(last)
                if k == "ret":
                    lo |= {"r0"}                # return value (r0 only)
                elif k in ("b", "ijmp") and not succ_b[n]:
                    lo |= {"r0", "r1", "r2", "r3"}  # tail call: argument registers
                for s in succ_b[n]:
                    lo |= live_in[s]
                li = use_b[n] | (lo - def_b[n])
                if lo != live_out[n] or li != live_in[n]:
                    live_out[n], live_in[n] = lo, li
                    changed = True
        return bidx, succ_b, live_in, live_out, blk_of

    def compute_livein_all(self, order):
        """arg registers = live-in r0..r3 at function entry"""
        for _ in range(3):
            for e in order:
                f = self.an.funcs[e]
                blocks = self.split_blocks(f)
                if not blocks:
                    continue
                bidx, succ_b, li, lo, blk_of = self.liveness(f, blocks)
                ent = blocks[0]
                self.livein[e] = {r for r in li[bidx[f.entry]] if r in ("r0", "r1", "r2", "r3")}

    # ---------- naming ----------
    def mem_text(self, kind, addr_e, width, signed):
        suffix = {(1, False): "b", (1, True): "sb", (2, False): "h", (2, True): "sh", (4, False): "w", (4, True): "w", (8, False): "d", (8, True): "d"}[(width, signed)]
        if addr_e.kind == "c":
            a = addr_e.val
            rg = region_of(self.core, a)
            if rg == "RAM":
                r_ = self.namer.ram_name(a)
                off = a - 0x20000000
                if r_ and r_[2]:
                    nm = r_[2] if a == r_[0] else "%s+0x%X" % (r_[2], a - r_[0])
                    return "%s.%s" % (nm, suffix)
                return "ram[0x%X].%s" % (off, suffix)
            if rg == "PERIPH":
                pn = self.namer.per_name(a)
                return "%s.%s" % (pn if pn else "reg[0x%08X]" % a, suffix)
            return "mem[0x%X].%s" % (a, suffix)
        return "*(%s)(%s)" % ({"b": "u8", "sb": "s8", "h": "u16", "sh": "s16", "w": "u32", "d": "u64"}[suffix], addr_e.text)

    def const_text(self, v):
        """constant used as value: name addresses"""
        rg = region_of(self.core, v)
        if rg == "RAM":
            r_ = self.namer.ram_name(v)
            if r_ and r_[2]:
                return "&%s%s" % (r_[2], "" if v == r_[0] else "+0x%X" % (v - r_[0]))
            return "&ram[0x%X]" % (v - 0x20000000)
        if rg == "PERIPH":
            pn = self.namer.per_name(v)
            if pn:
                return "&%s" % pn
            return "0x%08X" % v
        if rg == "FLASH" and (v & 1):
            fo = self.core.fo(v & ~1)
            if self.core.in_code(fo) and fo in self.an.funcs:
                return "&%s" % self.an.fname(fo)
        if rg == "FLASH" and not (v & 1) and self.core.name == "A" and 0x08003000 <= v < 0x0801B224:
            return "&rom[0x%X]" % self.core.fo(v)
        return None

    def new_tmp(self):
        self.tmp += 1
        return "t%d" % self.tmp

    def fn_label(self, fo):
        nm = self.names.get(fo)
        base = "%s:%X" % (self.core.name, fo)
        return base + ("<%s>" % nm if nm else "")

    # ---------- lift one function ----------
    def lift(self, f):
        d, core = self.d, self.core
        self.tmp = 0
        blocks = self.split_blocks(f)
        bidx, succ_b, live_in, live_out, blk_of = self.liveness(f, blocks)
        preds = collections.defaultdict(set)
        for n, ss in enumerate(succ_b):
            for s in ss:
                preds[s].add(n)
        label_needed = set()
        for t, srcs in d.block_targets.items():
            if t in f.blocks:
                label_needed.add(t)
        sm = getattr(self.an, "state_in_map", {}).get(f.entry, {})
        self.cins = [dict(sm.get(b[0], {})) for b in blocks]
        out = []
        argregs = sorted(self.livein.get(f.entry, set()))
        nm = self.names.get(f.entry)
        out.append("fn %s(%s) {" % (self.fn_label(f.entry), ", ".join(argregs)))
        for n, b in enumerate(blocks):
            first = b[0]
            if first in label_needed or n == 0 and False:
                out.append(" L%X:" % first)
            elif first != f.entry and (len(preds[n]) != 1 or True) and first in d.block_targets:
                out.append(" L%X:" % first)
            self._lift_block(f, b, n, blocks, bidx, succ_b, live_in, live_out, out)
        out.append("}")
        return out

    def _flags_text(self, flags, cc):
        if flags is None:
            return "cc.%s" % cc
        kind, a, b = flags
        sa, sb_ = a.text, b.text
        def cmp_(op, signed):
            if signed:
                return "%s %s %s" % (("(s32)" + a.wrap(90)) if a.kind != "c" else a.text, op, ("(s32)" + b.wrap(90)) if b.kind != "c" else b.text)
            return "%s %s %s" % (a.wrap(50), op, b.wrap(51))
        if kind == "res":
            e = a
            if cc in ("mi", "pl") and e.kind == "op" and e.op == "<<" and e.args[1].kind == "c" and 0 < e.args[1].val < 32:
                bit = 31 - e.args[1].val
                inner = e.args[0]
                return "%sbit%d(%s)" % ("" if cc == "mi" else "!", bit, inner.text)
            m = {"eq": "%s == 0", "ne": "%s != 0", "mi": "(s32)%s < 0", "pl": "(s32)%s >= 0", "gt": "(s32)%s > 0", "ge": "(s32)%s >= 0", "lt": "(s32)%s < 0", "le": "(s32)%s <= 0"}
            if cc in m:
                return m[cc] % e.wrap(90)
            return "%s [cc.%s]" % (e.text, cc)
        # cmp a,b
        if cc == "eq": return "%s == %s" % (a.wrap(45), b.wrap(46))
        if cc == "ne": return "%s != %s" % (a.wrap(45), b.wrap(46))
        if cc in ("hs", "cs"): return "u%s >= u%s" % (a.wrap(90), b.wrap(90)) if a.kind != "c" and b.kind != "c" else "%s >= %s" % (a.wrap(50), b.wrap(51))
        if cc in ("lo", "cc"): return "u%s < u%s" % (a.wrap(90), b.wrap(90)) if a.kind != "c" and b.kind != "c" else "%s < %s" % (a.wrap(50), b.wrap(51))
        if cc == "hi": return "u%s > u%s" % (a.wrap(90), b.wrap(90)) if a.kind != "c" and b.kind != "c" else "%s > %s" % (a.wrap(50), b.wrap(51))
        if cc == "ls": return "u%s <= u%s" % (a.wrap(90), b.wrap(90)) if a.kind != "c" and b.kind != "c" else "%s <= %s" % (a.wrap(50), b.wrap(51))
        if cc == "ge": return "(s32)%s >= %s" % (a.wrap(90), b.text if b.kind == "c" and b.val < 0x80000000 else "(s32)" + b.wrap(90))
        if cc == "lt": return "(s32)%s < %s" % (a.wrap(90), b.text if b.kind == "c" and b.val < 0x80000000 else "(s32)" + b.wrap(90))
        if cc == "gt": return "(s32)%s > %s" % (a.wrap(90), b.text if b.kind == "c" and b.val < 0x80000000 else "(s32)" + b.wrap(90))
        if cc == "le": return "(s32)%s <= %s" % (a.wrap(90), b.text if b.kind == "c" and b.val < 0x80000000 else "(s32)" + b.wrap(90))
        if cc == "mi": return "(s32)(%s - %s) < 0" % (a.text, b.text)
        if cc == "pl": return "(s32)(%s - %s) >= 0" % (a.text, b.text)
        return "cmp(%s,%s) [cc.%s]" % (a.text, b.text, cc)

    def _lift_block(self, f, b, n, blocks, bidx, succ_b, live_in, live_out, out):
        d, core = self.d, self.core
        st = {r: V(r) for r in GP}
        for r_, v_ in self.cins[n].items():
            if r_ in st:
                st[r_] = C(v_)
        flags = None
        # entry flag import if block begins with a flag consumer
        i0 = self.img.dec(b[0])
        first_consumer = False
        for o in b:
            i = self.img.dec(o)
            mb = i.mnemonic.split(".")[0]
            if i.update_flags or mb in ("cmp", "cmn", "tst", "teq"):
                break
            if is_cond(i):
                first_consumer = True
                break
        if first_consumer:
            flags = ("cmp", V("fa"), V("fb"))
        sp = {"off": 0}
        for r in ("sp",):
            pass
        stmts = []
        emit = stmts.append
        cond_it = None

        def reg_expr(i, op):
            if op.type == ARM_OP_IMM:
                return C(op.imm)
            if op.type == ARM_OP_REG:
                r = rn(i, op.reg)
                if r == "pc":
                    return C(core.rt(self.cur) + 4)
                if r == "sp":
                    return E("v", "sp%+d" % sp["off"] if sp["off"] else "sp", 60)
                return st.get(r, V(r))
            return V("?")

        def shifted(i, op, e):
            try:
                sh = op.shift
            except Exception:
                return e
            if sh.type == 0:
                return e
            t, nn = sh.type, sh.value
            if t == AC.ARM_SFT_LSL:
                return binop("<<", e, C(nn))
            if t == AC.ARM_SFT_LSR:
                return binop(">>", e, C(nn))
            if t == AC.ARM_SFT_ASR:
                return binop(">>", e, C(nn), signed_shift=True)
            if t == AC.ARM_SFT_ROR:
                return E("op", "ror(%s,%d)" % (e.text, nn), 100)
            return e

        def materialize(r):
            """write register's symbolic value into its variable (hazard-safe)"""
            nonlocal flags
            e = st[r]
            if e.kind == "v" and e.text == r:
                return
            # protect other expressions referencing variable r
            pat = re.compile(r"\b%s\b" % r)
            if any(pat.search(x.text) for k2, x in st.items() if k2 != r) or (flags and (pat.search(flags[1].text) or pat.search(flags[2].text))):
                t = self.new_tmp()
                emit("%s = %s;" % (t, r))
                for k2, x in list(st.items()):
                    if k2 != r and pat.search(x.text):
                        st[k2] = E(x.kind, pat.sub(t, x.text), x.prec, x.val, x.op, x.args)
                if flags:
                    flags = (flags[0], E(flags[1].kind, pat.sub(t, flags[1].text), flags[1].prec, flags[1].val), E(flags[2].kind, pat.sub(t, flags[2].text), flags[2].prec, flags[2].val))
            emit("%s = %s;" % (r, e.text))
            st[r] = V(r)

        def spill_all(live):
            """parallel assignment of live registers whose symbolic value is not their own variable"""
            todo = [(r, st[r]) for r in GP if r in live and not (st[r].kind == "v" and st[r].text == r)]
            if not todo:
                return
            dests = {r for r, _ in todo}
            pats = {r: re.compile(r"\b%s\b" % r) for r in dests}
            assigns = []
            for r, e in todo:
                refs = [q for q in dests if q != r and pats[q].search(e.text)]
                if refs:
                    t = self.new_tmp()
                    emit("%s = %s;" % (t, e.text))
                    assigns.append((r, t))
                else:
                    assigns.append((r, e.text))
            for r, txt in assigns:
                emit("%s = %s;" % (r, txt))
                st[r] = V(r)

        def load(i, o, w, signed, addr_e, dest, extra=None):
            tn = self.new_tmp()
            emit("%s = %s;" % (tn, self.mem_text("R", addr_e, w, signed)))
            st[dest] = V(tn)

        def addr_of(i, memop):
            base = memop.mem.base
            br = rn(i, base) if base else None
            if br == "pc":
                pc = (core.rt(self.cur) + 4) & ~3
                return C(pc + memop.mem.disp)
            if br == "sp":
                return ("stk", sp["off"] + memop.mem.disp)
            be = st.get(br, V(br)) if br else C(0)
            if memop.mem.index:
                ie = st.get(rn(i, memop.mem.index), V(rn(i, memop.mem.index)))
                if memop.mem.lshift:
                    ie = binop("<<", ie, C(memop.mem.lshift))
                if memop.subtracted:
                    be = binop("-", be, ie)
                else:
                    be = binop("+", be, ie)
            if memop.mem.disp:
                be = binop("+", be, C(memop.mem.disp))
            return be

        def ctext(e):
            return e.text

        def val_for_use(e):
            if e.kind == "c":
                t = self.const_text(e.val)
                if t:
                    return E("c", t, 100, e.val)
            return e

        last_kind = None
        for oi, o in enumerate(b):
            self.cur = o
            i = self.img.dec(o)
            m = i.mnemonic
            mb = m.split(".")[0]
            ops = i.operands
            cond = is_cond(i)
            cc = CC_BY_ID.get(i.cc) if cond else None
            is_last = (oi == len(b) - 1)

            def setreg(r, e):
                if r in ("sp", "pc"):
                    return
                if len(e.text) > 96 and e.kind != "c" and not cond:
                    tn = self.new_tmp()
                    emit("%s = %s;" % (tn, e.text))
                    e = V(tn)
                if cond and mb not in ("b",):
                    materialize(r)
                    emit("if (%s) %s = %s;" % (self._flags_text(flags, cc), r, e.text))
                    return
                st[r] = e

            def setflags(kind, a, bb=None):
                nonlocal flags
                flags = (kind, a, bb if bb is not None else C(0))

            # ---- branches ----
            if mb == "b" or (len(mb) == 3 and mb[0] == "b" and mb[1:] in CC_NAMES):
                tgt = core.fo(ops[0].imm)
                lbl = "L%X" % tgt
                if tgt in self.an.funcs and tgt != f.entry and tgt not in f.blocks:
                    # tail call
                    args = ", ".join(st[r].text for r in sorted(self.livein.get(tgt, ())))
                    if mb == "b" and not cond:
                        emit("return %s(%s);  // tail call" % (self.fn_label(tgt), args))
                    else:
                        c = self._flags_text(flags, mb[1:] if mb != "b" else cc)
                        t_ = self.new_tmp()
                        emit("%s = (%s);" % (t_, c))
                        emit("if (%s) return %s(%s);  // tail call" % (t_, self.fn_label(tgt), args))
                        spill_all(self._need_live(n, succ_b, live_in))
                        nxt_n = n + 1
                        if nxt_n < len(blocks) and flags is not None:
                            self._export_flags(flags, blocks[nxt_n], emit)
                    last_kind = "tail"
                    continue
                succs = succ_b[n]
                live = self._need_live(n, succ_b, live_in)
                if mb == "b" and not cond:
                    spill_all(live)
                    emit("goto %s;" % lbl)
                else:
                    ccn = mb[1:] if mb != "b" else cc
                    c = self._flags_text(flags, ccn)
                    # protect cond from spill hazards
                    dests = [r for r in GP if r in live and not (st[r].kind == "v" and st[r].text == r)]
                    if dests and any(re.search(r"\b%s\b" % r, c) for r in dests):
                        t = self.new_tmp()
                        emit("%s = (%s);" % (t, c))
                        c = t
                    # export flags if successors begin with consumers
                    spill_all(live)
                    emit("if (%s) goto %s;" % (c, lbl))
                    # flag export for fall-through consumer
                    nxt_n = n + 1
                    if nxt_n < len(blocks) and flags is not None:
                        self._export_flags(flags, blocks[nxt_n], emit)
                    elif flags is not None:
                        pass
                last_kind = "b"
                continue
            if mb in ("cbz", "cbnz"):
                tgt = core.fo(ops[1].imm)
                e = reg_expr(i, ops[0])
                succs = succ_b[n]
                live = self._need_live(n, succ_b, live_in)
                c = "%s %s 0" % (e.wrap(45), "==" if mb == "cbz" else "!=")
                dests = [r for r in GP if r in live and not (st[r].kind == "v" and st[r].text == r)]
                if dests and any(re.search(r"\b%s\b" % r, c) for r in dests):
                    t = self.new_tmp()
                    emit("%s = (%s);" % (t, c))
                    c = t
                spill_all(live)
                emit("if (%s) goto L%X;" % (c, tgt))
                last_kind = "b"
                continue
            if mb == "bl" or mb == "blx":
                tgt = None
                if ops and ops[0].type == ARM_OP_IMM:
                    tgt = core.fo(ops[0].imm)
                elif o in self.an.resolved_calls:
                    tgt = self.an.resolved_calls[o]
                if tgt is not None and self.d.switch8 is not None and tgt == self.d.switch8:
                    jt = next((j for j in d.jump_tables if j["site"] == o), None)
                    idx = st["r3"]
                    emit("switch (%s) {  // switch8" % idx.text)
                    if jt:
                        for k, t in enumerate(jt["targets"]):
                            lab = "default" if k == len(jt["targets"]) - 1 else "case %d" % k
                            emit("  %s: goto L%X;" % (lab, t))
                    emit("}")
                    spill_live = set()
                    for s in succ_b[n]:
                        spill_live |= live_in[s]
                    last_kind = "switch"
                    continue
                if tgt is not None:
                    label = self.fn_label(tgt)
                    regs = sorted(self.livein.get(tgt, set()))
                    if tgt not in self.livein:
                        regs = ["r0", "r1", "r2", "r3"]
                        # show only assigned ones
                        regs = [r for r in regs if not (st[r].kind == "v" and st[r].text == r)]
                else:
                    label = "(*%s)" % reg_expr(i, ops[0]).text
                    regs = [r for r in ("r0", "r1", "r2", "r3") if not (st[r].kind == "v" and st[r].text == r)]
                args = ", ".join(val_for_use(st[r]).text for r in regs)
                # is r0 live after?
                live_after = self._live_after(b, oi, live_out[n], f)
                if "r0" in live_after:
                    t = self.new_tmp()
                    emit("%s = %s(%s);" % (t, label, args))
                    st["r0"] = V(t)
                else:
                    emit("%s(%s);" % (label, args))
                    st["r0"] = V("r0_undef")
                if "r1" in live_after:
                    t = self.new_tmp()
                    emit("%s = r1_after_call;" % t)
                    st["r1"] = V(t)
                else:
                    st["r1"] = V("r1_undef")
                st["r2"] = V("r2_undef"); st["r3"] = V("r3_undef"); st["r12"] = V("r12_undef"); st["lr"] = V("lr")
                flags = None
                continue
            if mb == "bx" and ops[0].type == ARM_OP_REG:
                r = rn(i, ops[0].reg)
                if r == "lr":
                    if cond:
                        emit("if (%s) return %s;" % (self._flags_text(flags, cc), st["r0"].text))
                    else:
                        emit("return %s;" % st["r0"].text)
                else:
                    emit("goto *%s;  // indirect jump" % st.get(r, V(r)).text)
                last_kind = "ret"
                continue
            if mb in ("pop",) or (mb.startswith("ldm") and any(op.type == ARM_OP_REG and op.reg == ARM_REG_PC for op in ops) and rn(i, ops[0].reg) == "sp"):
                regs = [rn(i, op.reg) for op in ops if op.type == ARM_OP_REG]
                sp["off"] += 4 * len(regs)
                for r in regs:
                    if r != "pc":
                        st[r] = V("pop_" + r)
                if "pc" in regs:
                    if cond:
                        emit("if (%s) return %s;" % (self._flags_text(flags, cc), st["r0"].text))
                    else:
                        emit("return %s;" % st["r0"].text)
                    last_kind = "ret"
                continue
            if mb == "ldr" and ops and ops[0].type == ARM_OP_REG and ops[0].reg == ARM_REG_PC:
                # ldr pc,[sp],#n return
                emit("return %s;" % st["r0"].text)
                last_kind = "ret"
                continue
            if mb == "push":
                regs = [rn(i, op.reg) for op in ops if op.type == ARM_OP_REG]
                sp["off"] -= 4 * len(regs)
                continue
            if mb in ("tbb", "tbh"):
                jt = next((j for j in d.jump_tables if j["site"] == o), None)
                idx = None
                for op in ops:
                    if op.type == ARM_OP_MEM and op.mem.index:
                        idx = st.get(rn(i, op.mem.index), V("?"))
                emit("switch (%s) {  // %s" % (idx.text if idx else "?", mb))
                if jt:
                    for k, t in enumerate(jt["targets"]):
                        emit("  case %d: goto L%X;" % (k, t))
                emit("}")
                last_kind = "switch"
                continue
            if mb == "it" or mb in ("ite", "itt", "itte", "itee", "ittt", "itet", "itete", "ittee", "iteee", "itttt"):
                continue
            if mb in ("nop", "dsb", "isb", "dmb"):
                if mb != "nop":
                    emit("__%s();" % mb)
                continue
            if mb in ("wfi", "wfe", "sev", "cpsid", "cpsie", "bkpt", "udf", "svc"):
                emit("__asm(%s);" % (m + " " + i.op_str).strip())
                continue
            if mb in ("mrs", "msr"):
                emit("__asm(%s %s);" % (m, i.op_str))
                if mb == "mrs":
                    st[rn(i, ops[0].reg)] = V("sysreg")
                continue
            # ---- data movement / ALU ----
            if mb in ("mov", "movs", "movw"):
                dst = rn(i, ops[0].reg)
                e = reg_expr(i, ops[1])
                if ops[1].type == ARM_OP_REG:
                    e = shifted(i, ops[1], e)
                if dst == "sp":
                    continue
                setreg(dst, e)
                if mb == "movs" and not cond:
                    setflags("res", e)
                continue
            if mb == "mvn" or mb == "mvns":
                dst = rn(i, ops[0].reg)
                e = unop("~", reg_expr(i, ops[1]))
                setreg(dst, e)
                if mb == "mvns":
                    setflags("res", e)
                continue
            if mb == "movt":
                dst = rn(i, ops[0].reg)
                old = st[dst]
                if old.kind == "c":
                    setreg(dst, C((old.val & 0xFFFF) | (ops[1].imm << 16)))
                else:
                    setreg(dst, binop("|", binop("&", old, C(0xFFFF)), C(ops[1].imm << 16)))
                continue
            if mb in ("add", "adds", "addw", "sub", "subs", "subw", "rsb", "rsbs", "and", "ands", "orr", "orrs", "eor", "eors", "bic", "bics", "orn",
                      "lsl", "lsls", "lsr", "lsrs", "asr", "asrs", "ror", "rors", "mul", "muls", "adc", "adcs", "sbc", "sbcs"):
                dst = rn(i, ops[0].reg)
                if len(ops) == 2:
                    a = reg_expr(i, ops[0]) if ops[0].type == ARM_OP_REG else C(0)
                    bo = ops[1]
                else:
                    a = reg_expr(i, ops[1])
                    bo = ops[2]
                bv = reg_expr(i, bo)
                if bo.type == ARM_OP_REG:
                    bv = shifted(i, bo, bv)
                base = mb
                for suf in ("s", "w"):
                    if base.endswith(suf) and base[:-1] in ("add", "sub", "rsb", "and", "orr", "eor", "bic", "lsl", "lsr", "asr", "ror", "mul", "adc", "sbc"):
                        base = base[:-1]
                if dst == "sp":
                    if base == "sub" and bo.type == ARM_OP_IMM:
                        sp["off"] -= bo.imm
                    elif base == "add" and bo.type == ARM_OP_IMM:
                        sp["off"] += bo.imm
                    continue
                if len(ops) >= 2 and ops[1].type == ARM_OP_REG and rn(i, ops[1].reg) == "sp" and base == "add":
                    # address of local
                    off = sp["off"] + (bv.val if bv.kind == "c" else 0)
                    e = E("v", "&stk[%+d]" % off, 90)
                    setreg(dst, e)
                    continue
                if base == "add": e = binop("+", a, bv)
                elif base == "sub": e = binop("-", a, bv)
                elif base == "rsb": e = binop("-", bv, a)
                elif base == "and": e = binop("&", a, bv)
                elif base == "orr": e = binop("|", a, bv)
                elif base == "eor": e = binop("^", a, bv)
                elif base == "bic": e = binop("&", a, unop("~", bv))
                elif base == "orn": e = binop("|", a, unop("~", bv))
                elif base == "lsl": e = binop("<<", a, bv)
                elif base == "lsr": e = binop(">>", a, bv)
                elif base == "asr": e = binop(">>", a, bv, signed_shift=True)
                elif base == "ror": e = E("op", "ror(%s,%s)" % (a.text, bv.text), 100)
                elif base == "mul": e = binop("*", a, bv)
                elif base in ("adc", "sbc"):
                    e = E("op", "%s_c(%s,%s)" % (base, a.text, bv.text), 100)
                else:
                    e = V("?")
                setreg(dst, e)
                if (mb.endswith("s") and mb not in ("adds_",) and base not in ()) and i.update_flags and not cond:
                    setflags("res", e)
                continue
            if mb in ("cmp", "cmn", "tst", "teq"):
                a = reg_expr(i, ops[0])
                bv = reg_expr(i, ops[1])
                if ops[1].type == ARM_OP_REG:
                    bv = shifted(i, ops[1], bv)
                if mb == "cmp":
                    flags = ("cmp", a, bv)
                elif mb == "cmn":
                    flags = ("res", binop("+", a, bv), C(0))
                elif mb == "tst":
                    flags = ("res", binop("&", a, bv), C(0))
                else:
                    flags = ("res", binop("^", a, bv), C(0))
                continue
            if mb in ("uxtb", "uxth", "sxtb", "sxth"):
                dst = rn(i, ops[0].reg)
                e = reg_expr(i, ops[1])
                setreg(dst, ext({"uxtb": "u8", "uxth": "u16", "sxtb": "s8", "sxth": "s16"}[mb], e))
                continue
            if mb == "ubfx":
                dst = rn(i, ops[0].reg)
                e = reg_expr(i, ops[1])
                lsb, wd = ops[2].imm, ops[3].imm
                v = binop(">>", e, C(lsb))
                v = binop("&", v, C((1 << wd) - 1))
                setreg(dst, v)
                continue
            if mb == "sbfx":
                dst = rn(i, ops[0].reg)
                e = reg_expr(i, ops[1])
                setreg(dst, E("op", "sbfx(%s,%d,%d)" % (e.text, ops[2].imm, ops[3].imm), 100))
                continue
            if mb == "bfi":
                dst = rn(i, ops[0].reg)
                e = reg_expr(i, ops[1])
                lsb, wd = ops[2].imm, ops[3].imm
                mask = ((1 << wd) - 1) << lsb
                old = st[dst]
                new = binop("|", binop("&", old, C(~mask)), binop("&", binop("<<", e, C(lsb)), C(mask)))
                setreg(dst, new)
                continue
            if mb == "bfc":
                dst = rn(i, ops[0].reg)
                lsb, wd = ops[1].imm, ops[2].imm
                setreg(dst, binop("&", st[dst], C(~(((1 << wd) - 1) << lsb))))
                continue
            if mb in ("udiv", "sdiv"):
                dst = rn(i, ops[0].reg)
                a, bv = reg_expr(i, ops[1]), reg_expr(i, ops[2])
                if mb == "sdiv":
                    e = E("op", "(s32)%s / (s32)%s" % (a.wrap(90), bv.wrap(90)), 70)
                else:
                    e = E("op", "%s / %s" % (a.wrap(70), bv.wrap(71)), 70)
                setreg(dst, e)
                continue
            if mb in ("mla", "mls"):
                dst = rn(i, ops[0].reg)
                a, bv, c_ = reg_expr(i, ops[1]), reg_expr(i, ops[2]), reg_expr(i, ops[3])
                prod = binop("*", a, bv)
                setreg(dst, binop("+", c_, prod) if mb == "mla" else binop("-", c_, prod))
                continue
            if mb == "smulbb":
                dst = rn(i, ops[0].reg)
                a, bv = reg_expr(i, ops[1]), reg_expr(i, ops[2])
                setreg(dst, E("op", "(s16)%s * (s16)%s" % (a.wrap(90), bv.wrap(90)), 70))
                continue
            if mb in ("clz", "rev", "rev16", "rbit"):
                dst = rn(i, ops[0].reg)
                setreg(dst, E("op", "%s(%s)" % (mb, reg_expr(i, ops[1]).text), 100))
                continue
            if mb == "adr":
                dst = rn(i, ops[0].reg)
                pc = (core.rt(o) + 4) & ~3
                setreg(dst, C(pc + ops[1].imm))
                continue
            # ---- loads / stores ----
            if mb in ("ldr", "ldrb", "ldrh", "ldrsb", "ldrsh") or mb in ("str", "strb", "strh"):
                memop = next(op for op in ops if op.type == ARM_OP_MEM)
                w = 1 if mb.endswith("b") else 2 if mb.endswith("h") else 4
                if mb in ("ldrsb",): w = 1
                if mb in ("ldrsh",): w = 2
                signed = mb in ("ldrsb", "ldrsh")
                ad = addr_of(i, memop)
                is_ld = mb.startswith("ldr")
                dest = rn(i, ops[0].reg)
                # post-indexed immediate form
                post_imm = None
                if i.writeback and not memop.mem.disp:
                    for op in ops:
                        if op.type == ARM_OP_IMM:
                            post_imm = op.imm
                if isinstance(ad, tuple):
                    ref = "stk[%+d]" % ad[1]
                    if is_ld:
                        tn = self.new_tmp()
                        emit("%s = %s;" % (tn, ref) if not cond else "if (%s) %s = %s;" % (self._flags_text(flags, cc), tn, ref))
                        st[dest] = V(tn)
                    else:
                        emit("%s = %s;" % (ref, reg_expr(i, ops[0]).text))
                    continue
                if memop.mem.base and rn(i, memop.mem.base) == "pc" and is_ld:
                    # literal
                    pc_ea = ad.val
                    fo = core.fo(pc_ea)
                    v = u32(self.data, fo) if 0 <= fo <= len(self.data) - 4 else 0
                    if w == 4:
                        setreg(dest, C(v))
                    else:
                        setreg(dest, C(v))
                    continue
                if cond:
                    materialize(dest) if is_ld else None
                if is_ld:
                    tn = self.new_tmp()
                    rd_txt = self.mem_text("R", ad, w, signed)
                    if cond:
                        emit("if (%s) %s = %s;" % (self._flags_text(flags, cc), dest, rd_txt))
                        st[dest] = V(dest)
                    else:
                        emit("%s = %s;" % (tn, rd_txt))
                        st[dest] = V(tn)
                else:
                    sv = val_for_use(reg_expr(i, ops[0]))
                    txt = "%s = %s;" % (self.mem_text("W", ad, w, False), sv.text)
                    if cond:
                        txt = "if (%s) %s" % (self._flags_text(flags, cc), txt)
                    emit(txt)
                if i.writeback:
                    br = rn(i, memop.mem.base)
                    if post_imm is not None:
                        st[br] = binop("+", st[br], C(post_imm))
                    elif memop.mem.disp:
                        st[br] = ad
                continue
            if mb in ("ldrd", "strd"):
                memop = next(op for op in ops if op.type == ARM_OP_MEM)
                ad = addr_of(i, memop)
                r1_, r2_ = rn(i, ops[0].reg), rn(i, ops[1].reg)
                if isinstance(ad, tuple):
                    for k, r in enumerate((r1_, r2_)):
                        ref = "stk[%+d]" % (ad[1] + 4 * k)
                        if mb == "ldrd":
                            tn = self.new_tmp(); emit("%s = %s;" % (tn, ref)); st[r] = V(tn)
                        else:
                            emit("%s = %s;" % (ref, st[r].text))
                    continue
                for k, r in enumerate((r1_, r2_)):
                    a2 = binop("+", ad, C(4 * k)) if k else ad
                    if mb == "ldrd":
                        tn = self.new_tmp(); emit("%s = %s;" % (tn, self.mem_text("R", a2, 4, False))); st[r] = V(tn)
                    else:
                        emit("%s = %s;" % (self.mem_text("W", a2, 4, False), val_for_use(st[r]).text))
                continue
            if mb.startswith(("ldm", "stm")):
                base = rn(i, ops[0].reg)
                regs = [rn(i, op.reg) for op in ops[1:] if op.type == ARM_OP_REG]
                be = st[base] if base != "sp" else None
                for k, r in enumerate(regs):
                    if base == "sp":
                        ref = "stk[%+d]" % (sp["off"] + 4 * k)
                        if mb.startswith("ldm"):
                            tn = self.new_tmp(); emit("%s = %s;" % (tn, ref)); st[r] = V(tn)
                        else:
                            emit("%s = %s;" % (ref, st[r].text))
                    else:
                        a2 = binop("+", be, C(4 * k)) if k else be
                        if mb.startswith("ldm"):
                            tn = self.new_tmp(); emit("%s = %s;" % (tn, self.mem_text("R", a2, 4, False))); st[r] = V(tn)
                        else:
                            emit("%s = %s;" % (self.mem_text("W", a2, 4, False), val_for_use(st[r]).text))
                if i.writeback and base != "sp":
                    st[base] = binop("+", be, C(4 * len(regs)))
                continue
            if mb.startswith("v"):
                emit("__fpu(%s %s);" % (m, i.op_str))
                continue
            emit("__asm(%s %s);" % (m, i.op_str))
            try:
                _, wr = i.regs_access()
                for r in wr:
                    nm_ = REGN.get(i.reg_name(r), i.reg_name(r))
                    if nm_ in GP:
                        st[nm_] = V("unk_" + nm_)
            except Exception:
                pass
        # block end handling
        last_off = b[-1]
        k = d.kind.get(last_off)
        if last_kind in (None,) or k in ("seq", "bl", "blx"):
            live = self._need_live(n, succ_b, live_in)
            spill_all(live)
            nxt_n = n + 1
            if nxt_n < len(blocks) and flags is not None:
                self._export_flags(flags, blocks[nxt_n], emit)
            if nxt_n < len(blocks) and blocks[nxt_n][0] not in d.block_targets and False:
                pass
        for s in stmts:
            out.append("   " + s)

    def _need_live(self, n, succ_b, live_in):
        live = set()
        for s in succ_b[n]:
            live |= {r for r in live_in[s] if r not in self.cins[s]}
        return live

    def _export_flags(self, flags, next_block, emit):
        # does the next block start with a flag consumer?
        for o in next_block:
            i = self.img.dec(o)
            mb = i.mnemonic.split(".")[0]
            if i.update_flags or mb in ("cmp", "cmn", "tst", "teq"):
                return
            if is_cond(i) or (len(mb) == 3 and mb[0] == "b" and mb[1:] in CC_NAMES):
                kind, a, b = flags
                emit("fa = %s; fb = %s;" % (a.text, b.text))
                return
            if mb not in ("it", "ite", "itt", "nop"):
                return

    def _live_after(self, b, oi, live_out_b, f):
        live = set(live_out_b)
        for j in range(len(b) - 1, oi, -1):
            i = self.img.dec(b[j])
            u, df = self.usedef(i, f, b[j])
            live = (live - df) | u
        return live
