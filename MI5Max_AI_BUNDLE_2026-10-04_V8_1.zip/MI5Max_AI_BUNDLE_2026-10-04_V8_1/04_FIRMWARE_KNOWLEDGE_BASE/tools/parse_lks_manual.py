import re, csv, collections, os
HERE=os.path.dirname(os.path.abspath(__file__))
txt=open(os.path.join(HERE,"..","data","lks_manual.txt"),encoding="utf-8",errors="ignore").read().split("\n")
hdr=re.compile(r"^\s*(\d+\.\d+\.\d+(?:\.\d+)*)\s+([A-Z][A-Za-z0-9]*_[A-Za-z0-9_]+)")
adr=re.compile(r"0x([0-9A-Fa-f]{4})_([0-9A-Fa-f]{4})")
regs=collections.OrderedDict()
i=0
n=len(txt)
while i<n:
    m=hdr.match(txt[i])
    if m and not re.search(r"\.{5,}",txt[i]):
        name=m.group(2)
        addrs=[]
        for j in range(i+1,min(n,i+14)):
            if hdr.match(txt[j]): break
            for a,b in adr.findall(txt[j]):
                v=int(a+b,16)
                if v not in addrs: addrs.append(v)
            if addrs and j>i+3: break
        if addrs:
            regs.setdefault(name,addrs)
    i+=1
out=[]
for name,addrs in regs.items():
    if ("x" in name.split("_")[0][-1:] or name.endswith("x") or re.search(r"[A-Z]x(_|$)",name)) and len(addrs)>1:
        for k,a in enumerate(addrs):
            nm=re.sub(r"x(?=_|$)",str(k),name,count=1) if re.search(r"x(?=_|$)",name) else name+str(k)
            out.append((a,nm))
    else:
        for k,a in enumerate(addrs):
            out.append((a,name if len(addrs)==1 else name+"_%d"%k))
out.sort()
# dedupe
seen={}
for a,nm in out:
    seen.setdefault(a,nm)
with open(os.path.join(HERE,"..","annotations","periph_B.csv"),"w",newline="",encoding="utf-8") as fp:
    w=csv.writer(fp); w.writerow(["addr","name","desc"])
    for a,nm in sorted(seen.items()):
        w.writerow(["0x%08X"%a,nm,"LKS32MC07x user manual v1.69"])
print(len(seen),"registers")
for a in (0x40010C40,0x40010C38,0x40010C7C,0x40010C60,0x40010CA0,0x40010CA4,0x40010CB0,0x40010C80,0x40010C74,0x40010C50,0x40010510,0x40010408,0x40010300,0x40013024,0x40011700,0x40011100):
    print(hex(a),seen.get(a))
