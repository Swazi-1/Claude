"""bq_dm_decode: decode the BQ769x2 configuration image A writes (data/A_bq_config_image.bin, data-memory 0x9231..0x9350)
against the data-memory table extracted from the TRM text (data/bq76952_trm.txt).  Output: markdown table."""
import re, struct, sys, json
trm = open("../data/bq76952_trm.txt", encoding="utf-8", errors="ignore").read().split("\n")
ent = {}
pat = re.compile(r"(0x9[0-9A-Fa-f]{3})\s+(.+?)\s{2,}(U1|U2|U4|I1|I2|I4|H1|H2|H4|F4|S1)\b(.*)")
for ln in trm:
    m = pat.search(ln)
    if not m:
        continue
    a = int(m.group(1), 16)
    name = re.sub(r"\s+", " ", m.group(2)).strip()
    rest = m.group(4).split()
    ent[a] = (name, m.group(3), rest[:6])

# subclass context for the protection rows (TRM text loses it): address -> corrected name
OVR = {
 0x9275:"CUV Threshold (x50.6 mV)",0x9276:"CUV Delay (x3.3 ms)",0x927B:"CUV Recovery Hysteresis (x50.6 mV)",
 0x9278:"COV Threshold (x50.6 mV)",0x9279:"COV Delay (x3.3 ms)",0x927C:"COV Recovery Hysteresis (x50.6 mV)",
 0x927D:"COVL Latch Limit",0x927E:"COVL Counter Dec Delay (s)",0x927F:"COVL Recovery Time (s)",
 0x9280:"OCC Threshold (x2 mV)",0x9281:"OCC Delay (x3.3 ms)",0x9288:"OCC Recovery Threshold (userA)",0x92B0:"OCC PACK-TOS Delta (10 mV)",
 0x9282:"OCD1 Threshold (x2 mV)",0x9283:"OCD1 Delay (x3.3 ms)",0x9284:"OCD2 Threshold (x2 mV)",0x9285:"OCD2 Delay (x3.3 ms)",
 0x9286:"SCD Threshold (enum)",0x9287:"SCD Delay (x15 us)",0x9294:"SCD Recovery Time (s)",
 0x928A:"OCD3 Threshold (userA)",0x928C:"OCD3 Delay (s)",0x928D:"OCD Recovery Threshold (userA)",
 0x928F:"OCDL Latch Limit",0x9290:"OCDL Counter Dec Delay (s)",0x9291:"OCDL Recovery Time (s)",0x9292:"OCDL Recovery Threshold (userA)",
 0x9295:"SCDL Latch Limit",0x9296:"SCDL Counter Dec Delay (s)",0x9297:"SCDL Recovery Time (s)",0x9298:"SCDL Recovery Threshold (userA)",
 0x929A:"OTC Threshold (C)",0x929B:"OTC Delay (s)",0x929C:"OTC Recovery (C)",
 0x929D:"OTD Threshold (C)",0x929E:"OTD Delay (s)",0x929F:"OTD Recovery (C)",
 0x92A0:"OTF Threshold (C)",0x92A1:"OTF Delay (s)",0x92A2:"OTF Recovery (C)",
 0x92A3:"OTINT Threshold (C)",0x92A4:"OTINT Delay (s)",0x92A5:"OTINT Recovery (C)",
 0x92A6:"UTC Threshold (C)",0x92A7:"UTC Delay (s)",0x92A8:"UTC Recovery (C)",
 0x92A9:"UTD Threshold (C)",0x92AA:"UTD Delay (s)",0x92AB:"UTD Recovery (C)",
 0x92AC:"UTINT Threshold (C)",0x92AD:"UTINT Delay (s)",0x92AE:"UTINT Recovery (C)",
 0x92AF:"Protections Recovery Time (s)",0x92B2:"HWD Delay (s)",
 0x92B4:"Load Detect Active Time (s)",0x92B5:"Load Detect Retry Delay (s)",0x92B6:"Load Detect Timeout (hrs)",
}

for k,v in OVR.items():
    t=ent.get(k,(None,"U1",[]))[1]
    ent[k]=(v,t,[])
print("# parsed TRM entries:", len(ent), file=sys.stderr)
json.dump({hex(k): v for k, v in sorted(ent.items())}, open("../data/bq76952_dm_table.json", "w"), indent=0)
img = open("../data/A_bq_config_image.bin", "rb").read()
base = 0x9231
size = {"U1": 1, "I1": 1, "H1": 1, "S1": 1, "U2": 2, "I2": 2, "H2": 2, "U4": 4, "I4": 4, "H4": 4, "F4": 4}
rows = []
a = base
while a < base + len(img):
    if a in ent:
        name, t, rest = ent[a]
        n = size[t]
        raw = img[a - base:a - base + n]
        v = int.from_bytes(raw, "little", signed=t.startswith("I"))
        rows.append((a, name, t, n, raw.hex(), v, rest))
        a += n
    else:
        rows.append((a, "?", "?", 1, "%02x" % img[a - base], img[a - base], []))
        a += 1
print("| addr | name | type | raw (LE) | value | TRM min/max/default/unit |")
print("|---|---|---|---|---|---|")
for a, name, t, n, raw, v, rest in rows:
    print("| 0x%04X | %s | %s | %s | %d (0x%X) | %s |" % (a, name, t, raw, v, v & ((1 << (8 * n)) - 1), " ".join(rest)))
