"""fwkb_core: whole-image Thumb disassembly, function discovery, cross-references and coverage for the
Xiaomi Electric Scooter 5 Max firmware package (147,456 bytes).  READ-ONLY analysis; nothing here talks to a device.

Two programs live in the package (see 01_ARCHITECTURE.md):
  A = battery-side processor (Cortex-M4F class, N32G43x-like).  file 0x1000..0x19223 ; runtime = file + 0x08002000
  B = nested motor controller LKS32MC071 (Cortex-M0).           file 0x19818..0x2381B ; runtime = file - 0x17018
"""
import sys, struct, json, collections, os, re
HERE = os.path.dirname(os.path.abspath(__file__))
for p in (os.path.join(HERE, "pydeps"), r"E:/Claude workspace scooter/MI5Max_Claude_Handoff_2026-10-02/work/pydeps"):
    if os.path.isdir(p):
        sys.path.insert(0, p)
from capstone import Cs, CS_ARCH_ARM, CS_MODE_THUMB, CS_MODE_MCLASS
from capstone.arm import (ARM_OP_REG, ARM_OP_IMM, ARM_OP_MEM, ARM_CC_AL, ARM_CC_INVALID,
                          ARM_REG_PC, ARM_REG_LR, ARM_REG_SP)

CC_NAMES = {"eq", "ne", "hs", "lo", "cs", "cc", "mi", "pl", "vs", "vc", "hi", "ls", "ge", "lt", "gt", "le"}


class Core:
    def __init__(self, name, lo, hi, delta, vec, nvec, long_name):
        self.name, self.lo, self.hi, self.delta, self.vec, self.nvec, self.long_name = name, lo, hi, delta, vec, nvec, long_name

    def rt(self, off):
        return off + self.delta

    def fo(self, addr):
        return addr - self.delta

    def in_code(self, off):
        return self.lo <= off < self.hi


CORE_A = Core("A", 0x1000, 0x19224, 0x08002000, 0x1000, 82, "battery-side processor (Cortex-M4F class)")
CORE_B = Core("B", 0x19818, 0x2381C, -0x17018, 0x19818, 48, "nested motor controller LKS32MC071 (Cortex-M0)")


def u32(b, o):
    return struct.unpack_from("<I", b, o)[0]


def u16(b, o):
    return struct.unpack_from("<H", b, o)[0]


def scatter_decode(b, src_off, out_len):
    """ARM-style packed init-data decoder used by both programs (literal / zero-run / back-reference tokens)."""
    pos, out = src_off, bytearray()
    while len(out) < out_len:
        tok = b[pos]; pos += 1
        lit = tok & 7
        if lit == 0:
            lit = b[pos]; pos += 1
        run = tok >> 4
        if run == 0:
            run = b[pos]; pos += 1
        out.extend(b[pos:pos + lit - 1]); pos += lit - 1
        if tok & 8:
            dist = b[pos]; pos += 1
            for _ in range(run + 2):
                out.append(out[-dist])
        else:
            out.extend(b"\x00" * run)
    return bytes(out[:out_len]), pos


class Image:
    def __init__(self, data, core):
        self.b = data
        self.core = core
        self.md = Cs(CS_ARCH_ARM, CS_MODE_THUMB | CS_MODE_MCLASS)
        self.md.detail = True
        self.cache = {}

    def dec(self, off):
        if off in self.cache:
            return self.cache[off]
        c = self.core
        if off < c.lo or off + 2 > c.hi or off & 1:
            self.cache[off] = None
            return None
        chunk = bytes(self.b[off:off + 4])
        r = None
        for i in self.md.disasm(chunk, c.rt(off), count=1):
            r = i
        self.cache[off] = r
        return r


def is_cond(i):
    return i.cc not in (ARM_CC_AL, ARM_CC_INVALID, 0)


def mnem_base(i):
    return i.mnemonic.split(".")[0]


SWITCH8_SIG = bytes.fromhex("30b4 7446 641e 2578 641c ab42 00d2 1d46 635d 5b00 e318 30bc 1847".replace(" ", ""))


class Discovery:
    """recursive-descent code discovery with literal-pool, jump-table and inline-switch tracking"""

    def __init__(self, img):
        self.img = img
        self.core = img.core
        self.b = img.b
        n = self.core.hi - self.core.lo
        self.cover = bytearray(n)          # 0 none, 1 insn first byte, 2 insn continuation, 3 literal/table data
        self.instr = {}                    # file off -> insn size
        self.kind = {}                     # file off -> kind
        self.succ = {}                     # file off -> successor offsets (intra-procedural, not calls)
        self.func_entries = {}             # file off -> set(tags)
        self.lit_words = {}                # file off -> [insn offs]
        self.jump_tables = []
        self.table_ranges = []
        self.block_targets = collections.defaultdict(set)
        self.calls = collections.defaultdict(set)      # caller insn -> {callee}
        self.indirect_calls = set()
        self.indirect_jumps = set()
        self.bad_decode = set()
        self.conflict = set()
        self.queue = []
        self.switch8 = None
        self.heuristic_entries = set()
        if self.core.name == "B":
            self.switch8 = self._find_switch8()

    def _find_switch8(self):
        pos = bytes(self.b).find(SWITCH8_SIG, self.core.lo, self.core.hi)
        return pos if pos >= 0 else None

    # ---- state snapshot for trial decoding ----
    def snapshot(self):
        return (self.cover[:], dict(self.instr), dict(self.kind), dict(self.succ),
                {k: set(v) for k, v in self.func_entries.items()},
                {k: list(v) for k, v in self.lit_words.items()},
                list(self.jump_tables), list(self.table_ranges),
                {k: set(v) for k, v in self.block_targets.items()},
                {k: set(v) for k, v in self.calls.items()},
                set(self.indirect_calls), set(self.indirect_jumps), set(self.bad_decode), set(self.conflict))

    def restore(self, s):
        (self.cover, self.instr, self.kind, self.succ, self.func_entries, self.lit_words, self.jump_tables,
         self.table_ranges, bt, cl, self.indirect_calls, self.indirect_jumps, self.bad_decode, self.conflict) = s
        self.block_targets = collections.defaultdict(set, bt)
        self.calls = collections.defaultdict(set, cl)
        self.queue = []

    def add_seed(self, off, tag):
        c = self.core
        if not c.in_code(off) or off & 1:
            return
        self.func_entries.setdefault(off, set()).add(tag)
        self.queue.append(off)

    def mark_data(self, start, end, kind):
        c = self.core
        for o in range(start, end):
            k = o - c.lo
            if 0 <= k < len(self.cover) and self.cover[k] == 0:
                self.cover[k] = 3
        self.table_ranges.append((start, end, kind))

    def lit_ref(self, insn_off, i):
        c = self.core
        m = i.mnemonic
        if m.startswith(("ldr", "vldr", "adr")):
            for op in i.operands:
                if op.type == ARM_OP_MEM and op.mem.base == ARM_REG_PC:
                    pc = (c.rt(insn_off) + 4) & ~3
                    ea = pc + op.mem.disp
                    fo = c.fo(ea)
                    dbl = m.startswith("ldrd") or (m.startswith("vldr") and re.search(r"\bd\d+", i.op_str))
                    for k in range(0, 8 if dbl else 4, 4):
                        self.lit_words.setdefault(fo + k, []).append(insn_off)
                    return fo
        return None

    def run(self):
        c = self.core
        while self.queue:
            off = self.queue.pop()
            while True:
                k = off - c.lo
                if not (0 <= k < len(self.cover)):
                    break
                if off in self.instr:
                    break
                i = self.img.dec(off)
                if i is None:
                    self.bad_decode.add(off)
                    break
                sz = i.size
                if any(self.cover[k + j] != 0 for j in range(sz) if k + j < len(self.cover)):
                    self.conflict.add(off)
                    break
                self.cover[k] = 1
                for j in range(1, sz):
                    self.cover[k + j] = 2
                self.instr[off] = sz
                self.lit_ref(off, i)
                nxt = off + sz
                m = mnem_base(i)
                cond = is_cond(i)
                succ = []
                kind = "seq"
                stop = False
                if m == "b" or (len(m) == 3 and m[0] == "b" and m[1:] in CC_NAMES):
                    tgt = None
                    for op in i.operands:
                        if op.type == ARM_OP_IMM:
                            tgt = c.fo(op.imm)
                    if tgt is not None:
                        self.block_targets[tgt].add(off)
                        self.queue.append(tgt)
                        succ.append(tgt)
                    kind = "b" if (m == "b" and not cond) else "bcc"
                    if kind == "b":
                        stop = True
                    else:
                        succ.append(nxt)
                elif m in ("cbz", "cbnz"):
                    tgt = c.fo(i.operands[1].imm)
                    self.block_targets[tgt].add(off)
                    self.queue.append(tgt)
                    succ = [tgt, nxt]
                    kind = "bcc"
                elif m == "bl":
                    tgt = c.fo(i.operands[0].imm)
                    kind = "bl"
                    if self.switch8 is not None and tgt == self.switch8:
                        succ = list(self._switch8_site(off, nxt))
                        stop = True
                        kind = "switch8"
                    else:
                        self.calls[off].add(tgt)
                        self.func_entries.setdefault(tgt, set()).add("call")
                        self.queue.append(tgt)
                        succ.append(nxt)
                elif m == "blx":
                    op = i.operands[0]
                    kind = "blx"
                    if op.type == ARM_OP_IMM:
                        tgt = c.fo(op.imm)
                        self.calls[off].add(tgt)
                        self.func_entries.setdefault(tgt, set()).add("call")
                        self.queue.append(tgt)
                    else:
                        self.indirect_calls.add(off)
                    succ.append(nxt)
                elif m == "bx":
                    op = i.operands[0]
                    if op.type == ARM_OP_REG and op.reg == ARM_REG_LR:
                        kind = "ret"
                    else:
                        kind = "ijmp"
                        self.indirect_jumps.add(off)
                    if cond:
                        succ.append(nxt)
                    else:
                        stop = True
                elif m in ("pop", "ldm", "ldmia", "ldmdb") and any(op.type == ARM_OP_REG and op.reg == ARM_REG_PC for op in i.operands):
                    kind = "ret"
                    if cond:
                        succ.append(nxt)
                    else:
                        stop = True
                elif m == "ldr" and i.operands and i.operands[0].type == ARM_OP_REG and i.operands[0].reg == ARM_REG_PC:
                    if len(i.operands) > 1 and i.operands[1].type == ARM_OP_MEM and i.operands[1].mem.base == ARM_REG_SP:
                        kind = "ret"          # ldr pc,[sp],#n : return from variadic-style frame
                    else:
                        kind = "ijmp"
                        self.indirect_jumps.add(off)
                    if cond:
                        succ.append(nxt)
                    else:
                        stop = True
                elif m in ("mov", "movs", "add", "adds") and i.operands and i.operands[0].type == ARM_OP_REG and i.operands[0].reg == ARM_REG_PC:
                    kind = "ijmp"
                    self.indirect_jumps.add(off)
                    stop = not cond
                    if cond:
                        succ.append(nxt)
                elif m in ("tbb", "tbh"):
                    kind = "tbl"
                    succ = self.handle_tbl(off, i)
                    stop = True
                elif m in ("udf", "bkpt"):
                    kind = "stop"
                    stop = True
                else:
                    succ.append(nxt)
                self.kind[off] = kind
                self.succ[off] = succ
                if stop:
                    break
                off = nxt

    def _switch8_site(self, off, nxt):
        """compiler switch helper: after 'bl helper' comes [n][n+1 offsets]; target = nxt + 2*off"""
        b = self.b
        n = b[nxt]
        offs = list(b[nxt + 1: nxt + 2 + n])
        targets = [nxt + 2 * o for o in offs]
        size = 1 + len(offs)
        size += size & 1
        self.mark_data(nxt, nxt + size, "switch8_table")
        self.jump_tables.append(dict(site=off, kind="switch8", table_off=nxt, n=n, targets=targets))
        for t in targets:
            self.block_targets[t].add(off)
            self.queue.append(t)
        return targets

    def handle_tbl(self, off, i):
        c = self.core
        b = self.b
        half = i.mnemonic.startswith("tbh")
        base_pc = c.rt(off) + 4
        n = None
        brk = None
        k = off
        for _ in range(14):
            for sz in (2, 4):
                pj = k - sz
                if pj in self.instr and self.instr[pj] == sz:
                    k = pj
                    break
            else:
                break
            pi = self.img.dec(k)
            if pi is None:
                break
            mb = mnem_base(pi)
            if brk is None and mb in ("bhi", "bhs", "bcs"):
                brk = mb
            if pi.mnemonic.startswith("cmp"):
                for op in pi.operands:
                    if op.type == ARM_OP_IMM:
                        n = op.imm + (1 if brk == "bhi" else 0)
                break
        tbl = c.fo(base_pc)
        if n is None or n <= 0:
            n = 0
            while n < 128:
                v = b[tbl + n] if not half else u16(b, tbl + 2 * n)
                if not c.in_code(tbl + 2 * v):
                    break
                n += 1
        targets = []
        for e in range(n):
            v = b[tbl + e] if not half else u16(b, tbl + 2 * e)
            t = tbl + 2 * v
            targets.append(t)
            self.block_targets[t].add(off)
            self.queue.append(t)
        size = n * (2 if half else 1)
        size += size & 1
        self.mark_data(tbl, tbl + size, "tbh_table" if half else "tbb_table")
        self.jump_tables.append(dict(site=off, kind="tbh" if half else "tbb", table_off=tbl, n=n, targets=targets))
        return targets

    # ---- heuristics for code not reached by direct control flow ----
    def prologue_candidates(self):
        """halfword-aligned uncovered offsets that look like function starts"""
        c, b = self.core, self.b
        out = []
        for off in range(c.lo, c.hi - 3, 2):
            k = off - c.lo
            if self.cover[k] != 0:
                continue
            hw = u16(b, off)
            hw2 = u16(b, off + 2)
            if (hw & 0xFF00) == 0xB500:                       # push {..,lr}
                out.append(off)
            elif hw == 0xE92D and (hw2 & 0x4000):             # push.w / stmdb sp!,{..,lr}
                out.append(off)
        return out

    SUSPICIOUS = {"udf", "svc", "bkpt", "cdp", "cdp2", "mcr", "mcr2", "mrc", "mrc2", "ldc", "ldc2", "stc", "stc2", "mrrc", "mcrr",
                  "rrx", "ssat", "usat", "bfi", "bfc", "sbfx", "ubfx", "ldrex", "strex", "teq", "smlal", "umlal", "smull", "umull", "adr",
                  "ldrt", "strt", "ldrbt", "strbt", "ldrht", "strht", "sxtab", "uxtab", "pkhbt", "usad8", "ssub8"}

    def validate_new(self, new_offs, strict):
        b = self.b
        if not new_offs:
            return False
        nbytes = sum(self.instr[o] for o in new_offs)
        zero = sum(1 for o in new_offs for k in range(self.instr[o]) if b[o + k] == 0)
        if zero * 100 > nbytes * (21 if strict else 30):
            return False
        sus = 0
        ret_seen = False
        for o in new_offs:
            i = self.img.dec(o)
            mb = mnem_base(i)
            if mb in self.SUSPICIOUS:
                sus += 1
            if self.kind.get(o) in ("ret", "b", "ijmp", "tbl", "switch8"):
                ret_seen = True
        if sus * 5 > len(new_offs):
            return False
        if strict:
            if len(new_offs) == 1:
                return self.kind.get(new_offs[0]) == "ret"
            if not ret_seen:
                return False
            # at least one anchor of 'real code': literal load, call, push/pop, or conditional branch
            anchors = 0
            for o in new_offs:
                i = self.img.dec(o)
                mb = mnem_base(i)
                if mb in ("bl", "push", "pop", "cbz", "cbnz") or self.kind.get(o) == "bcc" or (mb == "ldr" and o in self._lit_insns()):
                    anchors += 1
            if anchors < 1:
                return False
        return True

    def _lit_insns(self):
        s = set()
        for v in self.lit_words.values():
            s.update(v)
        return s

    def quick_ok(self, off, strict):
        """cheap straight-line plausibility screen before a full trial (no state mutation)"""
        c, b = self.core, self.b
        n = 0
        zero = 0
        nbytes = 0
        sus = 0
        o = off
        ended = False
        while n < 400:
            k = o - c.lo
            if not (0 <= k < len(self.cover)):
                return False
            if self.cover[k] != 0:
                ended = n > 0 and self.cover[k] == 1
                break
            i = self.img.dec(o)
            if i is None:
                return False
            n += 1
            nbytes += i.size
            zero += sum(1 for q in range(i.size) if b[o + q] == 0)
            mb = mnem_base(i)
            if mb in self.SUSPICIOUS:
                sus += 1
            m = mb
            term = (m == "b" and not is_cond(i)) or (m == "bx") or (m in ("pop", "ldm", "ldmia", "ldmdb") and any(op.type == ARM_OP_REG and op.reg == ARM_REG_PC for op in i.operands) and not is_cond(i)) or m in ("tbb", "tbh", "udf", "bkpt")
            if m == "ldr" and i.operands and i.operands[0].type == ARM_OP_REG and i.operands[0].reg == ARM_REG_PC and not is_cond(i):
                term = True
            if term:
                ended = True
                break
            o += i.size
        if not ended or n < 1:
            return False
        if zero * 100 > nbytes * (21 if strict else 30):
            return False
        if sus * 5 > n:
            return False
        return True

    def trial(self, off, tag, min_new=2, strict=False):
        if not self.quick_ok(off, strict):
            return False
        snap = self.snapshot()
        before = set(self.instr)
        self.func_entries.setdefault(off, set()).add(tag)
        self.queue = [off]
        self.run()
        new_offs = sorted(set(self.instr) - before)
        ok = not self.bad_decode and not self.conflict and len(new_offs) >= min_new and self.validate_new(new_offs, strict)
        if not ok:
            self.restore(snap)
            return False
        self.heuristic_entries.add(off)
        return True

    def heuristic_pass(self):
        total = 0
        while True:
            acc = 0
            for off in self.prologue_candidates():
                if self.cover[off - self.core.lo] != 0:
                    continue
                if self.trial(off, "heur_prologue"):
                    acc += 1
            total += acc
            if not acc:
                break
        return total

    def gap_start_pass(self):
        """try decoding from the first uncovered, non-zero halfword after covered/literal/zero-pad bytes
        (leaf routines without a push, tiny handlers)"""
        c, b = self.core, self.b
        total = 0
        for _round in range(4):
            acc = 0
            lit = set()
            for w in self.lit_words:
                for kk in range(4):
                    lit.add(w + kk)
            off = c.lo
            while off < c.hi - 1:
                k = off - c.lo
                if self.cover[k] == 0 and off not in lit and (off + 1) not in lit and u16(b, off) not in (0x0000, 0xFFFF):
                    pv = off - 2
                    prev_ok = (k < 2) or self.cover[k - 1] != 0 or self.cover[k - 2] != 0 or (pv in lit) or (pv + 1 in lit) or u16(b, pv) == 0
                    if prev_ok and off & 1 == 0 and self.trial(off, "heur_gapstart", min_new=1, strict=True):
                        acc += 1
                off += 2
            total += acc
            if not acc:
                break
        return total


def scan_pointers(b, core):
    out = {}
    for off in range(core.lo & ~3, core.hi - 3, 4):
        v = u32(b, off)
        if v & 1:
            fo = core.fo(v & ~1)
            if core.lo <= fo < core.hi and (fo & 1) == 0:
                out.setdefault(fo, []).append(off)
    return out


def discover(data, core, manual=None):
    img = Image(data, core)
    d = Discovery(img)
    d.mark_data(core.vec, core.vec + 4 * core.nvec, "vector_table")
    for ds, de, kind in (manual or {}).get("data", []):
        d.mark_data(ds, de, kind)
    for k in range(1, core.nvec):
        v = u32(data, core.vec + 4 * k)
        if v & 1:
            fo = core.fo(v & ~1)
            if core.in_code(fo):
                d.add_seed(fo, "vector%d" % k)
    d.run()
    ptrs = scan_pointers(data, core)
    d.rejected_ptrs = []
    d.unverified_ptrs = {}

    def is_prologue(fo):
        hw = u16(data, fo)
        hw2 = u16(data, fo + 2)
        return (hw & 0xFF00) == 0xB500 or (hw == 0xE92D and (hw2 & 0x4000))

    # pass 1: pointer words whose target looks like a function prologue
    for fo in sorted(ptrs):
        if d.cover[fo - core.lo] == 1:
            d.func_entries.setdefault(fo, set()).add("pointer_word")
        elif d.cover[fo - core.lo] == 0 and is_prologue(fo):
            if not d.trial(fo, "pointer_word", min_new=1):
                d.rejected_ptrs.append(fo)
    d.heuristic_pass()
    # pass 2: other pointer words, only if the word itself is not inside decoded code and target still uncovered
    for fo in sorted(ptrs):
        if d.cover[fo - core.lo] == 1:
            d.func_entries.setdefault(fo, set()).add("pointer_word")
        elif d.cover[fo - core.lo] == 0 and not is_prologue(fo):
            srcs = ptrs[fo]
            in_code_word = all(d.cover[w - core.lo] in (1, 2) for w in srcs)
            if in_code_word:
                d.unverified_ptrs[fo] = srcs
            elif not d.trial(fo, "pointer_word", min_new=1):
                d.rejected_ptrs.append(fo)
        elif d.cover[fo - core.lo] == 2:
            d.unverified_ptrs[fo] = ptrs[fo]
    for _ in range(8):
        a = d.heuristic_pass()
        b2 = d.gap_start_pass()
        if not (a or b2):
            break
    return d
