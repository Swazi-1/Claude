"""emu_a_params: run A:9F64 (bms_params_init) in Unicorn on the stock image and dump the BQ769x2 config image (RAM 0x13CE..0x14ED).
Analysis only (pure host-side emulation; nothing touches a device)."""
import struct, sys
from unicorn import *
from unicorn.arm_const import *
def _root(*p):
    """path inside the workspace root (two levels above tools/); portable"""
    import os as _o
    return _o.path.normpath(_o.path.join(_o.path.dirname(_o.path.abspath(__file__)), "..", "..", *p))
STOCK = _root("01_FIRMWARE", "2_ORIGINAL_STOCK", "01_STOCK_ORIGINAL.bin")
fw = open(STOCK, "rb").read()
ramimg = open("../data/A_initial_ram.bin", "rb").read()
DELTA = 0x08002000
uc = Uc(UC_ARCH_ARM, UC_MODE_THUMB | UC_MODE_MCLASS)
# flash: map file at runtime base 0x08002000 (size rounded)
size = (len(fw) + 0xFFF) & ~0xFFF
uc.mem_map(DELTA, size)
uc.mem_write(DELTA, fw)
uc.mem_map(0x20000000, 0x8000)
uc.mem_write(0x20000000, ramimg)
uc.mem_map(0x40000000, 0x100000)   # peripherals as dumb RAM
uc.mem_map(0xE0000000, 0x100000)   # system control space
uc.mem_map(0x08000000, 0x2000)     # first 8 KB (bootloader area) dummy
STACK = 0x20007000
SENT = 0x08000100
uc.mem_write(SENT, b"\x00\xbe")      # bkpt
uc.reg_write(UC_ARM_REG_SP, STACK)
uc.reg_write(UC_ARM_REG_LR, SENT | 1)
entry = (DELTA + 0x9F64) | 1
try:
    uc.emu_start(entry, SENT, count=2000000)
except UcError as e:
    print("emu error", e, "pc=%x" % uc.reg_read(UC_ARM_REG_PC)); sys.exit(1)
img = bytes(uc.mem_read(0x200013CE, 0x120))
open("../data/A_bq_config_image.bin", "wb").write(img)
print("pc=%x" % uc.reg_read(UC_ARM_REG_PC), "dumped", len(img))
print(img.hex())
