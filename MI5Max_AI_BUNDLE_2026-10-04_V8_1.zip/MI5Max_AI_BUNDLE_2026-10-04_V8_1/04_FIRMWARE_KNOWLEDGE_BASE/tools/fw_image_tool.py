#!/usr/bin/env python3
"""Xiaomi Electric Scooter 5 Max image tool (standard library only).

  python fw_image_tool.py info  <image.bin>          layout, both checksums, key settings, SHA-256
  python fw_image_tool.py diff  <a.bin> <b.bin>      byte differences grouped by region, with names
  python fw_image_tool.py recrc <in.bin> <out.bin>   write a COPY with both checksums recomputed

Rules of this project (read before using `recrc`):
  * Claude/AI never flashes and never talks to the scooter; the owner does.
  * Build a firmware file only when the owner explicitly asks, always into a NEW folder, never overwrite.
  * Original one-press power button is priority #1: program A and B's boot/power-latch code stay byte-identical.
  `recrc` refuses to overwrite an existing file and only fixes the two checksums; it does not patch anything.

Image = 147,456 bytes (0x24000). Checksums (confirmed, reproduce stock and all known builds):
  inner  CRC-32/MPEG-2 (poly 0x04C11DB7, init 0xFFFFFFFF, no reflection, no final xor) over
         data[0x19818 : 0x19818+L], L = u32 LE at 0x19800 (0xA404), padded with 0xFF to a multiple of 4;
         stored u32 LE at 0x19804.
  outer  CRC-16/XMODEM (binascii.crc_hqx(data[0x19800:], 0)) stored big-endian at bytes 10..11.
Whether the dashboard/bootloader enforce them is unknown (U); keep them right anyway.
"""
import binascii, hashlib, os, struct, sys

SIZE = 0x24000
L_OFF, CRC_OFF = 0x19800, 0x19804
A_START, A_END = 0x1000, 0x19224          # program A (BMS), file offsets [start, end)
B_START, B_END = 0x19818, 0x2381C          # program B (motor controller)
# offsets of known settings: file offset -> (name, what it means)
KNOWN = {
    0x1FEB8: ("thermal_formula_const", "u32 literal K in cap = K - 3*temp_local; stock 3193, v7.1..V8 600 3620, V8.1 3193"),
    0x1BDDE: ("coast_regen_start", "cmp r3,#imm: speed (0.1 km/h) where coast regen starts; stock 0x3C=6.0, v7.1+ 0x32=5.0 km/h"),
    0x1C1BC: ("lowspeed_brake_count", "cmp r0,#imm; stock 0x1E, v7.1+ 0x5A"),
    0x1E02C: ("sport_env_cap", "S-mode current cap (counts; amps = counts/27.2): movs r0,#imm + adds/lsls; stock 493, RC02 560, V8 600"),
    0x1FC90: ("thermal_derate", "movs r1,#imm x4: local-temperature derate threshold; stock 0xE1 (900), v7.1+ 0xFF (1020)"),
    0x1FD96: ("lowcharge_cap_base", "movs r0,#0xFF; adds r0,#0xEE = 493 base of the SOC<20% current cap"),
    0x2001C: ("regen_weak", "movs r1,#imm: weak coast regen demand (stock/all 0x5B = 91)"),
    0x20020: ("regen_medium", "movs r1,#imm: medium demand; strong = imm*2; stock 0x92 (146/292), v7.1/RC02 0xA0 (160/320), V8 0x92"),
}


def inner_crc(d):
    n = struct.unpack_from("<I", d, L_OFF)[0]
    body = bytes(d[B_START:B_START + n])
    body += b"\xff" * ((-len(body)) % 4)
    crc = 0xFFFFFFFF
    for b in body:
        crc ^= b << 24
        for _ in range(8):
            crc = ((crc << 1) ^ (0x04C11DB7 if crc & 0x80000000 else 0)) & 0xFFFFFFFF
    return crc


def outer_crc(d):
    return binascii.crc_hqx(bytes(d[L_OFF:]), 0)


def load(path):
    d = open(path, "rb").read()
    if len(d) != SIZE:
        sys.exit(f"{path}: {len(d)} bytes, expected {SIZE}")
    return bytearray(d)


def region(i):
    if i < A_START or L_OFF <= i < B_START:
        return "header"
    if i < A_END:
        return "A (BMS)"
    if i < B_START:
        return "pad"
    if i < B_END:
        return "B (motor)"
    return "appended code/pad"


def imm_pair(d, off):
    """Decode `movs r0,#imm` followed by `adds r0,#n` or `lsls r0,r0,#2` (the Sport cap idiom)."""
    h0 = struct.unpack_from("<H", d, off)[0]
    h1 = struct.unpack_from("<H", d, off + 2)[0]
    if h0 >> 8 != 0x20:
        return None
    imm = h0 & 0xFF
    if h1 >> 8 == 0x30:
        return imm + (h1 & 0xFF)
    if h1 == 0x0080:
        return imm << 2
    return None


def info(path):
    d = load(path)
    sha = hashlib.sha256(d).hexdigest()
    st_in = struct.unpack_from("<I", d, CRC_OFF)[0]
    st_out = int.from_bytes(d[10:12], "big")
    c_in, c_out = inner_crc(d), outer_crc(d)
    print(f"{os.path.basename(path)}  {len(d)} bytes  sha256 {sha}")
    print(f"inner CRC32 stored {st_in:08X} computed {c_in:08X} {'OK' if st_in == c_in else 'MISMATCH'}")
    print(f"outer CRC16 stored {st_out:04X} computed {c_out:04X} {'OK' if st_out == c_out else 'MISMATCH'}")
    print(f"program A sha256 {hashlib.sha256(d[A_START:A_END]).hexdigest()[:16]}  (identical in every known build)")
    print(f"program B sha256 {hashlib.sha256(d[B_START:B_END]).hexdigest()[:16]}")
    tail = d[B_END:]
    nz = [i for i, b in enumerate(tail) if b != 0xFF]
    if nz:
        print(f"appended code: file 0x{B_END + nz[0]:X}..0x{B_END + nz[-1]:X} ({nz[-1] - nz[0] + 1} bytes; custom builds only)")
    else:
        print("appended code: none (stock layout)")
    sport = imm_pair(d, 0x1E02C)
    if sport is not None:
        print(f"Sport current cap (0x1E02C): {sport} counts = {sport / 27.2:.1f} A at the battery")
    med = d[0x20020]
    print(f"regen demand weak/medium/strong (0x2001C/0x20020): {d[0x2001C]}/{med}/{med * 2}")
    print(f"coast regen starts at (0x1BDDE): {d[0x1BDDE] / 10:.1f} km/h;  thermal derate imm (0x1FC90): 0x{d[0x1FC90]:02X} -> {d[0x1FC90] * 4}")


def diff(pa, pb):
    a, b = load(pa), load(pb)
    idx = [i for i in range(SIZE) if a[i] != b[i]]
    print(f"{len(idx)} differing bytes between {os.path.basename(pa)} and {os.path.basename(pb)}")
    counts = {}
    for i in idx:
        counts[region(i)] = counts.get(region(i), 0) + 1
    for r, n in counts.items():
        print(f"  {r}: {n}")
    runs = []
    for i in idx:
        if runs and i == runs[-1][1] + 1:
            runs[-1][1] = i
        else:
            runs.append([i, i])
    print(f"{len(runs)} runs:")
    for s, e in runs:
        names = [KNOWN[k][0] for k in KNOWN if s - 8 <= k <= e + 8]
        print(f"  0x{s:05X}..0x{e:05X} ({e - s + 1} B) {region(s)}  {' '.join(names)}")


def recrc(src, dst):
    if os.path.exists(dst):
        sys.exit(f"{dst} exists; never overwrite, choose a new path")
    d = load(src)
    struct.pack_into("<I", d, CRC_OFF, inner_crc(d))
    d[10:12] = outer_crc(d).to_bytes(2, "big")
    open(dst, "wb").write(d)
    print(f"wrote {dst}; run `info` on it and `diff` against its source before anything else")


if __name__ == "__main__":
    cmd = sys.argv[1] if len(sys.argv) > 1 else ""
    if cmd == "info" and len(sys.argv) == 3:
        info(sys.argv[2])
    elif cmd == "diff" and len(sys.argv) == 4:
        diff(sys.argv[2], sys.argv[3])
    elif cmd == "recrc" and len(sys.argv) == 4:
        recrc(sys.argv[2], sys.argv[3])
    else:
        print(__doc__)
