"""romconst: list every constant read from flash (mem[0x80xxxxx]) in the pseudocode, with value and reader functions.
usage: python romconst.py A  -> prints markdown to stdout"""
import sys, re, os, json, struct
from collections import defaultdict
from fwkb_export import *
def _root(*p):
    """path inside the workspace root (two levels above tools/); portable"""
    import os as _o
    return _o.path.normpath(_o.path.join(_o.path.dirname(_o.path.abspath(__file__)), "..", "..", *p))
core = {"A": CORE_A, "B": CORE_B}[sys.argv[1]]
STOCK = _root("01_FIRMWARE", "2_ORIGINAL_STOCK", "01_STOCK_ORIGINAL.bin")
data = open(STOCK, "rb").read()
txt = open(os.path.join(os.path.dirname(HERE), "data", "%s_pseudocode.txt" % core.name), encoding="utf-8").read()
parts = re.split(r"\n(?=fn %s:)" % core.name, txt)
reads = defaultdict(lambda: {"fn": set(), "w": set()})
pat = re.compile(r"mem\[0x([0-9A-Fa-f]+)\]\.(sb|sh|b|h|w)")
for p in parts:
    m = re.match(r"fn %s:([0-9A-F]+)<([^>]*)>" % core.name, p)
    if not m:
        continue
    fname = m.group(2)
    for a, w in pat.findall(p):
        a = int(a, 16)
        reads[a]["fn"].add(fname)
        reads[a]["w"].add(w)
rows = []
for a in sorted(reads):
    fo = a - core.delta
    if not (0 <= fo < len(data)):
        continue
    ws = reads[a]["w"]
    w = "w" if "w" in ws else ("h" if ("h" in ws or "sh" in ws) else "b")
    n = {"w": 4, "h": 2, "b": 1}[w]
    raw = data[fo:fo + n]
    v = int.from_bytes(raw, "little")
    sv = v - (1 << (8 * n)) if v >= 1 << (8 * n - 1) else v
    rows.append((a, fo, w, v, sv, sorted(reads[a]["fn"])))
print("| runtime | file | w | unsigned | signed | read by |")
print("|---|---|---|---|---|---|")
for a, fo, w, v, sv, fn in rows:
    print("| 0x%07X | 0x%05X | %s | %d (0x%X) | %d | %s |" % (a, fo, w, v, v, sv, ", ".join(fn[:6])))
