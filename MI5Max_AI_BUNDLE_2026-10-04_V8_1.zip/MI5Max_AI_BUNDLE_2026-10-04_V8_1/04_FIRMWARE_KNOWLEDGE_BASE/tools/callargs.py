import sys,json
core=sys.argv[1]
cs=json.load(open("../data/%s_callsites.json"%core))
for e in sys.argv[2:]:
    e=e.upper()
    lst=cs.get(e,[])
    print("== %s:%s  %d call sites"%(core,e,len(lst)))
    seen=[]
    for site,fe,a0,a1,a2,a3 in lst[:40]:
        print("   from %s@%s  r0=%s r1=%s r2=%s r3=%s"%(fe,site,a0,a1,a2,a3))
