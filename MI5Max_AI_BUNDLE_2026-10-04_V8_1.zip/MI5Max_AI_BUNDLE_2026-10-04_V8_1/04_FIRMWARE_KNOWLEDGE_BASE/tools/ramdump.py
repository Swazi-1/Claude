"""ramdump: compact per-cell RAM xref listing for naming work.  usage: python ramdump.py A [lo hi]"""
import sys, os, json
from fwkb_export import *
core = {"A": CORE_A, "B": CORE_B}[sys.argv[1]]
lo = int(sys.argv[2], 16) if len(sys.argv) > 2 else 0
hi = int(sys.argv[3], 16) if len(sys.argv) > 3 else 0x100000
names, _ = load_names(core)
ramx = json.load(open(os.path.join(os.path.dirname(HERE), "data", "%s_ram_xrefs.json" % core.name)))
ram = load_ram(core)
named = {a: (sz, n) for a, sz, n, d, c in ram}
def fn(h):
    fo = int(h, 16)
    return names.get(fo) or ("%X" % fo)
for k in sorted(ramx, key=lambda x: int(x, 16)):
    a = int(k, 16) - 0x20000000
    if not (lo <= a < hi):
        continue
    x = ramx[k]
    nm = named.get(int(k, 16))
    w = ",".join(str(z) for z in x["width"])
    R = x["R"]; W = x["W"]
    print("%X w%s R%d W%d %s | R: %s | W: %s%s" % (a, w, len(R), len(W), ("[%s]" % nm[1]) if nm else "", ";".join(fn(h) for h in R[:3]), ";".join(fn(h) for h in W[:3]),
          (" | v=" + ",".join("%X" % q for q in x["wvals"][:4])) if x["wvals"] else ""))
