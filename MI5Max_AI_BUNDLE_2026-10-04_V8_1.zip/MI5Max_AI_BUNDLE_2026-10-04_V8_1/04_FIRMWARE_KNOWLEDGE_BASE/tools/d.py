import sys
from fwkb_core import *
def _root(*p):
    """path inside the workspace root (two levels above tools/); portable"""
    import os as _o
    return _o.path.normpath(_o.path.join(_o.path.dirname(_o.path.abspath(__file__)), "..", "..", *p))
data=open(_root("01_FIRMWARE", "2_ORIGINAL_STOCK", "01_STOCK_ORIGINAL.bin"),"rb").read()
core={"A":CORE_A,"B":CORE_B}[sys.argv[1]]
img=Image(data,core)
a=int(sys.argv[2],16); n=int(sys.argv[3]) if len(sys.argv)>3 else 40
off=a
while n>0:
    i=img.dec(off)
    if i is None: print("%05x: ??"%off, data[off:off+4].hex()); off+=2; n-=1; continue
    print("%05x %08x  %-18s %s %s"%(off,core.rt(off),i.bytes.hex(),i.mnemonic,i.op_str))
    off+=i.size; n-=1
