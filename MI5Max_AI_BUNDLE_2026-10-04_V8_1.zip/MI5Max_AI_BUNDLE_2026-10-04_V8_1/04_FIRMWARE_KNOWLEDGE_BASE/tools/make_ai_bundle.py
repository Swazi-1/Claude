#!/usr/bin/env python3
"""make_ai_bundle: zip everything an AI needs (docs, firmware images, knowledge base, tools, photos, processed ride data)
into <workspace>/MI5Max_AI_BUNDLE_<date>.zip with a BUNDLE_README.md and a .sha256.txt. Leaves out the large
MI5Max_Claude_Handoff_2026-10-02 work folder, ride videos and old archives.

usage: python make_ai_bundle.py [YYYY-MM-DD]      (default: today; refuses to overwrite an existing zip)
Analysis-side packaging only; nothing here touches the scooter."""
import datetime, hashlib, os, sys, zipfile

ROOT = os.path.normpath(os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", ".."))
os.chdir(ROOT)
date = sys.argv[1] if len(sys.argv) > 1 else datetime.date.today().isoformat()
OUT = f"MI5Max_AI_BUNDLE_{date}.zip"
if os.path.exists(OUT):
    sys.exit(f"{OUT} exists; refusing to overwrite (delete it first or pass another date)")

files = []


def add_tree(base):
    for root, dirs, fs in os.walk(base):
        dirs[:] = [d for d in dirs if d != "__pycache__"]
        for f in fs:
            if not f.endswith(".pyc"):
                files.append(os.path.join(root, f))


files += ["00_START_HERE.md", "PROJECT_SUMMARY.md", "CLAUDE_PROMPT.txt", "FINDINGS_2026-10-03.md", "CONTRIBUTORS.txt"]
for tree in ("01_FIRMWARE", "04_FIRMWARE_KNOWLEDGE_BASE", "05_HARDWARE_PHOTOS"):
    add_tree(tree)
files.append(os.path.join("02_MODEL_HANDOFFS", "README.md"))
files.append(os.path.join("02_MODEL_HANDOFFS", "Opus_ChildMode_Options_Report", "MI5Max_ChildMode_Options_Report", "CHILD_MODE_OPTIONS_REPORT.md"))
ride = "03_RIDE_DATA_2026-10-03"
files.append(os.path.join(ride, "README.md"))
files.append(os.path.join(ride, "RUNS ALL", "Notes app what i wrote.txt"))
v8 = os.path.join(ride, "V8_tests_2026-10-03_04")
files += [os.path.join(v8, f) for f in os.listdir(v8) if f.lower().endswith((".md", ".csv", ".png"))]
for d in ("processed_100pct", "processed_50pct", "processed_35pct"):
    files += [os.path.join(ride, d, f) for f in os.listdir(os.path.join(ride, d))]
files = sorted(f for f in files if os.path.isfile(f))

readme = f"""# MI5Max AI bundle (built {date})

Everything an AI needs to understand the firmware of the owner's own Xiaomi Electric Scooter 5 Max and continue the project. **Start with `00_START_HERE.md`, then `04_FIRMWARE_KNOWLEDGE_BASE/FIRMWARE_AT_A_GLANCE.md`, then `PROJECT_SUMMARY.md`.** Paste `CLAUDE_PROMPT.txt` as the first message if you like.

## Included
* `00_START_HERE.md`, `PROJECT_SUMMARY.md` (master summary), `CLAUDE_PROMPT.txt`, `CONTRIBUTORS.txt`, `FINDINGS_2026-10-03.md` (older RC02-era page)
* `01_FIRMWARE/`: all seven firmware images (stock, v7.1, RC01, RC02, V8 FINAL 600 [on the scooter], 640 and 680 [DO NOT FLASH]), READMEs, `SHA256SUMS.txt`
* `04_FIRMWARE_KNOWLEDGE_BASE/`: the full firmware map (docs 00-11, function/RAM/peripheral catalogs, pseudo-code, disassembly, annotations, Python tools; `tools/fw_image_tool.py` needs only the standard library)
* `05_HARDWARE_PHOTOS/`: deck, battery and label photos
* `03_RIDE_DATA_2026-10-03/`: processed CSVs of the rides, the V8 600 OCR CSV, the 680 cut-out screenshot, notes (no videos)
* `02_MODEL_HANDOFFS/`: readme and the Opus child-mode report

## Left out (to keep the bundle small)
* `MI5Max_Claude_Handoff_2026-10-02/` (about 250 MB of older scripts, simulators, evidence and reports; not needed to understand the firmware), ride videos, archive zips, prompts and zips sent to other models.
* Some links in the docs point to those folders; ignore them or ask the owner.

## Using the tools (Python 3.12)
* No setup: `python 04_FIRMWARE_KNOWLEDGE_BASE/tools/fw_image_tool.py info 01_FIRMWARE/1_CURRENT_ON_SCOOTER_V8_FINAL_600/MI5Max_V8_FINAL_600.bin`
* Analysis pipeline (`04_FIRMWARE_KNOWLEDGE_BASE/00_README_FOR_AI.md` section 5) needs `pip install capstone unicorn numpy`. All paths are relative to the bundle folder.

## Rules
Analysis and documentation by default. An AI never flashes and never sends commands to the scooter; the owner does. Build firmware only when the owner explicitly asks, in a new folder, never overwriting. The original one-press power button is priority #1. Do not change the battery processor's protection limits; do not offer Sport caps above 600.

## Contents ({len(files) + 1} files)
""" + "\n".join(f.replace(os.sep, "/") for f in files) + "\n"

with zipfile.ZipFile(OUT, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    z.writestr("BUNDLE_README.md", readme)
    for f in files:
        z.write(f, f.replace(os.sep, "/"))
h = hashlib.sha256(open(OUT, "rb").read()).hexdigest()
open(OUT + ".sha256.txt", "w").write(h + " *" + OUT + "\n")
print(len(files) + 1, "files", os.path.getsize(OUT), "bytes", h)
