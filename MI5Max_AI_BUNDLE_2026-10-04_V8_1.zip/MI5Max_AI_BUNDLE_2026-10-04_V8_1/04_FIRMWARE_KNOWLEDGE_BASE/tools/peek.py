import sys,re
core=sys.argv[1]; n=int(sys.argv[2]); ents=[x.upper() for x in sys.argv[3:]]
txt=open("../data/%s_pseudocode.txt"%core,encoding="utf-8").read().split("\n")
i=0
while i<len(txt):
    m=re.match(r"fn %s:([0-9A-F]+)"%core,txt[i])
    if m and (not ents or m.group(1) in ents):
        j=i
        out=[]
        while j<len(txt) and not txt[j].startswith("}"):
            out.append(txt[j]); j+=1
        out.append("}")
        print("\n".join(out[:n+1]))
        if len(out)>n+1: print("   ... (%d more lines)"%(len(out)-n-1))
        i=j
    i+=1
