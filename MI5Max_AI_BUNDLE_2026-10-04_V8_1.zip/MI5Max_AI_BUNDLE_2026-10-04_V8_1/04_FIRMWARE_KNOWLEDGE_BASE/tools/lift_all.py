import sys, time, os, re, json
from fwkb_export import *
from fwkb_lift import *

def _root(*p):
    """path inside the workspace root (two levels above tools/); portable"""
    import os as _o
    return _o.path.normpath(_o.path.join(_o.path.dirname(_o.path.abspath(__file__)), "..", "..", *p))
STOCK = _root("01_FIRMWARE", "2_ORIGINAL_STOCK", "01_STOCK_ORIGINAL.bin")
OUT = os.path.join(os.path.dirname(HERE), "data")
data = open(STOCK, "rb").read()
which = sys.argv[1:] or ["A", "B"]
NL = chr(10)
for core in (CORE_A, CORE_B):
    if core.name not in which:
        continue
    t = time.time()
    names, descs = load_names(core)
    manual = json.load(open(os.path.join(os.path.dirname(HERE), "annotations", "manual_%s.json" % core.name)))
    d, an = full_analysis(data, core, names=names, manual=manual)
    an.names = names
    namer = Namer(core)
    L = Lifter(an, namer, names)
    order = sorted(an.funcs)
    L.compute_livein_all(order)
    lines = ["// %s pseudo-code (auto-generated reading aid; verify against disassembly)" % core.name]
    errs = 0
    for e in order:
        f = an.funcs[e]
        if names.get(e, "").startswith("lib_"):
            txt = ["fn %s { /* LIBRARY: %s */ }" % (L.fn_label(e), descs.get(e, ("",))[0])]
            lines.append("")
            lines += txt
            continue
        try:
            txt = L.lift(f)
        except Exception as ex:
            errs += 1
            import traceback
            txt = ["fn %s { /* LIFT ERROR: %r */ }" % (L.fn_label(e), ex)]
            if errs < 4:
                traceback.print_exc()
        body = NL.join(txt)
        out2 = []
        for ln in txt:
            m = re.match(r"\s+(t\d+) = r\d+_after_call;", ln)
            if m and len(re.findall(r"\b" + m.group(1) + r"\b", body)) <= 1:
                continue
            if re.match(r"\s+r\d+ = r\d+_undef;", ln):
                continue
            out2.append(ln)
        lines.append("")
        lines += out2
    open(os.path.join(OUT, "%s_pseudocode.txt" % core.name), "w", encoding="utf-8").write(NL.join(lines) + NL)
    print(core.name, "%.1fs" % (time.time() - t), "errors", errs, "lines", len(lines))
