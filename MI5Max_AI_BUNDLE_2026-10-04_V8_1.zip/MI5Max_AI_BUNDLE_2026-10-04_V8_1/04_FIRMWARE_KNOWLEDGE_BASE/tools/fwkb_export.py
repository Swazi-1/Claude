"""fwkb_export: write annotated disassembly, function catalog, xref tables (JSON/CSV/MD) for one core.
Name tables (optional, hand-curated, in ../annotations/): names_<A|B>.csv, ram_<A|B>.csv, periph_<A|B>.csv"""
import csv, json, os, re, collections, sys
from fwkb_analysis import *

HERE = os.path.dirname(os.path.abspath(__file__))
ANN = os.path.join(os.path.dirname(HERE), "annotations")


def load_csv(path):
    if not os.path.exists(path):
        return []
    with open(path, encoding="utf-8-sig", newline="") as fp:
        return [r for r in csv.DictReader(fp) if r and (r.get("addr") or r.get("file_off"))]


def parse_int(s):
    s = str(s).strip().lower().replace("0x", "")
    return int(s, 16)


def _psv(path):
    rows = []
    with open(path, encoding="utf-8") as fp:
        for line in fp:
            line = line.rstrip("\r\n")
            if not line.strip() or line.lstrip().startswith("#"):
                continue
            rows.append([x.strip() for x in line.split("|")])
    return rows


def load_names(core):
    """names_<core>*.psv : file_off|name|description|conf   (later files override earlier ones)"""
    import glob
    names, descs = {}, {}
    for p in sorted(glob.glob(os.path.join(ANN, "names_%s*.psv" % core.name))):
        for r in _psv(p):
            if len(r) < 2:
                continue
            fo = parse_int(r[0])
            names[fo] = r[1]
            # description may itself contain '|' (e.g. "x |= 4"): conf is the LAST field when it is a flag letter
            if len(r) >= 4 and r[-1] in ("C", "S", "L", "U"):
                dsc, cf = "|".join(r[2:-1]), r[-1]
            else:
                dsc, cf = (r[2] if len(r) > 2 else ""), (r[3] if len(r) > 3 else "")
            descs[fo] = (dsc, cf, os.path.basename(p))
    return names, descs


def load_ram(core):
    """ram_<core>.csv (seed) + ram_<core>*.psv : off|size|name|description|conf  (off = hex offset from 0x20000000)"""
    import glob
    ram = {}
    for r in load_csv(os.path.join(ANN, "ram_%s.csv" % core.name)):
        a = parse_int(r["addr"])
        ram[a] = (a, int(r.get("size") or 1), r.get("name", ""), r.get("desc", ""), r.get("conf", ""))
    for p in sorted(glob.glob(os.path.join(ANN, "ram_%s*.psv" % core.name))):
        for r in _psv(p):
            if len(r) < 3:
                continue
            a = 0x20000000 + parse_int(r[0])
            if len(r) >= 5 and r[-1] in ("C", "S", "L", "U"):
                dsc, cf = "|".join(r[3:-1]), r[-1]
            else:
                dsc, cf = (r[3] if len(r) > 3 else ""), (r[4] if len(r) > 4 else "")
            ram[a] = (a, int(r[1] or 1), r[2], dsc, cf)
    return sorted(ram.values())


def load_periph(core):
    per = []
    for r in load_csv(os.path.join(ANN, "periph_%s.csv" % core.name)):
        per.append((parse_int(r["addr"]), r.get("name", ""), r.get("desc", "")))
    per.sort()
    return per


class Namer:
    def __init__(self, core):
        self.core = core
        self.ram = load_ram(core)
        self.per = load_periph(core)
        self.per_map = {a: (n, dsc) for a, n, dsc in self.per}

    def ram_name(self, addr):
        # exact or covering entry
        best = None
        for a, sz, n, dsc, conf in self.ram:
            if a <= addr < a + max(sz, 1):
                best = (a, sz, n, dsc, conf)
                break
        return best

    def per_name(self, addr):
        if addr in self.per_map:
            return self.per_map[addr][0]
        if 0x42000000 <= addr < 0x44000000:
            off = addr - 0x42000000
            base = 0x40000000 + (off >> 5)
            bit = (off & 0x1F) >> 2
            bn = self.per_map.get(base & ~3)
            if bn:
                return "%s.bit%d" % (bn[0], (base & 3) * 8 + bit)
            return "0x%08X.bit%d(alias)" % (base, (base & 3) * 8 + bit)
        return None


def fmt_branch_ops(core, i, an, names):
    m = i.mnemonic.split(".")[0]
    op = i.op_str
    if m in ("bl", "blx", "b") or (len(m) == 3 and m[0] == "b" and m[1:] in CC_NAMES) or m in ("cbz", "cbnz"):
        def rep(mo):
            v = int(mo.group(1), 16)
            fo = core.fo(v)
            return "L%X" % fo if m in ("b", "cbz", "cbnz") or (len(m) == 3 and m[1:] in CC_NAMES) else an.fname(fo)
        return re.sub(r"#0x([0-9a-fA-F]+)", rep, op)
    return op


def write_listing(core, d, an, path, namer, names, descs):
    data = an.data
    lines = []
    # sort function entries
    fentries = sorted(an.funcs)
    owner = an.owner
    # label set: branch targets
    labels = set(d.block_targets.keys())
    # pool/data spans
    insn_sorted = sorted(d.instr)
    pos = core.lo
    func_at = {e: an.funcs[e] for e in fentries}
    # build ordered list of items: (offset, kind)
    items = []
    for o in insn_sorted:
        items.append((o, "i"))
    lit = set()
    for w in d.lit_words:
        lit.add(w)
    covered = bytearray(d.cover)
    # compute data spans = bytes with cover 0 or 3
    spans = []
    k = 0
    n = len(covered)
    while k < n:
        if covered[k] in (0, 3):
            j = k
            while j < n and covered[j] in (0, 3):
                j += 1
            spans.append((core.lo + k, core.lo + j))
            k = j
        else:
            k += 1
    for s, e in spans:
        items.append((s, "d", e))
    items.sort(key=lambda x: x[0])
    out = lines.append
    out("; %s  %s  file 0x%X..0x%X  runtime = file %s 0x%X" % (core.name, core.long_name, core.lo, core.hi, "+" if core.delta >= 0 else "-", abs(core.delta)))
    out("; ID syntax: %s:<file offset hex>.  Comments after ';' are machine-generated (constant propagation); verified names/descriptions come from annotations/*.csv" % core.name)
    out("")
    for it in items:
        o = it[0]
        if it[1] == "d":
            s, e = o, it[2]
            out("; ---- data/unclassified bytes %s:%X..%X (%d bytes)" % (core.name, s, e, e - s))
            p = s
            while p < e:
                if p % 4 == 0 and p + 4 <= e:
                    v = u32(data, p)
                    tag = ""
                    rg = region_of(core, v)
                    if (v & 1) and rg == "FLASH" and core.in_code(core.fo(v & ~1)):
                        tag = " ; ptr code %s" % an.fname(core.fo(v & ~1))
                    elif rg == "RAM":
                        rn_ = namer.ram_name(v)
                        tag = " ; RAM%s" % ((" <%s>" % rn_[2]) if rn_ else "")
                    elif rg == "PERIPH":
                        tag = " ; PERIPH%s" % ((" <%s>" % namer.per_name(v)) if namer.per_name(v) else "")
                    elif rg == "FLASH":
                        tag = " ; flash addr (file 0x%X)" % core.fo(v)
                    lbl = "<-- lit pool" if p in d.lit_words else ""
                    out("%s:%05X  %-12s .word 0x%08X%s %s" % (core.name, p, data[p:p + 4].hex(), v, tag, lbl))
                    p += 4
                else:
                    q = min(e, p + 4 - (p % 4)) if p % 4 else min(e, p + 1)
                    out("%s:%05X  %-12s .byte %s" % (core.name, p, data[p:q].hex(), ", ".join("0x%02X" % x for x in data[p:q])))
                    p = q
            continue
        if o in func_at:
            f = func_at[o]
            nm = names.get(o)
            out("")
            out("; " + "=" * 78)
            out("; FUNCTION %s:%05X  rt 0x%08X%s%s" % (core.name, o, core.rt(o) & 0xFFFFFFFF, ("  <%s>" % nm) if nm else "", "  [%s]" % ",".join(sorted(f.tags)) if f.tags else ""))
            if o in descs and descs[o][0]:
                out("; DESC (%s, %s): %s" % (descs[o][1], descs[o][2], descs[o][0]))
            callers = sorted(f.callers)
            out("; callers: %s%s" % (", ".join("%s:%X" % (core.name, c) for c in callers[:12]) or "-", " ..." if len(callers) > 12 else ""))
            if f.ptr_refs:
                out("; address-taken at: %s" % ", ".join("%s:%X" % (core.name, w) for w in f.ptr_refs[:8]))
            out("; " + "=" * 78)
        if o in labels and o not in func_at:
            out("L%X:" % o)
        i = an.img.dec(o)
        ops = fmt_branch_ops(core, i, an, names)
        ann = an.ann.get(o, [])
        # rename RAM/periph in annotation
        ann2 = []
        for a in ann:
            mm = re.match(r"(R|W) (RAM|PERIPH|mem|SCS|FLASH) 0x([0-9A-F]+)(.*)", a)
            if mm:
                addr = int(mm.group(3), 16)
                nmx = ""
                if mm.group(2) == "RAM":
                    r_ = namer.ram_name(addr)
                    if r_:
                        nmx = " <%s%s>" % (r_[2], "" if addr == r_[0] else "+0x%X" % (addr - r_[0]))
                elif mm.group(2) == "PERIPH":
                    pn = namer.per_name(addr)
                    if pn:
                        nmx = " <%s>" % pn
                a = "%s %s 0x%08X%s%s" % (mm.group(1), mm.group(2), addr, nmx, mm.group(4))
            else:
                mm = re.match(r"=0x([0-9A-F]+) \((RAM|PERIPH)\)", a)
                if mm:
                    addr = int(mm.group(1), 16)
                    nmx = ""
                    if mm.group(2) == "RAM":
                        r_ = namer.ram_name(addr)
                        if r_:
                            nmx = " <%s%s>" % (r_[2], "" if addr == r_[0] else "+0x%X" % (addr - r_[0]))
                    else:
                        pn = namer.per_name(addr)
                        if pn:
                            nmx = " <%s>" % pn
                    a = a + nmx
            ann2.append(a)
        cm = ("  ; " + " | ".join(ann2)) if ann2 else ""
        out("%s:%05X  %-9s %-7s %s%s" % (core.name, o, i.bytes.hex(), i.mnemonic, ops, cm))
    with open(path, "w", encoding="utf-8") as fp:
        fp.write("\n".join(lines) + "\n")


def func_summary(core, d, an, f, namer):
    ram_r, ram_w, per_r, per_w, fl = set(), set(), set(), set(), set()
    for a in f.accesses:
        if a.get("addr") is None:
            continue
        rg, addr = a["region"], a["addr"]
        if rg == "RAM":
            (ram_w if a["rw"] == "W" else ram_r).add(addr)
        elif rg == "PERIPH":
            (per_w if a["rw"] == "W" else per_r).add(addr)
        elif rg == "FLASH":
            fl.add(addr)
    callees = []
    for o, tl in f.calls.items():
        for t in tl:
            callees.append(t)
    tail = [t for tl in f.tail_calls.values() for t in tl]
    n_instr = len(f.blocks)
    sz = sum(d.instr[o] for o in f.blocks)
    mins = min(f.blocks) if f.blocks else f.entry
    maxe = max(o + d.instr[o] for o in f.blocks) if f.blocks else f.entry
    loops = 0
    for o in f.blocks:
        if d.kind.get(o) in ("b", "bcc"):
            for s in d.succ.get(o, ()):
                if s <= o and s in f.blocks:
                    loops += 1
    fpu = any(an.img.dec(o).mnemonic.startswith("v") for o in f.blocks)
    return dict(entry=f.entry, rt=core.rt(f.entry) & 0xFFFFFFFF, size=sz, n_instr=n_instr, hull=[mins, maxe], loops=loops, fpu=fpu,
                callers=sorted(f.callers), ptr_refs=sorted(f.ptr_refs), callees=sorted(set(callees)), tail_calls=sorted(set(tail)),
                indirect_calls=len([o for o in f.blocks if o in d.indirect_calls]),
                ram_r=sorted(ram_r), ram_w=sorted(ram_w), per_r=sorted(per_r), per_w=sorted(per_w), flash_refs=sorted(fl),
                tags=sorted(f.tags), shared=f.shared)


def export_all(core, d, an, outdir, tag=""):
    os.makedirs(outdir, exist_ok=True)
    names, descs = load_names(core)
    an.names = names
    namer = Namer(core)
    write_listing(core, d, an, os.path.join(outdir, "%s_annotated_disassembly%s.txt" % (core.name, tag)), namer, names, descs)
    summ = {}
    for e in sorted(an.funcs):
        summ[e] = func_summary(core, d, an, an.funcs[e], namer)
    with open(os.path.join(outdir, "%s_functions%s.json" % (core.name, tag)), "w", encoding="utf-8") as fp:
        json.dump({"%X" % k: v for k, v in summ.items()}, fp, indent=0)
    # RAM xref table
    ram_x = collections.defaultdict(lambda: {"R": set(), "W": set(), "w": set(), "vals": set()})
    per_x = collections.defaultdict(lambda: {"R": set(), "W": set(), "vals": set()})
    for a in an.accesses:
        if a["addr"] is None:
            continue
        if a["region"] == "RAM":
            x = ram_x[a["addr"]]
            x[a["rw"]].add(a["f"])
            x["w"].add(a["w"])
            if a["rw"] == "W" and a.get("val") is not None:
                x["vals"].add(a["val"])
        elif a["region"] == "PERIPH":
            x = per_x[a["addr"]]
            x[a["rw"]].add(a["f"])
            if a["rw"] == "W" and a.get("val") is not None:
                x["vals"].add(a["val"])
    cs = {}
    for tgt, lst in getattr(an, "callsites", {}).items():
        cs["%X" % tgt] = [["%X" % site, "%X" % fe] + [("%X" % v) if v is not None else None for v in args] for site, fe, args in lst]
    with open(os.path.join(outdir, "%s_callsites%s.json" % (core.name, tag)), "w", encoding="utf-8") as fp:
        json.dump(cs, fp, indent=0)
    ramj = {"%08X" % k: dict(R=sorted("%X" % x for x in v["R"]), W=sorted("%X" % x for x in v["W"]), width=sorted(v["w"]),
                              wvals=sorted(v["vals"])[:16]) for k, v in sorted(ram_x.items())}
    perj = {"%08X" % k: dict(R=sorted("%X" % x for x in v["R"]), W=sorted("%X" % x for x in v["W"]), wvals=sorted(v["vals"])[:24]) for k, v in sorted(per_x.items())}
    with open(os.path.join(outdir, "%s_ram_xrefs%s.json" % (core.name, tag)), "w", encoding="utf-8") as fp:
        json.dump(ramj, fp, indent=0)
    with open(os.path.join(outdir, "%s_periph_xrefs%s.json" % (core.name, tag)), "w", encoding="utf-8") as fp:
        json.dump(perj, fp, indent=0)
    return summ, ramj, perj
