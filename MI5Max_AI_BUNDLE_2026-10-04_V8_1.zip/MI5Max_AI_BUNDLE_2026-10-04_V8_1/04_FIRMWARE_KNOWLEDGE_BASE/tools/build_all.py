import sys, time, os, pickle
from fwkb_export import *
def _root(*p):
    """path inside the workspace root (two levels above tools/); portable"""
    import os as _o
    return _o.path.normpath(_o.path.join(_o.path.dirname(_o.path.abspath(__file__)), "..", "..", *p))
STOCK=_root("01_FIRMWARE", "2_ORIGINAL_STOCK", "01_STOCK_ORIGINAL.bin")
OUT=os.path.join(os.path.dirname(HERE),"data")
data=open(STOCK,"rb").read()
import hashlib; assert hashlib.sha256(data).hexdigest().startswith("015718dd8126")
which=sys.argv[1:] or ["A","B"]
for core in (CORE_A,CORE_B):
    if core.name not in which: continue
    t=time.time()
    names,_=load_names(core)
    import json
    manual=json.load(open(os.path.join(os.path.dirname(HERE),'annotations','manual_%s.json'%core.name)))
    d,an=full_analysis(data,core,names=names,manual=manual)
    summ,ramj,perj=export_all(core,d,an,OUT)
    print(core.name,"%.1fs"%(time.time()-t),"funcs",len(summ),"ram",len(ramj),"periph",len(perj))
