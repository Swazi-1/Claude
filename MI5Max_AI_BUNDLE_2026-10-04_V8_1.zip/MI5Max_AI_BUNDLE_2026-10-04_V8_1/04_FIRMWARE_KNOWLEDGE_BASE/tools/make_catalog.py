"""make_catalog: generate Markdown function catalog, RAM map and peripheral map for one core from the JSON xref data + annotations."""
import sys, os, json, glob, collections
from fwkb_export import *

KB = os.path.dirname(HERE)
DATA = os.path.join(KB, "data")


def short(desc, n=170):
    desc = desc.strip()
    if len(desc) <= n:
        return desc
    cut = desc[:n]
    k = cut.rfind(";")
    if k < 60:
        k = cut.rfind(",")
    if k < 60:
        k = n
    return cut[:k] + " ..."


def main(core):
    names, descs = load_names(core)
    ram = load_ram(core)
    per = load_periph(core)
    funcs = json.load(open(os.path.join(DATA, "%s_functions.json" % core.name)))
    ramx = json.load(open(os.path.join(DATA, "%s_ram_xrefs.json" % core.name)))
    perx = json.load(open(os.path.join(DATA, "%s_periph_xrefs.json" % core.name)))
    fn_name = lambda fo: names.get(fo, "")
    pn = {a: n for a, n, d in per}

    def ram_label(a):
        for aa, sz, n, d, c in ram:
            if aa <= a < aa + max(sz, 1):
                return n if a == aa else "%s+0x%X" % (n, a - aa)
        return "ram_%X" % (a - 0x20000000)

    ids = lambda fo: "%s:%X" % (core.name, fo)
    # ---------------- function catalog ----------------
    rows = sorted(funcs.items(), key=lambda kv: int(kv[0], 16))
    out = []
    out.append("# %s function catalog (%d functions)\n" % (core.name, len(rows)))
    out.append("Program %s = %s. ID syntax `%s:<file offset hex>`; runtime address = file offset %s 0x%X. Evidence flags: C confirmed from code, S strong, L likely, U unknown. `lib_*` = compiler/C-library routine (not application logic).\n" % (
        core.name, core.long_name, core.name, "+" if core.delta >= 0 else "-", abs(core.delta)))
    out.append("Columns: ID | runtime | size | name | conf | what it does | called from | calls | RAM written | peripheral regs written\n")
    out.append("| ID | rt | B | name | c | description | callers | callees | RAM W | periph W |")
    out.append("|---|---|---|---|---|---|---|---|---|---|")
    for k, v in rows:
        fo = int(k, 16)
        nm = names.get(fo, "")
        d = descs.get(fo, ("", "", ""))
        callers = sorted(set(v["callers"]))
        # map caller call-site offsets to owning function: use json hull search
        cl = []
        for c in callers[:6]:
            # find function containing call-site
            for k2, v2 in rows:
                h = v2["hull"]
                if h[0] <= c < h[1]:
                    cl.append(ids(int(k2, 16)))
                    break
        cl = sorted(set(cl))
        callees = [ids(c) + ("<%s>" % fn_name(c) if fn_name(c) else "") for c in v["callees"][:8]]
        rw = [ram_label(a) for a in v["ram_w"][:6]]
        pw = [pn.get(a, "0x%08X" % a) for a in v["per_w"][:5]]
        out.append("| %s | %X | %d | %s | %s | %s | %s | %s | %s | %s |" % (
            ids(fo), v["rt"], v["size"], nm or "-", d[1] or "", short(d[0]).replace("|", "/") or "-",
            ", ".join(cl) or ("ptr" if v["ptr_refs"] else "-"), ", ".join(callees) or "-", ", ".join(rw) or "-", ", ".join(pw) or "-"))
    open(os.path.join(KB, "%s_FUNCTION_CATALOG.md" % core.name), "w", encoding="utf-8").write("\n".join(out) + "\n")
    # ---------------- RAM map ----------------
    out = ["# %s RAM map (symbolic names, accessors)\n" % core.name,
           "RAM base 0x20000000 (offsets shown). Names come from annotations (ram_%s*.csv/psv); conf C/S/L/U as above. `R` = functions reading, `W` = functions writing (by name or ID).\n" % core.name,
           "| offset | size | name | conf | meaning | readers | writers | const-writes |", "|---|---|---|---|---|---|---|---|"]
    named = {}
    for a, sz, n, d, c in ram:
        named[a] = (sz, n, d, c)
    addrs = sorted(set(int(a, 16) for a in ramx) | set(named))
    for a in addrs:
        key = "%08X" % a
        x = ramx.get(key)
        nm = named.get(a)
        if nm is None:
            # interior cell of a named array/struct: show covering entry as name+0xN
            for aa in sorted(named):
                if aa < a < aa + max(named[aa][0], 1):
                    sz0, n0, d0, c0 = named[aa]
                    nm = (x["width"][0] if x else 1, "%s+0x%X" % (n0, a - aa), "(inside %s)" % n0, c0)
        r_ = ", ".join((fn_name(int(h, 16)) or ids(int(h, 16))) for h in (x["R"] if x else [])[:5])
        w_ = ", ".join((fn_name(int(h, 16)) or ids(int(h, 16))) for h in (x["W"] if x else [])[:5])
        vals = ",".join("%X" % q for q in (x["wvals"] if x else [])[:4])
        out.append("| 0x%X | %s | %s | %s | %s | %s | %s | %s |" % (
            a - 0x20000000, nm[0] if nm else (",".join(str(z) for z in x["width"]) if x else ""), nm[1] if nm else "-", nm[3] if nm else "",
            (nm[2] if nm else "").replace("|", "/") or "-", r_ or "-", w_ or "-", vals or "-"))
    open(os.path.join(KB, "%s_RAM_MAP.md" % core.name), "w", encoding="utf-8").write("\n".join(out) + "\n")
    # ---------------- peripheral map ----------------
    out = ["# %s peripheral registers touched by resolved accesses\n" % core.name,
           "| address | register | readers | writers | constants written |", "|---|---|---|---|---|"]
    for a, v in sorted(perx.items()):
        ai = int(a, 16)
        r_ = ", ".join((fn_name(int(h, 16)) or ids(int(h, 16))) for h in v["R"][:6])
        w_ = ", ".join((fn_name(int(h, 16)) or ids(int(h, 16))) for h in v["W"][:6])
        out.append("| 0x%08X | %s | %s | %s | %s |" % (ai, pn.get(ai, "-"), r_ or "-", w_ or "-", ",".join("%X" % q for q in v["wvals"][:8]) or "-"))
    open(os.path.join(KB, "%s_PERIPHERAL_MAP.md" % core.name), "w", encoding="utf-8").write("\n".join(out) + "\n")
    print(core.name, "catalog rows", len(rows), "ram rows", len(addrs), "periph rows", len(perx))


if __name__ == "__main__":
    for c in sys.argv[1:] or ["A", "B"]:
        main({"A": CORE_A, "B": CORE_B}[c])
