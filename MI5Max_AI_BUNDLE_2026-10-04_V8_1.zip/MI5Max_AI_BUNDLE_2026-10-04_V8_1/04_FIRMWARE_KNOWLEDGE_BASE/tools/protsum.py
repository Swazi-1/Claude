"""protsum: compact summary of one protection function: ram flags read/written (with bit masks), ROM thresholds, compare ops"""
import re,sys
txt=open('../data/A_pseudocode.txt',encoding='utf-8').read()
parts=re.split(r'\n(?=fn A:)',txt)
d={}
for p in parts:
    m=re.match(r'fn A:([0-9A-F]+)<([^>]*)>',p)
    if m: d[m.group(1)]=(m.group(2),p)
for a in sys.argv[1:]:
    nm,p=d[a]
    print('###',a,nm)
    # keep only informative lines
    for l in p.split('\n'):
        if re.search(r'mem\[0x|prot_flags|if \(|FA1|FC3|FCD|FD0|F72|GPIO|current_dir|temp_|cell_m|pack_|dir_state|sleep|latch|load_|return',l) and 'goto L' not in l.split('if')[0] or 'mem[' in l or 'prot_flags' in l:
            print(l.rstrip()[:150])
