"""fwkb_analysis: functions, constant propagation, memory-access resolution, cross-references.
Builds on fwkb_core.discover().  READ-ONLY."""
import collections, struct, re
from fwkb_core import *
from capstone.arm import (ARM_OP_REG, ARM_OP_IMM, ARM_OP_MEM, ARM_REG_PC, ARM_REG_LR, ARM_REG_SP)
import capstone.arm_const as AC

REGN = {"ip": "r12", "fp": "r11", "sb": "r9", "sl": "r10", "r13": "sp", "r14": "lr", "r15": "pc"}
M32 = 0xFFFFFFFF


def rn(i, reg):
    n = i.reg_name(reg)
    return REGN.get(n, n)


def region_of(core, v):
    if 0x20000000 <= v < 0x20010000:
        return "RAM"
    if 0x40000000 <= v < 0x60000000:
        return "PERIPH"
    if core.name == "A" and 0x42000000 <= v < 0x44000000:
        return "PERIPH"
    if 0xE0000000 <= v < 0xE0100000:
        return "SCS"
    if core.name == "A" and 0x08000000 <= v < 0x08040000:
        return "FLASH"
    if core.name == "B" and 0x20000 <= v < 0x20100:
        return "PERIPH"
    if core.name == "B" and 0 <= v < 0x20000:
        return "FLASH"
    return None


def width_of(m):
    mb = m.split(".")[0]
    if mb.startswith(("ldrb", "strb", "ldrsb", "ldrbt", "strbt", "ldrexb", "strexb")):
        return 1
    if mb.startswith(("ldrh", "strh", "ldrsh", "ldrht", "strht", "ldrexh", "strexh")):
        return 2
    if mb.startswith(("ldrd", "strd")):
        return 8
    if mb.startswith(("vldr", "vstr")):
        return 4
    return 4


class Func:
    def __init__(self, entry):
        self.entry = entry
        self.blocks = set()          # insn offsets
        self.calls = {}              # insn off -> [targets]
        self.tail_calls = {}
        self.indirect_call_sites = []
        self.callers = set()         # insn offs of call sites
        self.ptr_refs = []           # word offsets pointing to entry
        self.tags = set()
        self.accesses = []           # dicts
        self.lit_words = set()
        self.shared = False


class Analysis:
    def __init__(self, data, core, d):
        self.data = data
        self.core = core
        self.d = d
        self.img = d.img
        self.funcs = {}
        self.owner = {}              # insn off -> function entry
        self.ann = {}                # insn off -> list[str]
        self.resolved_calls = {}     # insn off -> target (indirect resolved)
        self.accesses = []           # all (func, insn, rw, width, addr, value)
        self.lit_val = {}

    # ---------- function extents ----------
    def build_functions(self):
        d, core = self.d, self.core
        all_entries = {o for o in d.func_entries if core.in_code(o) and d.cover[o - core.lo] == 1}
        self.external_calls = {o: sorted(t) for o, t in d.calls.items() if any(not core.in_code(x) for x in t)}
        weak = {o for o in all_entries if d.func_entries[o] <= {"pointer_word"}}
        strong = all_entries - weak
        self.owner = {}
        self.funcs = {}

        def flood(e, entries):
            f = self.funcs[e]
            stack = [e]
            while stack:
                o = stack.pop()
                if o in f.blocks:
                    continue
                if o in self.owner and self.owner[o] != e:
                    continue
                if o not in d.instr:
                    continue
                f.blocks.add(o)
                self.owner.setdefault(o, e)
                k = d.kind.get(o)
                for s_ in d.succ.get(o, ()):
                    if s_ != e and s_ in entries and k in ("b", "bcc"):
                        f.tail_calls.setdefault(o, []).append(s_)
                        continue
                    stack.append(s_)

        entries = set(strong)
        for e in sorted(strong):
            self.funcs[e] = Func(e)
            self.funcs[e].tags = set(d.func_entries[e])
        for e in sorted(strong):
            flood(e, entries)
        # weak (pointer-word-only) entries: keep only if not inside a function found by stronger evidence
        self.rejected_weak = []
        for e in sorted(weak):
            if e in self.owner:
                self.rejected_weak.append(e)
                continue
            self.funcs[e] = Func(e)
            self.funcs[e].tags = set(d.func_entries[e])
            entries.add(e)
            flood(e, entries)
        # orphans: instructions with no owner -> new functions
        changed = True
        while changed:
            changed = False
            for o in sorted(d.instr):
                if o not in self.owner:
                    self.funcs[o] = Func(o)
                    self.funcs[o].tags.add("orphan")
                    entries.add(o)
                    flood(o, entries)
                    changed = True
                    break
        self.entries = entries
        for e, f in self.funcs.items():
            for o in f.blocks:
                if self.owner.get(o) != e:
                    f.shared = True

    # ---------- constant propagation ----------
    def run_constprop(self):
        d, core, b = self.d, self.core, self.data
        for e, f in self.funcs.items():
            self._prop_func(f)

    def _word_at(self, fo):
        if 0 <= fo and fo + 4 <= len(self.data):
            return u32(self.data, fo)
        return None

    def _prop_func(self, f):
        d, core = self.d, self.core
        state_in = {f.entry: {}}
        work = [f.entry]
        seen_pass = collections.Counter()
        out_annotation = {}
        while work:
            o = work.pop()
            if o not in d.instr:
                continue
            seen_pass[o] += 1
            if seen_pass[o] > 12:
                continue
            st = dict(state_in.get(o, {}))
            i = self.img.dec(o)
            st = self._transfer(f, o, i, st)
            for s in d.succ.get(o, ()):
                if s not in f.blocks:
                    continue
                prev = state_in.get(s)
                if prev is None:
                    state_in[s] = dict(st)
                    work.append(s)
                else:
                    merged = {r: v for r, v in prev.items() if st.get(r) == v}
                    if merged != prev:
                        state_in[s] = merged
                        work.append(s)
        if not hasattr(self, "state_in_map"):
            self.state_in_map = {}
        self.state_in_map[f.entry] = state_in
        # final pass to record accesses/annotations with converged state
        f.accesses = []
        for o in sorted(f.blocks):
            st = dict(state_in.get(o, {}))
            i = self.img.dec(o)
            self._transfer(f, o, i, st, record=True)

    def _val(self, i, op, st):
        if op.type == ARM_OP_IMM:
            return op.imm & M32
        if op.type == ARM_OP_REG:
            r = rn(i, op.reg)
            if r == "pc":
                return (self.core.rt(self.cur_off) + 4) & M32
            return st.get(r)
        return None

    def _shifted(self, i, op, v):
        # apply operand shift if any
        if v is None:
            return None
        try:
            sh = op.shift
        except Exception:
            return v
        if sh.type == 0:
            return v
        t, n = sh.type, sh.value
        if t == AC.ARM_SFT_LSL:
            return (v << n) & M32
        if t == AC.ARM_SFT_LSR:
            return v >> n
        if t == AC.ARM_SFT_ASR:
            s = v - (1 << 32) if v & 0x80000000 else v
            return (s >> n) & M32
        return None

    def _note(self, o, text):
        self.ann.setdefault(o, [])
        if text not in self.ann[o]:
            self.ann[o].append(text)

    def _transfer(self, f, o, i, st, record=False):
        d, core = self.d, self.core
        self.cur_off = o
        m = i.mnemonic
        mb = m.split(".")[0]
        cond = is_cond(i)
        ops = i.operands
        # base mnemonic without condition suffix and 's'
        def kill(r):
            st.pop(r, None)
        def setv(r, v):
            if cond:
                st.pop(r, None)
            elif v is None:
                st.pop(r, None)
            else:
                st[r] = v & M32
        # --- calls ---
        if mb in ("bl", "blx"):
            tgt = None
            if ops and ops[0].type == ARM_OP_REG:
                v = st.get(rn(i, ops[0].reg))
                if v is not None and v & 1:
                    tgt = core.fo(v & ~1)
                    self.resolved_calls[o] = tgt
                    if record:
                        self._note(o, "indirect call -> %s" % self.fname(tgt))
            elif ops and ops[0].type == ARM_OP_IMM:
                tgt = core.fo(ops[0].imm)
            if record and tgt is not None:
                f.calls.setdefault(o, [])
                if tgt not in f.calls[o]:
                    f.calls[o].append(tgt)
                self._note(o, "call %s" % self.fname(tgt))
                if not hasattr(self, "callsites"):
                    self.callsites = {}
                self.callsites.setdefault(tgt, []).append((o, f.entry, [st.get(r) for r in ("r0", "r1", "r2", "r3")]))
            for r in ("r0", "r1", "r2", "r3", "r12", "lr"):
                kill(r)
            return st
        # --- literal / pc-relative ---
        is_ldr = mb in ("ldr", "ldrb", "ldrh", "ldrsb", "ldrsh", "ldrd", "vldr")
        is_str = mb in ("str", "strb", "strh", "strd", "vstr")
        if mb == "adr" or (mb in ("add", "addw", "sub", "subw") and len(ops) >= 2 and ops[1].type == ARM_OP_REG and rn(i, ops[1].reg) == "pc"):
            dst = rn(i, ops[0].reg)
            base = (core.rt(o) + 4) & ~3
            imm = ops[-1].imm if ops[-1].type == ARM_OP_IMM else 0
            v = base + (imm if mb.startswith(("add", "adr")) else -imm)
            setv(dst, v)
            if record:
                self._classify_note(o, v, "adr")
            return st
        if is_ldr or is_str:
            memop = None
            for op in ops:
                if op.type == ARM_OP_MEM:
                    memop = op
            if memop is not None:
                w = width_of(m)
                if mb in ("vldr", "vstr") and re.search(r"\bd\d+", i.op_str):
                    w = 8
                base_reg = rn(i, memop.mem.base) if memop.mem.base else None
                addr = None
                if base_reg == "pc":
                    pc = (core.rt(o) + 4) & ~3
                    ea = pc + memop.mem.disp
                    fo = core.fo(ea)
                    addr = ("lit", fo)
                    val = self._word_at(fo) if w == 4 else None
                    if mb == "ldr" and w == 4:
                        dst = rn(i, ops[0].reg)
                        setv(dst, val)
                        if record and val is not None:
                            self.lit_val[fo] = val
                            f.lit_words.add(fo)
                            self._classify_note(o, val, "=")
                    else:
                        for op in ops:
                            if op.type == ARM_OP_REG and is_ldr:
                                kill(rn(i, op.reg))
                    return st
                bv = st.get(base_reg) if base_reg else None
                idx_v = None
                if memop.mem.index:
                    iv = st.get(rn(i, memop.mem.index))
                    if iv is not None:
                        idx_v = (iv << memop.mem.lshift) & M32 if memop.mem.lshift else iv
                        if memop.subtracted:
                            idx_v = -idx_v
                if bv is not None and (not memop.mem.index or idx_v is not None):
                    addr = (bv + memop.mem.disp + (idx_v or 0)) & M32
                    if record:
                        sv = None
                        if is_str:
                            for op in ops:
                                if op.type == ARM_OP_REG:
                                    sv = st.get(rn(i, op.reg))
                                    break
                        rg = region_of(core, addr)
                        rec = dict(f=f.entry, o=o, rw=("W" if is_str else "R"), w=w, addr=addr, region=rg, val=sv, mn=m)
                        f.accesses.append(rec)
                        self.accesses.append(rec)
                        self._note(o, "%s %s%+d [%s]" % ("W" if is_str else "R", "", 0, "%s 0x%08X" % (rg or "?", addr)) if False else "%s %s 0x%08X%s" % ("W" if is_str else "R", rg or "mem", addr, (" =0x%X" % sv) if sv is not None else ""))
                elif record and base_reg is not None and base_reg not in ("sp",):
                    f.accesses.append(dict(f=f.entry, o=o, rw=("W" if is_str else "R"), w=w, addr=None, region="IND", base=base_reg, disp=memop.mem.disp, mn=m))
                # destinations
                if is_ldr:
                    # constant table load from flash image
                    dst = rn(i, ops[0].reg)
                    if bv is not None and mb == "ldr" and w == 4 and not memop.mem.index and region_of(core, bv + memop.mem.disp) == "FLASH":
                        fo = core.fo(bv + memop.mem.disp) if core.name == "A" else core.fo(bv + memop.mem.disp)
                        wv = self._word_at(fo) if 0 <= fo < len(self.data) else None
                        setv(dst, wv)
                    else:
                        kill(dst)
                        if mb in ("ldrd",):
                            kill(rn(i, ops[1].reg))
                # writeback
                if i.writeback and base_reg:
                    if bv is not None and not memop.mem.index:
                        # pre-indexed gives bv+disp, post-indexed: capstone puts disp in operand imm
                        st[base_reg] = (bv + memop.mem.disp) & M32 if memop.mem.disp else bv
                    else:
                        kill(base_reg)
                    # post-index immediate form
                    for op in ops:
                        if op.type == ARM_OP_IMM and bv is not None and not memop.mem.disp:
                            st[base_reg] = (bv + op.imm) & M32
                return st
        # --- ldm / stm ---
        if mb.startswith(("ldm", "stm", "ldmia", "stmia", "ldmdb", "stmdb", "pop", "push")):
            regs = [rn(i, op.reg) for op in ops if op.type == ARM_OP_REG]
            if mb in ("push",):
                return st
            if mb == "pop":
                for r in regs:
                    kill(r)
                return st
            if mb.startswith("ldm"):
                base = regs[0] if regs else None
                bv = st.get(base) if base else None
                for r in regs[1:]:
                    kill(r)
                if record and bv is not None:
                    for q in range(len(regs) - 1):
                        rec = dict(f=f.entry, o=o, rw="R", w=4, addr=(bv + 4 * q) & M32, region=region_of(core, bv + 4 * q), val=None, mn=m)
                        f.accesses.append(rec); self.accesses.append(rec)
                if i.writeback and base:
                    if bv is not None:
                        st[base] = (bv + 4 * (len(regs) - 1)) & M32
                    else:
                        kill(base)
                return st
            if mb.startswith("stm"):
                base = regs[0] if regs else None
                bv = st.get(base) if base else None
                if record and bv is not None:
                    for q, r in enumerate(regs[1:]):
                        rec = dict(f=f.entry, o=o, rw="W", w=4, addr=(bv + 4 * q) & M32, region=region_of(core, bv + 4 * q), val=st.get(r), mn=m)
                        f.accesses.append(rec); self.accesses.append(rec)
                if i.writeback and base:
                    if bv is not None:
                        st[base] = (bv + 4 * (len(regs) - 1)) & M32
                    else:
                        kill(base)
                return st
        # --- ALU ---
        if mb in ("mov", "movs", "movw", "mvn", "mvns"):
            dst = rn(i, ops[0].reg)
            v = self._val(i, ops[1], st) if len(ops) > 1 else None
            if v is not None and ops[1].type == ARM_OP_REG:
                v = self._shifted(i, ops[1], v)
            if v is not None and mb.startswith("mvn"):
                v = (~v) & M32
            if dst == "pc":
                return st
            setv(dst, v)
            return st
        if mb == "movt":
            dst = rn(i, ops[0].reg)
            old = st.get(dst)
            if old is None:
                kill(dst)
            else:
                setv(dst, (old & 0xFFFF) | ((ops[1].imm & 0xFFFF) << 16))
            return st
        if mb in ("add", "adds", "addw", "sub", "subs", "subw", "rsb", "rsbs", "and", "ands", "orr", "orrs", "eor", "eors", "bic", "bics", "lsl", "lsls", "lsr", "lsrs", "asr", "asrs", "ror", "rors", "mul", "muls", "uxtb", "uxth", "sxtb", "sxth", "rev", "rev16"):
            if not ops or ops[0].type != ARM_OP_REG:
                return st
            dst = rn(i, ops[0].reg)
            if dst in ("sp",) and mb.startswith(("add", "sub")):
                return st
            if mb in ("uxtb", "uxth", "sxtb", "sxth", "rev", "rev16"):
                v = self._val(i, ops[1], st) if len(ops) > 1 else None
                if v is None:
                    kill(dst)
                    return st
                if mb == "uxtb": v &= 0xFF
                elif mb == "uxth": v &= 0xFFFF
                elif mb == "sxtb": v = (v & 0xFF) - 0x100 if v & 0x80 else v & 0xFF
                elif mb == "sxth": v = (v & 0xFFFF) - 0x10000 if v & 0x8000 else v & 0xFFFF
                else:
                    kill(dst); return st
                setv(dst, v & M32)
                return st
            if len(ops) == 2:
                a = st.get(dst)
                bo = ops[1]
                bval = self._val(i, bo, st)
                if bo.type == ARM_OP_REG:
                    bval = self._shifted(i, bo, bval)
            else:
                ao, bo = ops[1], ops[2]
                a = self._val(i, ao, st)
                bval = self._val(i, bo, st)
                if bo.type == ARM_OP_REG:
                    bval = self._shifted(i, bo, bval)
            if a is None or bval is None:
                kill(dst)
                return st
            base = mb.rstrip("s") if mb not in ("lsls", "lsrs", "asrs", "rors", "muls", "movs", "subs", "adds") else mb[:-1]
            if mb in ("lsls", "lsrs", "asrs", "rors", "muls", "adds", "subs", "rsbs", "ands", "orrs", "eors", "bics"):
                base = mb[:-1]
            else:
                base = mb
            base = base.replace("addw", "add").replace("subw", "sub")
            if base == "add": v = a + bval
            elif base == "sub": v = a - bval
            elif base == "rsb": v = bval - a
            elif base == "and": v = a & bval
            elif base == "orr": v = a | bval
            elif base == "eor": v = a ^ bval
            elif base == "bic": v = a & ~bval
            elif base == "lsl": v = (a << (bval & 0xFF)) if (bval & 0xFF) < 32 else 0
            elif base == "lsr": v = (a >> (bval & 0xFF)) if (bval & 0xFF) < 32 else 0
            elif base == "asr":
                s = a - (1 << 32) if a & 0x80000000 else a
                v = s >> min(bval & 0xFF, 31)
            elif base == "ror":
                n = bval & 31
                v = ((a >> n) | (a << (32 - n))) if n else a
            elif base == "mul": v = a * bval
            else:
                kill(dst); return st
            setv(dst, v & M32)
            return st
        if mb in ("cmp", "cmn", "tst", "teq", "nop", "it", "dmb", "dsb", "isb", "wfi", "wfe", "cpsid", "cpsie", "b", "bx", "cbz", "cbnz", "tbb", "tbh", "svc", "bkpt", "udf", "sev", "yield", "msr"):
            return st
        # unknown: kill written registers
        try:
            _, wr = i.regs_access()
            for r in wr:
                nm = REGN.get(i.reg_name(r), i.reg_name(r))
                kill(nm)
        except Exception:
            st.clear()
        return st

    def _classify_note(self, o, v, kind):
        core = self.core
        rg = region_of(core, v)
        if rg == "FLASH":
            fo = core.fo(v & ~1) if core.name == "A" else core.fo(v & ~1)
            if (v & 1) and core.in_code(fo):
                self._note(o, "%s0x%X -> code %s" % (kind, v, self.fname(fo)))
                return
            self._note(o, "%s0x%X (flash, file 0x%X)" % (kind, v, core.fo(v)))
        elif rg:
            self._note(o, "%s0x%X (%s)" % (kind, v, rg))
        else:
            self._note(o, "%s0x%X" % (kind, v & M32))

    def fname(self, fo):
        if fo in getattr(self, "names", {}):
            return "%s:%X<%s>" % (self.core.name, fo, self.names[fo])
        return "%s:%X" % (self.core.name, fo)

    # ---------- cross references ----------
    def build_xrefs(self):
        d = self.d
        for e, f in self.funcs.items():
            for o, tl in f.calls.items():
                for t in tl:
                    if t in self.funcs:
                        self.funcs[t].callers.add(o)
            for o, tl in f.tail_calls.items():
                for t in tl:
                    if t in self.funcs:
                        self.funcs[t].callers.add(o)
        ptrs = scan_pointers(self.data, self.core)
        for t, ws in ptrs.items():
            if t in self.funcs:
                self.funcs[t].ptr_refs = list(ws)


def full_analysis(data, core, manual_seeds=(), names=None, iterations=3, manual=None):
    d = discover(data, core, manual)
    for s in list(manual_seeds) + list((manual or {}).get("seeds", [])):
        if d.cover[s - core.lo] == 0:
            d.trial(s, "manual", min_new=1)
    an = None
    for it in range(iterations):
        an = Analysis(data, core, d)
        an.names = names or {}
        an.build_functions()
        an.run_constprop()
        # indirect calls resolved -> feed back
        newseeds = 0
        for o, t in an.resolved_calls.items():
            if core.in_code(t) and d.cover[t - core.lo] == 0:
                if d.trial(t, "resolved_indirect", min_new=1):
                    newseeds += 1
            elif core.in_code(t) and d.cover[t - core.lo] == 1:
                d.func_entries.setdefault(t, set()).add("resolved_indirect")
        # literal words that are code pointers
        for fo, v in an.lit_val.items():
            if (v & 1) and region_of(core, v) == "FLASH":
                t = core.fo(v & ~1)
                if core.in_code(t) and d.cover[t - core.lo] == 0:
                    if d.trial(t, "literal_pointer", min_new=1):
                        newseeds += 1
                elif core.in_code(t) and d.cover[t - core.lo] == 1:
                    d.func_entries.setdefault(t, set()).add("literal_pointer")
        if not newseeds:
            break
        for _ in range(4):
            a = d.heuristic_pass(); b2 = d.gap_start_pass()
            if not (a or b2):
                break
    an.build_xrefs()
    return d, an
