# A peripheral registers touched by resolved accesses

| address | register | readers | writers | constants written |
|---|---|---|---|---|
| 0x40001820 | - | SystemInit, stop_mode_enter_regulator | SystemInit, stop_mode_enter_regulator | - |
| 0x40002800 | RTC_TSH | rtc_get_time | rtc_set_time | - |
| 0x40002804 | RTC_DATE | rtc_get_date | rtc_set_date | - |
| 0x40002808 | RTC_CTRL | rtc_it_config, rtc_set_time, rtc_set_hour_format, rtc_wakeup_timer_cmd, rtc_get_flag_status, rtc_init | rtc_it_config, rtc_set_hour_format, rtc_wakeup_timer_cmd, rtc_init | - |
| 0x4000280C | RTC_INITSTS | rtc_clear_wakeup_flag, rtc_wakeup_timer_cmd, rtc_enter_init_mode, rtc_exit_init_mode, rtc_get_flag_status, rtc_wait_sync | rtc_clear_wakeup_flag, rtc_enter_init_mode, rtc_exit_init_mode, rtc_wait_sync | 80 |
| 0x40002810 | RTC_PRE | rtc_init | rtc_init | - |
| 0x40002814 | RTC_WKUPT | - | rtc_set_wakeup_reload | - |
| 0x40002824 | RTC_WRP | - | rtc_it_config, rtc_set_time, rtc_set_hour_format, rtc_wakeup_timer_cmd, rtc_init, rtc_set_date | 53,CA,FF |
| 0x40002840 | RTC_TMPCFG | rtc_get_flag_status | - | - |
| 0x40003000 | IWDG_KEY | - | pack_power_state_machine, task_protection_and_wdt, main_init_a, pre_shutdown_pins_and_reinit, iwdg_feed_and_gpio_table, iwdg_feed | AAAA,CCCC |
| 0x40003004 | IWDG_PREDIV | - | iwdg_set_prescaler | - |
| 0x40003008 | IWDG_RELV | - | iwdg_set_reload | - |
| 0x40004800 | USART3_STS | USART3_IRQHandler | - | - |
| 0x40004804 | USART3_DAT | USART3_IRQHandler | - | - |
| 0x40005800 | I2C2_CTRL1 | i2c_master_write_read | i2c_master_write_read | - |
| 0x40007000 | PWR_CTRL1 | SystemInit, stop_mode_enter_regulator, enter_low_power_wait | stop_mode_enter_regulator, enter_low_power_wait | - |
| 0x40007008 | PWR_CTRL3 | enter_low_power_wait | enter_low_power_wait | - |
| 0x40007010 | PWR_STS2 | stop_mode_enter_regulator, enter_low_power_wait | - | - |
| 0x40010400 | EXTI_IMASK | exti_get_pending_masked, exti_init_line, gpio_init_from_struct | exti_init_line, gpio_init_from_struct | - |
| 0x40010404 | EXTI_EMASK | exti_init_line, gpio_init_from_struct | exti_init_line, gpio_init_from_struct | - |
| 0x40010408 | EXTI_RT_CFG | exti_init_line, gpio_init_from_struct | exti_init_line, gpio_init_from_struct | - |
| 0x4001040C | EXTI_FT_CFG | exti_init_line, gpio_init_from_struct | exti_init_line, gpio_init_from_struct | - |
| 0x40010414 | EXTI_PEND | exti_get_pending_masked | exti_clear_pending | - |
| 0x40010818 | GPIOA_PBSC | - | pre_shutdown_pins_and_reinit | 4 |
| 0x40010C18 | GPIOB_PBSC | - | pack_power_state_machine, bq_fault_response_1, pre_shutdown_pins_and_reinit, pb14_ctrl_logic, chg_ot_pb15_inhibit, chg_ut_pb15_inhibit | 2,4000,8000 |
| 0x40010C28 | GPIOB_PBC | - | pack_power_state_machine, bq_fault_response_1, power_rail_sequence_a, pb14_ctrl_logic, chg_ot_pb15_inhibit, chg_ut_pb15_inhibit | 2,4000,8000 |
| 0x40013800 | USART1_STS | USART1_IRQHandler | - | - |
| 0x40013804 | USART1_DAT | USART1_IRQHandler | - | - |
| 0x40020004 | DMA1_INTCLR | dma_channel_deinit | dma_channel_deinit | - |
| 0x40021000 | RCC_CTRL | clock_config_hsi_pll_96, SystemInit, rcc_hsi_enable_wait, rcc_hse_config, rcc_hsi_set, rcc_get_flag | clock_config_hsi_pll_96, SystemInit, rcc_hsi_enable_wait, rcc_hse_config, rcc_hsi_set | - |
| 0x40021004 | RCC_CFG | clock_config_hsi_pll_96, SystemInit, rcc_cfg_ahb_prescaler, rcc_cfg_apb1_prescaler, rcc_cfg_apb2_prescaler, rcc_config_pll | clock_config_hsi_pll_96, SystemInit, rcc_cfg_ahb_prescaler, rcc_cfg_apb1_prescaler, rcc_cfg_apb2_prescaler, rcc_config_pll | - |
| 0x40021008 | RCC_CLKINT | - | SystemInit | 4BF8000 |
| 0x4002100C | RCC_APB2PRST | rcc_apb2_reset_cmd | rcc_apb2_reset_cmd | - |
| 0x40021010 | RCC_APB1PRST | rcc_apb1_reset_cmd | rcc_apb1_reset_cmd | - |
| 0x40021014 | RCC_AHBPCLKEN | rcc_ahb_clock_cmd | rcc_ahb_clock_cmd | - |
| 0x40021018 | RCC_APB2PCLKEN | rcc_apb2_clock_cmd | rcc_apb2_clock_cmd | - |
| 0x4002101C | RCC_APB1PCLKEN | SystemInit, rcc_apb1_clock_cmd | SystemInit, rcc_apb1_clock_cmd | - |
| 0x40021020 | RCC_LDCTRL | rcc_ldctrl_set, rcc_get_flag | rcc_ldctrl_set | - |
| 0x40021024 | RCC_CTRLSTS | vbus_wake_flag_update, SystemInit, rcc_set_rtc_clock, rcc_get_clocks, rcc_get_flag | SystemInit, rcc_set_rtc_clock | - |
| 0x40021028 | RCC_AHBPRST | rcc_ahb_reset_cmd | rcc_ahb_reset_cmd | - |
| 0x4002102C | RCC_CFG2 | rcc_cfg2_set_low, rcc_cfg2_set_adc, rcc_get_clocks | SystemInit, rcc_cfg2_set_low, rcc_cfg2_set_adc | 0 |
| 0x40021030 | RCC_CFG3 | - | SystemInit | 3800 |
| 0x40021034 | RCC_RDCTRL | - | SystemInit | 0 |
| 0x40021040 | RCC_PLLHSIPRE | clock_config_hsi_pll_96, rcc_config_pll, rcc_get_clocks | clock_config_hsi_pll_96, SystemInit, rcc_config_pll | 0 |
| 0x40022000 | FLASH_AC | clock_config_hsi_pll_96, SystemInit, flash_set_latency_bits, flash_set_latency | clock_config_hsi_pll_96, SystemInit, flash_set_latency_bits, flash_set_latency | - |
| 0x40022004 | FLASH_KEY | - | flash_unlock | 45670123,CDEF89AB |
| 0x4002200C | FLASH_STS | flash_clear_status, flash_get_status | flash_clear_status | - |
| 0x40022010 | FLASH_CTRL | flash_erase_page, flash_lock, flash_program_word | flash_erase_page, flash_lock, flash_program_word | - |
| 0x40022014 | FLASH_ADDR | - | flash_erase_page | - |
| 0x420E0020 | - | - | pwr_ctrl1_bit8 | - |
| 0x42420060 | - | - | rcc_ctrl_pll_enable | - |
| 0x4242043C | - | - | rcc_ldctrl_rtc_enable | - |
| 0x42420480 | - | - | rcc_ctrlsts_bit0_set | - |
