# B peripheral registers touched by resolved accesses

| address | register | readers | writers | constants written |
|---|---|---|---|---|
| 0x00020000 | FLASH_CFG | flash_nvr_read, flash_erase_page, flash_program, hardware_init, flash_write_word | flash_nvr_read, flash_erase_page, flash_program, hardware_init, flash_write_word | - |
| 0x00020004 | FLASH_ADDR | - | flash_nvr_read, flash_erase_page, flash_program, flash_write_word | 59000000,95000000 |
| 0x00020008 | FLASH_WDATA | - | flash_program, flash_write_word | - |
| 0x0002000C | FLASH_RDATA | flash_nvr_read, flash_write_word | - | - |
| 0x40000008 | SYS_AFE_DBG | pll_enable | - | - |
| 0x40000010 | SYS_AFE_REG0 | - | afe_regs_clear | 0 |
| 0x40000014 | SYS_AFE_REG1 | dac_cfg | clock_init, dac_cfg | 1 |
| 0x40000018 | SYS_AFE_REG2 | - | afe_regs_clear | 0 |
| 0x4000001C | SYS_AFE_REG3 | cmp_init, dac_cfg | cmp_init, dac_cfg | - |
| 0x40000024 | SYS_AFE_REG5 | afe_reg5_set, sysclk_select | clock_init, afe_reg5_set, sysclk_select | B07D |
| 0x40000028 | SYS_AFE_REG6 | sysclk_select, pll_enable, ISR_WAKE_reset | sysclk_select, pll_enable, ISR_WAKE_reset | - |
| 0x4000005C | SYS_AFE_DAC_CTRL | dac_cfg | dac_cfg | - |
| 0x40000060 | SYS_AFE_DAC0 | - | dac_write, power_stage_selftest | 33,CB |
| 0x40000064 | SYS_AFE_DAC1 | - | dac_write | - |
| 0x40000068 | SYS_AFE_DAC0_AMC | - | dac_cfg | - |
| 0x4000006C | SYS_AFE_DAC0_DC | - | dac_cfg | - |
| 0x40000070 | SYS_AFE_DAC1_AMC | - | dac_cfg | - |
| 0x40000074 | SYS_AFE_DAC1_DC | - | dac_cfg | - |
| 0x40000080 | SYS_CLK_CFG | sysclk_select | sysclk_select, ISR_WAKE_reset | 0 |
| 0x40000090 | SYS_CLK_DIV0 | - | i2c0_init | D |
| 0x40000098 | SYS_CLK_DIV2 | - | clock_init | 0 |
| 0x4000009C | SYS_CLK_FEN | clk_gate_set | clock_init, clk_gate_set | 3CC06 |
| 0x400000A0 | - | flash_nvr_read | - | - |
| 0x400000A4 | SYS_SFT_RST | - | clock_init, periph_reset | 0,FFFFF7FF |
| 0x400000A8 | SYS_PROTECT | - | cmp_init, clock_init, dac_cfg, flash_erase_page, flash_program, hardware_init | 0,1,7A83,FFFF |
| 0x400000D0 | SYS_FLSE | - | flash_erase_page | 8FCA |
| 0x400000D4 | SYS_FLSP | - | flash_erase_page, flash_program, flash_write_word | 0,8F35 |
| 0x40010200 | CMP_IE | - | power_stage_selftest | 0 |
| 0x40010204 | CMP_IF | power_stage_selftest | power_stage_selftest, system_reset_request | 1 |
| 0x40010208 | CMP_TCLK | - | cmp_init | 8 |
| 0x4001020C | CMP_CFG | - | cmp_init | 2 |
| 0x40010300 | HALL0_CFG | - | hall_init | - |
| 0x40010304 | HALL0_INFO | hall_get_bit | hall_init | 0 |
| 0x4001030C | HALL0_TH | - | hall_init | - |
| 0x40010400 | ADC0_DAT0 | ISR_MCPWM0 | - | - |
| 0x40010404 | ADC0_DAT1 | ISR_MCPWM0 | - | - |
| 0x40010408 | ADC0_DAT2 | ISR_MCPWM0 | - | - |
| 0x4001040C | ADC0_DAT3 | ISR_MCPWM0 | - | - |
| 0x40010410 | ADC0_DAT4 | ISR_MCPWM0 | - | - |
| 0x40010414 | ADC0_DAT5 | ISR_MCPWM0 | - | - |
| 0x40010418 | ADC0_DAT6 | ISR_MCPWM0 | - | - |
| 0x40010474 | ADC0_CFG | adc_setup_all | adc_setup_all | - |
| 0x40010480 | ADC0_DC0 | - | adc_init | - |
| 0x40010484 | ADC0_AMC0 | - | adc_init | - |
| 0x40010488 | ADC0_DC1 | - | adc_init | - |
| 0x4001048C | ADC0_AMC1 | - | adc_init | - |
| 0x40010494 | ADC0_IF | ISR_MCPWM0 | ISR_MCPWM0 | - |
| 0x40010500 | ADC1_DAT0 | ISR_MCPWM0 | - | - |
| 0x40010504 | ADC1_DAT1 | ISR_MCPWM0 | - | - |
| 0x40010508 | ADC1_DAT2 | ISR_MCPWM0 | - | - |
| 0x4001050C | ADC1_DAT3 | ISR_MCPWM0 | - | - |
| 0x40010510 | ADC1_DAT4 | ISR_MCPWM0 | - | - |
| 0x40010514 | ADC1_DAT5 | ISR_MCPWM0 | - | - |
| 0x40010518 | ADC1_DAT6 | ISR_MCPWM0 | - | - |
| 0x40010574 | ADC1_CFG | adc_setup_all | adc_setup_all | - |
| 0x40010580 | ADC1_DC0 | - | adc_init | - |
| 0x40010584 | ADC1_AMC0 | - | adc_init | - |
| 0x40010588 | ADC1_DC1 | - | adc_init | - |
| 0x4001058C | ADC1_AMC1 | - | adc_init | - |
| 0x40010594 | ADC1_IF | ISR_MCPWM0 | ISR_MCPWM0 | - |
| 0x40010C00 | MCPWM0_TH00 | - | ISR_MCPWM0, throttle_mode_block, svpwm_output | 0 |
| 0x40010C04 | MCPWM0_TH01 | - | ISR_MCPWM0, throttle_mode_block, svpwm_output | 0 |
| 0x40010C08 | MCPWM0_TH10 | - | ISR_MCPWM0, throttle_mode_block, svpwm_output | 0 |
| 0x40010C0C | MCPWM0_TH11 | - | ISR_MCPWM0, throttle_mode_block, svpwm_output | 0 |
| 0x40010C10 | MCPWM0_TH20 | - | ISR_MCPWM0, throttle_mode_block, svpwm_output | 0 |
| 0x40010C14 | MCPWM0_TH21 | - | ISR_MCPWM0, throttle_mode_block, svpwm_output | 0 |
| 0x40010C38 | MCPWM0_TMR2 | - | pwm_init | F473 |
| 0x40010C40 | MCPWM0_TH0 | - | pwm_init | C00 |
| 0x40010C50 | MCPWM0_UPDATE | - | pwm_init | FFFF |
| 0x40010C60 | MCPWM0_DTH00 | - | pwm_init | 4C |
| 0x40010C64 | MCPWM0_DTH01 | - | pwm_init | 4C |
| 0x40010C68 | MCPWM0_DTH10 | - | pwm_init | 4C |
| 0x40010C6C | MCPWM0_DTH11 | - | pwm_init | 4C |
| 0x40010C70 | MCPWM0_FLT | - | pwm_init | 0 |
| 0x40010C74 | MCPWM0_SDCFG | - | pwm_init | 10 |
| 0x40010C7C | MCPWM0_TCLK | - | pwm_init | 44 |
| 0x40010C80 | MCPWM0_IE0 | - | pwm_init | 2 |
| 0x40010C84 | MCPWM0_IF0 | ISR_MCPWM0 | ISR_MCPWM0 | - |
| 0x40010C94 | MCPWM0_EIF | ISR_MCPWM0, power_stage_selftest | ISR_MCPWM0, pwm_init, power_stage_selftest | 10,FFFF |
| 0x40010CA0 | MCPWM0_IO01 | - | pwm_arm_special, pwm_arm_normal, pwm_init, power_stage_selftest | C0C,4040,4949 |
| 0x40010CA4 | MCPWM0_IO23 | - | pwm_arm_special, pwm_arm_normal, pwm_init, power_stage_selftest | 4040,4049 |
| 0x40010CB0 | MCPWM0_FAIL012 | pwm_moe_off, pwm_arm_special, pwm_arm_normal, power_stage_selftest, ISR_WAKE_reset | pwm_moe_off, pwm_arm_special, pwm_arm_normal, pwm_init, power_stage_selftest, ISR_WAKE_reset | 110 |
| 0x40010CB4 | MCPWM0_FAIL345 | ISR_WAKE_reset | ISR_WAKE_reset | - |
| 0x40010CC0 | MCPWM0_PRT | - | pwm_moe_off, pwm_arm_special, pwm_arm_normal, pwm_init, power_stage_selftest, ISR_WAKE_reset | 0,AEAD,CAFE,DEAD |
| 0x40010D00 | GPIO0_PIE | gpio_init | gpio_init | - |
| 0x40010D04 | GPIO0_POE | gpio_init | gpio_init | - |
| 0x40010D24 | GPIO0_F7654 | gpio_init | gpio_init | - |
| 0x40010D2C | GPIO0_FFEDC | gpio_init | gpio_init | - |
| 0x40010D40 | GPIO1_PIE | - | gpio_init | C00 |
| 0x40010D44 | GPIO1_POE | gpio_init | gpio_init | - |
| 0x40010D60 | GPIO1_F3210 | gpio_init | gpio_init | - |
| 0x40010D64 | GPIO1_F7654 | gpio_init | gpio_init | - |
| 0x40010D68 | GPIO1_FBA98 | gpio_init | gpio_init | - |
| 0x40010D80 | GPIO2_PIE | gpio_init | gpio_init | - |
| 0x40010D84 | GPIO2_POE | gpio_init | gpio_init | - |
| 0x40010D8C | GPIO2_PDO | gpio_init, gpio_outputs_update, gpio_p23_blink | gpio_init, gpio_outputs_update, gpio_p23_blink | - |
| 0x40010DA4 | GPIO2_F7654 | gpio_init | gpio_init | - |
| 0x40010DC4 | GPIO3_POE | gpio_init | gpio_init | - |
| 0x40010DCC | GPIO3_PDO | gpio_init, dash_loss_poweroff, uart0_command_dispatcher | gpio_init, dash_loss_poweroff, uart0_command_dispatcher | - |
| 0x40010F00 | - | crc32_hw | crc32_hw | - |
| 0x40010F04 | - | - | crc32_hw_init, crc32_hw | 1 |
| 0x40010F08 | - | - | crc32_hw_init | 0 |
| 0x40010F0C | - | - | crc32_hw_init | 4C11DB7 |
| 0x40011000 | UART0_CTRL | - | uart0_init | 0 |
| 0x40011004 | UART0_DIVH | - | uart0_init | 13 |
| 0x40011008 | UART0_DIVL | - | uart0_init | 87 |
| 0x4001100C | UART0_BUFF | ISR_UART0 | ISR_UART0, uart0_send | - |
| 0x40011014 | UART0_STT | uart0_send | - | - |
| 0x4001101C | UART0_IE | - | uart0_init | 3 |
| 0x40011020 | UART0_IF | ISR_UART0 | ISR_UART0, uart0_send | 1,2,1C |
| 0x40011100 | UART1_CTRL | - | uart1_init | 0 |
| 0x40011104 | UART1_DIVH | - | uart1_init | 13 |
| 0x40011108 | UART1_DIVL | - | uart1_init | 87 |
| 0x4001110C | UART1_BUFF | ISR_UART1 | ISR_UART1, uart1_send | - |
| 0x40011114 | UART1_STT | uart1_send | - | - |
| 0x4001111C | UART1_IE | - | uart1_init | 3 |
| 0x40011120 | UART1_IF | ISR_UART1 | ISR_UART1, uart1_send | 1,2,1C |
| 0x40011280 | DMA0_CTRL | - | i2c_read_reg, i2c_write_reg | 0 |
| 0x40011700 | IWDG_PSW | - | iwdg_feed, iwdg_init | A6B4 |
| 0x40011704 | IWDG_CFG | - | hardware_init, iwdg_init, system_reset_request | 1,3C00 |
| 0x40011708 | IWDG_CLR | - | iwdg_feed | 798D |
| 0x40011710 | IWDG_RTH | - | iwdg_init | 1F400 |
| 0x40013000 | DSP0_SC | dsp_sincos | hardware_init, dsp_sincos | 2 |
| 0x40013004 | DSP0_THETA | - | dsp_sincos | - |
| 0x40013010 | DSP0_SIN | dsp_sincos | - | - |
| 0x40013014 | DSP0_COS | dsp_sincos | - | - |
| 0x40013020 | DSP0_DID | - | dsp_div | - |
| 0x40013024 | DSP0_DIS | - | dsp_div | - |
| 0x40013028 | DSP0_QUO | dsp_div | - | - |
| 0x40013030 | DSP0_RAD | - | isqrt16 | - |
| 0x40013034 | DSP0_SQRT | isqrt16 | - | - |
