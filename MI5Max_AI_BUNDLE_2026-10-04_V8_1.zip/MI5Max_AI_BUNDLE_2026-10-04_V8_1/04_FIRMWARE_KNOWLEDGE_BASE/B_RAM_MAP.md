# B RAM map (symbolic names, accessors)

RAM base 0x20000000 (offsets shown). Names come from annotations (ram_B*.csv/psv); conf C/S/L/U as above. `R` = functions reading, `W` = functions writing (by name or ID).

| offset | size | name | conf | meaning | readers | writers | const-writes |
|---|---|---|---|---|---|---|---|
| 0x0 | 1 | main_slot_cnt_0 | C | main loop counter: visits of sub-schedule slot 1 (UART1 request cadence, resets to 0xF0 when link idle) | main | main | 0,F0 |
| 0x2 | 2 | main_cnt_mod5 | C | scheduler counter modulo 5 (speed loop slot machine) | main | main | 0 |
| 0x4 | 2 | main_cnt_mod10 | C | scheduler counter modulo 10 (10.24 ms slots) | main | main | 0 |
| 0x6 | 2 | main_cnt_mod100 | C | scheduler counter modulo 100 (102 ms slots) | main | main | 0 |
| 0x8 | 2 | main_cnt_mod250 | C | scheduler counter modulo 250 (256 ms slots) | main | main | 0 |
| 0xA | 2 | dash_msg_cnt | L | counter of status messages sent while ram 0x2E4 set | main | main | 0 |
| 0xC | 1 | enable_main | C | main enable (ISR runs hall/estimator when nonzero) | ISR_MCPWM0 | startup_calibrate_and_load, throttle_mode_block | 0,1 |
| 0x10 | 4 | identity_prefix | C | numeric region/identity prefix parsed from identity digits (60559 default; 60549/60558/61124/60560 alternates) | startup_calibrate_and_load, gpio_outputs_update, cruise_hold_logic, envelope_protection, region_config_defaults | region_config_defaults | - |
| 0x14 | 1 | hw_fault_flag | C | hardware (MCPWM EIF) fault latch; cleared by self-test path | uart0_status_frame_tx, cruise_hold_logic, throttle_mode_block, speed_loop | startup_calibrate_and_load, ISR_MCPWM0, throttle_mode_block | 0,1 |
| 0x15 | 1 | odo_tick | L | odometer tick flag set every 2^? ISR (0x61A count) | odometer_update | ISR_MCPWM0, odometer_update | 0,1 |
| 0x16 | 1 | isr_tick_counter | C | free-running ISR counter used to seed mcu_rand | ISR_MCPWM0, ascii_down_command_executor | ISR_MCPWM0 | - |
| 0x17 | 1 | isr_startup_lock | C | set after 16 ISR ticks of startup; gates ASCII command execution | ISR_MCPWM0, main | ISR_MCPWM0, main | 0,1 |
| 0x18 | 1 | isr_tick_prescale | C | MCPWM ISR counter; every 16 ISRs sets sched_tick | ISR_MCPWM0 | ISR_MCPWM0 | 0 |
| 0x19 | 1 | sector_prev | C | SVPWM sector of the previous PWM period (selects which phase ADCs are valid) | ISR_MCPWM0 | ISR_MCPWM0 | - |
| 0x1A | 1 | startup_cnt_1a | C | startup counter 0..16 | ISR_MCPWM0 | ISR_MCPWM0 | 0 |
| 0x1B | 1 | adc_ring_idx | C | index 0..3 into the 4-sample ADC rings; wrap sets ram 0xD7 | ISR_MCPWM0 | ISR_MCPWM0 | 0 |
| 0x1C | 1 | run_phase_cnt | C | ISR counter within run state (flying-start sync, MOE arm after wait) | ISR_MCPWM0 | ISR_MCPWM0 | 0 |
| 0x1D | 1 | isr_state | prior-verified | MCPWM ISR state 0..3 (0 off 2 normal) | ISR_MCPWM0, envelope_protection, ascii_down_command_executor | startup_calibrate_and_load, ISR_MCPWM0 | 0,1 |
| 0x1E | 1 | sched_tick | prior-verified | scheduler tick flag set by MCPWM ISR (1.0242 ms nominal) consumed by main loop | startup_calibrate_and_load, throttle_mode_block, main | startup_calibrate_and_load, ISR_MCPWM0, throttle_mode_block, main | 0,1 |
| 0x1F | 1 | run_latch | prior-verified | activity/run latch (motor run enabled) | calibration_measure_and_save, ISR_MCPWM0, uart0_status_frame_tx, cruise_hold_logic, throttle_mode_block | ISR_MCPWM0, current_limiter_drive_cmd, speed_loop | 0,1 |
| 0x20 | 1 | hall_h0 | C | filtered hall bit 0 | ISR_MCPWM0 | ISR_MCPWM0 | - |
| 0x21 | 1 | hall_h1 | C | filtered hall bit 1 | ISR_MCPWM0 | ISR_MCPWM0 | - |
| 0x22 | 1 | hall_h2 | C | filtered hall bit 2 | ISR_MCPWM0 | ISR_MCPWM0 | - |
| 0x23 | 1 | hall_state | C | packed 3-bit hall state (h0<<2/h1<<1/h2) passed to rotor_estimator | ISR_MCPWM0 | ISR_MCPWM0 | - |
| 0x24 | 1 | phA_valid_prev | C | phase-A sample valid (pipeline copy) | ISR_MCPWM0 | ISR_MCPWM0 | - |
| 0x25 | 1 | phB_valid_prev | C | phase-B sample valid | ISR_MCPWM0 | ISR_MCPWM0 | - |
| 0x26 | 1 | phC_valid_prev | C | phase-C sample valid | ISR_MCPWM0 | ISR_MCPWM0 | - |
| 0x28 | 2 | phv_a | S | ADC1 DAT1 phase-A terminal voltage-like sample (12 bit) | calc_modulation_index, throttle_mode_block | ISR_MCPWM0 | - |
| 0x2A | 2 | phv_b | S | ADC1 DAT2 phase-B terminal voltage-like sample | calc_modulation_index, throttle_mode_block | ISR_MCPWM0 | - |
| 0x2C | 2 | phv_c | S | ADC1 DAT3 phase-C terminal voltage-like sample | calc_modulation_index, throttle_mode_block | ISR_MCPWM0 | - |
| 0x2E | 2 | odo_isr_cnt | C | ISR counter to 1562 (0x61A) -> sets odo_tick (~0.1 s) | ISR_MCPWM0 | ISR_MCPWM0 | 0 |
| 0x30 | 2 | adc0_slot0_raw | prior-verified | phase sample ADC0 DAT0 (OPA1) latest | ISR_MCPWM0, throttle_mode_block | ISR_MCPWM0 | - |
| 0x32 | 2 | adc1_slot0_raw | prior-verified | phase sample ADC1 DAT0 (OPA0) latest | ISR_MCPWM0, throttle_mode_block | ISR_MCPWM0 | - |
| 0x34 | 2 | adc0_slot1_raw | prior-verified | phase sample ADC0 DAT1 (OPA3) latest | ISR_MCPWM0, throttle_mode_block | ISR_MCPWM0 | - |
| 0x48 | 8 | ring_dc_current | prior-verified | ADC0 DAT2 (OPA2) 4-sample ring (left-aligned) DC-like current | - | - | - |
| 0x50 | 8 | ring_vbus | prior-verified | ADC0 DAT3 ext CH5 4-sample ring voltage-like | - | - | - |
| 0x58 | 8 | ring_ntc_a | prior-verified | ADC0 DAT6 ext CH4 gain1 ring NTC A | - | - | - |
| 0x60 | 8 | ring_temp_local | prior-verified | ADC0 DAT5 ext CH7 ring local linear temp C2 | - | - | - |
| 0x68 | 8 | ring_avdd | prior-verified | ADC1 DAT6 internal AVDD ring | - | - | - |
| 0x70 | 8 | ring_mcu_temp | prior-verified | ADC1 DAT5 internal MCU temp ring | - | - | - |
| 0x78 | 8 | ring_ch9 | prior-verified | ADC1 DAT4 ext CH9 ring | - | - | - |
| 0x80 | 8 | ring_ntc_b | prior-verified | ADC0 DAT4 ext CH8 gain1 ring NTC B | - | - | - |
| 0x88 | 1 | p23_duty_code | C | duty code (0..20) of software PWM on P2.3 (set by gpio_outputs_update: 20 active brake, 8 running) | gpio_p23_blink | gpio_outputs_update | 0 |
| 0x8A | 2 | hist_value_8a | L | value inserted into settings history table (second 50-entry table) | settings_save | - | - |
| 0x8C | 2 | hall_period | prior-verified | filtered Hall/sector period (ISR counts) | throttle_mode_block, speed_loop, rotor_estimator | rotor_estimator | - |
| 0x90 | 1 | gov_flag | prior-verified | governor-detector latched flag byte (RC02 hooks) | uart0_status_frame_tx, current_limiter_drive_cmd | governor_detector | 0,1 |
| 0x91 | 1 | gov_detect_cnt | C | governor detector consecutive-hit counter (0..8) | governor_detector | governor_detector | 0,8 |
| 0x92 | 1 | lowspeed_brake_cnt | prior-verified | low-speed brake special-state accumulation counter (max 100) | lowspeed_brake_state | lowspeed_brake_state | 0 |
| 0x94 | 2 | odo_wrap_cnt | L | odometer wrap counter (increments each 36000 units) | odometer_update, settings_save | odometer_update | - |
| 0x96 | 2 | speed_delta_odo | L | speed change since last odometer call | - | odometer_update | - |
| 0x98 | 2 | speed_rise_filt | C | filtered clipped (0..40) speed increase used as lookahead in speed loop | speed_loop | speed_filter_update | - |
| 0x9A | 2 | freq_like | C | 6e7/(hall_period_copy*1280): frequency-like speed measure used by governor detector | governor_detector | governor_detector | - |
| 0x9C | 2 | freq_highpass | C | high-passed freq_like (freq - IIR) | governor_detector | governor_detector | - |
| 0x9E | 2 | iq_highpass | C | high-passed filtered i_q | governor_detector | governor_detector | - |
| 0xA0 | 2 | freq_iir | C | IIR(1/20) of freq_like | governor_detector | governor_detector | - |
| 0xA2 | 2 | iq_iir | C | IIR(1/20) of i_q_filt | governor_detector | governor_detector | - |
| 0xA4 | 2 | speed_prev_odo | L | previous speed for odometer delta | odometer_update | odometer_update | - |
| 0xA6 | 2 | speed_filtered | L | float-filtered speed (speed_filter_update) | speed_filter_update | speed_filter_update | - |
| 0xA8 | 4 | trip_counter | L | trip/odometer counter (persisted in settings word 1) | odometer_update, settings_save | odometer_update, settings_load | 0 |
| 0xAC | 4 | gov_product | C | governor product 0x9E*/0x9C/>>4 (trigger when < -250) | governor_detector | governor_detector | 0 |
| 0xB0 | 4 | odo_accum | L | odometer accumulator of/speed/(wraps at 36000) | odometer_update | odometer_update | - |
| 0xB4 | 1 | flag_b4 | prior-verified | fault/self-test flag (self-test result B4) | uart0_status_frame_tx, cruise_hold_logic, throttle_mode_block, power_stage_selftest, speed_loop | power_stage_selftest | 0 |
| 0xB6 | 1 | fault_stall | C | stall-like fault (counter 180) / cleared by throttle block | cruise_hold_logic, speed_loop | throttle_mode_block, envelope_protection | 0,1 |
| 0xB7 | 1 | flag_b7 | prior-verified | remote thermal fault B7 (consumed by main inhibit) | speed_loop, envelope_protection | envelope_protection | 0,1 |
| 0xB8 | 1 | fault_temp_sensor | prior-verified | local temperature sensor fault | uart0_status_frame_tx | temp_local_update | 0,1 |
| 0xB9 | 1 | flag_local_thermal | prior-verified | local thermal flag (C2 above derate entry) | uart0_status_frame_tx, cruise_hold_logic | envelope_protection | 0,1 |
| 0xBA | 1 | remote_hot_cnt | prior-verified | remote thermal debounce counter | envelope_protection | envelope_protection | - |
| 0xBB | 1 | longcurr_low_cnt | L | region(60549/61124) long-term current limiter: low-current counter | envelope_protection | envelope_protection | 0,14 |
| 0xBC | 1 | longcurr_active | L | region long-term current limit active flag | envelope_protection | envelope_protection | 0,1 |
| 0xBD | 1 | temp_sensor_invalid_cnt | prior-verified | local temp invalid debounce | temp_local_update | temp_local_update | 0 |
| 0xBE | 2 | env_target | prior-verified | mode-selected forward envelope BE (current-like units) | envelope_protection | throttle_mode_block | 89,112,148,1ED |
| 0xC0 | 2 | stall_cnt | prior-verified | stall-like counter | envelope_protection | envelope_protection | 0 |
| 0xC2 | 2 | temp_local | prior-verified | calibrated local temperature (tenths) | uart0_status_frame_tx, temp_local_update, envelope_protection | temp_local_update | - |
| 0xC4 | 2 | temp_ntc_a | prior-verified | NTC A temperature | uart0_status_frame_tx | ntc_a_update | - |
| 0xC6 | 2 | temp_ntc_b | prior-verified | NTC B temperature | - | ntc_b_update | - |
| 0xC8 | 2 | env_protected | prior-verified | protected envelope C8 after clamps | envelope_protection | envelope_protection | 112 |
| 0xCA | 2 | env_ramped | prior-verified | envelope CA slewed toward BE | envelope_protection | envelope_protection | - |
| 0xCC | 2 | longcurr_filt | L | float-filtered dc_current for region long-term limit | - | envelope_protection | - |
| 0xCE | 2 | longcurr_high_cnt | L | calls with filtered current >328 (limit 60000) | envelope_protection | envelope_protection | 0,EA60 |
| 0xD0 | 2 | longcurr_sub | L | sub-counter (136) for long-term limiter decrement | envelope_protection | envelope_protection | 0 |
| 0xD2 | 2 | longcurr_derate | L | derate amount (0..219) subtracted from 493 envelope | envelope_protection | envelope_protection | 0 |
| 0xD4 | 2 | neg_dc_cnt | prior-verified | sustained negative DC-feedback counter | envelope_protection | envelope_protection | - |
| 0xD6 | 1 | unused_flag_d6 | C | byte tested in the speed-loop inhibit chain (==1 inhibits) but never written by code: stays at its initial RAM value | speed_loop | - | - |
| 0xD7 | 1 | isr_every4_flag | C | set by ISR every 4th PWM period: triggers current limiter + ch9 in main loop | main | ISR_MCPWM0, main | 0,1 |
| 0xD8 | 1 | limiter_clamp_active | C | recovery/limiter clamp active (set by current limiter when over limit, cleared when within limits): ISR copies drive_cmd straight to vq | ISR_MCPWM0, current_limiter_drive_cmd | current_limiter_drive_cmd, throttle_mode_block | 0,1 |
| 0xD9 | 1 | gov_ramp_subcnt | C | governor recovery sub-counter | current_limiter_drive_cmd | current_limiter_drive_cmd | 0 |
| 0xDA | 2 | drive_cmd_target | C | DESIRED DRIVE COMMAND produced by the speed loop (-1023..1023): drive_cmd slews toward it by 3 per limiter call (seed name deriv_detector_da was wrong) | current_limiter_drive_cmd, speed_loop | ISR_MCPWM0, current_limiter_drive_cmd, speed_loop | 0 |
| 0xDC | 2 | dc_current | prior-verified | signed DC-like current feedback (ring48 avg>>6 - E8) | current_limiter_drive_cmd, speed_loop, envelope_protection, uart0_command_dispatcher, voltage_monitor | current_limiter_drive_cmd | - |
| 0xDE | 2 | neg_dc_env | prior-verified | negative DC-like envelope (-547 / -192) | current_limiter_drive_cmd | envelope_protection | - |
| 0xE0 | 2 | neg_bound | prior-verified | braking-branch negative feedback bound (E0) | current_limiter_drive_cmd | envelope_protection | - |
| 0xE2 | 2 | dc_current_prev | C | previous dc_current for derivative term of limiter | current_limiter_drive_cmd | current_limiter_drive_cmd | - |
| 0xE4 | 2 | gov_iq_limit | C | governor: q-current limit while gov_flag set (starts 10, grows to 1461) | current_limiter_drive_cmd | current_limiter_drive_cmd | A |
| 0xE6 | 2 | gov_hold_cnt | C | governor: calls since flag set (saturates 2000) | current_limiter_drive_cmd | current_limiter_drive_cmd | 0,7D0 |
| 0xE8 | 2 | dc_zero_offset | prior-verified | DC-like current zero offset measured at boot | startup_calibrate_and_load, current_limiter_drive_cmd, uart0_command_dispatcher | startup_calibrate_and_load | - |
| 0xEA | 2 | env_applied | prior-verified | envelope EA slewed toward C8 (current limit compared with dc_current) | current_limiter_drive_cmd, speed_loop, envelope_protection | startup_calibrate_and_load, envelope_protection | 1ED |
| 0xEC | 1 | zero_offset_fault | C | bit flags: 1/2/4 = phase A/B/C zero offset outside +-500; 8 = DC current zero offset outside +-500 | uart0_status_frame_tx, cruise_hold_logic, throttle_mode_block, speed_loop | startup_calibrate_and_load, throttle_mode_block | 0,8 |
| 0xEE | 2 | dc_zero_copy | L | copy of dc_zero_offset | - | startup_calibrate_and_load | - |
| 0xF0 | 1 | flag_lowv_severe | prior-verified | severe low-voltage flag | ISR_MCPWM0, cruise_hold_logic, speed_loop | voltage_monitor | 0,1 |
| 0xF1 | 1 | flag_highv | prior-verified | high-voltage flag | ISR_MCPWM0, uart0_status_frame_tx, cruise_hold_logic, speed_loop | current_limiter_drive_cmd, voltage_monitor | 0,1 |
| 0xF2 | 1 | flag_lowv_warn | prior-verified | low-voltage warning flag | speed_loop | voltage_monitor | 0,1 |
| 0xF3 | 1 | soc_like | prior-verified | SOC-like percent (remote or fallback) | uart0_status_frame_tx, active_brake_demand_calc, envelope_protection | voltage_monitor | - |
| 0xF4 | 1 | fault_ch9 | prior-verified | ADC1 CH9 fault F4 | cruise_hold_logic, speed_loop | ch9_process | 0,1 |
| 0xF5 | 1 | ch9_cnt | prior-verified | ADC1 CH9 low counter | ch9_process | ch9_process | 0,A |
| 0xF6 | 2 | vbus_unloaded_est | C | unloaded-voltage estimate (min-tracking when dc_current<279) used for fallback SOC | voltage_monitor | voltage_monitor | - |
| 0xF8 | 2 | ch9_avg | prior-verified | ADC1 CH9 averaged value | ch9_process | ch9_process | - |
| 0xFA | 2 | vbus_est_cnt | C | counter for vbus_unloaded_est update (80) | voltage_monitor | voltage_monitor | 0 |
| 0xFC | 1 | lowv_debounce | prior-verified | low-voltage debounce counter | voltage_monitor | voltage_monitor | 0 |
| 0xFE | 2 | vbus_raw | prior-verified | voltage-like ADC count (sum>>6) | calc_modulation_index, startup_calibrate_and_load, current_limiter_drive_cmd, active_brake_demand_calc, speed_loop | startup_calibrate_and_load, current_limiter_drive_cmd | - |
| 0x100 | 2 | nvr_trim_100 | L | factory trim word from NVR 0x14D0 | - | nvr_trim_load | - |
| 0x102 | 2 | nvr_trim_102 | L | factory trim word from NVR 0x14D4 | - | nvr_trim_load | - |
| 0x108 | 1 | brake_active_flag | C | active-brake request/in-progress (set when brake demand>5 or low-speed state) | cruise_hold_logic, speed_loop, governor_detector | active_brake_demand_calc | 0,1 |
| 0x109 | 1 | brake_regen_inhibit | C | set when active brake requested but regen inhibited (remote temp outside 0..45, remote_state>2, SOC>=95): ISR uses special symmetric-duty brake state 3 | ISR_MCPWM0, cruise_hold_logic, active_brake_demand_calc, speed_loop | active_brake_demand_calc | 0,1 |
| 0x10A | 1 | flag_10a | prior-verified | inhibit condition flag 10A | cruise_hold_logic, active_brake_demand_calc, speed_loop | uart0_command_dispatcher | - |
| 0x10B | 1 | brake_branch_sel | prior-verified | selects braking-branch constants (0 vs nonzero) | active_brake_demand_calc, envelope_protection | startup_calibrate_and_load | 0,1 |
| 0x10C | 1 | brake_soc_block | prior-verified | active braking restriction set at SOC>=95 | active_brake_demand_calc | active_brake_demand_calc | 0,1 |
| 0x10E | 2 | active_brake_demand | prior-verified | active braking demand | active_brake_demand_calc, speed_loop | active_brake_demand_calc | 0,3FF |
| 0x110 | 2 | brake_lever | C | brake lever 0..100 from dashboard frame byte7 | lowspeed_brake_state, gpio_outputs_update, active_brake_demand_calc | uart0_command_dispatcher | - |
| 0x112 | 1 | brake_ramp_state | C | active braking ramp state machine flag (speed loop) | current_limiter_drive_cmd, throttle_mode_block, speed_loop, envelope_protection, governor_detector | speed_loop | 0,1 |
| 0x113 | 1 | brake_special_flag | C | special brake (state 3) hold flag | ISR_MCPWM0, speed_loop | ISR_MCPWM0, speed_loop | 0,1 |
| 0x114 | 1 | phase_sample_valid | C | phase current sample valid this PWM period | ISR_MCPWM0 | ISR_MCPWM0 | 0,1 |
| 0x118 | 1 | sector_cur | C | SVPWM sector computed this period (6 values 1..6) | ISR_MCPWM0 | svpwm_output | - |
| 0x119 | 1 | phA_valid_next | C | phase A ADC sample valid next period | ISR_MCPWM0, svpwm_output | ISR_MCPWM0, svpwm_output | 0,1 |
| 0x11A | 1 | phB_valid_next | C | phase B ADC sample valid next period | ISR_MCPWM0, svpwm_output | ISR_MCPWM0, svpwm_output | 0,1 |
| 0x11B | 1 | phC_valid_next | C | phase C ADC sample valid next period | ISR_MCPWM0, svpwm_output | ISR_MCPWM0, svpwm_output | 0,1 |
| 0x11C | 2 | vq_like | prior-verified | q-axis-like voltage command | ISR_MCPWM0, inverse_park, d_axis_regulator, speed_loop | ISR_MCPWM0, d_axis_regulator | - |
| 0x11E | 2 | vd_like | prior-verified | d-axis-like voltage command | inverse_park, d_axis_regulator | reset_dq_state, d_axis_regulator | - |
| 0x120 | 2 | id_prev | C | previous i_d for d-axis regulator | d_axis_regulator | d_axis_regulator | - |
| 0x122 | 2 | i_phase_a | C | reconstructed phase-A current sample (zero_offset - ADC) | ISR_MCPWM0, clarke_transform, svpwm_output | ISR_MCPWM0 | - |
| 0x124 | 2 | i_phase_b | C | reconstructed phase-B current sample | ISR_MCPWM0, clarke_transform, svpwm_output | ISR_MCPWM0 | - |
| 0x126 | 2 | i_phase_c | C | reconstructed phase-C current sample | svpwm_output | - | - |
| 0x128 | 2 | i_alpha | prior-verified | alpha current | park_transform | clarke_transform | - |
| 0x12A | 2 | i_beta | prior-verified | beta current | park_transform | clarke_transform | - |
| 0x12C | 2 | v_alpha | prior-verified | inverse-Park alpha voltage | svpwm_output | inverse_park | - |
| 0x12E | 2 | v_beta | prior-verified | inverse-Park beta voltage | svpwm_output | inverse_park | - |
| 0x130 | 2 | i_d | prior-verified | d-axis current feedback | d_axis_regulator | reset_dq_state, ISR_MCPWM0, park_transform | 0 |
| 0x132 | 2 | i_q | prior-verified | q-axis current feedback | speed_filter_update, current_limiter_drive_cmd, speed_loop | reset_dq_state, park_transform | 0 |
| 0x134 | 2 | duty_a | L | phase-A duty (SVPWM) written to TH00/01 | - | svpwm_output | - |
| 0x136 | 2 | d_reg_neg_id | C | d-axis regulator -i_d | - | d_axis_regulator | - |
| 0x138 | 2 | d_reg_diff | C | d-axis regulator 2*(prev-i_d) | - | d_axis_regulator | - |
| 0x13A | 2 | d_reg_integ | C | d-axis regulator (-i_d)>>3 | - | d_axis_regulator | - |
| 0x13C | 4 | phase_v_mag | C | magnitude of the phase voltage vector (isqrt) | calc_modulation_index | calc_modulation_index | - |
| 0x140 | 2 | drive_cmd | prior-verified | drive command into PWM (cap 1023) | ISR_MCPWM0, current_limiter_drive_cmd, cruise_hold_logic | ISR_MCPWM0, current_limiter_drive_cmd | 0 |
| 0x142 | 2 | brake_duty_ramp | C | state-3 symmetric duty ramp value (0..3070) | ISR_MCPWM0 | ISR_MCPWM0 | - |
| 0x144 | 6 | phase_zero_offsets | prior-verified | phase current zero offsets (3 x s16) | ISR_MCPWM0, throttle_mode_block, uart0_command_dispatcher | startup_calibrate_and_load, throttle_mode_block | 0 |
| 0x146 | 2 | phase_zero_offsets+0x2 | prior-verified | (inside phase_zero_offsets) | ISR_MCPWM0, throttle_mode_block, uart0_command_dispatcher | startup_calibrate_and_load, throttle_mode_block | 0 |
| 0x148 | 2 | phase_zero_offsets+0x4 | prior-verified | (inside phase_zero_offsets) | ISR_MCPWM0, throttle_mode_block, uart0_command_dispatcher | startup_calibrate_and_load, throttle_mode_block | 0 |
| 0x14A | 2 | i_q_filt | C | IIR(1/20) of i_q | current_limiter_drive_cmd, speed_loop, governor_detector | current_limiter_drive_cmd | - |
| 0x14C | 1 | inhibit_14c | prior-verified | inhibit condition 14C | cruise_hold_logic, throttle_mode_block, speed_loop | uart0_command_dispatcher | - |
| 0x14D | 1 | riding_mode | C | riding mode selector from dashboard frame byte3 low nibble (1,2,3,0x0B) | gpio_outputs_update, uart0_status_frame_tx, cruise_hold_logic, throttle_mode_block | uart0_command_dispatcher | - |
| 0x14E | 1 | zero_cal_cnt | C | counter before phase zero-offset measurement (50 calls) | throttle_mode_block | throttle_mode_block | 0 |
| 0x14F | 1 | zero_cal_done | C | phase zero offsets measured flag | throttle_mode_block | throttle_mode_block | 1 |
| 0x150 | 1 | throttle_gate_150 | L | gate flag (1 after zero calibration) | throttle_mode_block | throttle_mode_block | 1 |
| 0x151 | 1 | mode_prev | C | previous riding mode (pending ramp when != riding_mode) | throttle_mode_block | throttle_mode_block | - |
| 0x152 | 1 | selftest_cnt | C | number of power-stage self-tests performed (max 8) | throttle_mode_block | throttle_mode_block | - |
| 0x153 | 1 | mode_ramp_cnt | prior-verified | pending mode ramp cadence counter | throttle_mode_block | throttle_mode_block | 0 |
| 0x154 | 2 | throttle_prev_copy | L | copy of ram 0x156 | - | throttle_mode_block | - |
| 0x156 | 2 | throttle_alt | U | alternate throttle source word (unused write) | throttle_mode_block | - | - |
| 0x158 | 2 | throttle | prior-verified | expanded throttle byte (0..100) | lowspeed_brake_state, cruise_hold_logic, throttle_mode_block, direction_lowspeed_flags | uart0_command_dispatcher | - |
| 0x15A | 2 | target_speed | prior-verified | target speed for current mode (0.1 km/h) | throttle_mode_block | throttle_mode_block | 67 |
| 0x15C | 1 | frame_b3_hi | C | dashboard frame byte3 high nibble | uart0_status_frame_tx | uart0_command_dispatcher | - |
| 0x160 | 4 | flash_wr_buf | C | flash program staging word (4 bytes) | flash_program | flash_program | FF |
| 0x161 | 1 | flash_wr_buf+0x1 | C | (inside flash_wr_buf) | - | flash_program | FF |
| 0x162 | 1 | flash_wr_buf+0x2 | C | (inside flash_wr_buf) | - | flash_program | FF |
| 0x163 | 1 | flash_wr_buf+0x3 | C | (inside flash_wr_buf) | - | flash_program | - |
| 0x164 | 1 | dir_armed | prior-verified | direction/start-state flag 164 | throttle_mode_block, direction_lowspeed_flags | direction_lowspeed_flags | 0,1 |
| 0x165 | 1 | dir_cfg_165 | prior-verified | direction cfg flag 165 | uart0_status_frame_tx, direction_lowspeed_flags | uart0_command_dispatcher | - |
| 0x166 | 1 | p23_mode_sel | C | dashboard frame byte4 bit0 (selects P2.3 PWM pattern) | gpio_outputs_update, uart0_status_frame_tx | uart0_command_dispatcher | - |
| 0x167 | 1 | frame_b5_b6_deb | C | dashboard frame byte5 bit6 debounced over 3 frames (blocks low-speed latch / stall derate) | uart0_status_frame_tx, direction_lowspeed_flags, envelope_protection | uart0_command_dispatcher | 0,1 |
| 0x168 | 1 | lowspeed_latch | C | low-speed latch (speed<2.0 with 0x167 set) | throttle_mode_block, direction_lowspeed_flags, rotor_estimator | direction_lowspeed_flags | 0,1 |
| 0x169 | 1 | lowspeed_state_169 | prior-verified | auxiliary low-speed state | lowspeed_brake_state, ISR_MCPWM0, uart0_status_frame_tx, current_limiter_drive_cmd, active_brake_demand_calc | direction_lowspeed_flags | 0,1 |
| 0x16A | 1 | gpio_16a | L | unused output state | - | gpio_outputs_update | 0 |
| 0x16B | 1 | gpio_16b | L | unused output state | - | gpio_outputs_update | 0 |
| 0x16C | 1 | cruise_active | C | CRUISE/hold active flag (held_reference used as requested_speed) | uart0_status_frame_tx, cruise_hold_logic, throttle_mode_block, speed_loop | cruise_hold_logic, throttle_mode_block, speed_loop | 0,1 |
| 0x16D | 1 | cruise_enable | C | dashboard frame byte5 bit5: cruise feature enable | cruise_hold_logic | uart0_command_dispatcher | - |
| 0x16E | 1 | p23_phase | C | software PWM phase counter 0..19 for P2.3 | gpio_p23_blink | gpio_p23_blink | 0 |
| 0x16F | 1 | out_toggle_16f | L | P2.10 toggle state (blink) | gpio_outputs_update | gpio_outputs_update | 0,1 |
| 0x170 | 1 | out_cnt_170 | L | P2.10 blink counter | gpio_outputs_update | gpio_outputs_update | 0 |
| 0x171 | 1 | out_cnt_171 | L | P2.12 blink counter | gpio_outputs_update | gpio_outputs_update | 0 |
| 0x172 | 1 | out_toggle_172 | L | P2.12 toggle state | gpio_outputs_update | gpio_outputs_update | 0 |
| 0x173 | 1 | cruise_throttle_low | C | throttle<5 seen while cruise active | cruise_hold_logic | cruise_hold_logic | 0,1 |
| 0x174 | 1 | throttle_ring_idx | C | index into 8-sample throttle ring ram 0x570 | cruise_hold_logic | cruise_hold_logic | 0 |
| 0x175 | 1 | mode_at_cruise | C | riding mode when cruise last evaluated | cruise_hold_logic | cruise_hold_logic | - |
| 0x176 | 1 | cruise_speed_stable | C | speed stable for 300 calls flag | cruise_hold_logic | cruise_hold_logic | 0,1 |
| 0x177 | 1 | cruise_throttle_stable | C | throttle stable for 500 calls flag | cruise_hold_logic | cruise_hold_logic | 0,1 |
| 0x178 | 2 | held_reference | prior-verified | held reference (hold/cruise) | throttle_mode_block, speed_loop | cruise_hold_logic, speed_loop | 0 |
| 0x17A | 2 | aux_timeout_cnt | prior-verified | aux low-speed timeout counter | direction_lowspeed_flags | direction_lowspeed_flags | 0 |
| 0x17C | 1 | dir_reverse_cnt | prior-verified | direction reverse debounce counter | direction_lowspeed_flags | direction_lowspeed_flags | 0 |
| 0x17E | 2 | cruise_thr_hi | C | avg throttle + 10 | - | cruise_hold_logic | - |
| 0x180 | 2 | cruise_thr_lo | C | avg throttle - 10 | - | cruise_hold_logic | - |
| 0x182 | 2 | cruise_thr_prev | C | previous avg throttle | cruise_hold_logic | cruise_hold_logic | - |
| 0x184 | 2 | cruise_spd_hi | C | speed + 2.0 | - | cruise_hold_logic | - |
| 0x186 | 2 | cruise_spd_lo | C | speed - 2.0 | - | cruise_hold_logic | - |
| 0x188 | 2 | cruise_spd_prev | C | previous speed trend | cruise_hold_logic | cruise_hold_logic | - |
| 0x18A | 2 | cruise_thr_ref | C | throttle reference for stability window | cruise_hold_logic | cruise_hold_logic | - |
| 0x18C | 2 | throttle_avg8 | C | average of last 8 throttle samples | - | cruise_hold_logic | - |
| 0x18E | 2 | cruise_thr_stable_cnt | C | throttle stability counter (500) | cruise_hold_logic | cruise_hold_logic | 0 |
| 0x190 | 2 | cruise_spd_stable_cnt | C | speed stability counter (300) | cruise_hold_logic | cruise_hold_logic | 0 |
| 0x192 | 2 | cruise_spd_ref | C | speed reference for stability window | cruise_hold_logic | cruise_hold_logic | - |
| 0x194 | 2 | lowspeed_aux_194 | L | signed accumulator (+-200) for low-speed latch, gate in ISR/rotor estimator | direction_lowspeed_flags, speed_loop, rotor_estimator | direction_lowspeed_flags, speed_loop, rotor_estimator | 0 |
| 0x196 | 1 | frame_b4_b7 | C | dashboard frame byte4 bit7 (reported in status bit 0x80) | uart0_status_frame_tx | uart0_command_dispatcher | - |
| 0x198 | 2 | special_acc_198 | L | signed accumulator (+-200) while special_state_207 | speed_loop, rotor_estimator | rotor_estimator | 0 |
| 0x19A | 1 | status_flag_19a | U | status flags reported in status frame (bit 3 of byte B) | uart0_status_frame_tx | - | - |
| 0x19B | 1 | status_flag_19b | U | status flag | uart0_status_frame_tx | - | - |
| 0x19C | 1 | status_flag_19c | U | status flag | uart0_status_frame_tx | - | - |
| 0x19D | 1 | status_flag_19d | U | status flag | uart0_status_frame_tx | - | - |
| 0x1A0 | 1 | mode_change_flag | L | set by throttle_mode_block when mode changes without ramp (inhibit in speed loop) | cruise_hold_logic, speed_loop | throttle_mode_block | 0 |
| 0x1A1 | 1 | speed_cadence_cnt | C | speed loop cadence counter (compared to 0x1A2) | speed_loop | speed_loop | 0 |
| 0x1A2 | 1 | speed_cadence_lim | C | speed loop cadence limit (reload from 0x1A3) | speed_loop | speed_loop | - |
| 0x1A3 | 1 | speed_cadence_reload | C | cadence reload value (12 in drive, 5 in coast) | speed_loop | speed_loop | 5,C |
| 0x1A4 | 1 | speed_accel_int | derived-from-code | speed-trend integrator +-20 | speed_loop | speed_loop | 0,14,FFFFFFEC |
| 0x1A6 | 2 | speed_kmh10 | prior-verified | measured signed speed (0.1 km/h units) | coast_regen_demand, lowspeed_brake_state, speed_filter_update, active_brake_demand_calc, throttle_mode_block | speed_loop | - |
| 0x1A8 | 2 | speed_snapshot_1a8 | L | speed snapshot at end of coast branch | - | speed_loop | - |
| 0x1AA | 2 | requested_speed | prior-verified | requested speed = applied_ref*throttle/100 | coast_regen_demand, cruise_hold_logic, speed_loop, governor_detector | throttle_mode_block, speed_loop | 0 |
| 0x1AC | 2 | speed_trend_ref | derived-from-code | slowly-tracking speed reference (+-1 per call) | uart0_status_frame_tx, cruise_hold_logic, speed_loop | speed_loop | - |
| 0x1AE | 2 | mod_index | C | measured modulation index (1023*/phase voltage//vbus) used for flying start | calc_modulation_index, ISR_MCPWM0, speed_loop | calc_modulation_index | - |
| 0x1B0 | 2 | da_snapshot | L | drive command snapshot (brake release / start) | - | speed_loop | - |
| 0x1B2 | 2 | coast_target | prior-verified | coast recovery target demand | coast_regen_demand | coast_regen_demand, speed_loop | 0 |
| 0x1B4 | 2 | coast_demand | prior-verified | coast recovery demand (slews by 5) | coast_regen_demand, speed_loop | coast_regen_demand, speed_loop | 0 |
| 0x1B6 | 2 | brake_target_signed | prior-verified | signed braking target (-max(active,coast)) | - | speed_loop | - |
| 0x1B8 | 2 | brake_iq_corr | C | filtered i_q clamp (+-30) used by special brake loop | speed_loop | speed_loop | 2 |
| 0x1BA | 2 | coast_adj | prior-verified | coast adjustment | speed_loop | speed_loop | 0 |
| 0x1BC | 2 | coast_floor | C | negative lower bound for da in active braking (-25*speed) | speed_loop | speed_loop | 0 |
| 0x1BE | 2 | lowspeed_hold_cnt | L | counter (max 200) in low-speed brake hold | speed_loop | speed_loop | 0 |
| 0x1C0 | 2 | speed_prev_brake | C | previous speed for brake derivative | speed_loop | speed_loop | - |
| 0x1C2 | 2 | speed_abs_copy | derived-from-code | abs speed estimate copy | remote_flag374_filter, odometer_update | speed_loop | - |
| 0x1C4 | 2 | speed_abs_raw | prior-verified | abs speed from period (0x36CAB/period) | speed_loop | speed_loop | 0 |
| 0x1C6 | 2 | accel_step | prior-verified | current-error acceleration step | speed_loop | speed_loop | 2 |
| 0x1C8 | 2 | speed_step | C | speed loop step: change applied to drive_cmd_target (-30 fast decrease, 1..40 increase) | speed_loop | speed_loop | 1E |
| 0x1CC | 4 | brake_decel_term | L | 50*(speed-prev) deceleration term | - | speed_loop | - |
| 0x1D0 | 2 | applied_reference | prior-verified | applied speed reference (ramped) | throttle_mode_block, governor_detector | throttle_mode_block | - |
| 0x1D4 | 1 | activated_flag | C | persistent activation flag (set by service cmd 0x52/0x18, saved in settings) | settings_save, uart0_command_dispatcher | settings_load, uart0_command_dispatcher | 0,1 |
| 0x1D5 | 1 | reset_request | C | set after update commit: after 80 calls system reset (to bootloader) | system_reset_request | system_reset_request, uart0_update_handler, ascii_down_command_executor | 0,1 |
| 0x1D6 | 1 | service_mode | C | authenticated/service state (set by mcu_key success, update start; cleared on 13 idle service ticks); inhibits driving, IMU/NTC/status tasks | uart_reply_ack_handler, uart0_status_frame_tx, cruise_hold_logic, throttle_mode_block, gpio_p23_blink | update_state_reset, uart0_update_handler, ascii_down_command_executor, main | 0,1 |
| 0x1D7 | 1 | throttle_lost | C | dashboard control frames lost (throttle_age>=10) / cleared by every valid control frame; error code 0x10; forces requested_speed 0 | uart0_status_frame_tx, cruise_hold_logic, throttle_mode_block, speed_loop, dash_loss_poweroff | uart0_status_frame_tx, uart0_command_dispatcher | 0,1 |
| 0x1D8 | 1 | decel_detect_enable | C | dashboard frame byte9 bit7: enables slope filter (remote_flag374_filter) | remote_flag374_filter | uart0_command_dispatcher | - |
| 0x1D9 | 1 | lowspeed_brake_enable | C | dashboard frame byte9 bit6: enables low-speed brake special state | lowspeed_brake_state | uart0_command_dispatcher | - |
| 0x1DA | 1 | mode_ready | derived-from-code | mode block ready | governor_detector | uart0_command_dispatcher | - |
| 0x1DB | 1 | uart1_req_0e | C | request flag for UART1 poll index 0xE (selector 0x63) | uart1_request_builder | uart1_request_builder, uart0_command_dispatcher | 0 |
| 0x1DC | 1 | light_mode | L | dashboard frame byte9 low nibble (blink pattern on P2.10/12) | gpio_outputs_update, uart0_status_frame_tx | uart0_command_dispatcher | - |
| 0x1DD | 1 | uart0_tx_rd | C | UART0 TX ring read index (ring ram 0x720, 50 bytes) | ISR_UART0, uart0_send | ISR_UART0, uart0_send | 0 |
| 0x1DE | 1 | uart0_tx_wr | C | UART0 TX ring write index | ISR_UART0, uart0_send | uart0_send | 0 |
| 0x1DF | 1 | uart0_rx_pending | C | pending UART0 frame type for main loop (1 control 2 ascii 3 xmodem 4 update) | ISR_MCPWM0, ISR_UART0, main | ISR_UART0, main | 0,3 |
| 0x1E0 | 1 | uart0_rx_timeout | C | UART0 RX inter-byte timeout counter (8) | ISR_MCPWM0, ISR_UART0 | ISR_MCPWM0, ISR_UART0 | 8 |
| 0x1E1 | 1 | uart0_tx_timeout | C | UART0 TX idle timer (5) | ISR_MCPWM0, uart0_send | ISR_MCPWM0, ISR_UART0 | 5 |
| 0x1E2 | 1 | uart0_rx_kind | C | UART0 RX frame kind being received (1..4) | ISR_UART0 | ISR_UART0 | 1,2,3,4 |
| 0x1E3 | 1 | uart0_rx_aux | L | UART0 RX aux byte | - | ISR_UART0 | - |
| 0x1E4 | 1 | uart0_forward_len | L | length for forwarding UART0 frame to UART1 | xmodem_update_receiver | ISR_UART0 | 1,85 |
| 0x1E5 | 1 | upd_flag_1e5 | L | update state flag | xmodem_update_receiver | update_state_reset, xmodem_update_receiver | 0,1 |
| 0x1E6 | 1 | upd_flag_1e6 | L | update state flag (metadata received) | uart_reply_pass_handler | uart_reply_pass_handler, update_state_reset, xmodem_update_receiver | 0,1 |
| 0x1E7 | 1 | upd_flag_1e7 | L | update state flag | xmodem_update_receiver | uart_reply_pass_handler, update_state_reset, xmodem_update_receiver | 0,1 |
| 0x1E8 | 1 | upd_flag_1e8 | L | update state flag | uart_reply_pass_handler | uart_reply_pass_handler, update_state_reset, xmodem_update_receiver | 0,1 |
| 0x1E9 | 1 | upd_active | L | firmware update in progress (forward bytes to UART1) | uart_reply_ack_handler, uart_reply_pass_handler, ISR_UART1, xmodem_update_receiver | uart_reply_ack_handler, uart_reply_pass_handler, update_state_reset, xmodem_update_receiver | 0,1 |
| 0x1EA | 1 | uart0_tx_pending | L | status/reply frame pending flag | uart1_rx_frame_parser, uart0_status_frame_tx | uart1_rx_frame_parser, uart0_status_frame_tx, uart0_command_dispatcher | 0,1 |
| 0x1EB | 1 | frame_b5_b2 | C | dashboard frame byte5 bit2 | - | uart0_command_dispatcher | - |
| 0x1EC | 1 | profile_byte | prior-verified | dashboard frame byte 8 = energy-recovery selector (30/60/90) also child-cap trigger 0x3C | coast_regen_demand | uart0_command_dispatcher | - |
| 0x1ED | 1 | frame_b4_b3 | C | dashboard frame byte4 bit3 (drives P2.3 PWM override / status bit 0x08) | gpio_outputs_update, uart0_status_frame_tx | uart0_command_dispatcher | - |
| 0x1EE | 1 | frame_b4_b6 | C | dashboard frame byte4 bit6 | - | uart0_command_dispatcher | - |
| 0x1EF | 1 | frame_b4_b5 | C | dashboard frame byte4 bit5 | - | uart0_command_dispatcher | - |
| 0x1F0 | 1 | throttle_age | prior-verified | throttle frame age counter | uart0_status_frame_tx | uart0_status_frame_tx, uart0_command_dispatcher | 0 |
| 0x1F1 | 1 | ping_retry_cnt | L | retry timer for uart0_ping_tx (10) | uart0_ping_tx | uart0_ping_tx, ascii_down_command_executor | A |
| 0x1F2 | 1 | ping_active | L | ping state active | uart0_ping_tx | uart0_ping_tx, ascii_down_command_executor, xmodem_update_receiver, main | 0,1 |
| 0x1F3 | 1 | image_valid | C | staged image header+CRC valid | ascii_down_command_executor | ascii_down_command_executor | 0,1 |
| 0x1F4 | 1 | ping_count | L | ping repetitions | uart0_ping_tx | uart0_ping_tx, ascii_down_command_executor | - |
| 0x1F5 | 1 | upd_flag_1f5 | L | update flag | - | update_state_reset, ascii_down_command_executor | 0,1 |
| 0x1F6 | 1 | upd_flag_1f6 | L | update/hold flag (blocks status frames) | main | update_state_reset, ascii_down_command_executor | 0,1 |
| 0x1F7 | 1 | uart0_rx_idx | C | UART0 RX byte index in current frame | ISR_UART0 | ISR_UART0 | 0,1,2 |
| 0x1F8 | 1 | uart0_rx_len | C | UART0 RX expected frame length | ISR_UART0 | ISR_UART0 | 0,7,1F |
| 0x1F9 | 1 | uart0_rx_flag | L | UART0 RX substate | ISR_UART0 | ISR_UART0 | 0,1 |
| 0x1FA | 1 | pwr_low_cnt | C | consecutive control frames with power-latch bit clear (3 -> shutdown) | uart0_command_dispatcher | uart0_command_dispatcher | 0 |
| 0x1FB | 1 | settings_saved_pwr | C | settings saved once at power-off flag | uart0_command_dispatcher | uart0_command_dispatcher | 1 |
| 0x1FC | 1 | b5_b6_debounce | C | byte5 bit6 frame debounce counter | uart0_command_dispatcher | uart0_command_dispatcher | - |
| 0x1FD | 1 | settings_saved_loss | C | settings saved once at dashboard-loss shutdown flag | dash_loss_poweroff | dash_loss_poweroff | 1 |
| 0x1FE | 1 | status_frame_type | C | alternates 0/1 selects status frame content | uart0_status_frame_tx | uart0_status_frame_tx | 0,1 |
| 0x1FF | 1 | reset_delay_cnt | C | counter to 80 before system reset after commit | system_reset_request | system_reset_request | 0 |
| 0x200 | 1 | commit_written | C | update commit record written flag | ascii_down_command_executor | ascii_down_command_executor | 1 |
| 0x201 | 1 | ascii_reply_len | C | length of ASCII reply being built | ascii_down_command_executor | ascii_down_command_executor | 3,6 |
| 0x202 | 1 | xmodem_retry | C | xmodem retry counter | xmodem_update_receiver | xmodem_update_receiver | 0,1 |
| 0x203 | 1 | xmodem_block_no | C | last accepted xmodem block number | xmodem_update_receiver | xmodem_update_receiver | 0 |
| 0x204 | 1 | update_started | C | update erase done flag | uart0_update_handler | uart0_update_handler | 0,1 |
| 0x205 | 1 | update_commit_flag | C | update finish record written | uart0_update_handler | uart0_update_handler | 0,1 |
| 0x206 | 1 | update_toggle_206 | L | toggles between flash data and constant text in 0x11 reply | uart0_update_handler | uart0_update_handler | 1 |
| 0x207 | 1 | special_state_207 | prior-verified | low-speed braking special state | ISR_MCPWM0, uart0_status_frame_tx, current_limiter_drive_cmd, active_brake_demand_calc, speed_loop | lowspeed_brake_state | - |
| 0x208 | 2 | xmodem_block_cnt | L | xmodem blocks received | xmodem_update_receiver | update_state_reset, xmodem_update_receiver | 0 |
| 0x20A | 2 | upd_hdr_20a | L | update header field (size high) | - | xmodem_update_receiver | - |
| 0x20C | 2 | upd_crc_hdr | C | update header CRC16 (compared with computed CRC) | ascii_down_command_executor | xmodem_update_receiver | - |
| 0x20E | 2 | upd_hdr_20e | L | update header field | - | xmodem_update_receiver | - |
| 0x210 | 2 | vbus_decivolt | prior-verified | FE*8850>>14 voltage telemetry | speed_loop, uart0_command_dispatcher | voltage_monitor | - |
| 0x212 | 2 | dash_loss_cnt | C | calls without valid dashboard frame (poweroff at 480) | dash_loss_poweroff | dash_loss_poweroff | - |
| 0x214 | 1 | ping_byte | C | byte 0x43 transmitted by uart0_ping_tx | - | uart0_ping_tx | 43 |
| 0x216 | 2 | upd_seq | C | update packet sequence number | uart0_update_handler | uart0_update_handler | 0 |
| 0x218 | 2 | current_10mA | S | dc_current*1000/274 (10 mA units) for service reply 0x34 | uart0_command_dispatcher | uart0_command_dispatcher | - |
| 0x219 | 1 | current_10mA+0x1 | S | (inside current_10mA) | uart0_command_dispatcher | - | - |
| 0x21A | 3 | serial_model_bytes | L | 3-byte model/serial bytes (service reply 0x22) | settings_save | load_config_defaults, settings_load | - |
| 0x21B | 1 | serial_model_bytes+0x1 | L | (inside serial_model_bytes) | settings_save | load_config_defaults, settings_load | - |
| 0x21C | 1 | serial_model_bytes+0x2 | L | (inside serial_model_bytes) | settings_save | load_config_defaults, settings_load | - |
| 0x220 | 4 | xmodem_state_220 | L | xmodem state/block counter | xmodem_update_receiver | uart_reply_ack_handler, update_state_reset, xmodem_update_receiver | 0,10 |
| 0x224 | 4 | upd_hdr_224 | L | update header word (first) | - | xmodem_update_receiver | - |
| 0x228 | 4 | xmodem_frame_cnt | L | received frame counter | xmodem_update_receiver | xmodem_update_receiver | - |
| 0x22C | 4 | upd_image_size | C | update image size (limit 0x1B800) | ascii_down_command_executor, xmodem_update_receiver | xmodem_update_receiver | - |
| 0x230 | 4 | upd_stage_off | L | update staging offset/limit | xmodem_update_receiver | update_state_reset, xmodem_update_receiver | 0 |
| 0x234 | 4 | upd_hdr_234 | L | update header word | xmodem_update_receiver | xmodem_update_receiver | - |
| 0x238 | 4 | crc32_result | C | CRC32 of staged region returned by service reply 0x2B | uart0_command_dispatcher | uart0_command_dispatcher | - |
| 0x23C | 4 | upd_crc_expected | C | expected image CRC from staged header | ascii_down_command_executor | ascii_down_command_executor | - |
| 0x240 | 4 | upd_length | C | image length from staged header | ascii_down_command_executor | ascii_down_command_executor | - |
| 0x244 | 4 | upd_crc_computed | C | computed CRC32 of staged image | - | ascii_down_command_executor | - |
| 0x248 | 4 | xmodem_flash_ptr | C | current flash programming pointer (starts 0xF000) | xmodem_update_receiver | xmodem_update_receiver | F000 |
| 0x24C | 4 | upd_flash_ptr | C | update handler flash pointer (starts 0xF000) | uart0_update_handler | uart0_update_handler | F000 |
| 0x250 | 4 | upd_total_bytes | C | total bytes received by update handler | uart0_update_handler | uart0_update_handler | 0 |
| 0x254 | 4 | identity_word_254 | L | identity word (4 bytes) restored from settings | settings_save | load_config_defaults, settings_load | - |
| 0x255 | 1 | identity_word_254+0x1 | L | (inside identity_word_254) | settings_save | load_config_defaults, settings_load | - |
| 0x256 | 1 | identity_word_254+0x2 | L | (inside identity_word_254) | settings_save | load_config_defaults, settings_load | - |
| 0x257 | 1 | identity_word_254+0x3 | L | (inside identity_word_254) | settings_save | load_config_defaults, settings_load | - |
| 0x258 | 5 | xmodem_meta_258 | L | xmodem metadata bytes | - | xmodem_update_receiver | - |
| 0x259 | 1 | xmodem_meta_258+0x1 | L | (inside xmodem_meta_258) | - | xmodem_update_receiver | - |
| 0x25A | 1 | xmodem_meta_258+0x2 | L | (inside xmodem_meta_258) | - | xmodem_update_receiver | - |
| 0x25B | 1 | xmodem_meta_258+0x3 | L | (inside xmodem_meta_258) | - | xmodem_update_receiver | - |
| 0x25C | 1 | xmodem_meta_258+0x4 | L | (inside xmodem_meta_258) | - | xmodem_update_receiver | - |
| 0x25D | 23 | identity_serial | C | 23-byte identity/serial field (first 5 chars = numeric prefix; erased FF/0x30 -> default) | region_config_defaults | - | - |
| 0x274 | 18 | identity_18 | C | 18-byte identity field loaded from flash 0x1F800 | - | - | - |
| 0x286 | 75 | cmd_signatures | L | RAM copies of command-signature strings used by B:1FF38 | - | - | - |
| 0x2D8 | 4 | key_magic | C | key buffer magic 0x5AA55AA5 (key valid) | key_init_default, settings_save | key_init_default, settings_load | 5AA55AA5 |
| 0x2DC | 4 | settings_word_2dc | L | persisted settings word | settings_save | settings_load | - |
| 0x2E0 | 4 | config_magic | C | config magic 0x5AA55AA5 | load_config_defaults, settings_load, settings_save | load_config_defaults, settings_load | 5AA55AA5 |
| 0x2E4 | 1 | commit_msg_flag | L | update committed: send down-ok messages | main | startup_calibrate_and_load, main | 0,1 |
| 0x2E5 | 1 | service_timeout_cnt | C | service-mode (flag_1d6) timeout counter (13) | main | main | 0 |
| 0x2E6 | 1 | settings_flag_2e6 | L | persisted setting flag (bit0 of settings word) | settings_save | settings_load | 0,1 |
| 0x2E8 | 1 | est_mode_2e8 | L | rotor estimator open-loop/forced mode flag | rotor_estimator | rotor_estimator | - |
| 0x2E9 | 1 | hall_invalid_flag | C | invalid hall state seen (hall code 0 or 7): fault, outputs off | uart0_status_frame_tx, cruise_hold_logic, speed_loop | throttle_mode_block, rotor_estimator | 0,1 |
| 0x2EA | 1 | dir_prev_2ea | C | previous direction (ctrl_445_ref) | rotor_estimator | rotor_estimator | - |
| 0x2EB | 1 | sector_diff | C | sector-to-sector step (+-1 / +-5) | - | rotor_estimator | - |
| 0x2EC | 1 | hall_cur_2ec | C | current hall state | rotor_estimator | rotor_estimator | - |
| 0x2ED | 1 | hall_prev_2ed | C | previous hall state | rotor_estimator | rotor_estimator | - |
| 0x2EE | 1 | hall_startup_cnt | L | hall startup counter (10) | rotor_estimator | rotor_estimator | 0 |
| 0x2EF | 1 | est_valid_2ef | C | estimator has valid history | rotor_estimator | rotor_estimator | 0,1 |
| 0x2F0 | 1 | est_hist_full | C | sector-time history full (6 entries) | rotor_estimator | rotor_estimator | 0,1 |
| 0x2F1 | 1 | hall_seq_idx | C | hall sequence index of current state | rotor_estimator | rotor_estimator | - |
| 0x2F2 | 1 | est_wrap_flag | C | angle wrap event flag | rotor_estimator | rotor_estimator | 0,1 |
| 0x2F3 | 1 | est_flag_2f3 | L | estimator flag (angle crossing) | rotor_estimator | rotor_estimator | 0,1 |
| 0x2F4 | 1 | est_hist_idx | C | index into sector-time history (0..5) | rotor_estimator | rotor_estimator | 0 |
| 0x2F5 | 1 | hall_state_copy | C | copy of hall state (used by throttle_mode_block) | throttle_mode_block | rotor_estimator | - |
| 0x2F6 | 2 | hall_period_copy | prior-verified | period copy used by scheduler functions | direction_lowspeed_flags, rotor_estimator, governor_detector, ascii_down_command_executor | rotor_estimator | 2E,41E8,41E9 |
| 0x2F8 | 2 | isr_since_hall | C | ISR ticks since last hall transition (timeout 2812) | rotor_estimator | rotor_estimator | 0 |
| 0x2FA | 2 | angle_est | C | rotor angle estimate (Q16) | rotor_estimator | rotor_estimator | 0,1555,EAAA |
| 0x2FC | 2 | angle_rate | C | angle increment per ISR (Q16) | rotor_estimator | rotor_estimator | - |
| 0x2FE | 2 | angle_err | C | angle error term | rotor_estimator | rotor_estimator | 0 |
| 0x300 | 2 | ctrl_445_ref | derived-from-code | reference compared with ctrl+0x445 | direction_lowspeed_flags, speed_loop, rotor_estimator | rotor_estimator | 0,1 |
| 0x302 | 2 | sector_start_ang | C | start angle of current sector (Q16) | rotor_estimator | rotor_estimator | 0,2AAA,AAAA,D555 |
| 0x304 | 2 | angle_limit_hi | C | upper angle limit for interpolation in sector | rotor_estimator | rotor_estimator | 0 |
| 0x306 | 2 | sector_end_ang | C | end angle of current sector | rotor_estimator | rotor_estimator | 1555,3FFF,6AAA,9555 |
| 0x308 | 2 | sector_lim_a | C | sector interpolation limit | rotor_estimator | rotor_estimator | 13E9,3E93,693E,93E9 |
| 0x30A | 2 | sector_lim_b | C | sector interpolation limit | rotor_estimator | rotor_estimator | 16C1,416C,6C17,96C1 |
| 0x30C | 2 | sector_lim_c | C | sector interpolation limit | rotor_estimator | rotor_estimator | 3E93,6C17,C16C |
| 0x30E | 2 | sector_prev_ang | C | previous sector boundary angle | rotor_estimator | rotor_estimator | 0,2AAA,AAAA,D555 |
| 0x310 | 2 | elec_angle | prior-verified | electrical angle | inverse_park, rotor_estimator | rotor_estimator | - |
| 0x31A | 2 | sin_theta | prior-verified | sine of angle | inverse_park, park_transform | dsp_sincos | - |
| 0x31C | 2 | cos_theta | prior-verified | cosine of angle | inverse_park, park_transform | dsp_sincos | - |
| 0x31E | 1 | uart1_rx_tmp | L | UART1 RX temp | - | uart1_rx_frame_parser | - |
| 0x31F | 1 | uart1_tx_rd | C | UART1 TX ring read index (ring ram 0x833, 150 bytes) | ISR_UART1, uart1_send | ISR_UART1, uart1_send | 0 |
| 0x320 | 1 | uart1_tx_wr | C | UART1 TX ring write index | ISR_UART1, uart1_send | uart1_send | 0 |
| 0x321 | 1 | uart1_rx_pending | C | pending UART1 frame type for main loop (1 reply 2/3 acks) | ISR_UART1, main | ISR_UART1, main | 0,1,2,3 |
| 0x322 | 1 | uart1_rx_timeout | C | UART1 RX inter-byte timeout (10) | ISR_MCPWM0, ISR_UART1 | ISR_MCPWM0, ISR_UART1 | A |
| 0x323 | 1 | uart1_tx_timeout | C | UART1 TX idle timer (5) | ISR_MCPWM0, uart1_send | ISR_MCPWM0, ISR_UART1 | 5 |
| 0x324 | 1 | uart1_rx_kind | C | UART1 RX frame kind (0 reply 0x74, 1 forwarded 0x64 / ASCII, 2 update ack) | ISR_UART1 | ISR_UART1 | 0,1,2 |
| 0x325 | 1 | uart1_rx_len_copy | L | UART1 RX frame length copy | - | ISR_UART1 | 1 |
| 0x326 | 1 | uart1_req_flag_326 | L | cleared when a 0x14-type request was queued by dispatcher | - | uart1_rx_frame_parser, uart0_command_dispatcher | 0,1 |
| 0x327 | 1 | remote_state | prior-verified | UART1 remote state code (freshness) | uart0_status_frame_tx, cruise_hold_logic, active_brake_demand_calc, envelope_protection, voltage_monitor | uart1_rx_frame_parser, uart1_request_builder | 0,3 |
| 0x328 | 2 | remote_temp | prior-verified | remote signed temperature byte | coast_regen_demand, cruise_hold_logic, active_brake_demand_calc, envelope_protection | uart1_rx_frame_parser | - |
| 0x329 | 1 | remote_temp+0x1 | prior-verified | (inside remote_temp) | xmodem_update_receiver | uart_reply_ack_handler, update_state_reset, xmodem_update_receiver | 0,1 |
| 0x32A | 1 | update_ack_flag | L | update acknowledgement flag | xmodem_update_receiver | uart_reply_ack_handler, update_state_reset, xmodem_update_receiver | 0,1 |
| 0x32B | 1 | uart1_rx_flag | L | UART1 RX substate (frame 0x40 special) | ISR_UART1 | ISR_UART1 | 0,1 |
| 0x32C | 1 | uart1_rx_idx | C | UART1 RX byte index | ISR_UART1 | ISR_UART1 | 0,1 |
| 0x32D | 1 | uart1_rx_len | C | UART1 RX expected frame length | ISR_UART1 | ISR_UART1 | 6,7 |
| 0x32E | 1 | uart1_poll_idx | C | UART1 poll rotation index (selects selector 0x41..0x4B,0x60,0x61,0x63) | uart1_request_builder | uart1_request_builder | 0,2,3,4 |
| 0x32F | 1 | uart1_poll_sub | C | UART1 poll sub-state | uart1_request_builder | uart1_request_builder | 0,2 |
| 0x330 | 1 | uart1_poll_next | C | next UART1 poll index (3..6 loop) | uart1_request_builder | uart1_request_builder | 3 |
| 0x331 | 1 | uart1_poll_toggle | C | UART1 poll alternate flag | uart1_request_builder | uart1_request_builder | 0,1 |
| 0x332 | 1 | uart1_miss_cnt | C | consecutive missing replies (to 5) | uart1_request_builder | uart1_request_builder | 0 |
| 0x333 | 1 | uart1_pass_cnt | L | pass-through reply counter | uart_reply_pass_handler | uart_reply_pass_handler | 0 |
| 0x334 | 2 | uart1_age | C | calls since last valid UART1 reply (>300 -> remote_state=3) | uart1_request_builder | uart1_rx_frame_parser, uart1_request_builder | 0 |
| 0x336 | 3 | uart_ack_buf | L | 3-byte reply buffer (0x18 0x18 0x18 or 6 ..) | - | uart_reply_ack_handler | 6 |
| 0x339 | 4 | remote_blob_339 | L | selector 0x43 data (4 bytes)+3 header bytes at 0x339..0x33B / data 0x343 | - | uart1_rx_frame_parser | - |
| 0x33A | 1 | remote_blob_339+0x1 | L | (inside remote_blob_339) | - | uart1_rx_frame_parser | - |
| 0x33B | 1 | remote_blob_339+0x2 | L | (inside remote_blob_339) | - | uart1_rx_frame_parser | - |
| 0x33C | 3 | remote_hdr_33c | L | selector 0x42 header bytes | - | uart1_rx_frame_parser | - |
| 0x33D | 1 | remote_hdr_33c+0x1 | L | (inside remote_hdr_33c) | - | uart1_rx_frame_parser | - |
| 0x33E | 1 | remote_hdr_33c+0x2 | L | (inside remote_hdr_33c) | - | uart1_rx_frame_parser | - |
| 0x33F | 4 | remote_blob_33f | L | selector 0x42 payload (4 bytes) | - | - | - |
| 0x343 | 4 | remote_blob_343 | L | selector 0x43 payload (4 bytes) | - | - | - |
| 0x347 | 1 | power_off_flag | C | set when power-off sequence started (dash loss or byte5 bit7 low) | lowspeed_brake_state, uart0_status_frame_tx | dash_loss_poweroff, uart0_command_dispatcher | 0,1 |
| 0x348 | 1 | power_evt_348 | L | power transition event flag | - | uart0_command_dispatcher | 1 |
| 0x349 | 1 | power_evt_349 | L | power transition seen flag | uart0_command_dispatcher | uart0_command_dispatcher | 1 |
| 0x34C | 4 | flash_ptr_key | C | key 0x9A0D361F that selects obfuscated flash-controller pointer (cleared after use) | flash_erase_page | identity_save_flash, flash_erase_page, flash_program, startup_calibrate_and_load, settings_save | 0,9A0D361F |
| 0x350 | 4 | flash_ptr_key2 | C | key 0x9AFDA40C for second obfuscated flash pointer | flash_program, flash_write_word | flash_program, flash_write_word | 0,9AFDA40C |
| 0x354 | 4 | sysclk_hz | prior-verified | configured system clock (96 MHz) | - | sysclk_select | - |
| 0x358 | 1 | stream_state | C | update stream cipher running state (init 0xA7) | update_stream_decrypt | init_ram358, update_stream_decrypt | A7 |
| 0x35C | 4 | stream_counter | C | update stream cipher byte counter | update_stream_decrypt | init_ram358, update_stream_decrypt | 0 |
| 0x360 | 1 | i2c_done | C | I2C transaction done flag | i2c_read_reg, i2c_write_reg | ISR_I2C0, i2c_read_reg, i2c_write_reg | 0,1 |
| 0x361 | 1 | i2c_busy | C | I2C busy flag | - | ISR_I2C0, i2c_read_reg, i2c_write_reg | 0,1 |
| 0x362 | 1 | i2c_error | C | I2C error flag (timeout) | i2c_read_reg, i2c_write_reg, imu_init | i2c_read_reg, i2c_write_reg, main | 0 |
| 0x363 | 1 | i2c_bytes_left | C | I2C bytes remaining | ISR_I2C0 | ISR_I2C0, i2c_read_reg, i2c_write_reg | 0 |
| 0x364 | 1 | i2c_len | C | I2C transaction length parameter | ISR_I2C0 | i2c_read_reg | - |
| 0x365 | 1 | i2c_rx_idx | C | I2C rx index | ISR_I2C0 | ISR_I2C0, i2c_read_reg | 2 |
| 0x366 | 1 | i2c_phase | C | I2C phase (0 idle 1 .. 3 write) | ISR_I2C0 | ISR_I2C0, i2c_read_reg, i2c_write_reg | 0,1,2,3 |
| 0x368 | 2 | i2c_timeout | C | I2C timeout counter (10000) | i2c_read_reg, i2c_write_reg | i2c_read_reg, i2c_write_reg | 2710 |
| 0x36A | 1 | i2c_wr_reg | C | I2C write: register | ISR_I2C0 | i2c_write_reg | - |
| 0x36B | 1 | i2c_wr_val | C | I2C write: value | ISR_I2C0 | i2c_write_reg | - |
| 0x36C | 4 | i2c_base_ptr | C | pointer to I2C0 peripheral (0x40010100) | ISR_I2C0, i2c_read_reg, i2c_write_reg, i2c0_init | i2c0_init | - |
| 0x370 | 1 | imu_missing | C | IMU not detected / read failure flag (error code 0x43) | uart0_status_frame_tx, imu_attitude_update, main, imu_read | imu_init, imu_read | 0,1 |
| 0x371 | 1 | imu_whoami | C | last WHO_AM_I value read (0x6A expected) | imu_init, imu_read | imu_init, imu_read | - |
| 0x372 | 1 | calib_done | C | calibration finished flag | calibration_measure_and_save, uart0_command_dispatcher | calibration_measure_and_save, uart0_command_dispatcher | 0,1 |
| 0x373 | 1 | calib_request | C | calibration requested (service cmd 0x35) | calibration_measure_and_save | calibration_measure_and_save, uart0_command_dispatcher | 0,1 |
| 0x374 | 1 | remote_status_flag | prior-verified | remote status flag (clamps recovery selector to 30) | coast_regen_demand, uart0_status_frame_tx | remote_flag374_filter | 0,1 |
| 0x376 | 2 | incline_dd | S | IMU-derived inclination value, int(-10*roll_deg) (0.1 deg) | remote_flag374_filter, lowspeed_brake_state, uart0_command_dispatcher | imu_attitude_update | 0 |
| 0x378 | 2 | incline_pitch | S | IMU-derived second angle int(10*pitch_deg) | uart0_command_dispatcher | imu_attitude_update | - |
| 0x37A | 2 | imu_off_gx | L | IMU calibration offset (gyro/accel channel 0) | calibration_save, imu_read | calibration_measure_and_save, calibration_load | 0 |
| 0x37C | 2 | imu_off_gy | L | IMU calibration offset channel 1 | calibration_save, imu_read | calibration_measure_and_save, calibration_load | 0 |
| 0x37E | 2 | imu_off_gz | L | IMU calibration offset channel 2 | calibration_save, imu_read | calibration_measure_and_save, calibration_load | - |
| 0x380 | 2 | imu_off_ax | L | IMU calibration offset channel 3 | calibration_save, imu_read | calibration_measure_and_save, calibration_load | 0 |
| 0x382 | 2 | imu_off_ay | L | IMU calibration offset channel 4 | calibration_save, imu_read | calibration_measure_and_save, calibration_load | 0 |
| 0x384 | 2 | imu_off_az | L | IMU calibration offset channel 5 (+-0x1000 gravity) | calibration_measure_and_save, calibration_save, imu_read | calibration_measure_and_save, calibration_load | 0 |
| 0x386 | 2 | decel_filt | C | filtered speed derivative (114*(v-prev), IIR 1/20) | remote_flag374_filter, imu_attitude_update | remote_flag374_filter | 0 |
| 0x388 | 2 | speed_prev_388 | C | previous speed for derivative | remote_flag374_filter | remote_flag374_filter | - |
| 0x38A | 2 | decel_cnt_up | C | counter of incline < -20 (to 400 sets flag) | remote_flag374_filter | remote_flag374_filter | 0,190 |
| 0x38C | 2 | decel_cnt_down | C | counter of incline > -10 (to 500 clears flag) | remote_flag374_filter | remote_flag374_filter | 0,1F4 |
| 0x38E | 2 | imu_f0 | L | filtered IMU channel (gyro X?) | imu_attitude_update, imu_read | imu_read | - |
| 0x390 | 2 | imu_f1 | L | filtered IMU channel | imu_attitude_update, imu_read | imu_read | - |
| 0x392 | 2 | imu_f2 | L | filtered IMU channel (accel Z) | imu_attitude_update, imu_read | imu_read | - |
| 0x394 | 2 | imu_f3 | L | filtered IMU channel | imu_attitude_update, imu_read | imu_read | - |
| 0x396 | 2 | imu_f4 | L | filtered IMU channel | imu_attitude_update, imu_read | imu_read | - |
| 0x398 | 2 | imu_f5 | L | filtered IMU channel | imu_attitude_update, imu_read | imu_read | - |
| 0x39A | 2 | imu_raw0 | C | IMU raw word 0 (register 0x22 block) | calibration_measure_and_save | imu_read | - |
| 0x39C | 2 | imu_raw1 | C | IMU raw word 1 | calibration_measure_and_save | imu_read | - |
| 0x39E | 2 | imu_raw2 | C | IMU raw word 2 | calibration_measure_and_save | imu_read | - |
| 0x3A0 | 2 | imu_raw3 | C | IMU raw word 3 | calibration_measure_and_save | imu_read | - |
| 0x3A2 | 2 | imu_raw4 | C | IMU raw word 4 | calibration_measure_and_save | imu_read | - |
| 0x3A4 | 2 | imu_raw5 | C | IMU raw word 5 | calibration_measure_and_save | imu_read | - |
| 0x3A8 | 4 | imu_angle_a | C | float angle A (deg) | - | imu_attitude_update | 0 |
| 0x3AC | 4 | imu_angle_b | C | float angle B (deg) | imu_attitude_update | imu_attitude_update | 0 |
| 0x3B0 | 16 | imu_quat | C | float quaternion q0..q3 (Madgwick filter state) | imu_attitude_update | imu_attitude_update | - |
| 0x3B4 | 4 | imu_quat+0x4 | C | (inside imu_quat) | imu_attitude_update | imu_attitude_update | - |
| 0x3B8 | 4 | imu_quat+0x8 | C | (inside imu_quat) | imu_attitude_update | imu_attitude_update | - |
| 0x3BC | 4 | imu_quat+0xC | C | (inside imu_quat) | imu_attitude_update | imu_attitude_update | - |
| 0x3C0 | 12 | imu_gyro_f | C | float gyro rates (rad/s) x,y,z | imu_attitude_update | imu_attitude_update | - |
| 0x3C4 | 4 | imu_gyro_f+0x4 | C | (inside imu_gyro_f) | imu_attitude_update | imu_attitude_update | - |
| 0x3C8 | 4 | imu_gyro_f+0x8 | C | (inside imu_gyro_f) | imu_attitude_update | imu_attitude_update | - |
| 0x3CC | 12 | imu_acc_f | C | float accel (normalised) x,y,z | imu_attitude_update | imu_attitude_update | - |
| 0x3D0 | 4 | imu_acc_f+0x4 | C | (inside imu_acc_f) | imu_attitude_update | imu_attitude_update | - |
| 0x3D4 | 4 | imu_acc_f+0x8 | C | (inside imu_acc_f) | imu_attitude_update | imu_attitude_update | - |
| 0x438 | 16 | ctrl_block | prior-verified | controller parameter block (regen demands at +4/+6/+8) | throttle_mode_block | region_config_defaults | 99,CB |
| 0x43A | 2 | ctrl_block+0x2 | prior-verified | (inside ctrl_block) | throttle_mode_block | region_config_defaults | CB,FD |
| 0x43C | 2 | ctrl_block+0x4 | prior-verified | (inside ctrl_block) | coast_regen_demand | region_config_defaults | 5B |
| 0x43E | 2 | ctrl_block+0x6 | prior-verified | (inside ctrl_block) | coast_regen_demand | region_config_defaults | 92 |
| 0x440 | 2 | ctrl_block+0x8 | prior-verified | (inside ctrl_block) | coast_regen_demand | region_config_defaults | 124 |
| 0x442 | 2 | ctrl_block+0xA | prior-verified | (inside ctrl_block) | - | active_brake_demand_calc, region_config_defaults | 17C,1F4 |
| 0x444 | 1 | ctrl_block+0xC | prior-verified | (inside ctrl_block) | - | active_brake_demand_calc, region_config_defaults | 0 |
| 0x445 | 1 | ctrl_445 | derived-from-code | control byte compared to ram 0x300 | direction_lowspeed_flags, speed_loop | region_config_defaults | 0 |
| 0x446 | 1 | ctrl_block+0xE | prior-verified | (inside ctrl_block) | - | region_config_defaults | 3 |
| 0x44A | 2 | angle_off_rev | C | rotor angle offset reverse (0x0E38) | - | region_config_defaults | E38 |
| 0x44C | 2 | angle_off_fwd | C | rotor angle offset forward (0x1A4F) | - | region_config_defaults | 1A4F |
| 0x450 | 4 | ctrl_450 | U | control constant 0x1D4C0 (120000) | - | region_config_defaults | 1D4C0 |
| 0x454 | 2 | vbus_regen_limit | S | regen voltage ceiling in vbus_raw counts: 1001 (=54.07 V at 0.054 V/count) or 1013 for regional ids; braking drive is cut when vbus_raw exceeds it | current_limiter_drive_cmd | region_config_defaults | 3E9,3F5 |
| 0x456 | 1 | ctrl_456 | U | control constant (0x14 default / 0x0F region) | - | region_config_defaults | F,14 |
| 0x457 | 1 | ctrl_457 | U | control constant (0x0F default / 0x0A region) | - | region_config_defaults | A,F |
| 0x458 | 80 | settings_buf | C | settings/calibration working buffer (20 words): magic, odometer, flags, identity words, key words... | calibration_load | settings_save, calibration_save | 12345678,5A5A5AA5 |
| 0x45C | 2 | settings_buf+0x4 | C | (inside settings_buf) | settings_load, calibration_load | settings_save, calibration_save | - |
| 0x460 | 2 | settings_buf+0x8 | C | (inside settings_buf) | calibration_load | calibration_save | - |
| 0x464 | 2 | settings_buf+0xC | C | (inside settings_buf) | calibration_load | calibration_save | - |
| 0x468 | 2 | settings_buf+0x10 | C | (inside settings_buf) | calibration_load | calibration_save | - |
| 0x46C | 2 | settings_buf+0x14 | C | (inside settings_buf) | calibration_load | calibration_save | - |
| 0x470 | 2 | settings_buf+0x18 | C | (inside settings_buf) | settings_load, calibration_load, settings_save | settings_save, calibration_save | 0,1 |
| 0x474 | 4 | settings_buf+0x1C | C | (inside settings_buf) | settings_load, calibration_load, calibration_save | settings_save, calibration_save | 0 |
| 0x478 | 4 | settings_buf+0x20 | C | (inside settings_buf) | settings_load | settings_save | - |
| 0x47C | 4 | settings_buf+0x24 | C | (inside settings_buf) | settings_load | settings_save | - |
| 0x480 | 4 | settings_buf+0x28 | C | (inside settings_buf) | settings_load | settings_save | - |
| 0x494 | 4 | settings_buf+0x3C | C | (inside settings_buf) | settings_load | settings_save | - |
| 0x498 | 4 | child_state | prior-verified | child-mode state word (0 or 0xC1) v7.1/RC builds | - | - | - |
| 0x4A8 | 100 | history_a | L | 50-entry history table (16-bit values) persisted in settings | - | settings_save | - |
| 0x50C | 100 | history_b | L | second 50-entry history table | - | settings_save | - |
| 0x570 | 16 | throttle_ring | C | 8-sample throttle ring | - | - | - |
| 0x580 | 16 | uart0_tx_frame | C | UART0 reply frame build buffer (hdr 0x64/0x65) | uart0_command_dispatcher | uart0_command_dispatcher | 64,65 |
| 0x581 | 1 | uart0_tx_frame+0x1 | C | (inside uart0_tx_frame) | - | uart0_command_dispatcher | - |
| 0x582 | 1 | uart0_tx_frame+0x2 | C | (inside uart0_tx_frame) | uart0_command_dispatcher | uart0_command_dispatcher | 1,2,4,8 |
| 0x583 | 1 | uart0_tx_frame+0x3 | C | (inside uart0_tx_frame) | - | uart0_command_dispatcher | 0,1,4B |
| 0x584 | 1 | uart0_tx_frame+0x4 | C | (inside uart0_tx_frame) | - | uart0_command_dispatcher | 13 |
| 0x585 | 1 | uart0_tx_frame+0x5 | C | (inside uart0_tx_frame) | - | uart0_command_dispatcher | 9C |
| 0x586 | 1 | uart0_tx_frame+0x6 | C | (inside uart0_tx_frame) | - | uart0_command_dispatcher | - |
| 0x587 | 1 | uart0_tx_frame+0x7 | C | (inside uart0_tx_frame) | - | uart0_command_dispatcher | 18 |
| 0x588 | 1 | uart0_tx_frame+0x8 | C | (inside uart0_tx_frame) | - | uart0_command_dispatcher | 6 |
| 0x589 | 1 | uart0_tx_frame+0x9 | C | (inside uart0_tx_frame) | - | uart0_command_dispatcher | - |
| 0x58A | 1 | uart0_tx_frame+0xA | C | (inside uart0_tx_frame) | - | uart0_command_dispatcher | - |
| 0x58B | 1 | uart0_tx_frame+0xB | C | (inside uart0_tx_frame) | - | uart0_command_dispatcher | - |
| 0x58C | 1 | uart0_tx_frame+0xC | C | (inside uart0_tx_frame) | - | uart0_command_dispatcher | - |
| 0x58D | 1 | uart0_tx_frame+0xD | C | (inside uart0_tx_frame) | - | uart0_command_dispatcher | - |
| 0x58E | 1 | uart0_tx_frame+0xE | C | (inside uart0_tx_frame) | - | uart0_command_dispatcher | - |
| 0x58F | 1 | uart0_tx_frame+0xF | C | (inside uart0_tx_frame) | - | uart0_command_dispatcher | - |
| 0x5B2 | 32 | ascii_reply_buf | C | ASCII reply buffer ('ok ...') | - | ascii_down_command_executor | 6F |
| 0x5B3 | 1 | ascii_reply_buf+0x1 | C | (inside ascii_reply_buf) | - | ascii_down_command_executor | 6B |
| 0x5B4 | 1 | ascii_reply_buf+0x2 | C | (inside ascii_reply_buf) | - | ascii_down_command_executor | 20 |
| 0x5E4 | 16 | aes_key | C | 16-byte AES key (default A0..AF; written by service cmd 0x1A when not activated) | - | - | - |
| 0x5F4 | 150 | uart0_rx_buf | C | UART0 RX accumulation buffer | ISR_UART0 | ISR_UART0 | - |
| 0x5F5 | 1 | uart0_rx_buf+0x1 | C | (inside uart0_rx_buf) | - | ISR_UART0 | - |
| 0x5F6 | 1 | uart0_rx_buf+0x2 | C | (inside uart0_rx_buf) | ISR_UART0 | - | - |
| 0x5F8 | 1 | uart0_rx_buf+0x4 | C | (inside uart0_rx_buf) | ISR_UART0 | - | - |
| 0x68A | 150 | uart0_rx_frame | C | UART0 completed frame (control frame 0x51, xmodem 0x01 block etc.) | uart0_command_dispatcher, xmodem_update_receiver | ISR_UART0 | 4 |
| 0x68B | 1 | uart0_rx_frame+0x1 | C | (inside uart0_rx_frame) | uart0_command_dispatcher, xmodem_update_receiver | - | - |
| 0x68C | 1 | uart0_rx_frame+0x2 | C | (inside uart0_rx_frame) | uart0_update_handler, uart0_command_dispatcher, xmodem_update_receiver | - | - |
| 0x68D | 1 | uart0_rx_frame+0x3 | C | (inside uart0_rx_frame) | uart0_command_dispatcher, xmodem_update_receiver | - | - |
| 0x68E | 1 | uart0_rx_frame+0x4 | C | (inside uart0_rx_frame) | uart0_update_handler, uart0_command_dispatcher, xmodem_update_receiver | - | - |
| 0x68F | 1 | uart0_rx_frame+0x5 | C | (inside uart0_rx_frame) | uart0_update_handler, uart0_command_dispatcher, xmodem_update_receiver | - | - |
| 0x690 | 1 | uart0_rx_frame+0x6 | C | (inside uart0_rx_frame) | uart0_update_handler, uart0_command_dispatcher, xmodem_update_receiver | - | - |
| 0x691 | 1 | uart0_rx_frame+0x7 | C | (inside uart0_rx_frame) | uart0_command_dispatcher, xmodem_update_receiver | - | - |
| 0x692 | 1 | uart0_rx_frame+0x8 | C | (inside uart0_rx_frame) | uart0_command_dispatcher, xmodem_update_receiver | - | - |
| 0x693 | 1 | uart0_rx_frame+0x9 | C | (inside uart0_rx_frame) | uart0_command_dispatcher, xmodem_update_receiver | - | - |
| 0x694 | 1 | uart0_rx_frame+0xA | C | (inside uart0_rx_frame) | xmodem_update_receiver | - | - |
| 0x695 | 1 | uart0_rx_frame+0xB | C | (inside uart0_rx_frame) | xmodem_update_receiver | - | - |
| 0x696 | 1 | uart0_rx_frame+0xC | C | (inside uart0_rx_frame) | xmodem_update_receiver | - | - |
| 0x697 | 1 | uart0_rx_frame+0xD | C | (inside uart0_rx_frame) | xmodem_update_receiver | - | - |
| 0x698 | 1 | uart0_rx_frame+0xE | C | (inside uart0_rx_frame) | xmodem_update_receiver | - | - |
| 0x699 | 1 | uart0_rx_frame+0xF | C | (inside uart0_rx_frame) | xmodem_update_receiver | - | - |
| 0x69A | 1 | uart0_rx_frame+0x10 | C | (inside uart0_rx_frame) | xmodem_update_receiver | - | - |
| 0x69B | 1 | uart0_rx_frame+0x11 | C | (inside uart0_rx_frame) | xmodem_update_receiver | - | - |
| 0x69C | 1 | uart0_rx_frame+0x12 | C | (inside uart0_rx_frame) | xmodem_update_receiver | - | - |
| 0x69D | 1 | uart0_rx_frame+0x13 | C | (inside uart0_rx_frame) | xmodem_update_receiver | - | - |
| 0x69E | 1 | uart0_rx_frame+0x14 | C | (inside uart0_rx_frame) | xmodem_update_receiver | - | - |
| 0x69F | 1 | uart0_rx_frame+0x15 | C | (inside uart0_rx_frame) | xmodem_update_receiver | - | - |
| 0x6A0 | 1 | uart0_rx_frame+0x16 | C | (inside uart0_rx_frame) | xmodem_update_receiver | - | - |
| 0x6A1 | 1 | uart0_rx_frame+0x17 | C | (inside uart0_rx_frame) | xmodem_update_receiver | - | - |
| 0x6A2 | 1 | uart0_rx_frame+0x18 | C | (inside uart0_rx_frame) | xmodem_update_receiver | - | - |
| 0x6A3 | 1 | uart0_rx_frame+0x19 | C | (inside uart0_rx_frame) | xmodem_update_receiver | - | - |
| 0x720 | 50 | uart0_tx_ring | C | UART0 transmit ring buffer | - | - | - |
| 0x752 | 16 | rand_challenge | C | mcu_rand challenge bytes (compared in mcu_key) | - | - | - |
| 0x762 | 16 | aes_in_762 | C | AES input block (ble_rand) | - | - | - |
| 0x772 | 16 | aes_in_772 | C | AES input block (mcu_key) | - | - | - |
| 0x782 | 16 | aes_out_782 | C | AES output block | - | - | - |
| 0x792 | 16 | aes_out_792 | C | AES output block (decrypted) | - | - | - |
| 0x7A2 | 12 | sector_time_hist | C | six 16-bit sector-time samples (one electrical revolution) | - | - | - |
| 0x7AE | 1 | uart1_flag_base | L | base of UART1 request flags | - | - | - |
| 0x7AF | 1 | uart1_rx_flag_41 | C | selector 0x41 data pending | uart1_rx_frame_parser, uart1_request_builder | uart1_rx_frame_parser, uart1_request_builder | 0 |
| 0x7B0 | 1 | uart1_rx_flag_42 | C | selector 0x42 data pending | uart1_rx_frame_parser, uart1_request_builder, main | uart1_rx_frame_parser, uart1_request_builder, startup_calibrate_and_load | 0 |
| 0x7B1 | 1 | uart1_rx_flag_43 | C | selector 0x43 data pending | uart1_rx_frame_parser, uart1_request_builder | uart1_rx_frame_parser, uart1_request_builder | 0 |
| 0x7B2 | 1 | uart1_rx_flag_40 | C | selector 0x40/0x41 flag pending (poll index 0) | uart1_request_builder | uart1_request_builder | 0 |
| 0x7B3 | 1 | uart1_rx_flag_45 | C | selector 0x45 data pending | uart1_rx_frame_parser, uart1_request_builder | uart1_rx_frame_parser, uart1_request_builder | 0 |
| 0x7B4 | 1 | uart1_rx_flag_46 | C | selector 0x46 data pending | uart1_rx_frame_parser, uart1_request_builder | uart1_rx_frame_parser, uart1_request_builder | 0 |
| 0x7B5 | 1 | uart1_req_47 | C | request flag selector 0x47 | uart1_request_builder | uart1_request_builder, uart0_command_dispatcher | 0,1 |
| 0x7B6 | 1 | uart1_req_48 | C | request flag selector 0x48 | uart1_request_builder, main | uart1_request_builder, uart0_command_dispatcher | 0,1 |
| 0x7B7 | 1 | uart1_req_49 | C | request flag selector 0x49 | uart1_request_builder | uart1_request_builder | 0 |
| 0x7B8 | 1 | uart1_req_4a | C | request flag selector 0x4A | uart1_request_builder | uart1_request_builder | 0 |
| 0x7BA | 1 | uart1_req_60 | C | request flag selector 0x60 | uart1_request_builder | uart1_request_builder, uart0_command_dispatcher | 0,1 |
| 0x7BB | 1 | uart1_req_61 | C | request flag selector 0x61 | uart1_request_builder | uart1_request_builder, uart0_command_dispatcher | 0,1 |
| 0x7BC | 1 | uart1_req_63 | C | request flag selector 0x63 | uart1_request_builder | uart1_request_builder, uart0_command_dispatcher | 0,1 |
| 0x7BD | 18 | remote_blob_46 | C | selector 0x46 payload (18 bytes) | - | - | - |
| 0x7CF | 20 | uart1_rx_frame | C | UART1 completed reply frame (hdr, selector, length, payload, sum, tail) | uart1_rx_frame_parser, uart_reply_pass_handler | ISR_UART1 | - |
| 0x7D0 | 1 | uart1_rx_frame+0x1 | C | (inside uart1_rx_frame) | uart1_rx_frame_parser | - | - |
| 0x7D1 | 1 | uart1_rx_frame+0x2 | C | (inside uart1_rx_frame) | uart1_rx_frame_parser | - | - |
| 0x7D2 | 1 | uart1_rx_frame+0x3 | C | (inside uart1_rx_frame) | uart1_rx_frame_parser | - | - |
| 0x7D3 | 1 | uart1_rx_frame+0x4 | C | (inside uart1_rx_frame) | uart1_rx_frame_parser | - | - |
| 0x7D4 | 1 | uart1_rx_frame+0x5 | C | (inside uart1_rx_frame) | uart1_rx_frame_parser | - | - |
| 0x7D5 | 1 | uart1_rx_frame+0x6 | C | (inside uart1_rx_frame) | uart1_rx_frame_parser | - | - |
| 0x7D6 | 1 | uart1_rx_frame+0x7 | C | (inside uart1_rx_frame) | uart1_rx_frame_parser | - | - |
| 0x7D7 | 1 | uart1_rx_frame+0x8 | C | (inside uart1_rx_frame) | uart1_rx_frame_parser | - | - |
| 0x7D8 | 1 | uart1_rx_frame+0x9 | C | (inside uart1_rx_frame) | uart1_rx_frame_parser | - | - |
| 0x7D9 | 1 | uart1_rx_frame+0xA | C | (inside uart1_rx_frame) | uart1_rx_frame_parser | - | - |
| 0x7DA | 1 | uart1_rx_frame+0xB | C | (inside uart1_rx_frame) | uart1_rx_frame_parser | - | - |
| 0x7DB | 1 | uart1_rx_frame+0xC | C | (inside uart1_rx_frame) | uart1_rx_frame_parser | - | - |
| 0x7DC | 1 | uart1_rx_frame+0xD | C | (inside uart1_rx_frame) | uart1_rx_frame_parser | - | - |
| 0x7DD | 1 | uart1_rx_frame+0xE | C | (inside uart1_rx_frame) | uart1_rx_frame_parser | - | - |
| 0x7DE | 1 | uart1_rx_frame+0xF | C | (inside uart1_rx_frame) | uart1_rx_frame_parser | - | - |
| 0x801 | 50 | uart1_rx_buf | C | UART1 RX accumulation buffer | - | ISR_UART1 | - |
| 0x802 | 1 | uart1_rx_buf+0x1 | C | (inside uart1_rx_buf) | ISR_UART1 | - | - |
| 0x803 | 1 | uart1_rx_buf+0x2 | C | (inside uart1_rx_buf) | ISR_UART1 | - | - |
| 0x833 | 150 | uart1_tx_ring | C | UART1 transmit ring buffer | - | - | - |
| 0x8CA | 16 | remote_telemetry | prior-verified | UART1 selector 0x44 telemetry copy (SOC at +1 -> 0x8CB) | uart0_status_frame_tx | uart1_rx_frame_parser | - |
| 0x8CB | 1 | remote_telemetry+0x1 | prior-verified | (inside remote_telemetry) | coast_regen_demand, voltage_monitor | uart1_rx_frame_parser, startup_calibrate_and_load | 64 |
| 0x8CC | 2 | remote_telemetry+0x2 | prior-verified | (inside remote_telemetry) | uart0_status_frame_tx | uart1_rx_frame_parser | - |
| 0x8CE | 2 | remote_telemetry+0x4 | prior-verified | (inside remote_telemetry) | uart0_status_frame_tx | uart1_rx_frame_parser | - |
| 0x8D0 | 1 | remote_telemetry+0x6 | prior-verified | (inside remote_telemetry) | uart0_status_frame_tx | uart1_rx_frame_parser | - |
| 0x8D1 | 1 | persist_flags_8d1 | prior-verified | persistent flag byte consumed by main inhibit | uart0_status_frame_tx, cruise_hold_logic, speed_loop | uart1_rx_frame_parser | - |
| 0x8D2 | 1 | remote_status_8d2 | prior-verified | selector44 status byte (mask 0x2C) | uart0_status_frame_tx, envelope_protection | uart1_rx_frame_parser | - |
| 0x8D4 | 2 | remote_telemetry+0xA | prior-verified | (inside remote_telemetry) | uart0_command_dispatcher | uart1_rx_frame_parser | - |
| 0x8D6 | 2 | remote_telemetry+0xC | prior-verified | (inside remote_telemetry) | uart0_command_dispatcher | uart1_rx_frame_parser | - |
| 0x8D8 | 2 | remote_telemetry+0xE | prior-verified | (inside remote_telemetry) | uart0_command_dispatcher | uart1_rx_frame_parser | - |
| 0x8DA | 6 | remote_telemetry2 | C | selector 0x45 tail words | uart0_command_dispatcher | uart1_rx_frame_parser | - |
| 0x8DC | 2 | remote_telemetry2+0x2 | C | (inside remote_telemetry2) | uart0_command_dispatcher | uart1_rx_frame_parser | - |
| 0x8DE | 2 | remote_telemetry2+0x4 | C | (inside remote_telemetry2) | uart0_command_dispatcher | uart1_rx_frame_parser | - |
| 0x8E0 | 1 | remote_telemetry_e0 | C | selector 0x45 last byte | uart0_command_dispatcher | uart1_rx_frame_parser | - |
| 0x8E2 | 10 | ctrl_snapshot | C | snapshot of last dashboard control-frame fields (shared with UART1 request 0x47 payload) | uart1_request_builder, uart0_command_dispatcher | uart1_rx_frame_parser, uart0_command_dispatcher | - |
| 0x8E4 | 1 | ctrl_snapshot+0x2 | C | (inside ctrl_snapshot) | uart1_request_builder, uart0_command_dispatcher | uart1_rx_frame_parser, uart0_command_dispatcher | - |
| 0x8E5 | 1 | ctrl_snapshot+0x3 | C | (inside ctrl_snapshot) | uart1_request_builder, uart0_command_dispatcher | uart1_rx_frame_parser, uart0_command_dispatcher | - |
| 0x8E6 | 1 | ctrl_snapshot+0x4 | C | (inside ctrl_snapshot) | uart1_request_builder, uart0_command_dispatcher | uart1_rx_frame_parser, uart0_command_dispatcher | - |
| 0x8E7 | 1 | ctrl_snapshot+0x5 | C | (inside ctrl_snapshot) | uart1_request_builder, uart0_command_dispatcher | uart1_rx_frame_parser, uart0_command_dispatcher | - |
| 0x8E8 | 1 | ctrl_snapshot+0x6 | C | (inside ctrl_snapshot) | uart1_request_builder, uart0_command_dispatcher | uart1_rx_frame_parser, uart0_command_dispatcher | - |
| 0x8E9 | 1 | ctrl_snapshot+0x7 | C | (inside ctrl_snapshot) | uart1_request_builder, uart0_command_dispatcher | uart1_rx_frame_parser, uart0_command_dispatcher | - |
| 0x8EA | 1 | ctrl_snapshot+0x8 | C | (inside ctrl_snapshot) | uart1_request_builder, uart0_command_dispatcher | uart1_rx_frame_parser, uart0_command_dispatcher | - |
| 0x8EB | 1 | ctrl_snapshot+0x9 | C | (inside ctrl_snapshot) | uart1_request_builder, uart0_command_dispatcher | uart1_rx_frame_parser, uart0_command_dispatcher | - |
| 0x8EC | 2 | i2c_buf | C | I2C master buffer (device address byte + register) | ISR_I2C0 | i2c_read_reg | - |
| 0x8ED | 1 | i2c_buf+0x1 | C | (inside i2c_buf) | ISR_I2C0 | i2c_read_reg | D7 |
| 0x8EE | 12 | imu_rx_buf | C | IMU register read result buffer (12 bytes) | i2c_read_reg, imu_read | - | - |
| 0x8EF | 1 | imu_rx_buf+0x1 | C | (inside imu_rx_buf) | imu_read | - | - |
| 0x8F0 | 1 | imu_rx_buf+0x2 | C | (inside imu_rx_buf) | imu_read | - | - |
| 0x8F1 | 1 | imu_rx_buf+0x3 | C | (inside imu_rx_buf) | imu_read | - | - |
| 0x8F2 | 1 | imu_rx_buf+0x4 | C | (inside imu_rx_buf) | imu_read | - | - |
| 0x8F3 | 1 | imu_rx_buf+0x5 | C | (inside imu_rx_buf) | imu_read | - | - |
| 0x8F4 | 1 | imu_rx_buf+0x6 | C | (inside imu_rx_buf) | imu_read | - | - |
| 0x8F5 | 1 | imu_rx_buf+0x7 | C | (inside imu_rx_buf) | imu_read | - | - |
| 0x8F6 | 1 | imu_rx_buf+0x8 | C | (inside imu_rx_buf) | imu_read | - | - |
| 0x8F7 | 1 | imu_rx_buf+0x9 | C | (inside imu_rx_buf) | imu_read | - | - |
| 0x8F8 | 1 | imu_rx_buf+0xA | C | (inside imu_rx_buf) | imu_read | - | - |
| 0x8F9 | 1 | imu_rx_buf+0xB | C | (inside imu_rx_buf) | imu_read | - | - |
| 0x9E8 | 4 | rand_ptr_a | L | C library rand() table pointer | lib___rt_entry | lib___rt_entry, lib_srand_init | 20000988 |
| 0x9EC | 4 | rand_ptr_b | L | C library rand() table pointer | lib___rt_entry | lib___rt_entry, lib_srand_init | 2000090C |
