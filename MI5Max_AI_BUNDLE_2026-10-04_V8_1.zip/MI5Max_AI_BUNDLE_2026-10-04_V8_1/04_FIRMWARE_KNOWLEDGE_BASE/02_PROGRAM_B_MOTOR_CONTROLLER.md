# Program B: the motor-controller firmware (LKS32MC071, Cortex-M0, FOC)

Coverage: **all 230 functions named**, 610 RAM cells named (`annotations/names_B_part00..12.psv`, `ram_B*.psv`, `periph_B.csv`); catalogs `B_FUNCTION_CATALOG.md`, `B_RAM_MAP.md`, `B_PERIPHERAL_MAP.md`; pseudo-code `data/B_pseudocode.txt` (10,154 lines). B is the program that differs between stock, farm v7.1, RC01 and RC02 (all differences are in B and the header). Labels: **C** confirmed from code, **S** strong, **L** likely, **U** unknown. ID syntax `B:<file offset hex>`, runtime = file - 0x17018.

## 1. Role
Drives the three-phase hub motor of the scooter: reads Hall sensors, phase currents, DC-link current and voltage, NTC temperatures and an IMU; runs a **speed loop** (requested speed -> drive command), a **current limiter/envelope**, **coast and brake regeneration**, a **governor/slip detector**, cruise hold, low-speed brake; talks to the **dashboard** (UART0) and the **BMS** (UART1); implements the **update/service** receivers and the **AES challenge/response** unlock. It never sees the physical buttons: the dashboard decodes them and sends the mode, throttle, brake, profile and power-latch bits in the control frame.

## 2. Function index by address range
| range | content |
|---|---|
| 0x198D8..0x1ADCC | C runtime and soft-float/libm (`lib_*`), Reset/default handlers (vector table at 0x19818) |
| 0x1ADCC..0x1B8D4 | NVR trim read, ADC init/config, AES wrapper, **`remote_flag374_filter`**, **UART1 parser and request builder**, ack handlers, comparator init, DSP divide, CRC16, NTC B, **`soc_from_vbus`**, modulation index, image validate |
| 0x1B8D4..0x1BFD4 | config/key/identity load-save, clock init, CRC32 HW, PWM arm/off helpers, **`coast_regen_demand` B:1BDD0**, flash erase, update state reset/decrypt, calibration measure |
| 0x1BFD4..0x1D09C | Hall init, **low-speed brake state**, I2C0 ISR + register read/write, flash program, **startup_calibrate_and_load**, **`hardware_init`**, GPIO init, ADC setup, IWDG, IMU init, GPIO outputs, **`ISR_MCPWM0` B:1CB14** |
| 0x1D09C..0x1D92C | PWM init, **UART0 status frame TX**, speed filter, Clarke/Park/inverse Park, flash write word, **d-axis regulator**, wake IRQ forward, **`current_limiter_drive_cmd` B:1D654** |
| 0x1D92C..0x1E280 | local temperature, **cruise hold**, **active brake demand**, **throttle + mode block**, direction/low-speed flags, P2.3 blink, odometer, power-stage self-test |
| 0x1E280..0x1F0EC | NTC A, **`speed_loop` B:1E3D0**, settings/calibration/identity load, ping TX, NTC convert, system reset request, **SVPWM output** |
| 0x1F0EC..0x1FF04 | clock gating/select, PLL, wake ISR, settings/calibration/identity save, **hall rotor estimator B:1F660**, **envelope protection B:1FC0C** |
| 0x1FF04..0x20488 | delay loops, isqrt, ASCII command matcher, SystemInit, **region defaults B:1FFDC**, **UART0 update handler B:200A8**, NVR trim load, **governor detector B:2036C** |
| 0x20488..0x21698 | **UART0/UART1 ISRs**, dash-loss power-off, UART init/send, **dashboard frame decoder B:20A14**, ASCII `down` executor B:210C4, XMODEM receiver B:21450 |
| 0x21698..0x2328A | ADC ch9, slew/clamp, NVIC, libm (asin/atan/log), AES core, DSP sincos, **IMU attitude estimator B:22058**, I2C0 init, float biquad, **`main` B:2292C**, IMU read, **voltage monitor B:22F38** |

## 3. Scheduler and main loop (`main` B:2292C)  **C**
* Hardware: MCPWM0 at 15.625 kHz (96 MHz clock, center-aligned, TH0 0xC00); the PWM ISR does the FOC step and every 16th ISR sets `sched_tick` (**1.024 ms**).
* Main loop: every 4th ISR (3.9 kHz) runs `current_limiter_drive_cmd` and `ch9_process`; dispatches pending UART0 frames by RAM 0x1DF (1 dashboard frame decoder, 2 ASCII executor, 3 XMODEM, 4 update handler) and UART1 frames by 0x321 (1 reply parser, 2/3 ack handlers); per tick it runs sub-schedules: **mod5**: slot0 `speed_loop`, slot1 `voltage_monitor`, slot2 `throttle_mode_block`, slot3 IMU read + attitude; **mod10**: 0 `remote_flag374_filter`, 1 UART1 request builder (every 11th visit), 2 ping, 3 direction flags, 4 `envelope_protection`, 5 speed filter + reset request, 7 `governor_detector`, 8 `active_brake_demand_calc`, 9 `cruise_hold_logic`; **mod100**: 6 `iwdg_feed`, 0x11 status frame TX, 0x13 NTC B, 0x17 odometer, 0x1B NTC A, 0x35 calibration, 0x4D low-speed brake state; **mod250**: 0x14 `dash_loss_poweroff`, 0x1D local temperature, 0x1E send "down ok", 0x21 service-mode timeout.

## 4. Control structure  (details and numbers in `04_FEATURE_CHAINS.md` sections 2 and 4)
* **Command path:** control frame (throttle, brake, mode, profile) -> `throttle_mode_block` (requested speed from mode target x throttle) -> `speed_loop` (drive command toward the requested speed; coast/brake branches) -> `current_limiter_drive_cmd` (limits by `env_applied`, `i_q` bounds, regen bounds, governor) -> ISR: d-axis regulator, inverse Park, SVPWM.
* **Estimation:** Hall-based rotor estimator with per-sector interpolation (period history of 6 sectors) -> speed (0x36CAB / period, 0.1 km/h) and electrical angle; phase currents reconstructed from the two ADC shunt channels per PWM sector (valid |x| < 1800); DC-link current from a separate channel (zero offset measured at start and at each first stop); bus voltage `vbus_raw` (`vbus_decivolt = vbus_raw * 8850 >> 14`).
* **Protection/derating:** hardware over-current comparator (DAC0 threshold 203, self-test lowers it to 51); `ISR_MCPWM0` handles the fault flag (EIF bit 4: fault code 0x14, `run_latch = 0`, MOE off); over/under voltage in `voltage_monitor` (`vbus_raw` < 603 MOE off + severe low flag, > 1075 over-voltage flag cleared < 1037, < 743 debounced 200 low warning); stall derate, thermal derate (local NTC and BMS temperature), SOC derate, ADC ch9 check (fault after 11 consecutive low reads), hall-invalid fault (hall code 0 or 7), IMU-missing fault, current-zero offsets out of +/-500 fault.
* **Modes** (dashboard byte 3 low nibble -> RAM 0x14D): 0x0B walking (env 137, target 6.2 km/h), 2 = D (env 328, 20.3 km/h), 3 = S (env 493, 25.3 km/h), 1/other (env 274, 10.3 km/h). Region prefixes 60549/60558/61124 use 15.3 / 20.3 km/h for modes 2/3 (`region_config_defaults`). **C**
* **Cruise/hold** (RAM 0x16C): engages after throttle stable within +/-10 for 500 calls and speed within +/-2.0 km/h for 300 calls, avg throttle > 10, speed > 2.0, no brake; cancels on throttle < 5 then > 15, a change > 10 from the held value, any fault, mode change; **never active for region prefixes 0xEC85/0xEEC4**.
* **Low-speed brake special state** (needs dashboard byte 9 bit 6): counter of (|incline| <= 20 and speed < 3.0 and brake pressed); special state at count >= 30 (farm builds 90). **C**
* **Governor/slip detector** (`governor_detector` B:2036C, hooked in RC02): high-pass filtered speed-frequency-like and i_q signals; product < -250 for > 8 calls sets `gov_flag` (limits i_q to a creeping value). **C**
* **IMU:** LSM6DS-class on I2C0 0x6B, Madgwick-style quaternion (beta 0.0025, gyro 0.061 dps/LSB); `ram[0x376] = int(-10 * roll_deg)`, `ram[0x378] = int(10 * pitch_deg)`; zero when the IMU is missing. Calibration offsets stored at flash 0x1F200. **C**

## 5. Communications and services
Dashboard (UART0), BMS (UART1), update, AES unlock: all in `05_PROTOCOLS_AND_REGISTERS.md`. Key points: control frame 0x51/0x10 from the dashboard (rate not visible in the image); status frame 0x61 every ~102 ms; BMS poll through objects 0x41..0x63; `remote_state` = 3 after > 300 missed polls; dashboard-loss power-off after 480 counts of the 5th tick.

## 6. Persistent data (B flash)
| page | content |
|---|---|
| 0x1FA00 | settings page (magic 0x5A5A5AA5, 20 words: odometer RAM 0xA8, flags 0x2E6/0x1D4 (activation), calibration-like words, identity words) |
| 0x1F200 | IMU calibration (magic 0x12345678, six offsets, checksum word = sum of the first 7) |
| 0x1F800 | identity (18 + 23 bytes, one byte per word) and serial |
| 0x1FC00 | update commit record (magic 0x5AA55AA5 / 0x20161107 variants, length, CRC) |
| 0xF000.. | update staging area |

## 7. Differences between builds (see `07_BUILDS_AND_DIFFS.md`)
Stock vs farm v7.1: higher regen demands (91/160/320 vs 91/146/292), coast regen from 5.0 km/h, higher per-mode envelopes and targets (D 25.0, S 45.0 km/h), the child-cap helper and six-press gesture, region-free literals, low-speed-brake threshold 90, thermal-derate threshold 900 -> 1020. RC01/RC02: child-cap fix; RC02 additionally gates the optional governor below nominal 35 km/h (two hooks). None changes the power-button path as far as the diffs show (**C** for byte diffs, **U** for hardware behaviour).

## 8. Known gaps
* Real amps-per-count and volts-per-count of the sensors (only the dashboard's own conversions are known): **U**.
* IMU angle sign vs physical slope direction: **U** (`ram[0x376] < -20` means roll > +2 degrees in the estimator's convention).
* Meaning of RAM 0xD6 init, a few single-use flags, and the Madgwick axis mapping: **U**/**L**.
* Dashboard behaviour (beep at ~30 km/h, button decoding, what it sends for the three recovery levels on a 5 Max): **U** (the stock B code only recognises exactly 30/60/90).
