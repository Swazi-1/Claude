# B function catalog (230 functions)

Program B = nested motor controller LKS32MC071 (Cortex-M0). ID syntax `B:<file offset hex>`; runtime address = file offset - 0x17018. Evidence flags: C confirmed from code, S strong, L likely, U unknown. `lib_*` = compiler/C-library routine (not application logic).

Columns: ID | runtime | size | name | conf | what it does | called from | calls | RAM written | peripheral regs written

| ID | rt | B | name | c | description | callers | callees | RAM W | periph W |
|---|---|---|---|---|---|---|---|---|---|
| B:198D8 | 28C0 | 8 | lib___main | L | C runtime entry: runs scatter-load then __rt_entry | ptr | B:198E0<lib___scatterload>, B:19944<lib___rt_entry> | - | - |
| B:198E0 | 28C8 | 52 | lib___scatterload | L | copies/zero-inits RAM from the scatter table (decompresses via B:1AD76) | B:198D8 | B:19944<lib___rt_entry> | - | - |
| B:19938 | 2920 | 8 | lib_rt_stub1 | L | C runtime stub | B:19944 | B:19A0C<lib_srand> | - | - |
| B:19940 | 2928 | 4 | lib_rt_stub2 | L | C runtime stub (returns arg) | B:19944 | - | - | - |
| B:19944 | 292C | 84 | lib___rt_entry | L | C runtime: init libs, then calls user main (B:2292C), then exit | B:198D8, B:198E0 | B:19938<lib_rt_stub1>, B:19940<lib_rt_stub2>, B:1AC78<lib_rt_lib_init>, B:1ACB6<lib_rt_stub5>, B:1AD68<lib_semihost_exit>, B:2292C<main> | rand_ptr_a, rand_ptr_b | - |
| B:19956 | 293E | 0 | lib_rt_stub3 | L | C runtime stub | B:1ACB6 | - | - | - |
| B:19964 | 294C | 0 | lib_rt_stub4 | L | C runtime stub | B:210C4 | - | - | - |
| B:1999C | 2984 | 14 | Reset_Handler | C | vector[1]: sets MSP from r0, calls SystemInit B:1FFC8 (clock), then jumps to __main B:198D8 | ptr | B:1FFC8<SystemInit> | - | - |
| B:199AA | 2992 | 2 | NMI_Handler | C | vector[2] endless loop | ptr | - | - | - |
| B:199AC | 2994 | 2 | HardFault_Handler | C | vector[3] endless loop | ptr | - | - | - |
| B:199AE | 2996 | 2 | SVC_Handler | C | vector[11] endless loop | ptr | - | - | - |
| B:199B0 | 2998 | 2 | PendSV_Handler | C | vector[14] endless loop | ptr | - | - | - |
| B:199B2 | 299A | 2 | SysTick_Handler | C | vector[15] endless loop (SysTick unused) | ptr | - | - | - |
| B:199B4 | 299C | 2 | Default_IRQ_Handler | C | all unused IRQ vectors: endless loop | ptr | - | - | - |
| B:199B8 | 29A0 | 10 | lib_user_initial_stackheap | L | returns heap/stack base 0x20000A50 | B:1AC78 | - | - | - |
| B:199E0 | 29C8 | 44 | lib_srand_init | L | seeds 55-word lagged-Fibonacci rand() table at RAM 0x90C with LCG 0x10DCD*x+0x66D619E1 | B:19A0C, B:210C4 | - | rand_ptr_a, rand_ptr_b | - |
| B:19A0C | 29F4 | 4 | lib_srand | L | srand wrapper | B:19938 | - | - | - |
| B:19A54 | 2A3C | 60 | lib_memclr | L | zero-fills r1 bytes at r0 | B:1BCC4 | - | - | - |
| B:19A58 | 2A40 | 4 | lib_memclr_alias | L | alias of memclr entry | B:21450 | - | - | - |
| B:19A5C | 2A44 | 262 | lib_uidivmod | C | unsigned 32-bit divide: r0=r0/r1 (quotient) r1=remainder | B:1DCB0, B:1E3D0 | - | - | - |
| B:19A78 | 2A60 | 226 | lib_idivmod | C | signed 32-bit divide: r0=r0/r1 r1=remainder | B:1AF94, B:1B730 | - | - | - |
| B:19C44 | 2C2C | 2 | lib_ret_stub1 | L | returns r0 | - | - | - | - |
| B:19C46 | 2C2E | 2 | lib_ret_stub2 | L | returns r0 | - | - | - | - |
| B:19C48 | 2C30 | 2 | lib_ret_stub3 | L | returns r0 | - | - | - | - |
| B:19C4C | 2C34 | 120 | lib_d2f | L | double to float conversion (soft-float) | B:22058 | - | - | - |
| B:19C56 | 2C3E | 0 | lib_stub | L | empty | - | - | - | - |
| B:19CC8 | 2CB0 | 290 | lib_dadd | L | double add (soft-float) | B:19FC0, B:19FDA, B:19FF0 | - | - | - |
| B:19DEA | 2DD2 | 470 | lib_dsub | L | double subtract (soft-float) | B:19FC0, B:19FDA, B:19FF0 | - | - | - |
| B:19FC0 | 2FA8 | 26 | lib_dadd_signed | L | double add with sign dispatch | B:1ED60, B:21810 | B:19CC8<lib_dadd>, B:19DEA<lib_dsub> | - | - |
| B:19FDA | 2FC2 | 22 | lib_dsub_signed | L | double sub with sign dispatch | B:1ED60, B:21A30, B:21CA4 | - | - | - |
| B:19FF0 | 2FD8 | 28 | lib_drsub_signed | L | double reverse subtract | B:21A30 | B:19CC8<lib_dadd>, B:19DEA<lib_dsub> | - | - |
| B:1A020 | 3008 | 1050 | lib_ddiv | L | double divide (table-based reciprocal) | B:1A450, B:1ED60, B:2036C, B:218BC, B:218E2 | - | - | - |
| B:1A450 | 3438 | 20 | lib_drdiv | L | double reverse divide | - | B:1A020<lib_ddiv> | - | - |
| B:1A468 | 3450 | 98 | lib_d2iz | L | double to signed int (truncate) | B:1ED60 | - | - | - |
| B:1A4D4 | 34BC | 68 | lib_d2uiz | L | double to unsigned int (truncate) | B:2036C | - | - | - |
| B:1A4DA | 34C2 | 0 | lib_stub | L | stub | - | - | - | - |
| B:1A55E | 3546 | 82 | lib_i2d | L | int to double | B:225D8 | - | - | - |
| B:1A56E | 3556 | 6 | lib_ui2d | L | unsigned int to double | B:1ED60, B:2036C | - | - | - |
| B:1A574 | 355C | 558 | lib_dmul | L | double multiply | B:2036C, B:21810 | - | - | - |
| B:1A7BC | 37A4 | 80 | lib_f2d | L | float to double | B:1ED60, B:22058 | - | - | - |
| B:1A810 | 37F8 | 334 | lib_fmul | L | float multiply | B:1ED60, B:224B0 | - | - | - |
| B:1A970 | 3958 | 76 | lib_f2iz | L | float to signed int (truncate) | B:1C828, B:1D3D8, B:1D5B8, B:1FC0C, B:22058 | - | - | - |
| B:1AA04 | 39EC | 88 | lib_ui2f | L | int to float (normalize) | B:1D3D8, B:1D5B8, B:1ED60, B:1FC0C, B:22058 | - | - | - |
| B:1AA14 | 39FC | 6 | lib_ui2f_alias | L | alias | B:1ED60 | - | - | - |
| B:1AA1C | 3A04 | 64 | lib_scalbnf | L | float scalbn | B:22058 | - | - | - |
| B:1AA60 | 3A48 | 10 | lib_stub | L | stub | - | B:1AAD8<lib_errno_addr> | - | - |
| B:1AA6A | 3A52 | 12 | lib_set_errno | L | stores r0 at errno address | B:21A30, B:225D8, B:22EAC | B:1AAD8<lib_errno_addr> | - | - |
| B:1AA78 | 3A60 | 84 | lib_scalbn | L | double scalbn | B:218D0, B:218F4, B:21A30 | - | - | - |
| B:1AAD8 | 3AC0 | 4 | lib_errno_addr | L | returns &errno = 0x200009F0 | B:1AA60, B:1AA6A | - | - | - |
| B:1AAE0 | 3AC8 | 140 | lib_math_error | L | libm error dispatch (pow/fmod style) | B:2300C | B:1ACC6<lib_fp_exception>, B:1ACF4<lib_dnan> | - | - |
| B:1AB70 | 3B58 | 248 | lib_sqrt | L | double sqrt (soft) | B:22EAC | - | - | - |
| B:1AC70 | 3C58 | 4 | lib_errno_addr2 | L | returns &errno | B:1AC78 | - | - | - |
| B:1AC78 | 3C60 | 62 | lib_rt_lib_init | L | clears C library state | B:19944 | B:199B8<lib_user_initial_stackheap>, B:1AC70<lib_errno_addr2> | - | - |
| B:1AC8E | 3C76 | 0 | - |  | - | - | - | - | - |
| B:1ACB6 | 3C9E | 16 | lib_rt_stub5 | L | stub | B:19944 | B:19956<lib_rt_stub3> | - | - |
| B:1ACC6 | 3CAE | 46 | lib_fp_exception | L | FP exception flag helper | B:1AAE0, B:1AD08 | - | - | - |
| B:1ACF4 | 3CDC | 14 | lib_dnan | L | returns NaN via math error | B:1AAE0 | B:1AD08<lib_math_err2> | - | - |
| B:1AD08 | 3CF0 | 94 | lib_math_err2 | L | libm error code helper | B:1ACF4 | B:1ACC6<lib_fp_exception> | - | - |
| B:1AD68 | 3D50 | 6 | lib_semihost_exit | L | bkpt 0xAB semihosting exit | B:19944 | - | - | - |
| B:1AD74 | 3D5C | 2 | - |  | - | - | - | - | - |
| B:1AD76 | 3D5E | 86 | lib_scatter_decompress | C | decompresses packed init data (literal/zero-run/backref tokens) used by __scatterload | - | - | - | - |
| B:1ADCC | 3DB4 | 52 | flash_nvr_read | C | reads one word from the flash NVR info area at address r0 using FLASH_CFG region bit + FLASH_ADDR unlock keys 0x59000000/0x95000000 (factory trim read) | B:1AE38 | - | - | FLASH_CFG, FLASH_ADDR |
| B:1AE08 | 3DF0 | 42 | adc_cfg_channel | C | ADC_ChannelConfig(adc,slot,channel,gain): writes 4-bit channel into ADCx_CHN0..3 nibble for slot, sets ADCx_GAIN bit when gain==1 | B:1C84C | - | - | - |
| B:1AE32 | 3E1A | 6 | adc_set_ie | C | writes ADCx_IE (r0+0x94) = r1 | B:1C84C | - | - | - |
| B:1AE38 | 3E20 | 176 | adc_init | C | ADC_Init(adc,cfg): enables ADC clock (B:1F0EC), writes ADCx_CHNT/TRIG/CFG/LTH/HTH/GEN from cfg struct ... | B:1C84C | B:1ADCC<flash_nvr_read>, B:1F0EC<afe_reg5_set> | - | ADC0_DC0, ADC0_AMC0, ADC0_DC1, ADC0_AMC1, ADC1_DC0 |
| B:1AEF4 | 3EDC | 32 | adc_cfg_default | C | zero-initialises ADC init struct (sequence lengths 1,1,1) | B:1C84C | - | - | - |
| B:1AF14 | 3EFC | 126 | aes128_block_wrapper | L | transposes two 16-byte blocks (state/key) and calls the AES core B:21930, transposes result back (aes encrypt/decrypt block) | B:210C4 | B:21930<aes128_core> | - | - |
| B:1AF94 | 3F7C | 156 | remote_flag374_filter | C | sustained-condition detector: filters speed derivative (0x386) and, when ram 0x1D8!=0, sets remote_status_flag(0x374)=1 after 400 calls of ram[0x376]<-20 ... | B:2292C | B:19A78<lib_idivmod> | remote_status_flag, decel_filt, speed_prev_388, decel_cnt_up, decel_cnt_down | - |
| B:1B03C | 4024 | 658 | uart1_rx_frame_parser | C | parses replies from the battery-side processor in RX buffer ram 0x7CF (hdr 0x74, sel at 0x7D0, len 0x7D1, sum, tail 0x8B): stores telemetry per selector 0x41-0x4A,0x60 ... | B:2292C | B:208E0<uart0_send>, B:21714<lib_switch8_helper> | uart0_tx_pending, uart1_rx_tmp, uart1_req_flag_326, remote_state, remote_temp, uart1_age | - |
| B:1B2E8 | 42D0 | 610 | uart1_request_builder | C | round-robin poll scheduler: picks next pending selector (flags 0x7AF..0x7BC, index 0x32E), builds request frame (hdr 0x63, sel 0x41..0x4B/0x60/0x61/0x63 ... | B:2292C | B:209A8<uart1_send>, B:21714<lib_switch8_helper> | uart1_req_0e, remote_state, uart1_poll_idx, uart1_poll_sub, uart1_poll_next, uart1_poll_toggle | - |
| B:1B56C | 4554 | 104 | uart_reply_ack_handler | L | checks reply code from B:1FF38 (6 or 7), builds 3-byte status reply at 0x336 and sends via B:208E0 (update/ack path) | B:2292C | B:1BF44<update_state_reset>, B:1FF38<uart_cmd_match>, B:208E0<uart0_send> | upd_active, xmodem_state_220, remote_temp+0x1, update_ack_flag, uart_ack_buf | - |
| B:1B5E8 | 45D0 | 90 | uart_reply_pass_handler | L | handles 0x18-coded reply, counter 0x333, forwards 1 byte via B:208E0 | B:2292C | B:1BF44<update_state_reset>, B:208E0<uart0_send> | upd_flag_1e6, upd_flag_1e7, upd_flag_1e8, upd_active, uart1_pass_cnt | - |
| B:1B65C | 4644 | 26 | cmp_init | C | unlock SYS_PROTECT=0x7A83, SYS_AFE_REG3/=8, CMP_TCLK=8, CMP_CFG=2 (comparator for hardware over-current trip path) | B:1C6AC | - | - | SYS_AFE_REG3, SYS_PROTECT, CMP_TCLK, CMP_CFG |
| B:1B684 | 466C | 10 | dsp_div | C | hardware divide via DSP0: DSP0_DID=num, DSP0_DIS=den, returns DSP0_QUO | B:1B7EC, B:1F660 | - | - | DSP0_DID, DSP0_DIS |
| B:1B694 | 467C | 48 | crc16_ccitt | C | CRC16 poly 0x1021 init 0 over buffer r0 length r1 (non-reflected) | B:210C4, B:21450 | - | - | - |
| B:1B6C8 | 46B0 | 44 | crc16_ff_run | C | CRC16 poly 0x1021 over n 0xFF bytes (erased-flash padding CRC) | B:210C4 | - | - | - |
| B:1B6F8 | 46E0 | 38 | ntc_b_update | C | sums ring_ntc_b (4 samples)>>6 and converts via B:1ED60(pullup 10000, beta 3435) into temp_ntc_b (0xC6) | B:2292C | B:1ED60<ntc_convert> | temp_ntc_b | - |
| B:1B730 | 4718 | 178 | soc_from_vbus | C | fallback SOC curve: raw vbus breakpoints 783/837/858/876/907/951/1007 -> 0/10/20/40/60/80/100 (piecewise linear) | B:22F38 | B:19A78<lib_idivmod> | - | - |
| B:1B732 | 471A | 0 | - |  | - | - | - | - | - |
| B:1B7EC | 47D4 | 122 | calc_modulation_index | L | /duty vector/*1023/vbus: squared magnitude of phase duty/voltage triple (ram 0x28,0x2A,0x2C) -> isqrt -> ram 0x13C ... | B:1CB14 | B:1B684<dsp_div>, B:1FF28<isqrt16> | phase_v_mag, mod_index | - |
| B:1B888 | 4870 | 54 | image_validate | L | checks staged image header (SP word range like own image 0x2800) and CRC (via B:1BF98) against r2; returns 0 ok / 1 fail | B:200A8 | B:1BF98<crc32_hw> | - | - |
| B:1B8C4 | 48AC | 12 | init_ram358 | L | sets ram[0x35C]=0, ram[0x358]=0xA7 (init of a small state block) | B:200A8 | - | stream_state, stream_counter | - |
| B:1B8D4 | 48BC | 56 | load_config_defaults | L | if ram[0x2E0]!=0x5AA55AA5 copy defaults from flash 0xC2DA.. into RAM 0x254.. (identity/config); magic-checked settings block | B:1C53C | B:1F364<settings_save> | serial_model_bytes, serial_model_bytes+0x1, serial_model_bytes+0x2, identity_word_254, identity_word_254+0x1, identity_word_254+0x2 | - |
| B:1B924 | 490C | 40 | key_init_default | C | if ram[0x2D8]!=0x5AA55AA5 fills the 16-byte key buffer at ram 0x5E4 with A0 A1 .. AF and saves it (B:1F364); magic-checked | B:1C53C | B:1F364<settings_save> | key_magic | - |
| B:1B958 | 4940 | 392 | identity_save_flash | C | counts non-FF bytes of identity buffers (ram 0x274 x18, 0x25D x23) ... | B:1C53C | B:1BEA4<flash_erase_page>, B:1D50C<flash_write_word> | flash_ptr_key | - |
| B:1BAF8 | 4AE0 | 56 | clock_init | C | SYS reset pulse, SYS_AFE_REG5=0xB07D, PLL/clock select via B:1F270/1FF04/1F10C, SYS_CLK_DIV2=0, SYS_CLK_FEN=0x3CC06, AFE_REG1=1 | B:1FFC8 | B:1F10C<sysclk_select>, B:1F270<pll_enable>, B:1FF04<delay_loop_a> | - | SYS_AFE_REG1, SYS_AFE_REG5, SYS_CLK_DIV2, SYS_CLK_FEN, SYS_SFT_RST |
| B:1BB44 | 4B2C | 16 | crc32_hw_init | C | CRC0: CR=1 INIT=0 POL=0x04C11DB7 | B:1C6AC | - | - | 0x40010F04, 0x40010F08, 0x40010F0C |
| B:1BB5C | 4B44 | 50 | crc16_ccitt_fast | C | byte-wise CRC16-CCITT using the swap/nibble method | B:200A8 | - | - | - |
| B:1BB8E | 4B76 | 24 | periph_clk_gate | L | selects clock-gate mask (0->0x1000, 1->0x200) and calls B:1F0EC(mask,en) | B:1BBA6 | B:1F0EC<afe_reg5_set> | - | - |
| B:1BBA6 | 4B8E | 36 | dac_init | C | clears config struct, B:1BBCC(dac0), writes DAC0 value 0xCB (=203, hardware over-current comparator threshold), enables clock | B:1C6AC | B:1BB8E<periph_clk_gate>, B:1BBCC<dac_cfg>, B:1BCA8<dac_write>, B:1BCC4<memclr4> | - | - |
| B:1BBCC | 4BB4 | 204 | dac_cfg | C | configures SYS_AFE DAC0/1 (REG1 bits, DAC_CTRL, REG3) and loads factory trim from NVR 0x1450..0x146C into SYS_AFE_DACx_AMC/DC | B:1BBA6 | B:1ADCC<flash_nvr_read> | - | SYS_AFE_REG1, SYS_AFE_REG3, SYS_AFE_DAC_CTRL, SYS_AFE_DAC0_AMC, SYS_AFE_DAC0_DC |
| B:1BCA8 | 4C90 | 22 | dac_write | C | writes 12-bit value to SYS_AFE_DAC0 or DAC1 | B:1BBA6 | - | - | SYS_AFE_DAC0, SYS_AFE_DAC1 |
| B:1BCC4 | 4CAC | 10 | memclr4 | C | zero 4 bytes at r0 | B:1BBA6 | B:19A54<lib_memclr> | - | - |
| B:1BCCE | 4CB6 | 12 | flash_clk_enable | L | calls B:1F234(&FLASH_CFG,1) | B:1C6AC | B:1F234<clk_gate_set> | - | - |
| B:1BCDC | 4CC4 | 56 | update_stream_decrypt | C | custom stream cipher: out=(in ^ tblA[ctr&15]) - state - ctr, state = out + tblB[ctr&15] (state ram 0x358 init 0xA7, ctr ram 0x35C ... | B:1BF78 | - | stream_state, stream_counter | - |
| B:1BD1C | 4D04 | 24 | pwm_moe_off | C | MCPWM0_PRT=0xDEAD; FAIL012 &= ~0x40 (clear MOE: outputs off); PRT=0xCAFE | B:1CB14, B:1D654, B:1DDCC | - | - | MCPWM0_FAIL012, MCPWM0_PRT |
| B:1BD44 | 4D2C | 40 | irq_disable_set | L | calls B:21774 (NVIC disable) for IRQ 0x10,0xF,0xE,0xA,0xB,0x17 | B:1EDFC | B:21774<nvic_disable_irq> | - | - |
| B:1BD6C | 4D54 | 32 | pwm_arm_special | C | IO01=0x4949 IO23=0x4049, FAIL012/=0x40 (set MOE) special arm state | B:1CB14 | - | - | MCPWM0_IO01, MCPWM0_IO23, MCPWM0_FAIL012, MCPWM0_PRT |
| B:1BDA0 | 4D88 | 30 | pwm_arm_normal | C | IO01=IO23=0x4040, FAIL012/=0x40 (set MOE) normal arm | B:1CB14, B:1DDCC | - | - | MCPWM0_IO01, MCPWM0_IO23, MCPWM0_FAIL012, MCPWM0_PRT |
| B:1BDD0 | 4DB8 | 174 | coast_regen_demand | C | COAST RECOVERY: if speed>=6.0 && speed-2.0>requested && 0<remote_temp<45: profile=profile_byte, capped to 30 if flag374, capped to 60 if SOC>=90 ... | B:1E3D0 | B:19A78<lib_idivmod>, B:216E8<slew_toward> | coast_target, coast_demand | - |
| B:1BEA4 | 4E8C | 116 | flash_erase_page | C | SYS_PROTECT unlock, SYS_FLSE=0x8FCA, obfuscated FLASH controller pointer (key 0x9A0D361F in ram 0x34C), FLASH_ADDR=r0, FLASH_CFG/=ERS_EN, FLASH_ERASE=0x7654DCBA | B:1B958, B:1C3A8, B:1C53C, B:1F364, B:1F4D8 | - | flash_ptr_key | FLASH_CFG, FLASH_ADDR, SYS_PROTECT, SYS_FLSE, SYS_FLSP |
| B:1BF44 | 4F2C | 38 | update_state_reset | C | clears firmware-update state flags (ram 0x1E5..0x1E9, 0x1D6, 0x208, 0x220, 0x230, 0x1F5, 0x1F6, 0x329, 0x32A) | B:1B56C, B:1B5E8, B:21450, B:2292C | - | service_mode, upd_flag_1e5, upd_flag_1e6, upd_flag_1e7, upd_flag_1e8, upd_active | - |
| B:1BF78 | 4F60 | 32 | update_decrypt_and_check | L | decrypts r1 into stack buffer via B:1BCDC then calls B:1C3A8 | B:200A8 | B:1BCDC<update_stream_decrypt>, B:1C3A8<flash_program> | - | - |
| B:1BF98 | 4F80 | 56 | crc32_hw | C | CRC32 over r1 bytes at r0 using CRC0 hardware (words padded with 0xFF) | B:1B888, B:20A14, B:210C4 | - | - | 0x40010F00, 0x40010F04 |
| B:1BFD4 | 4FBC | 200 | calibration_measure_and_save | L | when ram 0x373==1 (request) && 0x372==0 && run_latch==0: averages 50 samples of six signed values (ram 0x39A..0x3A4) into 0x37A..0x384, adds/subtracts 0x1000 on 0x384 ... | B:20A14, B:2292C | B:19A78<lib_idivmod>, B:1F4D8<calibration_save>, B:22D4C<imu_read> | calib_done, calib_request, imu_off_gx, imu_off_gy, imu_off_gz, imu_off_ax | - |
| B:1C0A4 | 508C | 12 | hall_clk_enable | L | calls B:1F234(8,r0) | B:1C0E8 | B:1F234<clk_gate_set> | - | - |
| B:1C0B0 | 5098 | 50 | hall_init | C | HALL0_CFG/HALL0_TH/HALL0_INFO init from config struct r0 | B:1C0E8 | - | - | HALL0_CFG, HALL0_INFO, HALL0_TH |
| B:1C0E8 | 50D0 | 50 | hall_init_default | C | builds HALL config (TH=0x927C00, filter fields) and calls hall_init, enables clock | B:1C6AC | B:1C0A4<hall_clk_enable>, B:1C0B0<hall_init>, B:1C120<hall_cfg_default> | - | - |
| B:1C120 | 5108 | 28 | hall_cfg_default | C | fills default HALL config struct (TH=0x3E8 ...) | B:1C0E8 | - | - | - |
| B:1C140 | 5128 | 22 | hall_get_bit | C | reads HALL0_INFO bit r1 into *r0 (filtered hall level), returns 0/1 | B:1CB14 | - | - | - |
| B:1C15C | 5144 | 106 | lowspeed_brake_state | C | LOW-SPEED BRAKE SPECIAL STATE: needs setting ram 0x1D9!=0, throttle==0, lowspeed_169==0, ram 0x347==0 ... | B:2292C | - | lowspeed_brake_cnt, special_state_207 | - |
| B:1C1EC | 51D4 | 176 | ISR_I2C0 | C | I2C0 interrupt handler (IRQ6): byte-wise master state machine on peripheral pointer ram 0x36C, tx/rx buffer ram 0x8EC.., counters 0x363-0x366 | ptr | - | i2c_done, i2c_busy, i2c_bytes_left, i2c_rx_idx, i2c_phase | - |
| B:1C2A4 | 528C | 118 | i2c_read_reg | C | I2C register read transaction with DMA reset and 10000-count timeouts: dev addr byte 0xD6/0xD7 (7-bit 0x6B), register r0, returns byte at ram 0x8EE | B:1C9C8, B:22D4C | - | i2c_done, i2c_busy, i2c_error, i2c_bytes_left, i2c_len, i2c_rx_idx | DMA0_CTRL |
| B:1C32C | 5314 | 110 | i2c_write_reg | C | I2C register write (reg r0, value r1) to device 0xD6 | B:1C9C8 | - | i2c_done, i2c_busy, i2c_error, i2c_bytes_left, i2c_phase, i2c_timeout | DMA0_CTRL |
| B:1C3A8 | 5390 | 352 | flash_program | C | programs r2 bytes from r1 to flash address r0 word-wise through FLASH_WDATA with 512-byte page erase (B:1BEA4) at page boundaries; interrupts off ... | B:1BF78, B:21450 | B:1BEA4<flash_erase_page> | flash_wr_buf, flash_wr_buf+0x1, flash_wr_buf+0x2, flash_wr_buf+0x3, flash_ptr_key, flash_ptr_key2 | FLASH_CFG, FLASH_ADDR, FLASH_WDATA, SYS_PROTECT, SYS_FLSP |
| B:1C53C | 5524 | 272 | startup_calibrate_and_load | C | boot sequence after hardware init: waits 100 ticks, dc_zero_offset=avg(ring_dc_current) (fault code ram[0xEC]=8 if/x/>=500), self-test B:1E280(0x1F4), zero phase offsets ... | B:2292C | B:1B8D4<load_config_defaults>, B:1B924<key_init_default>, B:1B958<identity_save_flash>, B:1BEA4<flash_erase_page>, B:1E280<power_stage_selftest>, B:1EB34<settings_load>, B:1EC54<calibration_load>, B:1ECE4<identity_load> | enable_main, hw_fault_flag, isr_state, sched_tick, dc_zero_offset, env_applied | - |
| B:1C6AC | 5694 | 156 | hardware_init | C | IRQs off, FLASH_CFG bit19, IWDG_CFG=0x3C00, then GPIO/ADC/DAC/CMP/MCPWM/HALL/CRC/UART0/UART1/DSP0/I2C0/IWDG init and NVIC priorities+enables for IRQ 0x10 (MCPWM) 0xA (UAR ... | B:2292C | B:1B65C<cmp_init>, B:1BB44<crc32_hw_init>, B:1BBA6<dac_init>, B:1BCCE<flash_clk_enable>, B:1C0E8<hall_init_default>, B:1C760<gpio_init>, B:1C84C<adc_setup_all>, B:1C9AC<iwdg_init> | - | FLASH_CFG, SYS_PROTECT, IWDG_CFG, DSP0_SC |
| B:1C760 | 5748 | 178 | gpio_init | C | configures GPIO0..GPIO3 pin directions/alternate functions/outputs (P2.10 P2.12 P2.3 outputs low, P3.9 high, etc.) | B:1C6AC | - | - | GPIO0_PIE, GPIO0_POE, GPIO0_F7654, GPIO0_FFEDC, GPIO1_PIE |
| B:1C828 | 5810 | 26 | reset_dq_state | L | i_d=0, i_q=0, vd_like = int(B:224B0(&ram[0x420],0)) (float helper) | B:1CB14 | B:1A970<lib_f2iz>, B:224B0<float_biquad_filter> | vd_like, i_d, i_q | - |
| B:1C84C | 5834 | 320 | adc_setup_all | C | configures ADC0/ADC1 regular sequences: ADC0 slots ch1,3,2,5,8(g1),7,4(g1); ADC1 slots ch0,10,13,12,9,14,15; IE=0x7F; CFG/=0x800 | B:1C6AC | B:1AE08<adc_cfg_channel>, B:1AE32<adc_set_ie>, B:1AE38<adc_init>, B:1AEF4<adc_cfg_default> | - | ADC0_CFG, ADC1_CFG |
| B:1C994 | 597C | 12 | iwdg_feed | C | IWDG_PSW=0xA6B4, IWDG_CLR=0x798D | B:2292C | - | - | IWDG_PSW, IWDG_CLR |
| B:1C9AC | 5994 | 18 | iwdg_init | C | IWDG_PSW=0xA6B4, IWDG_RTH=0x1F400, IWDG_CFG=1 (enable; ~4 s at 32 kHz LRC) | B:1C6AC | - | - | IWDG_PSW, IWDG_CFG, IWDG_RTH |
| B:1C9C8 | 59B0 | 82 | imu_init | S | probes I2C device 0x6B reg 0x0F up to 8 times for WHO_AM_I==0x6A (LSM6DSL/LSM6DS3TR-C class IMU), sets ram 0x370=1 on failure ... | B:2292C | B:1C2A4<i2c_read_reg>, B:1C32C<i2c_write_reg> | imu_missing, imu_whoami | - |
| B:1CA24 | 5A0C | 200 | gpio_outputs_update | L | drives GPIO2 P2.10/P2.12 (PDO bits 0x400/0x1000): square-wave toggles by counters 0x171/0x172 and 0x170/0x16F depending on mode 0x14D (0xB) and 0x1DC and region id ... | B:1E108 | - | p23_duty_code, gpio_16a, gpio_16b, out_toggle_16f, out_cnt_170, out_cnt_171 | GPIO2_PDO |
| B:1CB14 | 5AFC | 1156 | ISR_MCPWM0 | C | MCPWM0 ISR at ~15.6 kHz: reads ADC0/ADC1 results into rings, reconstructs two phase currents per PWM sector (valid/x/<1800) ... | ptr | B:1B7EC<calc_modulation_index>, B:1BD1C<pwm_moe_off>, B:1BD6C<pwm_arm_special>, B:1BDA0<pwm_arm_normal>, B:1C140<hall_get_bit>, B:1C828<reset_dq_state>, B:1D444<clarke_transform>, B:1D468<inverse_park> | hw_fault_flag, odo_tick, isr_tick_counter, isr_startup_lock, isr_tick_prescale, sector_prev | ADC0_IF, ADC1_IF, MCPWM0_TH00, MCPWM0_TH01, MCPWM0_TH10 |
| B:1D034 | 601C | 80 | pwm_init | C | MCPWM0 init: TCLK=0x44 TH0=0xC00 (3072) TMR2=0xF473 IO01=IO23=0x4040 FAIL012=0x110 SDCFG=0x10 deadtime 0x4C IE0=2 | B:1C6AC | - | - | MCPWM0_TMR2, MCPWM0_TH0, MCPWM0_UPDATE, MCPWM0_DTH00, MCPWM0_DTH01 |
| B:1D09C | 6084 | 700 | uart0_status_frame_tx | C | builds and sends the periodic status frame to the dashboard (UART0, hdr 0x61, alternates two types selected by ram 0x1FE): type0 = mode/flag bits, local temp C2/10 ... | B:2292C | B:19A78<lib_idivmod>, B:208E0<uart0_send> | throttle_lost, uart0_tx_pending, throttle_age, status_frame_type | - |
| B:1D3D8 | 63C0 | 86 | speed_filter_update | L | float IIR filters of speed (state ram 0x3F0/0x408 blocks): ram[0xA6]=filtered speed, ram[0x98]=filtered clipped (0..40) speed increase; forces ram[0xA6]=speed when i_q<0 | B:2292C | B:1A970<lib_f2iz>, B:1AA04<lib_ui2f>, B:224B0<float_biquad_filter> | speed_rise_filt, speed_filtered | - |
| B:1D444 | 642C | 28 | clarke_transform | C | i_alpha=ram[0x122]; i_beta=(18919*(2*ram[0x124]+ram[0x122]))>>15 | B:1CB14 | - | i_alpha, i_beta | - |
| B:1D468 | 6450 | 72 | inverse_park | C | calls sin/cos B:22038(elec_angle); v_alpha=(cos*vd-sin*vq)>>15; v_beta=(cos*vq+sin*vd)>>15 | B:1CB14 | B:22038<dsp_sincos> | v_alpha, v_beta | - |
| B:1D4C0 | 64A8 | 62 | park_transform | C | i_q=(cos*i_beta-sin*i_alpha)>>15; i_d=(cos*i_alpha+sin*i_beta)>>15 (project onto rotor angle) | B:1CB14 | - | i_d, i_q | - |
| B:1D50C | 64F4 | 108 | flash_write_word | C | programs one 32-bit word at flash addr r0 with value r1 (interrupt/obfuscated pointer key 0x9AFDA40C) and verifies; returns 1 ok / 0 mismatch | B:1B958, B:1F364 | - | flash_ptr_key2 | FLASH_CFG, FLASH_ADDR, FLASH_WDATA, SYS_PROTECT, SYS_FLSP |
| B:1D59C | 6584 | 18 | afe_regs_clear | C | SYS_PROTECT unlock, SYS_AFE_REG0=0, SYS_AFE_REG2=0 | B:1C6AC | - | - | SYS_AFE_REG0, SYS_AFE_REG2, SYS_PROTECT |
| B:1D5B8 | 65A0 | 130 | d_axis_regulator | C | d-axis control: vd_like += (-i_d>>3) + 2*(prev_i_d - i_d) clamp +-920, then float IIR (B:224B0 block 0x420) ... | B:1CB14 | B:1A970<lib_f2iz>, B:1AA04<lib_ui2f>, B:1FF28<isqrt16>, B:224B0<float_biquad_filter> | vq_like, vd_like, id_prev, d_reg_neg_id, d_reg_diff, d_reg_integ | - |
| B:1D64C | 6634 | 8 | ISR_irq23 | L | vector idx39 (IRQ23) forwards to B:1F2FC | ptr | B:1F2FC<ISR_WAKE_reset> | - | - |
| B:1D654 | 663C | 654 | current_limiter_drive_cmd | C | CURRENT LIMITER: dc_current=(sum ring_dc_current>>6)-dc_zero_offset ... | B:2292C | B:19A78<lib_idivmod>, B:1BD1C<pwm_moe_off>, B:216E8<slew_toward> | run_latch, limiter_clamp_active, gov_ramp_subcnt, drive_cmd_target, dc_current, dc_current_prev | - |
| B:1D92C | 6914 | 120 | temp_local_update | C | local linear temperature: ring_temp_local sum>>5, valid 600..1900 else debounce 5 -> fault_temp_sensor and value 300 ... | B:2292C | B:19A78<lib_idivmod> | fault_temp_sensor, temp_sensor_invalid_cnt, temp_local | - |
| B:1D9C0 | 69A8 | 628 | cruise_hold_logic | C | CRUISE/HOLD (ram 0x16C): averages 8 throttle samples (ram 0x570 ring, avg 0x18C) ... | B:2292C | - | cruise_active, cruise_throttle_low, throttle_ring_idx, mode_at_cruise, cruise_speed_stable, cruise_throttle_stable | - |
| B:1DCB0 | 6C98 | 234 | active_brake_demand_calc | C | ACTIVE BRAKE: if brake input ram 0x110!=0: base=639 (region 60549/61124/60560 branch: 1644), demand=brake*base/100 scaled by 1013/vbus_raw (cap base) + min(speed/5,50) ... | B:2292C | B:19A5C<lib_uidivmod>, B:19A78<lib_idivmod> | brake_active_flag, brake_regen_inhibit, brake_soc_block, active_brake_demand, ctrl_block+0xA, ctrl_block+0xC | - |
| B:1DDCC | 6DB4 | 682 | throttle_mode_block | C | THROTTLE+MODE: throttle 6..100 -> requested_speed=applied_reference*throttle/100; 0..5 or >100 -> 0 (or held_reference when cruise 0x16C active) ... | B:2292C | B:19A78<lib_idivmod>, B:1BD1C<pwm_moe_off>, B:1BDA0<pwm_arm_normal>, B:1E280<power_stage_selftest> | enable_main, hw_fault_flag, sched_tick, fault_stall, env_target, limiter_clamp_active | MCPWM0_TH00, MCPWM0_TH01, MCPWM0_TH10, MCPWM0_TH11, MCPWM0_TH20 |
| B:1E108 | 70F0 | 174 | direction_lowspeed_flags | C | updates dir_armed (0x164) from speed vs 3.0/5.0 thresholds, 0x168 low-speed latch (speed<2.0) ... | B:2292C | B:1CA24<gpio_outputs_update> | dir_armed, lowspeed_latch, lowspeed_state_169, aux_timeout_cnt, dir_reverse_cnt, lowspeed_aux_194 | - |
| B:1E1D4 | 71BC | 54 | gpio_p23_blink | C | every ISR: 20-count counter 0x16E vs ram 0x88 duty: drives GPIO2 PDO bit 3 (P2.3) high/low (software PWM, active brake overrides 20/20, running 8/20 per prior notes) | B:1CB14 | - | p23_phase | GPIO2_PDO |
| B:1E21C | 7204 | 76 | odometer_update | C | on 0x15 tick: accumulates/speed/in ram 0xB0 (wraps at 36000 -> increments ram 0x94 and 32-bit trip counter 0xA8) ... | B:2292C | - | odo_tick, odo_wrap_cnt, speed_delta_odo, speed_prev_odo, trip_counter, odo_accum | - |
| B:1E280 | 7268 | 238 | power_stage_selftest | C | hardware over-current path self-test: DAC0 threshold lowered 203->51, then for each of 6 output patterns (IO01/IO23 combinations) sets MOE briefly ... | B:1C53C, B:1DDCC | B:1BD1C<pwm_moe_off> | flag_b4 | SYS_AFE_DAC0, CMP_IE, CMP_IF, MCPWM0_EIF, MCPWM0_IO01 |
| B:1E398 | 7380 | 38 | ntc_a_update | C | sums ring_ntc_a (4 samples)>>6 and converts via B:1ED60(pullup 8200, beta 3950) into temp_ntc_a (0xC4) | B:2292C | B:1ED60<ntc_convert> | temp_ntc_a | - |
| B:1E3D0 | 73B8 | 1664 | speed_loop | C | SPEED LOOP (every 5th scheduler tick): speed from hall_period via 0x36CAB/period (0.1 km/h), sign from ctrl+0xD vs 0x300 ... | B:2292C | B:19A5C<lib_uidivmod>, B:19A78<lib_idivmod>, B:1BDD0<coast_regen_demand>, B:21706<clamp_s32> | run_latch, drive_cmd_target, brake_ramp_state, brake_special_flag, cruise_active, held_reference | - |
| B:1EB34 | 7B1C | 236 | settings_load | C | loads persistent settings page (flash 0x1FA00, magic 0x5A5A5AA5, 20 words) into RAM 0x458.. and unpacks fields (odometer 0xA8, flags 0x2E6/0x1D4 ... | B:1C53C | - | trip_counter, activated_flag, serial_model_bytes, serial_model_bytes+0x1, serial_model_bytes+0x2, identity_word_254 | - |
| B:1EC54 | 7C3C | 110 | calibration_load | C | loads calibration page (flash 0x1F200, 8 words: magic 0x12345678, six offsets, checksum word at 0x474 must equal sum of first 7 words) into 0x380..0x37E else zeros | B:1C53C, B:1F4D8 | - | imu_off_gx, imu_off_gy, imu_off_gz, imu_off_ax, imu_off_ay, imu_off_az | - |
| B:1ECE4 | 7CCC | 42 | identity_load | C | copies identity bytes from flash 0x1F800 (18 words -> ram 0x274, 23 words -> ram 0x25D, low byte of each word) | B:1C53C | - | - | - |
| B:1ED18 | 7D00 | 68 | uart0_ping_tx | L | periodic 1-byte 0x43 transmit (retries counted in 0x1F1/0x1F4) while ram 0x1F2 active | B:2292C | B:208E0<uart0_send> | ping_retry_cnt, ping_active, ping_count, ping_byte | - |
| B:1ED60 | 7D48 | 130 | ntc_convert | C | NTC temperature (deg C) from ADC sum: divider math with soft-float; args (adc>>6, pullup ohms, beta); R25=10000, T25=298.15 K, +0.5 rounding | B:1B6F8, B:1E398 | B:19A78<lib_idivmod>, B:19FC0<lib_dadd_signed>, B:19FDA<lib_dsub_signed>, B:1A020<lib_ddiv>, B:1A468<lib_d2iz>, B:1A56E<lib_ui2d>, B:1A7BC<lib_f2d>, B:1A810<lib_fmul> | - | - |
| B:1EDFC | 7DE4 | 80 | system_reset_request | C | after ram 0x1D5 set for 80 ticks: IWDG_CFG=0x3C00, CMP_IF clear, IRQs disabled, VTOR=0, MSP=[0], SCB->AIRCR=0x05FA0004 (system reset to bootloader) | B:2292C | B:1BD44<irq_disable_set> | reset_request, reset_delay_cnt | CMP_IF, IWDG_CFG |
| B:1EE60 | 7E48 | 628 | svpwm_output | C | SVPWM: sector (1..6) from v_alpha/v_beta (scale 0xDDB3), stores sector in ram 0x118 for next ISR current reconstruction ... | B:1CB14 | B:19A78<lib_idivmod>, B:21714<lib_switch8_helper> | sector_cur, phA_valid_next, phB_valid_next, phC_valid_next, duty_a | MCPWM0_TH00, MCPWM0_TH01, MCPWM0_TH10, MCPWM0_TH11, MCPWM0_TH20 |
| B:1F0EC | 80D4 | 24 | afe_reg5_set | C | sets/clears mask r0 bits in SYS_AFE_REG5 (analog block enables) depending on r1 | B:1AE38, B:1BB8E, B:20344 | - | - | SYS_AFE_REG5, SYS_PROTECT |
| B:1F10C | 80F4 | 246 | sysclk_select | C | configures SYS_CLK_CFG/AFE REG5/REG6 for clock mode r0 and stores sysclk_hz: mode1 96 MHz (cfg 0x1FF), mode2 48 MHz (0x155), mode3 24 MHz (0x111), mode4 12 MHz (0x2FF) ... | B:1BAF8 | B:1ADCC<flash_nvr_read>, B:1FF16<delay_loop_b> | sysclk_hz | SYS_AFE_REG5, SYS_AFE_REG6, SYS_CLK_CFG, SYS_PROTECT |
| B:1F234 | 821C | 26 | clk_gate_set | C | sets/clears mask r0 in SYS_CLK_FEN (peripheral clock enables) | B:1BCCE, B:1C0A4 | - | - | SYS_CLK_FEN, SYS_PROTECT |
| B:1F258 | 8240 | 14 | periph_reset | C | SYS_SFT_RST = r0 (peripheral soft reset pulse), PROTECT=1 | B:22434 | - | - | SYS_SFT_RST, SYS_PROTECT |
| B:1F270 | 8258 | 86 | pll_enable | L | PLL start sequence: AFE_REG6 bit changes, waits SYS_AFE_DBG bit15 clear, then enables clock source; calls B:2175C(0x17) | B:1BAF8 | B:1FF16<delay_loop_b>, B:2175C<nvic_clear_pending> | - | SYS_AFE_REG6, SYS_PROTECT |
| B:1F2D0 | 82B8 | 34 | wake_irq_config | C | enables IRQ23 (WAKE) with priority bits (NVIC ISER 0x800000) or disables via B:21794 | B:1C6AC | B:21794<nvic_disable_irq_dup> | - | - |
| B:1F2FC | 82E4 | 80 | ISR_WAKE_reset | C | IRQ23 wake handler: disables WAKE IRQ, clears clock config, clears MOE bits of MCPWM FAIL012/FAIL345, then SCB->AIRCR=0x05FA0004 system reset (endless loop until reset) | B:1D64C | B:2175C<nvic_clear_pending>, B:21794<nvic_disable_irq_dup> | - | SYS_AFE_REG6, SYS_CLK_CFG, SYS_PROTECT, MCPWM0_FAIL012, MCPWM0_FAIL345 |
| B:1F364 | 834C | 312 | settings_save | C | builds 20-word settings block (magic 0x5A5A5AA5, odometer 0xA8, flags 0x2E6/0x1D4, calibration-like words, identity words ... | B:1B8D4, B:1B924, B:206E4, B:20A14 | B:1BEA4<flash_erase_page>, B:1D50C<flash_write_word> | flash_ptr_key, settings_buf, settings_buf+0x4, settings_buf+0x18, settings_buf+0x1C, settings_buf+0x20 | - |
| B:1F4D8 | 84C0 | 158 | calibration_save | C | builds calibration page (magic 0x12345678, six values 0x380..0x37E, sum checksum) and programs flash 0x1F200 with up to 6 retries until read-back sum matches | B:1BFD4 | B:1BEA4<flash_erase_page>, B:1D50C<flash_write_word>, B:1EC54<calibration_load> | flash_ptr_key, settings_buf, settings_buf+0x4, settings_buf+0x8, settings_buf+0xC, settings_buf+0x10 | - |
| B:1F5A0 | 8588 | 170 | identity_save_retry | C | identity save routine: erase 0x1F800, program 18+23 bytes (one per word) with verify ... | B:20A14 | B:1BEA4<flash_erase_page>, B:1D50C<flash_write_word> | flash_ptr_key | - |
| B:1F660 | 8648 | 1286 | rotor_estimator | C | HALL ROTOR ESTIMATOR (called every MCPWM ISR with 3-bit hall state): counts ISR ticks since last transition (timeout 2812 -> standstill period 0x41E9) ... | B:1CB14 | B:19A78<lib_idivmod>, B:1B684<dsp_div>, B:1BD1C<pwm_moe_off>, B:21714<lib_switch8_helper> | hall_period, lowspeed_aux_194, special_acc_198, est_mode_2e8, hall_invalid_flag, dir_prev_2ea | - |
| B:1FC0C | 8BF4 | 660 | envelope_protection | C | ENVELOPE PIPELINE (each 5th tick): env_ramped slews +-1 toward env_target; stall-like derate (speed<0.4 for >110/130/150 calls scales by 80/50/20 /128, fault at 180) ... | B:2292C | B:1A970<lib_f2iz>, B:1AA04<lib_ui2f>, B:224B0<float_biquad_filter> | fault_stall, flag_b7, flag_local_thermal, remote_hot_cnt, longcurr_low_cnt, longcurr_active | - |
| B:1FF04 | 8EEC | 18 | delay_loop_a | C | busy-wait counting r1 up to r0 | B:1BAF8, B:1C6AC | - | - | - |
| B:1FF16 | 8EFE | 18 | delay_loop_b | C | busy-wait counting r1 up to r0 (second copy) | B:1F10C, B:1F270 | - | - | - |
| B:1FF28 | 8F10 | 10 | isqrt16 | C | integer square root via DSP0_RAD/DSP0_SQRT, returns low 16 bits | B:1B7EC, B:1D5B8 | - | - | DSP0_RAD |
| B:1FF38 | 8F20 | 122 | uart_cmd_match | L | matches the received frame (ram 0x68A.. +5) against 11 stored command signatures (table at flash 0xC2B4 lengths, RAM signature buffers 0x286..0x2CF) ... | B:1B56C, B:20488, B:210C4 | B:21714<lib_switch8_helper> | - | - |
| B:1FFC8 | 8FB0 | 16 | SystemInit | C | sets VTOR=0x2800 then calls clock_init B:1BAF8 | B:1999C | B:1BAF8<clock_init> | - | - |
| B:1FFDC | 8FC4 | 166 | region_config_defaults | C | parses first 5 ASCII digits of identity ram[0x25D] into numeric prefix ram[0x10] (leading '0' or 0xFF -> 0xEC8F=60559 default) ... | B:1C53C | - | identity_prefix, ctrl_block, ctrl_block+0x2, ctrl_block+0x4, ctrl_block+0x6, ctrl_block+0x8 | - |
| B:200A8 | 9090 | 634 | uart0_update_handler | C | firmware-update/service command handler on UART0 (frame hdr 0x5A 0xB1, CRC16 via B:1BB5C): cmd 0x11 returns 12 bytes (version/chip text) ... | B:2292C | B:1B888<image_validate>, B:1B8C4<init_ram358>, B:1BB5C<crc16_ccitt_fast>, B:1BEA4<flash_erase_page>, B:1BF78<update_decrypt_and_check>, B:1D50C<flash_write_word>, B:208E0<uart0_send> | reset_request, service_mode, update_started, update_commit_flag, update_toggle_206, upd_seq | - |
| B:20344 | 932C | 32 | nvr_trim_load | C | enables clock bit 0x2000 and loads two factory trim words from NVR 0x14D0/0x14D4 into ram 0x100/0x102 | B:1C6AC | B:1ADCC<flash_nvr_read>, B:1F0EC<afe_reg5_set> | nvr_trim_100, nvr_trim_102 | - |
| B:2036C | 9354 | 236 | governor_detector | C | POWER-DIP/SLIP DETECTOR (every 10th tick, RC02 hooks it): when not braking and (speed<requested or speed>applied_reference): freq-like g=6e7/(hall_period_copy*1280) high- ... | B:2292C | B:19A78<lib_idivmod>, B:1A020<lib_ddiv>, B:1A4D4<lib_d2uiz>, B:1A56E<lib_ui2d>, B:1A574<lib_dmul> | gov_flag, gov_detect_cnt, freq_like, freq_highpass, iq_highpass, freq_iir | - |
| B:20488 | 9470 | 566 | ISR_UART0 | C | UART0 interrupt (IRQ10): RX state machine for dashboard frames: header 0x51..0x54 (control), 0x64 (forwarded), 0x5A (service/update), plus 1/4 when flag_1d6 ... | ptr | B:1FF38<uart_cmd_match> | uart0_tx_rd, uart0_rx_pending, uart0_rx_timeout, uart0_tx_timeout, uart0_rx_kind, uart0_rx_aux | UART0_BUFF, UART0_IF |
| B:206D8 | 96C0 | 12 | data_stub_206D8 | U | referenced as literal/pointer (not a real function) | ptr | - | - | - |
| B:206E4 | 96CC | 74 | dash_loss_poweroff | C | every 5th tick while throttle frames are lost (hold_active!=0) and not in update: counts ram 0x212 to 480 ... | B:2292C | B:1BD1C<pwm_moe_off>, B:1F364<settings_save> | settings_saved_loss, dash_loss_cnt, power_off_flag | GPIO3_PDO |
| B:2073C | 9724 | 372 | ISR_UART1 | C | UART1 interrupt (IRQ11): RX state machine for replies from the battery-side processor: hdr 0x74 (reply) or 0x64 (forward) or 0x06/0x15/0x18/0x43 in update mode ... | ptr | - | uart1_tx_rd, uart1_rx_pending, uart1_rx_timeout, uart1_tx_timeout, uart1_rx_kind, uart1_rx_len_copy | UART1_BUFF, UART1_IF |
| B:208C8 | 98B0 | 20 | uart0_init | C | UART0_CTRL=0, DIVH=0x13 DIVL=0x87 (divisor 4999 -> 19200 baud at 96 MHz), IE=3 | B:1C6AC | - | - | UART0_CTRL, UART0_DIVH, UART0_DIVL, UART0_IE |
| B:208E0 | 98C8 | 126 | uart0_send | C | queues r1 bytes from r0 into the UART0 TX ring (50 bytes) and starts transmission; waits while previous byte pending | B:1B03C, B:1B56C, B:1B5E8, B:1D09C, B:1ED18, B:200A8 | - | uart0_tx_rd, uart0_tx_wr | UART0_BUFF, UART0_IF |
| B:2096C | 9954 | 30 | uart0_send_8bytes | L | sends 8 constant bytes from flash 0xC292 on UART0 | B:2292C | B:208E0<uart0_send> | - | - |
| B:20990 | 9978 | 20 | uart1_init | C | UART1_CTRL=0, DIVH=0x13 DIVL=0x87 (19200 baud), IE=3 | B:1C6AC | - | - | UART1_CTRL, UART1_DIVH, UART1_DIVL, UART1_IE |
| B:209A8 | 9990 | 94 | uart1_send | C | queues r1 bytes from r0 into the UART1 TX ring (150 bytes) and starts transmission | B:1B2E8, B:21450 | - | uart1_tx_rd, uart1_tx_wr | UART1_BUFF, UART1_IF |
| B:20A14 | 99FC | 1526 | uart0_command_dispatcher | C | DASHBOARD FRAME DECODER (UART0 binary frames in ram 0x68A, checksum = byte sum ... | B:2292C | B:19A78<lib_idivmod>, B:1BD1C<pwm_moe_off>, B:1BF98<crc32_hw>, B:1BFD4<calibration_measure_and_save>, B:1F364<settings_save>, B:1F5A0<identity_save_retry>, B:208E0<uart0_send>, B:21714<lib_switch8_helper> | flag_10a, brake_lever, inhibit_14c, riding_mode, throttle, frame_b3_hi | GPIO3_PDO |
| B:210C4 | A0AC | 836 | ascii_down_command_executor | C | executes the ASCII/bootloader-style service commands matched by B:1FF38 (11 signatures): replies from flash strings ('ok', 'error', 'down ok', 'LKS071BT') ... | B:2292C | B:19964<lib_rt_stub4>, B:199E0<lib_srand_init>, B:19A78<lib_idivmod>, B:1AF14<aes128_block_wrapper>, B:1B694<crc16_ccitt>, B:1B6C8<crc16_ff_run>, B:1BEA4<flash_erase_page>, B:1BF98<crc32_hw> | reset_request, service_mode, ping_retry_cnt, ping_active, image_valid, ping_count | - |
| B:21450 | A438 | 568 | xmodem_update_receiver | L | XMODEM/YMODEM-style firmware receiver on UART0: SOH 0x01 blocks (num, ~num, 128 data, CRC16 CCITT via B:1B694), EOT 0x04, replies ACK 0x06 / NAK 0x15 / CAN 0x18 ... | B:2292C | B:19A58<lib_memclr_alias>, B:1B694<crc16_ccitt>, B:1BF44<update_state_reset>, B:1C3A8<flash_program>, B:208E0<uart0_send>, B:209A8<uart1_send> | upd_flag_1e5, upd_flag_1e6, upd_flag_1e7, upd_flag_1e8, upd_active, ping_active | - |
| B:21698 | A680 | 68 | ch9_process | C | ADC1 CH9: ch9_avg=sum(ring_ch9)>>6; if <=1422 (0x58E) counts ch9_cnt, fault_ch9=1 on the 11th consecutive low call; >1422 clears | B:2292C | - | fault_ch9, ch9_cnt, ch9_avg | - |
| B:216E8 | A6D0 | 30 | slew_toward | C | slew(cur=r0,target=r1,step=r2): moves cur toward target by at most step | B:1BDD0, B:1D654 | - | - | - |
| B:21706 | A6EE | 14 | clamp_s32 | C | clamp r0 to [r1,r2] signed | B:1E3D0 | - | - | - |
| B:21714 | A6FC | 26 | lib_switch8_helper | C | compiler switch helper: index in r3, table follows the call (count byte + offsets) | B:1B03C, B:1B2E8, B:1EE60, B:1F660, B:1FF38 | - | - | - |
| B:21730 | A718 | 40 | lib_fpclassify | L | double classification helper | B:21A30, B:21CA4 | - | - | - |
| B:2175C | A744 | 18 | nvic_clear_pending | C | NVIC ICPR clear pending IRQ r0 | B:1F270, B:1F2FC | - | - | - |
| B:21774 | A75C | 26 | nvic_disable_irq | C | NVIC ICER disable IRQ r0 (+DSB/ISB) | B:1BD44 | - | - | - |
| B:21794 | A77C | 26 | nvic_disable_irq_dup | C | duplicate of NVIC disable | B:1F2D0, B:1F2FC | - | - | - |
| B:217B4 | A79C | 18 | nvic_enable_irq | C | NVIC ISER enable IRQ r0 | B:1C6AC | - | - | - |
| B:217CC | A7B4 | 60 | nvic_set_priority | C | NVIC IPR (or SHPR for negative) priority write | B:1C6AC | - | - | - |
| B:21810 | A7F8 | 172 | lib_poly_eval | L | polynomial evaluation with soft doubles (libm helper) | B:21A30, B:21CA4 | B:19FC0<lib_dadd_signed>, B:1A574<lib_dmul> | - | - |
| B:218BC | A8A4 | 16 | lib_div0_helper | L | double 1/0 error helper | B:225D8 | B:1A020<lib_ddiv> | - | - |
| B:218D0 | A8B8 | 10 | lib_scalbn_wrap | L | libm wrapper (scalbn) | B:21A30, B:21CA4, B:225D8 | B:1AA78<lib_scalbn> | - | - |
| B:218DA | A8C2 | 8 | lib_dadd_wrap | L | libm wrapper (dadd) | B:21EC0 | B:19FC0<lib_dadd_signed> | - | - |
| B:218E2 | A8CA | 16 | lib_ddiv_wrap0 | L | libm wrapper (0/0 invalid) | B:21A30, B:225D8 | B:1A020<lib_ddiv> | - | - |
| B:218F4 | A8DC | 14 | lib_underflow | L | libm underflow helper | B:21A30, B:21CA4 | B:1AA78<lib_scalbn> | - | - |
| B:218F6 | A8DE | 0 | - |  | - | - | - | - | - |
| B:21908 | A8F0 | 40 | aes_add_round_key | C | AES AddRoundKey: state[r0] ^= roundkey[r1] (4x4 bytes) | B:21930 | - | - | - |
| B:21930 | A918 | 138 | aes128_core | C | AES-128 block cipher core (r2!=0 encrypt: key expand B:22504, 10 rounds SubBytes B:22EF4 ShiftRows B:22E64 MixColumns B:22BFC AddRoundKey ... | B:1AF14 | B:21908<aes_add_round_key>, B:22504<aes_key_expand>, B:22BFC<aes_mixcolumns>, B:22E64<aes_shiftrows>, B:22EF4<aes_subbytes> | - | - |
| B:219BA | A9A2 | 118 | aes_gmul | C | GF(2^8) multiply by constant mask (poly 0x11B) used by MixColumns/InvMixColumns | B:22BFC | - | - | - |
| B:21A30 | AA18 | 574 | lib_asin | L | libm asin (double) | B:22058 | B:19FC0<lib_dadd_signed>, B:19FDA<lib_dsub_signed>, B:19FF0<lib_drsub_signed>, B:1A020<lib_ddiv>, B:1A574<lib_dmul>, B:1AA6A<lib_set_errno>, B:1AA78<lib_scalbn>, B:21730<lib_fpclassify> | - | - |
| B:21CA4 | AC8C | 472 | lib_atan | L | libm atan (double) | B:21EC0 | B:19FC0<lib_dadd_signed>, B:19FDA<lib_dsub_signed>, B:19FF0<lib_drsub_signed>, B:1A020<lib_ddiv>, B:1A574<lib_dmul>, B:1AA78<lib_scalbn>, B:21730<lib_fpclassify>, B:21810<lib_poly_eval> | - | - |
| B:21EC0 | AEA8 | 334 | lib_atan2 | L | libm atan2 (double) | B:22058 | B:19FDA<lib_dsub_signed>, B:19FF0<lib_drsub_signed>, B:1A020<lib_ddiv>, B:218DA<lib_dadd_wrap>, B:21CA4<lib_atan> | - | - |
| B:22038 | B020 | 24 | dsp_sincos | C | loads angle into DSP0_THETA and stores sin_theta/cos_theta from DSP0_SIN/COS (CORDIC) | B:1D468 | - | sin_theta, cos_theta | DSP0_SC, DSP0_THETA |
| B:22058 | B040 | 962 | imu_attitude_update | S | IMU 6-axis attitude estimator: reads raw accel/gyro words (ram 0x386..0x398), converts gyro with 0.061 dps/LSB (0x3A8BA058) ... | B:2292C | B:19C4C<lib_d2f>, B:1A574<lib_dmul>, B:1A7BC<lib_f2d>, B:1A970<lib_f2iz>, B:1AA04<lib_ui2f>, B:1AA1C<lib_scalbnf>, B:21A30<lib_asin>, B:21EC0<lib_atan2> | incline_dd, incline_pitch, imu_angle_a, imu_angle_b, imu_quat, imu_quat+0x4 | - |
| B:22434 | B41C | 52 | i2c0_init | C | SYS_CLK_DIV0=0xD, stores I2C0 base in ram 0x36C, resets I2C periph (B:1F258(2)), I2C0_CFG=0xF2, NVIC IRQ6 enable | B:1C6AC, B:2292C | B:1F258<periph_reset> | i2c_base_ptr | SYS_CLK_DIV0, SYS_PROTECT |
| B:2247C | B464 | 46 | fast_inv_sqrt | C | float fast inverse square root (0x5F3759DF magic + one Newton step) | B:22058 | B:1AA1C<lib_scalbnf>, B:230FC<lib_fmul2>, B:231AC<lib_fsub> | - | - |
| B:224B0 | B498 | 84 | float_biquad_filter | L | float IIR filter state block (coeffs at +0x10/+0x14, state +0/+4/+8/+0xC): used for vd smoothing and speed filters | B:1C828, B:1D3D8, B:1D5B8, B:1FC0C | B:1A810<lib_fmul>, B:23070<lib_fadd>, B:230FC<lib_fmul2>, B:231C4<lib_fsub_stub> | - | - |
| B:22504 | B4EC | 202 | aes_key_expand | C | AES-128 key expansion into 11 round keys at stack buffer | B:21930 | - | - | - |
| B:225D8 | B5C0 | 790 | lib_log | L | libm natural log (double), used by NTC conversion | B:1ED60 | B:19FC0<lib_dadd_signed>, B:19FDA<lib_dsub_signed>, B:19FF0<lib_drsub_signed>, B:1A020<lib_ddiv>, B:1A55E<lib_i2d>, B:1A574<lib_dmul>, B:1AA6A<lib_set_errno>, B:1AA78<lib_scalbn> | - | - |
| B:2292C | B914 | 644 | main | C | MAIN LOOP: hardware_init, startup_calibrate_and_load, IMU probe loop ... | B:19944 | B:1AF94<remote_flag374_filter>, B:1B03C<uart1_rx_frame_parser>, B:1B2E8<uart1_request_builder>, B:1B56C<uart_reply_ack_handler>, B:1B5E8<uart_reply_pass_handler>, B:1B6F8<ntc_b_update>, B:1BF44<update_state_reset>, B:1BFD4<calibration_measure_and_save> | main_slot_cnt_0, main_cnt_mod5, main_cnt_mod10, main_cnt_mod100, main_cnt_mod250, dash_msg_cnt | - |
| B:22BFC | BBE4 | 336 | aes_mixcolumns | C | AES MixColumns / InvMixColumns using aes_gmul | B:21930 | B:219BA<aes_gmul> | - | - |
| B:22D4C | BD34 | 272 | imu_read | C | reads 12 bytes from IMU register 0x22 (gyro XYZ + accel XYZ little-endian) into ram 0x39A..0x3A4, subtracts calibration offsets (0x37A..0x384) and low-pass filters (1/20 ... | B:1BFD4, B:2292C | B:19A78<lib_idivmod>, B:1C2A4<i2c_read_reg> | imu_missing, imu_whoami, imu_f0, imu_f1, imu_f2, imu_f3 | - |
| B:22E64 | BE4C | 72 | aes_shiftrows | C | AES ShiftRows / InvShiftRows | B:21930 | - | - | - |
| B:22EAC | BE94 | 66 | lib_sqrt_wrap | L | libm sqrt wrapper with errno | B:21A30 | B:1AA6A<lib_set_errno>, B:1AB70<lib_sqrt> | - | - |
| B:22EF4 | BEDC | 64 | aes_subbytes | C | AES SubBytes / InvSubBytes using S-boxes at flash 0xC2F8 / 0xC3F8 | B:21930 | - | - | - |
| B:22F38 | BF20 | 178 | voltage_monitor | C | vbus_decivolt=vbus_raw*8850>>14; vbus_raw<603: MOE off + severe low flag; >1075: over-voltage flag (clear <1037); <743 (debounced 200) low warning ... | B:2292C | B:1B730<soc_from_vbus>, B:1BD1C<pwm_moe_off> | flag_lowv_severe, flag_highv, flag_lowv_warn, soc_like, vbus_unloaded_est, vbus_est_cnt | - |
| B:2300C | BFF4 | 94 | lib_fcmp_helper | L | libm compare/error helper | B:225D8 | B:1AAE0<lib_math_error> | - | - |
| B:23070 | C058 | 76 | lib_fadd | L | float add (soft-float) | B:22058 | B:231D0<lib_fsub_core> | - | - |
| B:2307C | C064 | 58 | lib_fadd_core | L | float add core | B:23070, B:231AC | - | - | - |
| B:230FC | C0E4 | 172 | lib_fmul2 | L | float multiply (soft-float) | B:22058 | - | - | - |
| B:231AC | C194 | 62 | lib_fsub | L | float subtract | B:2247C | B:2307C<lib_fadd_core>, B:231D0<lib_fsub_core> | - | - |
| B:231C4 | C1AC | 0 | lib_fsub_stub | L | stub | B:22058 | - | - | - |
| B:231D0 | C1B8 | 166 | lib_fsub_core | L | float subtract core | B:23070, B:231AC | - | - | - |
