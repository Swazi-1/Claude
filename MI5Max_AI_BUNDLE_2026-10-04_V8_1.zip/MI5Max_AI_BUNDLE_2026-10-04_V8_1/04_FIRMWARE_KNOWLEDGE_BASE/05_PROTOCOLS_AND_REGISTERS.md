# Protocols, frames and the BMS register map

Scope: every serial link visible in the firmware image, with frame layouts as the code parses/builds them. Evidence labels: **C** confirmed from code, **S** strong, **L** likely, **U** unknown. IDs `A:<file offset hex>` / `B:<...>` refer to `A_FUNCTION_CATALOG.md` / `B_FUNCTION_CATALOG.md`. RAM offsets are from 0x20000000 of the named program (A and B have different RAM spaces!).

```
 dashboard MCU (not available)
      |  UART0 19200 baud (B)   control frames hdr 0x51 / status frames hdr 0x61 / service 0x5A
      v
 B  motor controller LKS32MC071  --UART1 19200--  A  battery-side MCU (N32G43x) --I2C2-- BQ769x2 AFE
      ^                                           |  USART1 19200: B-link (hdr 0x63), BLE/dash 0x90, protocol N 0x6E
      |                                           |  USART3 4800 : challenge/response + peer data (hdr 0xAA)
   IMU (I2C0, 0x6B)                               |  SPI1: NOR flash (event log, history, RTC backup, update staging)
```
Which physical device sits on A's USART3 and on the 0x90/0x6E families is **U** (no schematic). The B <-> A link (B's UART1, A's USART1) is **S** (both 19200 baud, B sends hdr 0x63 requests, A answers hdr 0x74).

## 1. Common framing rule (B and A, 0x51/0x61/0x63/0x74 families) **C**

`[hdr] [type] [len] [len payload bytes...] [sum8] [tail]` where **sum8 = sum of all preceding bytes (mod 256)** (at index len + 3) and **tail = 0xFF - hdr** (index len + 4; 0x51 -> 0xAE, 0x61 -> 0x9E, 0x63 -> 0x9C, 0x64 -> 0x9B, 0x65 -> 0x9A, 0x74 -> 0x8B). B's UART0 RX ISR takes the total frame length as `len + 5` for headers 0x51..0x54. Example (community/earlier capture): `51 10 06 33 01 88 64 00 5A E1 AE` = 11 bytes, len 6, sum 0x1E1 -> 0xE1, tail 0xAE.

## 2. Dashboard <-> B (UART0, 19200 8N1) **C**

B decoder: `uart0_command_dispatcher` (B:20A14), RX ISR `ISR_UART0` (B:20488), TX ring 50 bytes.

### 2.1 Control frame: hdr 0x51, byte1 0x10 (length 6 payload) - the riding command
| byte | field | consumer |
|---|---|---|
| 0 | 0x51 | |
| 1 | 0x10 (type) | |
| 2 | length: 6 in community captures of other Brightway models (11-byte frame), but see the note below | |
| 3 | low nibble = **riding mode selector** (RAM 0x14D: 1, 2, 3, 0x0B), high nibble -> RAM 0x15C | `throttle_mode_block` |
| 4 | bit7 -> 0x196, bit6 -> 0x1EE, bit5 -> 0x1EF, bit3 -> 0x1ED, bit0 -> 0x166 | misc flags |
| 5 | **bit7 = power-latch request** (drives GPIO3 bit 9 = "P3.9": high; after 3 low frames -> MOE off + save settings once + P3.9 low), bit6 -> 0x167 (3-frame debounce), bit5 -> 0x16D cruise enable, bit3 -> 0x165, bit2 -> 0x1EB, bit1 -> `inhibit_14c`, bit0 -> `flag_10a` | power / cruise |
| 6 | **throttle 0..100** (RAM 0x158) | `throttle_mode_block` |
| 7 | **brake lever 0..100** (RAM 0x110) | `active_brake_demand_calc` |
| 8 | **`profile_byte` (RAM 0x1EC) = energy-recovery selector, accepted only when <= 100; stock values 30 / 60 / 90 = Weak / Medium / Strong** | `coast_regen_demand`, child-cap hook in custom builds |
| 9 | bit7 -> 0x1D8 (decel-detector enable), bit6 -> 0x1D9 (low-speed-brake enable), bit5 -> mode_ready 0x1DA, bits3:0 -> 0x1DC (light mode) | |
| 10 | sum8 (length 7) | |
| 11 | 0xAE (length 7) | |

**Length note (S for the code, U for what the 5 Max dashboard sends):** `uart0_command_dispatcher` validates the checksum at index `len + 3` but **always reads bytes 3..9** (including byte 9 as the flag byte). With length 6 (11-byte frame, as in the community documentation of other models) index 9 *is the checksum*, so the three flags would then be set from the checksum bits; the 5 Max dashboard is therefore expected to send length 7 (12 bytes, byte 9 = flags, checksum at index 10). The profile byte (index 8) and the other fields are the same either way.

Every valid control frame clears `throttle_age`/`hold_active`. If frames stop, `dash_loss_poweroff` (B:206D8) counts to 480 (every 5th scheduler tick) then MOE off, saves settings once and drops P3.9 (power latch off).

### 2.2 Other dashboard -> B frames
* `0x52` family (B replies hdr 0x65 + "OK"): 0x14 store control snapshot, 0x15 write 18-byte identity (flash 0x1F800), 0x16 write 20-byte serial (RAM 0x25D; only while activation flag 0x1D4 == 0), 0x18 activation (0x1D4 = 1 + save), 0x1A write 16-byte key (only while 0x1D4 == 0), 0x1B/0x53 flag sets.
* `0x51` query family (B replies hdr 0x64): 0x20 control snapshot, 0x21 version bytes, 0x22 model bytes, 0x23/0x24 BMS objects 0x42/0x43 data, 0x26 BMS object 0x45, 0x27 BMS object 0x46 (18 bytes), 0x28 identity (18 bytes), 0x29 serial (20 bytes), 0x2A **key (16 bytes)**, 0x2B CRC32 of staged image, 0x2D activation flag, 0x33 phase/DC zero offsets, 0x34 dc_current*1000/274 (10 mA units), 0x35 start calibration (only at speed 0), 0x36 IMU-derived values (RAM 0x376/0x378), 0x80 `vbus_decivolt`.
* `0x5A 0xB1` service/update frames (CRC16-CCITT): 0x11 version/chip text, 0x1D 23 identity bytes, 0xE0 start update (erase staging 0xF000), 0xE1 data block (decrypt with the custom stream cipher + program), 0xE2 finish (verify image CRC, write commit record 0x1FC00, reset). Also ASCII `down ...` commands (11 signatures), XMODEM receiver, AES-128 challenge/response (`ble_rand`/`mcu_rand`/`mcu_key`, key in RAM 0x5E4, default key A0 A1 .. AF) that unlocks the service state (`flag_1d6`).

### 2.3 B -> dashboard status frame (hdr 0x61), every 100 scheduler ticks
Alternates two types (RAM 0x1FE): **type 0** = mode/flag bits, local controller temperature (C2/10), NTC-A temperature, a **status/error code byte** (0x10 throttle frames lost, 0x11 hardware fault 0x14, 0x12 current-zero fault 0xEC, 0x18 flag 0x2E9, 0x21 BMS link fault (`remote_state`), 0x24 over-voltage, 0x28/0x29 fault flag_b4, 0x40 temp-sensor fault, 0x43 IMU fault, 0x45 local thermal, 0x49 flag 1D6; 2 running; 1 idle), |speed_trend_ref|, status bits. **type 1** = forwards the BMS telemetry object 0x44 (see 3.3).

## 3. B <-> A (B's UART1 / A's USART1, 19200 8N1) **C**

### 3.1 Request (B -> A)
Read: `[0x63] [object id] [sum8] [0x9C]` (e.g. `63 41 A4 9C`). Write: `[0x63] [object id] [len] [data...] [sum8] [0x9C]` (B writes objects 0x47 (7 bytes), 0x4B (1,1) and 0x63 (1,1)).
B polls round-robin (`uart1_request_builder`, B:1B2E8; one request per visit, every 11th visit of the mod-10 slot): ids 0x41..0x4A, 0x60, 0x61, then the writes 0x47/0x4B/0x63 when pending. A reply timeout counter (`uart1_age`) over 300 sets `remote_state = 3` = BMS link fault.

### 3.2 Reply (A -> B)
`[0x74] [object id] [len] [data...] [sum8] [0x8B]`; for object 0x41-style identity read with selector 0x81 on cmd 0x10 the reply is `0x1B` + two RTC bytes + 0x19 bytes of identity block from A RAM 0x30DD; unknown selectors get `OK` (0x4F 0x4B). Implemented by A: `rx_frame_router` (A:A6B0) -> `uart_frame_parse_min4_max40` (A:54DC) -> `registry_write_object` (A:53FC, really a registry read/write) -> `uart1_reply_builder_0x74` (A:56BC).

### 3.3 The BMS register map (17 objects, A RAM 0x92C + descriptors 0x7D8..0x918; decoded from the initial RAM image) **C**
Descriptor word0: 0x100 = read-only, 0x101 = read/write, 0x102 = write-only; word1 = data pointer; word2 = length; word3 = post-write callback; word4 = pre-read callback.

| id | dir | A RAM source | len | content |
|---|---|---|---|---|
| 0x40 | R/W | 0xD8 (`link_state_D8`) | 2 | link/status bytes (D8, D9) |
| 0x41 | R | 0xDA (`link_datetime_pkt`) | 7 | BMS RTC date/time: year BE, month|weekday<<4, day, hour (bit6 PM), minute, second |
| 0x42 | R | 0xE1 (`id_string_a`) | 7 | `0108` + date bytes 18 07 0C (version/build) |
| 0x43 | R | 0xE8 (`id_string_b`) | 7 | `0101` + 18 01 0F; pre-read callback `decode_date_0x1032` |
| **0x44** | R | 0x106E (`reg_max_cell_x`) | 9 | **main telemetry**: [0] max-cell byte, [1] **SOC %**, [2..3] **pack mV** BE, [4..5] **current**, 10 mA units, sign-magnitude (bit15 = sign), [6] **temperature**, sign-magnitude (bit7 = sign), [7..8] **flags** (see below) |
| 0x45 | R | 0x1077 (`reg_cycle_count`) | 13 | cycle count BE, remaining capacity/10, full capacity/10, age days, elapsed days, ROM const 54600, SOH % |
| 0x46 | R | 0x1038 (inside `settings_block_1004`) | 18 | settings sub-block (meaning U) |
| 0x47 | R/W | 0xDA | 7 | date/time; **write callback `link_status_pack_send` sets the BMS RTC** (B forwards the dashboard's time) |
| 0x48 | R | 0xD0 (`image_crc32`) | 4 | CRC32 of the app flash image; pre-read callback `image_crc32_check` computes it |
| 0x49 | R | 0x109E | 26 | the 13 cell voltages in mV, big-endian u16 each |
| 0x4A | R | 0xF9 | 2 | |NTC1|, |NTC2| temperatures (sign-magnitude) |
| 0x4B | R/W | 0xEF | 1 | link flag EF (B writes 1,1 to request the power-down/hand-over path; see `pack_power_state_machine`) |
| 0x60 | R | 0x1084 (`reg_chg_energy`) | 10 | charge energy (24-bit), discharge energy (16-bit), UV count (16-bit), resistance /40, capacity ref /10 (16-bit) |
| 0x61 | R | 0xF0 | 8 | stress-time counters |
| 0x63 | R/W | 0xF8 | 1 | write 1 -> `bms_new_second_housekeeping` (clears statistics accumulators, sets resistance 120, increments seconds counter) |
| 0x80 | R | 0xCB5 | 2 | RTC readout; pre-read callback `rtc_get_to_0xCB5` |
| 0x81 | W | 0xCB3 | 2 | RTC set input; write callback `rtc_set_from_0xCB3` |

**Flags word (object 0x44 bytes 7..8, A RAM 0x1075; high byte first), built by `bms_register_block_publish` (A:1337C) - exact sources:** bit15 charging (dir state 0), bit14 discharging (dir 1), bit13 pack on (RAM 0x107), bit12 **fully charged** (SOC = 100 % while pack on; RAM 0x40), bit11 cell imbalance level B (F72.b4), bit10 BQ/I2C fault (RAM 0xF73 != 0 for 50 ticks), bit9 temperature-sensor fault (FD0.b3 | FCD.b6), bit8 **temperature spread** >= 8 C (FD0.b2), bit7 UV (FA1.b2 | FA1.b5 = soft cell-min 2900 mV / mean 3300 mV levels), bit6 OV (FA1.b0 | FA1.b1 | FAC.b0), bit5 discharge OC report latch (FC3.b2), bit4 charge OC (FC3.b0 | FC3.b1), bit3 FCD.b4 (T_min <= -10 C level), bit2 FCD.b2 (T_max >= 55 C level), bit1 FCD.b1 (charge UT < 2 C), bit0 FCD.b0 (charge OT >= 45 C). **C** (read directly from the publish code). Note the *block* flags that actually switch the FETs are different subsets - see `04_FEATURE_CHAINS.md` section 3.

**What B does with these (the regen/limit coupling):** `uart1_rx_frame_parser` (B:1B03C) copies object 0x44 into `remote_telemetry` (B RAM 0x8CA..): `remote_telemetry[0]` = d0, **`remote_telemetry[1]` = SOC**, `+2` pack mV, `+4` current, `+6` raw temperature byte -> **`remote_temp` (RAM 0x328) = signed temperature**, `+8` flags high byte. Consumers: `coast_regen_demand` (SOC >= 90 caps recovery at 60; 0 < T < 45 C required), `active_brake_demand_calc` (T outside 0..45 C, link state > 2 or SOC >= 95 % inhibits regen braking), `envelope_protection` (battery-temperature and SOC current caps), `voltage_monitor` (SOC from remote when `remote_state == 0`, else SOC from voltage). See `04_FEATURE_CHAINS.md`.

Which temperature the BMS reports in byte [6] (A:1337C): coldest cell NTC if a cold latch (FCD b1|b4) is active, else hottest if a hot latch (FCD b0|b2), else the mean. **S**

## 4. A's USART1 other frame families (router A:A6B0, keyed on frame byte[2]) **C/L**
| byte[2] | family | handlers | notes |
|---|---|---|---|
| 0x90 | "BLE / dashboard" | parse A:3838 (len 6..0x82, hdr 0x90 type 0x10 or 3, CRC16 table A:3C4C), exec `reg_lookup_exec` A:3700 (id lookup in a 58-entry table at RAM 0x5CC), build A:38EC (CRC16 big-endian) | the application-facing register protocol (same shape as the 0x63 registry, richer id table) **L** |
| 0x6E | "protocol N" | parse A:BD50 (len 8..0x82, func 3/6/0x10, CRC16 A:8A50 modbus-like), exec A:BCC0 (object descriptor table at RAM 0x7C4, 2 entries), build A:BE6C | Modbus-like function codes **L** |
| 0x63 | motor-controller link | section 3 | **S** |
Frames that fail all of these but pass a sum8 check go to `frame_dispatch_generic` -> ASCII/XMODEM update path (section 6).

## 5. A's USART3 link (4800 baud, hdr 0xAA, CRC16-Modbus) **C/L**
`usart3_link_tx_sequencer` (A:3F00; state RAM 0x9B4: 0 init, 1..5 request slots) builds `[0xAA] [type|seq nibble] [cmd] [payload...] [CRC16 hi][CRC16 lo]` (length nibble in byte 3). `link_frame_rx_parse` (A:DF10) dispatches by state: cmd 3 (4 bytes -> RAM 0xFE9), cmd 5 (serial -> 0x9B8/0xFED), cmd 7 (7 packed words -> 0xFF2..0xFFD, "peer data"), cmd 9/0xA/0xB (state -> 3), cmd 0x1D (**16-byte challenge response**). Authentication: A sends a random 16-byte challenge (`lib_rand`, LCG 0x41C64E6D) built in state 3; the peer must return `aes_like_scramble(challenge || counter)` (A:1AC8) -> RAM 0xFF1 = 1 pass / 2 fail (`link_auth_response_check`, A:DE08). The scrambling routine is custom (AES-like). What passing authentication enables downstream is **U**. A also sends the current-limit percent (RAM 0xC89) and two scaled values in state 5.

## 6. Firmware update path on A (USART1 ASCII + XMODEM-style) **C/L**
* ASCII commands (ROM table stride 52): `down rd_info`, `down get_ver`, `down dfu_active`, `down nvm_write`, `down wr_info`, `down dfu_verify` (+ reply texts `ok`, `error`, `ok 0000000000`, `0002`, `down ok`). `dfu_active` (cmd 3) sets `update_mode_requested` (RAM 0xC7E) -> power state 4 (update mode).
* XMODEM-style packets: `SOH(1) | seq | ~seq | 128 data | CRC16-CCITT`. Packet 1 = header (compares the model/version string from ROM 0x8017A0C/0x8017A10 `RPED`/`C5D` pattern, 32-bit image length, block count = len >> 11, 10-char name); data packets are staged in the SPI NOR (A:119E4, 2 KB buffer, sector erase + CRC check); at the end A compares total CRC vs header CRC and writes a **0x14-byte image descriptor (flag 1, length, CRC) to internal flash 0x801D800**.
* Entry/exit: `bootloader_entry_commands` (A:DDC4): word 0x1260 == 0xE0 and 0x1262 == 0x5AA5 -> erase the descriptor page and reset into the bootloader; 0xE2 + magic -> plain reset. `update_finish_reset` waits 3 ticks, saves the RTC backup to SPI flash and resets. The bootloader itself is not in the image.
* The same family exists in B (`ascii_down_command_executor`, `uart0_update_handler`, `xmodem_update_receiver`) for the motor controller image (staging flash 0xF000, commit record flash 0x1FC00).

## 7. Peripheral buses
* **A I2C2 -> BQ769x2 (7-bit address 0x08)**: polled/IRQ driver (A:AF94, B978, BB14), direct-command read `bq_read_direct` (A:1C60, optional CRC8 poly 0x07 transaction), subcommand write `bq_cmd_write16` (A:1BDC), data-memory read A:CEE0 / write A:155AC / block write A:280C. Direct commands read every cycle (mapped to A RAM): 0x03/0x05/0x07 safety status A/B/C, 0x12 battery status, 0x14..0x2A + 0x32 cell voltages (13 cells), 0x36 PACK pin, 0x38 LD pin, 0x3A CC2 current, 0x70 ALERT-pin thermistor, 0x7F FET status. Subcommands used: 0x90/0x92 CFGUPDATE enter/exit, 0x93 DSG_PDSG_OFF, 0x94 CHG_PCHG_OFF, 0x97 FET_CONTROL (helper A:BF58: idx 0 DSG, 1 PDSG, 2 CHG, 3 PCHG), 0x99/0x9A SLEEP_ENABLE/DISABLE, 0x9E/0x9F LOAD_DETECT_ON/OFF, 0xA1 OTP_WRITE (A:5EE0, gated), 0x0010 SHUTDOWN (sent twice in the final shutdown) and 0x0012 RESET (sent twice when PB9 aborts the shutdown), 0x29BC / 0x9335 configuration tweaks.
* **B I2C0 -> IMU (7-bit 0x6B)**: WHO_AM_I register 0x0F == 0x6A (LSM6DSL/LSM6DS3TR-C class), gyro/accel read from register 0x22 (12 bytes), attitude estimator (Madgwick-style).
* **A SPI1 -> NOR flash** (JEDEC C84014/C84013/A14014): layout in `03_PROGRAM_A_BMS.md` section 9.
