# V8 candidate 640 (review only, NOT flashed) - built 2026-10-03
File `06_V8_FINAL_CANDIDATE_640_REVIEW_ONLY_NOT_FLASHED.bin`, 147,456 bytes, SHA-256 9b1c7a52fc929e2854bd91f3d4acbd4d8408b9e1f1132071006feb210a217fa0.
= the flashed 600 candidate (sha 901ce6ce...) with one byte changed: file 0x1E02C 0x96 -> 0xA0 (Sport envelope 160 x 4 = 640) plus recomputed CRCs. Versus RC02: regen byte 0x20020 (0xA0 -> 0x92, stock regen) and 0x1E02C (0x8C -> 0xA0) plus CRCs. Program A, boot/power path and the appended code are byte-identical to RC02.
Model: Sport peak ~23.5 A / ~1.19 kW (600 measured 22.13 A / 1124 W, model 22.1 A / 1.116 kW). Likely BMS trip ~30 A (unconfirmed). Pack is 13S4P (label): ~5.9 A per cell at 23.5 A.
Same flash precautions as `../4_V8_candidate_600_same_bytes_as_final/POWER_BUTTON_TEST_AND_FLASH_CHECKLIST.md` (button test before/after; know how to recover; one flash). Revert: flash the 600 file or RC02.
