# V8 candidate 680 (review only, NOT flashed, for LATER) - built 2026-10-03
File `07_V8_FINAL_CANDIDATE_680_REVIEW_ONLY_NOT_FLASHED.bin`, 147,456 bytes, SHA-256 8d1e5c427739bf114e548e51dc8c804e1945ad8274fca43a11478c0736131468.
= the 640 candidate with one byte changed: file 0x1E02C 0xA0 -> 0xAA (Sport envelope 170 x 4 = 680) plus recomputed CRCs. Versus RC02: 0x20020 (stock regen 0x92), 0x1E02C, CRCs. Program A, boot/power path, appended code identical to RC02.
Model: Sport peak ~25.0 A / ~1.25 kW at 100 % charge (600 measured 22.13 A / 1124 W; model error ~1 %). Phase current ~35-38 A peak amplitude. Likely BMS trip ~30 A (unconfirmed); amps could be ~15 % off, so real peak could approach ~29 A.
Precondition (Claude's advice): ride 640 first, check temperatures on a hot day and at low charge, see ~23.5 A; do not skip steps. Same flash precautions as `../4_V8_candidate_600_same_bytes_as_final/POWER_BUTTON_TEST_AND_FLASH_CHECKLIST.md`. Revert: flash the previous candidate or RC02.
