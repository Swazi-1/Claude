# V8 final CANDIDATE (600) - review only, NOT flashed, NOT hardware tested (built 2026-10-03)

File: `05_V8_FINAL_CANDIDATE_600_REVIEW_ONLY_NOT_FLASHED.bin` (147,456 bytes)
SHA-256: 901ce6cea8fa6751bd00f147caad86fcd95bc6e29f08f0a6bf997bd7dcdf1df9

## What it is
RC02 (the build the owner says is installed) plus exactly two byte edits and the checksum bytes that must follow them.

| change | file offset | RC02 | candidate | effect |
|---|---|---|---|---|
| regen strength back to stock | 0x20020 | 0xA0 | 0x92 | Weak/Medium/Strong 91/146/292 (RC02 91/160/320) |
| Sport current envelope | 0x1E02C | 0x8C (140x4 = 560) | 0x96 (150x4 = 600) | Sport battery-current cap ~20.6 A -> ~22.1 A (model) |
| inner CRC32 | 0x19804..07 | - | 0x523C31CC | recomputed (CRC-32/MPEG-2 over the B body) |
| outer CRC16 | 0x0A..0B | - | recomputed | CRC-16/XMODEM over 0x19800..end |
Everything else is byte-identical to RC02: program A (BMS) 0x1000..0x19223, all of program B except those two bytes, and the appended code at 0x2381C.. (child cap, six-press gesture, RC02 governor mask). Drive mode envelope is unchanged (400); only Sport changed.

## Checks run (all pass)
* Checksum recipe reproduces RC02's own stored CRCs, then candidate CRCs verify. Length field unchanged (0xA404).
* Only 8 byte positions differ from RC02: 0x0A,0x0B,0x19804-07,0x1E02C,0x20020.
* Program A identical to stock/RC02. Appended code identical to RC02. Power-button / boot path in B untouched.
* Real firmware run in the host emulator: `region_config_defaults` writes 91/146/292 (stock) for the candidate; the Sport env_target is 600 chosen by the code itself.
* Model (plant assumptions): Sport peak 22.1 A / 1.12 kW at 100/56/35 % charge (RC02 20.6 A / 1.05 kW).

## Safety notes
* 22 A is ~7 % above RC02 and ~12 % above Xiaomi's 1000 W maximum motor power; the likely BMS electronic trip is ~30 A (unconfirmed; shunt unknown), fuse probably ~40 A (unconfirmed AI-sourced figure). 600 stays under both.
* Amps are modelled (27.2 counts/A, ~15 % uncertain). Short spikes can exceed the filtered cap.
* NOT checked: hardware behaviour, power button on this exact image, heat. Flashing is the owner's decision after the original power-button baseline. If power cuts out while riding: release throttle, wait 10-30 s, press power once, then charger; if it recurs go back to RC02/560.
* To revert to 560 only: set byte 0x1E02C back to 0x8C and recompute both CRCs.
