# MI5 Max firmware V8 FINAL (600), released 2026-10-04

**File:** `MI5Max_V8_FINAL_600.bin`, 147,456 bytes
**SHA-256:** `901ce6cea8fa6751bd00f147caad86fcd95bc6e29f08f0a6bf997bd7dcdf1df9`
These are the same bytes as `../3_OLDER/4_V8_candidate_600_same_bytes_as_final/05_V8_FINAL_CANDIDATE_600_REVIEW_ONLY_NOT_FLASHED.bin`. That file was flashed and ridden on 2026-10-03 (owner report).

Flashing is the owner's own decision and action. Claude did not and does not send anything to the scooter.

## 1. What it is
It is RC02 (the build the owner rode) with exactly two byte changes, plus the checksum bytes that must follow them.

| change | file offset | RC02 | V8 final | effect |
|---|---|---|---|---|
| Regen strength back to stock | 0x20020 | 0xA0 | 0x92 | Weak/Medium/Strong 91/146/292 (RC02 91/160/320) |
| Sport current cap | 0x1E02C | 0x8C (140x4 = 560) | 0x96 (150x4 = 600) | Sport battery current about 20.6 A -> about 22 A |
| Inner CRC32 | 0x19804..07 | | recomputed | CRC-32/MPEG-2 over program B |
| Outer CRC16 | 0x0A..0B | | recomputed | CRC-16/XMODEM over 0x19800..end |

Everything else is byte-identical to RC02:
* program A (the battery/BMS processor, including all power and sleep logic);
* the motor controller's boot and power-latch code;
* the appended code (child cap, six-press gesture, RC02 governor mask).

## 2. Behaviour vs original Xiaomi firmware
| Item | Stock | V8 final |
|---|---|---|
| Drive (D) speed target / current cap | 20.3 km/h / 328 | 25.0 km/h / 400 |
| Sport (S) speed target / current cap | 25.3 km/h / 493 | 45.0 km/h (not reachable; real top ~33 km/h at full charge) / **600** |
| Walking mode | 6.2 km/h / 137 | 20.0 km/h / 210 (6 km/h when child cap is on) |
| Regen strength (Weak/Medium/Strong) | 91/146/292 | **91/146/292 (stock)** |
| Coast regen starts from | 6.0 km/h | 5.0 km/h |
| Child cap (D 15 / S 20 / other 6 km/h) | none | on when recovery = Medium (60) **or** after six mode changes at standstill (toggle, saved) |
| Region speed limits | by serial prefix | region-free |
| Other v7.1 patches | | low-speed brake threshold 90 (30), thermal derate 1020 (900) with formula constant 3620 (3193), direction thresholds 0 (3.0/5.0 km/h), RC02 governor mask |
Unchanged from stock: the low-charge power cap (cut below 20 %, about half power at 10 % or less), temperature caps, full-charge regen limit (SOC >= 90 caps Strong to Medium; regen weak near 54 V), the IMU slope clamp, and all battery protections.

## 3. Verification
* **Offline:** both checksums verify (the same code also reproduces stock, v7.1 and RC02); only 8 byte positions differ from RC02. In the emulator the real firmware gives Sport cap 600 and regen 91/146/292. Side by side with RC02 over 24 mode/child/recovery combinations, the only working-memory difference is the Sport cap (plus the regen defaults).
* **On the scooter** (owner report and screen recording, 2026-10-03, 100 % charge, 16-17 C):
  * power button 10/10 before and after, child toggle OK, charger OK, no flash error;
  * peak **22.13 A / 1124 W** and 22.31 A later; sustained 21.1-22.3 A, mostly 21.4-21.8 A; voltage sag 54.0 -> about 50 V;
  * no cut-out, no error; battery 16 -> 17 C, 'Scooter Temperature' (controller) 36-37 C.
  The model predicted 22.1 A / 1.116 kW.
* **Next-day report (owner, 2026-10-04):** works perfectly. About 100 m climbed over 2.2 km, 'Scooter Temperature' (controller) maximum 75 C. Final climb about 10 degrees, Sport, about 20 km/h, **1000-1170 W the whole way** (about 90 % above 1000 W), no cut-out.

## 4. Known limits (why 600 is the final value)
The battery processor (program A, untouched) has software discharge over-current latches. These are Xiaomi's own pack limits (C, from code A:FF3C, sampled every 100 ms):
* **L2: 25 A or more for 1.0 s without a break -> battery output off.** This is what the 680 test hit (25.35 A uphill, 2026-10-04).
* **L1: 22 A or more for 10 s without a break -> battery output off.**
* The counter resets as soon as one 100 ms sample is below the level, so only uninterrupted current trips.
* The latch releases about 10 s after tripping, once current has stopped. You need to let go of the throttle and wait.
* After 3 trips, release needs an extra condition, probably load removal/wake. This is L (likely), from the code; power off/on is expected to clear it.

At 600 the current sits around 21.4-22.3 A, so it is just under L1. A sustained 10 degree climb at about 1.1 kW (2026-10-04) did not trip it; a much longer or steeper one could in theory still trip L1 after 10 s. If that ever happens: release throttle, wait 30 s, press power. If it repeats, ask for a 592 (148x4, about 21.8 A) build.
**Do not flash the 640 or 680 builds.** 640 trips L1 after about 10 s of sustained full throttle, and 680 trips L2 after about 1 s. Do not change A's limits: they protect the pack.

## 5. Flash and test
Use `POWER_BUTTON_TEST_AND_FLASH_CHECKLIST.md` (in this folder):
1. Do the button test BEFORE.
2. Make sure the battery is at 60 % or more.
3. Flash once, without interrupting it.
4. Do the button test AFTER.
5. Do a short test ride.

## 6. If power cuts out
1. Let go of the throttle.
2. Wait 30 s.
3. Press power once.
4. Check the app for errors.
5. If it is still dead, plug in the charger for about a minute, then press power again.
6. If it is still dead, stop and do not keep trying.

## 7. Revert
Flash RC02 (`../3_OLDER/3_V8_RC02_Sport35_was_on_scooter/`) or v7.1 (`../3_OLDER/1_FARM_V7_1_known_flashed_works/`) with the same method.

## 8. Still open (not blockers)
* Regen at normal charge (75/56/35 %) on this build is not yet recorded.
* The downhill "rolls from about 30 to about 22 km/h" symptom is undiagnosed. The best candidate is the IMU slope clamp: record the app current while it rolls. See `04_FIRMWARE_KNOWLEDGE_BASE/10_REGEN_ENTRY_DELAY_ANALYSIS.md`.
* Ride at low charge (< 20 %) and on a hot day.
