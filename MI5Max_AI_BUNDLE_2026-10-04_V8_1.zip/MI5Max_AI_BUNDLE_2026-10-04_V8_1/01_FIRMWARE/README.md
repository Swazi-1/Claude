# Firmware

All images are 147,456 bytes (battery processor A + motor controller B in one file). Full hashes: `SHA256SUMS.txt`. A new build always gets a new folder; nothing is overwritten.

## 1. Current: on the scooter now
| Folder | What | SHA-256 (first 12) |
|---|---|---|
| **`1_CURRENT_ON_SCOOTER_V8_FINAL_600/`** | **V8 FINAL**: RC02 + stock regen (91/146/292) + Sport current cap 600 (~22 A / 1.1 kW). Release notes, flash checklist inside. Owner flashed it 2026-10-04 (same bytes ridden 2026-10-03: button 10/10, 22.13 A / 1124 W, no cut-out; 10 degree climb at 1.0-1.17 kW, controller ('Scooter Temperature') max 75 C, no cut-out). **Owner decision 2026-10-04: leave as is, no further build planned.** | 901ce6cea8fa |

## 1b. Next build: V8.1 candidate (not flashed)
| Folder | What | SHA-256 (first 12) |
|---|---|---|
| `1b_V8_1_CANDIDATE_not_flashed/` | V8 600 + smooth low-battery ramp (no steps at 20 % / 10 %), Medium recovery no longer turns on the child cap, smooth controller heat fade from 86 C (stock constant). Program A and power/boot path identical. Release notes, emulator results, flash checklist inside. **Not flashed, not hardware tested.** | 9218c5ef58b7 |

## 2. Original
| Folder | What | SHA-256 |
|---|---|---|
| `2_ORIGINAL_STOCK/` | Original Xiaomi firmware (comparison base; D 20.3 / S 25.3 km/h, Sport cap 493) | 015718dd8126 |

## 3. Older (history, rollback, do-not-flash)
| Folder | What | SHA-256 | Status |
|---|---|---|---|
| `3_OLDER/1_FARM_V7_1_known_flashed_works/` | Farm v7.1 regenfix (regen 91/160/320, D 25 / S 45 km/h, Sport 560) | b4c64d8464db | Ridden earlier; rollback option |
| `3_OLDER/2_V8_RC01_child_cap/` | v7.1 + child-cap fix | 1c58131d6be7 | Never ridden |
| `3_OLDER/3_V8_RC02_Sport35_was_on_scooter/` | RC02 = RC01 + governor mask | f1037de2f08b | Was on the scooter until 2026-10-03; **main rollback** |
| `3_OLDER/4_V8_candidate_600_same_bytes_as_final/` | The 600 candidate (identical bytes to the final) + candidate notes | 901ce6cea8fa | = final |
| `3_OLDER/5_V8_candidate_640_DO_NOT_FLASH/` | Sport cap 640 (~23.5 A) | 9b1c7a52fc92 | **Do not flash**: trips the battery's 22 A / 10 s limit on a sustained climb |
| `3_OLDER/6_V8_candidate_680_DO_NOT_FLASH/` | Sport cap 680 (~25 A) | 8d1e5c427739 | **Do not flash**: cut out at 25.35 A in the owner's test (battery 25 A / 1 s limit), dashboard error 10 |

History on the scooter (owner statements, never read back): v7.1 -> RC02 -> 600 candidate (2026-10-03) -> 680 test (2026-10-04, cut-out) -> **V8 FINAL 600** (2026-10-04).
Loose copies in `E:\` (outside this folder): `05_V8_SPORT35_REBUILD_NOT_HARDWARE_TESTED.bin` = RC02, `mi5max_farm_v7_1_regenfix.bin` = v7.1, `05_V8_FINAL_CANDIDATE_600_...bin` = final 600, `07_..._680_...bin` = 680 (do not flash).
Rules: the original one-press power button is priority #1 (button test before/after every flash); Claude never flashes or talks to the scooter.
