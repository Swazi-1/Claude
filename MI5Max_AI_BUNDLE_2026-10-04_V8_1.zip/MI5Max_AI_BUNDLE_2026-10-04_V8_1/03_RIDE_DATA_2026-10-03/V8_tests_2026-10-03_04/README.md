# V8 tests (owner, 2026-10-03 / 04)
* `V8_600_first_ride_screen_recording_2026-10-03.mp4`: app Battery info page during the first ride on the 600 build (100 %, 16-17 C). Copy of the owner's `Videos\Rpreplay Final1791060852.mp4`.
* `V8_600_first_ride_screen_recording_ocr.csv`: OCR of every 3rd frame (time s, recognised text). Peak 22.13 A / 1124 W, later 22.31 A; regen only -2.5..-3.2 A (full-charge limit).
* `V8_680_cutoff_app_25.35A_2026-10-04.png`: last app reading before the 680 build cut out uphill (25.35 A, 50.07 V, 1269 W, 98 %, 18 C). Dashboard showed error 10 afterwards (owner). Cause: battery processor 25 A / 1 s latch.
* Owner's button test: 10/10 before (RC02) and after (600); child toggle, charger, 10-min-off all normal.
Analysis: `../../04_FIRMWARE_KNOWLEDGE_BASE/11_POWER_ENVELOPE_SWEEP.md`.
