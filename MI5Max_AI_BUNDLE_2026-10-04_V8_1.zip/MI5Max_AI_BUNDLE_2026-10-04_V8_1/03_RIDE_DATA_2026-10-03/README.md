# Ride data (put the recordings and notes here)

Pre-registered predictions (written before the rides): `../MI5Max_Claude_Handoff_2026-10-02/outputs/RC02_RIDE_OBSERVATIONS/PREREGISTERED_PREDICTIONS_BEFORE_2026-10-03_RIDES.md`
Earlier owner notes: `../MI5Max_Claude_Handoff_2026-10-02/outputs/RC02_RIDE_OBSERVATIONS/`

Name files like `100pct_run1.mp4`, `50pct_run1.mp4`, `30pct_run1.mp4`, `regen_90pct_down1.mp4`, and put your typed notes in `notes.txt`.
Recording reader: `../MI5Max_Claude_Handoff_2026-10-02/work/analyze_ride_recording_2026_10_03.py`.

## What to write down
Once: date/time, air temp, wind, road (same flat stretch and direction every run), firmware on the scooter (v7.1 or RC02), Sport, Strong recovery, tyre pressure, rider weight and load, button check.
Before each run: label, dashboard battery %, rest voltage from the app, battery and controller temperature, clap once at the start of the recording.
During (say aloud): dashboard speed every couple of seconds, "pinned" when throttle is fully down, "released", "dip" when power falls, top speed, "beep" with the speed, any icon or error.
After: top speed, whether it stopped accelerating, rolling voltage/current (negative current = regen), anything different from the 100 % run.
Rules: 2-3 runs per level (100 %, 50 %, 30 %), same stretch/direction/mode/throttle, let it cool between runs, do not start below about 20 % (firmware low-charge cap).
Regen downhill: test at about 95-100 %, 85-90 %, 70-80 %, 50-60 %; write battery % and voltage at the top; speed where braking really starts; current sign; keep a hand on the brake.

## Contents added 2026-10-03 (afternoon)
- `recordings_100pct/`, `recordings_50pct/`: original iPhone .mov screen recordings (hashes inside).
- `RUNS ALL/`: owner's re-encoded .mp4 copies, notes (`Notes app what i wrote.txt`) and two voltage screenshots; includes the new 35% runs. Hashes: `RUNS_ALL_SHA256SUMS.txt`.
- `processed_100pct/`, `processed_50pct/`, `processed_35pct/`: values read from the app frames (CSV).
- Analysis: `MI5Max_Claude_Handoff_2026-10-02/outputs/RC02_RIDE_OBSERVATIONS/2026-10-03_ALL_CHARGE_LEVELS_ANALYSIS.md`.
