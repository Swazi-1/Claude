# Xiaomi Electric Scooter 5 Max project: start here

**Status 2026-10-04: V8 FINAL 600 is on the scooter and works. A V8.1 CANDIDATE (smooth low-battery ramp, no Medium->child trigger, smooth heat fade from 86 C) is built in `01_FIRMWARE/1b_V8_1_CANDIDATE_not_flashed/`, not flashed yet. See `PROJECT_SUMMARY.md` section 9.**

**If you are an AI, read in this order (about 15 minutes gets you to full speed):**
1. `04_FIRMWARE_KNOWLEDGE_BASE/FIRMWARE_AT_A_GLANCE.md`: one page on the whole firmware image (layout, checksums, every build, where each setting lives, what each program does).
2. `PROJECT_SUMMARY.md`: everything found, what is on the scooter, power limits, regen, open items, where things are.
3. `04_FIRMWARE_KNOWLEDGE_BASE/00_README_FOR_AI.md`: question -> file index, conventions, regenerate commands. Then the numbered docs (01-11), catalogs and `data/` as needed.
4. Only if needed: `MI5Max_Claude_Handoff_2026-10-02/` (older work; read its `00_READ_ROOT_PROJECT_SUMMARY_FIRST.md` first).

A ready-to-send bundle (everything above except the big work folder, plus all firmware images and photos) is `MI5Max_AI_BUNDLE_2026-10-04_V8_1.zip`; its `BUNDLE_README.md` lists contents and what is left out.

| Folder | Contents |
|---|---|
| `01_FIRMWARE/` | **`1_CURRENT_ON_SCOOTER_V8_FINAL_600/` (on the scooter)**, `1b_V8_1_CANDIDATE_not_flashed/` (next build, not flashed), `2_ORIGINAL_STOCK/`, `3_OLDER/` (v7.1, RC01, RC02 rollback, 600/640/680 candidates; 640/680 = do not flash). README + SHA256SUMS. |
| `02_MODEL_HANDOFFS/` | Prompts/zips sent to Opus and Sol, and their reports. |
| `03_RIDE_DATA_2026-10-03/` | Ride recordings and processed data (RC02, all charge levels) + `V8_tests_2026-10-03_04/` (600 recording + OCR, 680 cut-out screenshot). |
| `04_FIRMWARE_KNOWLEDGE_BASE/` | AI-oriented map of the whole firmware (both processors). Start with `00_README_FOR_AI.md`. |
| `05_HARDWARE_PHOTOS/` | Deck opened: battery pack, controller box, battery label (13S4P). |
| `MI5Max_Claude_Handoff_2026-10-02/` | Project work folder: scripts, emulator/simulator, evidence, older reports. The name is kept on purpose because scripts use its paths. Its older start files describe the RC02 era; read `00_READ_ROOT_PROJECT_SUMMARY_FIRST.md` there. |
| `MI5Max_AI_BUNDLE_2026-10-04_V8_1.zip` | Ready-to-send package for another AI (see above). |
| `99_ARCHIVE_SNAPSHOTS/` | Cleanup log (what was removed and why), removed-zip manifests, salvaged files, old start page and prompt. |
| `FINDINGS_2026-10-03.md` | Earlier findings page (RC02 era), kept for history. |
| `CLAUDE_PROMPT.txt` | Standard instruction text for a new Claude chat. |
| `CONTRIBUTORS.txt` | Who did what: the owner, Claude (Anthropic), other models consulted, sources and tools. |

Rules that apply everywhere:
* The original one-press power button is priority #1: do the button test before and after every flash.
* Claude never flashes or sends commands to the scooter; the owner does.
* Keep confirmed / strong / likely / unknown separate.
