# MI5Max AI bundle (built 2026-10-04, V8.1 update)

**What is new in this bundle:** V8.1 CANDIDATE (not flashed) in `01_FIRMWARE/1b_V8_1_CANDIDATE_not_flashed/`; docs updated (PROJECT_SUMMARY section 9, 04_FEATURE_CHAINS section 10); corrections: the heat formula constant 0x1FEB8, 'Scooter Temperature' = controller not motor, amps scale 27.2 measured.

Everything an AI needs to understand the firmware of the owner's own Xiaomi Electric Scooter 5 Max and continue the project. **Start with `00_START_HERE.md`, then `04_FIRMWARE_KNOWLEDGE_BASE/FIRMWARE_AT_A_GLANCE.md`, then `PROJECT_SUMMARY.md`.** Paste `CLAUDE_PROMPT.txt` as the first message if you like.

## Included
* `00_START_HERE.md`, `PROJECT_SUMMARY.md` (master summary), `CLAUDE_PROMPT.txt`, `CONTRIBUTORS.txt`, `FINDINGS_2026-10-03.md` (older RC02-era page)
* `01_FIRMWARE/`: all eight firmware images (incl. V8.1 candidate, not flashed) (stock, v7.1, RC01, RC02, V8 FINAL 600 [on the scooter], 640 and 680 [DO NOT FLASH]), READMEs, `SHA256SUMS.txt`
* `04_FIRMWARE_KNOWLEDGE_BASE/`: the full firmware map (docs 00-11, function/RAM/peripheral catalogs, pseudo-code, disassembly, annotations, Python tools; `tools/fw_image_tool.py` needs only the standard library)
* `05_HARDWARE_PHOTOS/`: deck, battery and label photos
* `03_RIDE_DATA_2026-10-03/`: processed CSVs of the rides, the V8 600 OCR CSV, the 680 cut-out screenshot, notes (no videos)
* `02_MODEL_HANDOFFS/`: readme and the Opus child-mode report

## Left out (to keep the bundle small)
* `MI5Max_Claude_Handoff_2026-10-02/` (about 250 MB of older scripts, simulators, evidence and reports; not needed to understand the firmware), ride videos, archive zips, prompts and zips sent to other models.
* Some links in the docs point to those folders; ignore them or ask the owner.

## Using the tools (Python 3.12)
* No setup: `python 04_FIRMWARE_KNOWLEDGE_BASE/tools/fw_image_tool.py info 01_FIRMWARE/1_CURRENT_ON_SCOOTER_V8_FINAL_600/MI5Max_V8_FINAL_600.bin`
* Analysis pipeline (`04_FIRMWARE_KNOWLEDGE_BASE/00_README_FOR_AI.md` section 5) needs `pip install capstone unicorn numpy`. All paths are relative to the bundle folder.

## Rules
Analysis and documentation by default. An AI never flashes and never sends commands to the scooter; the owner does. Build firmware only when the owner explicitly asks, in a new folder, never overwriting. The original one-press power button is priority #1. Do not change the battery processor's protection limits; do not offer Sport caps above 600.

## Contents
See the file list in the zip; `01_FIRMWARE/SHA256SUMS.txt` lists every firmware hash.
