# Hand-offs to other models

**Note 2026-10-04:** most of the zips named below were removed in a duplicate cleanup because every file inside also exists as an ordinary file (hashes unchanged). `../99_ARCHIVE_SNAPSHOTS/removed_zip_manifests/` lists each zip's members and where the identical files are; members that existed nowhere else are in `../99_ARCHIVE_SNAPSHOTS/salvaged_from_removed_zips/`. Still present as zips: the two `MI5Max_ChildMode_*` packages. The unpacked reports in `responses_received/` are untouched.

- `zips_sent_to_models/MI5Max_Opus_Next_Investigation_2026-10-02.zip` (SHA256 c04273a7c390fcab3a9b811b19c89d46ddbfc0a969c02588cbff8b0a7edba55d): the package sent to Opus 5.5 and GPT 6.1 Sol. No flasher, update or fuzz material.
- Prompts (in the project folder): `MI5Max_Claude_Handoff_2026-10-02/CLAUDE_OPUS_NEXT_INVESTIGATION_PROMPT.md` and `SECOND_MODEL_BLIND_CROSSCHECK_PROMPT.md`.
- `responses_received/Claude opus 5.5/` : Opus report ZIP, chat summary, and an unpacked copy (`unz/`).
- `responses_received/GPT 6/` : Sol cross-check report.
- Preserved unchanged copies and comparison: `MI5Max_Claude_Handoff_2026-10-02/inputs/prior_reports/Opus_and_Sol_2026-10-03/` and `.../outputs/10_Latest_Findings_2026-10-02/OPUS_AND_SOL_COMPARISON_2026-10-03.md`.

## From-scratch package for Opus 5.5 (2026-10-03)
- Prompt: `OPUS_FROM_SCRATCH_PROMPT.md`
- ZIP: `zips_sent_to_models/MI5Max_Opus_FromScratch_2026-10-03.zip`, SHA256 3fc32c25ee8055373fad7347335edceab9964c72636707adf8547682234327ec (13.7 MB). Contents: stock, farm v7.1, RC01, RC02 images, LKS32 and BQ769x2 manuals, filtered settings catalog (maintenance/update/provisioning rows removed), ride notes, earlier reports as claims to check, working emulator scripts.
- Left out on purpose (safeguard flags last time): update/maintenance/provisioning command material, parser-guard report, flasher tool, the unfiltered deep settings map.

## From-scratch results returned (2026-10-03)
`responses_received/2026-10-03_from_scratch/` — `opus/` (report + follow-up + scripts), `sol/` (report, coverage, evidence), `original_zips/` with SHA256SUMS. Review: `MI5Max_Claude_Handoff_2026-10-02/outputs/10_Latest_Findings_2026-10-02/FROM_SCRATCH_OPUS_AND_SOL_REVIEW_2026-10-03.md`.

## Child-mode investigation package for Opus 5.5 (2026-10-03)
- Prompt: `OPUS_CHILD_MODE_PROMPT.md` (copy also in Downloads). ZIP: `zips_sent_to_models/MI5Max_ChildMode_Investigation_2026-10-03.zip` (SHA256 afad0d2d5d92bda733f80fb0a5e9403b995d5d1c761dfd56db06a6b2d6013f2d). Focused on the speed-limit profile only; excludes battery-side, protection-chip, update and region material. Returned report not yet received.

## Child-mode OPTIONS package for Opus 5.5 (2026-10-03, research and reasoning only, no firmware files)
- Prompt `OPUS_CHILD_MODE_OPTIONS_PROMPT.md`; ZIP `zips_sent_to_models/MI5Max_ChildMode_Options_2026-10-03.zip` (SHA256 99b0305a1585eb504d0912a31e6fe3f8cec1da8986e73002c1958ec1043ca196). Made after the first child-mode package was flagged. Contains the findings summary only.
